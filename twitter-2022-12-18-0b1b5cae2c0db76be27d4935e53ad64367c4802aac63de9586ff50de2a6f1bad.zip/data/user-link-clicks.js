window.YTD.user_link_clicks.part0 = [
  {
    "userInteractionsData" : {
      "linkClick" : {
        "tweetId" : "1593399133645295616",
        "finalUrl" : "https://www.jeffgeerling.com/",
        "timeStampOfInteraction" : "2022-11-18T22:24:02.275Z"
      }
    }
  },
  {
    "userInteractionsData" : {
      "linkClick" : {
        "tweetId" : "1594440297236566016",
        "finalUrl" : "https://www.amazon.com/HIGOLEPC-PC-Windows-Computer-Ethernet/dp/B0BKRY1YFS?&linkCode=ll1&tag=fanle0d-20&linkId=2581a6574613c73089f2f8acfa4fdb3b&language=en_US&ref_=as_li_ss_tl",
        "timeStampOfInteraction" : "2022-11-21T02:32:36.483Z"
      }
    }
  }
]