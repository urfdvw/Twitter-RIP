window.YTD.ad_online_conversions_attributed.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "attributedOnlineConversions" : {
          "conversions" : [
            {
              "attributedConversionType" : "Session",
              "eventType" : "{}",
              "conversionPlatform" : "Mobile",
              "conversionUrl" : "https://www.theiwise.com/en/easy-ways-stay-warm-throughout-cold?utm_source=twitter2&utm_medium=paid&utm_campaign=create&ly=native_one&mbid=nf7qtbat6i&twclid=23dcpv6y7ueh08owwlwzq4yo4g",
              "advertiserInfo" : {
                "advertiserName" : "theiwise",
                "screenName" : "@theiwise1"
              },
              "conversionTime" : "2022-09-23 20:07:05",
              "additionalParameters" : { }
            },
            {
              "attributedConversionType" : "SiteVisit",
              "eventType" : "{}",
              "conversionPlatform" : "Mobile",
              "conversionUrl" : "https://www.theiwise.com/en/easy-ways-stay-warm-throughout-cold?utm_source=twitter2&utm_medium=paid&utm_campaign=create&ly=native_one&mbid=nf7qtbat6i&twclid=23dcpv6y7ueh08owwlwzq4yo4g",
              "advertiserInfo" : {
                "advertiserName" : "theiwise",
                "screenName" : "@theiwise1"
              },
              "conversionTime" : "2022-09-23 20:07:05",
              "additionalParameters" : { }
            },
            {
              "attributedConversionType" : "Custom",
              "eventType" : "{}",
              "conversionPlatform" : "Mobile",
              "conversionUrl" : "https://www.theiwise.com/en/easy-ways-stay-warm-throughout-cold?ly=native_one",
              "advertiserInfo" : {
                "advertiserName" : "theiwise",
                "screenName" : "@theiwise1"
              },
              "conversionTime" : "2022-09-23 20:07:25",
              "additionalParameters" : { }
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "attributedOnlineConversions" : {
          "conversions" : [
            {
              "attributedConversionType" : "SiteVisit",
              "eventType" : "pageview",
              "conversionPlatform" : "Mobile",
              "conversionUrl" : "https://www.hbomax.com/series/urn:hbo:series:GYsYeoAxKH8LCwgEAAAOR?utm_source=twitter&utm_medium=paid-social&utm_id=cm|27728128|2568609|335442596|170736970&dclid=CKjEyPHfwfoCFUO_nwodw1gNdQ",
              "advertiserInfo" : {
                "advertiserName" : "HBO Max",
                "screenName" : "@hbomax"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-10-02 20:35:22",
              "additionalParameters" : {
                "numItems" : "0"
              }
            },
            {
              "attributedConversionType" : "SiteVisit",
              "eventType" : "pageview",
              "conversionPlatform" : "Mobile",
              "conversionUrl" : "https://www.hbomax.com/series/urn:hbo:series:GYsYeoAxKH8LCwgEAAAOR?utm_source=twitter&utm_medium=paid-social&utm_id=cm|27728128|2568609|335442596|170736970&dclid=CKjEyPHfwfoCFUO_nwodw1gNdQ",
              "advertiserInfo" : {
                "advertiserName" : "HBO Max",
                "screenName" : "@hbomax"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-10-02 20:35:22",
              "additionalParameters" : {
                "numItems" : "0"
              }
            },
            {
              "attributedConversionType" : "SiteVisit",
              "eventType" : "pageview",
              "conversionPlatform" : "Mobile",
              "conversionUrl" : "https://www.hbomax.com/series/urn:hbo:series:GYsYeoAxKH8LCwgEAAAOR?utm_source=twitter&utm_medium=paid-social&utm_id=cm|27728128|2568609|335442596|170736970&dclid=CKjEyPHfwfoCFUO_nwodw1gNdQ",
              "advertiserInfo" : {
                "advertiserName" : "HBO Max",
                "screenName" : "@hbomax"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-10-02 14:25:08",
              "additionalParameters" : {
                "numItems" : "0"
              }
            },
            {
              "attributedConversionType" : "SiteVisit",
              "eventType" : "pageview",
              "conversionPlatform" : "Mobile",
              "conversionUrl" : "https://www.hbomax.com/series/urn:hbo:series:GYsYeoAxKH8LCwgEAAAOR?utm_source=twitter&utm_medium=paid-social&utm_id=cm|27728128|2568609|335442596|170736970&dclid=CKjEyPHfwfoCFUO_nwodw1gNdQ",
              "advertiserInfo" : {
                "advertiserName" : "HBO Max",
                "screenName" : "@hbomax"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-10-02 14:25:08",
              "additionalParameters" : {
                "numItems" : "0"
              }
            },
            {
              "attributedConversionType" : "SiteVisit",
              "eventType" : "pageview",
              "conversionPlatform" : "Mobile",
              "conversionUrl" : "https://www.hbomax.com/series/urn:hbo:series:GYsYeoAxKH8LCwgEAAAOR?utm_source=twitter&utm_medium=paid-social&utm_id=cm|27728128|2568609|335442596|170736970&dclid=CKjEyPHfwfoCFUO_nwodw1gNdQ",
              "advertiserInfo" : {
                "advertiserName" : "HBO Max",
                "screenName" : "@hbomax"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-10-02 21:09:19",
              "additionalParameters" : {
                "numItems" : "0"
              }
            },
            {
              "attributedConversionType" : "Session",
              "eventType" : "pageview",
              "conversionPlatform" : "Mobile",
              "conversionUrl" : "https://www.hbomax.com/series/urn:hbo:series:GYsYeoAxKH8LCwgEAAAOR?utm_source=twitter&utm_medium=paid-social&utm_id=cm|27728128|2568609|335442596|170736970&dclid=CKjEyPHfwfoCFUO_nwodw1gNdQ",
              "advertiserInfo" : {
                "advertiserName" : "HBO Max",
                "screenName" : "@hbomax"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-10-02 21:09:19",
              "additionalParameters" : {
                "numItems" : "0"
              }
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "attributedOnlineConversions" : {
          "conversions" : [
            {
              "attributedConversionType" : "LandingPageView",
              "eventType" : "{}",
              "conversionPlatform" : "Mobile",
              "conversionUrl" : "https://www.on-running.com/en-us/collection/roger?utm_source=twitter&utm_medium=cpc&utm_campaign=CAM_US_Prospecting_Purchase_TWBudget&utm_term=CAM__US_Prospecting_Interests_TWBudget&utm_content=US_THE_ROGER_ClubhouseMid_Carousel&twclid=26b3un27oubo5i88mdra54foql",
              "advertiserInfo" : {
                "advertiserName" : "On",
                "screenName" : "@on_running"
              },
              "conversionTime" : "2022-10-11 11:31:15",
              "additionalParameters" : { }
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "attributedOnlineConversions" : {
          "conversions" : [
            {
              "attributedConversionType" : "Custom",
              "eventType" : "{}",
              "conversionPlatform" : "Mobile",
              "conversionUrl" : "https://www.historictalk.com/en/rare-historic-photos?ly=native_one",
              "advertiserInfo" : {
                "advertiserName" : "HistoricTalk",
                "screenName" : "@historictalk"
              },
              "conversionTime" : "2022-11-13 03:53:02",
              "additionalParameters" : { }
            },
            {
              "attributedConversionType" : "LandingPageView",
              "eventType" : "{}",
              "conversionPlatform" : "Mobile",
              "conversionUrl" : "https://www.historictalk.com/en/rare-historic-photos?utm_source=twitter2&utm_medium=paid&utm_campaign=create&ly=native_one&mbid=nsm640hoah&twclid=27efn8p88xvuk0obta1ox9vtax",
              "advertiserInfo" : {
                "advertiserName" : "HistoricTalk",
                "screenName" : "@historictalk"
              },
              "conversionTime" : "2022-11-13 03:52:21",
              "additionalParameters" : { }
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "attributedOnlineConversions" : {
          "conversions" : [
            {
              "attributedConversionType" : "SiteVisit",
              "eventType" : "{}",
              "conversionPlatform" : "Mobile",
              "conversionUrl" : "https://www.nintendo.com/store/products/cat-quest-switch/",
              "advertiserInfo" : {
                "advertiserName" : "Nintendo of America",
                "screenName" : "@NintendoAmerica"
              },
              "conversionTime" : "2022-11-27 19:42:17",
              "additionalParameters" : { }
            }
          ]
        }
      }
    }
  }
]