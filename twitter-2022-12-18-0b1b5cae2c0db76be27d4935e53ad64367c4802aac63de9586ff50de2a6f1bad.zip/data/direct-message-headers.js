window.YTD.direct_message_headers.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "41765435-1450661638009405445",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1572274495452516363",
            "senderId" : "1450661638009405445",
            "recipientId" : "41765435",
            "createdAt" : "2022-09-20T17:20:25.850Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1572274057328095236",
            "senderId" : "1450661638009405445",
            "recipientId" : "41765435",
            "createdAt" : "2022-09-20T17:18:41.405Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1572268973949087748",
            "senderId" : "41765435",
            "recipientId" : "1450661638009405445",
            "createdAt" : "2022-09-20T16:58:29.450Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1572220238535475206",
            "senderId" : "1450661638009405445",
            "recipientId" : "41765435",
            "createdAt" : "2022-09-20T13:44:50.005Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1572219862369374214",
            "senderId" : "1450661638009405445",
            "recipientId" : "41765435",
            "createdAt" : "2022-09-20T13:43:20.308Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1572219671666884612",
            "senderId" : "1450661638009405445",
            "recipientId" : "41765435",
            "createdAt" : "2022-09-20T13:42:34.842Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1572219507048960004",
            "senderId" : "1450661638009405445",
            "recipientId" : "41765435",
            "createdAt" : "2022-09-20T13:41:55.596Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "4918794850-1450661638009405445",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1483129809043664901",
            "senderId" : "4918794850",
            "recipientId" : "1450661638009405445",
            "createdAt" : "2022-01-17T17:31:16.384Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1483129525500325898",
            "senderId" : "1450661638009405445",
            "recipientId" : "4918794850",
            "createdAt" : "2022-01-17T17:30:08.783Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1014021799359627265-1450661638009405445",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1587256053955428356",
            "senderId" : "1014021799359627265",
            "recipientId" : "1450661638009405445",
            "createdAt" : "2022-11-01T01:31:47.748Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1587255463145623558",
            "senderId" : "1450661638009405445",
            "recipientId" : "1014021799359627265",
            "createdAt" : "2022-11-01T01:29:26.881Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1587255308518592518",
            "senderId" : "1014021799359627265",
            "recipientId" : "1450661638009405445",
            "createdAt" : "2022-11-01T01:28:50.009Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1587254503052550148",
            "senderId" : "1450661638009405445",
            "recipientId" : "1014021799359627265",
            "createdAt" : "2022-11-01T01:25:37.981Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1587254386979475460",
            "senderId" : "1450661638009405445",
            "recipientId" : "1014021799359627265",
            "createdAt" : "2022-11-01T01:25:10.304Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1587254275054395398",
            "senderId" : "1450661638009405445",
            "recipientId" : "1014021799359627265",
            "createdAt" : "2022-11-01T01:24:43.620Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585593327931604998",
            "senderId" : "1450661638009405445",
            "recipientId" : "1014021799359627265",
            "createdAt" : "2022-10-27T11:24:42.964Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585511424767434758",
            "senderId" : "1014021799359627265",
            "recipientId" : "1450661638009405445",
            "createdAt" : "2022-10-27T05:59:15.724Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585096891120893956",
            "senderId" : "1014021799359627265",
            "recipientId" : "1450661638009405445",
            "createdAt" : "2022-10-26T02:32:03.211Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585091373857906692",
            "senderId" : "1450661638009405445",
            "recipientId" : "1014021799359627265",
            "createdAt" : "2022-10-26T02:10:07.803Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585090690417147908",
            "senderId" : "1450661638009405445",
            "recipientId" : "1014021799359627265",
            "createdAt" : "2022-10-26T02:07:24.858Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585089833978023940",
            "senderId" : "1450661638009405445",
            "recipientId" : "1014021799359627265",
            "createdAt" : "2022-10-26T02:04:00.668Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585089537226809348",
            "senderId" : "1450661638009405445",
            "recipientId" : "1014021799359627265",
            "createdAt" : "2022-10-26T02:02:49.902Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585089122594693127",
            "senderId" : "1450661638009405445",
            "recipientId" : "1014021799359627265",
            "createdAt" : "2022-10-26T02:01:11.055Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585088003394994180",
            "senderId" : "1014021799359627265",
            "recipientId" : "1450661638009405445",
            "createdAt" : "2022-10-26T01:56:44.223Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585087700889178122",
            "senderId" : "1014021799359627265",
            "recipientId" : "1450661638009405445",
            "createdAt" : "2022-10-26T01:55:32.088Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585086824703315974",
            "senderId" : "1450661638009405445",
            "recipientId" : "1014021799359627265",
            "createdAt" : "2022-10-26T01:52:03.198Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1585085886307475460",
            "senderId" : "1450661638009405445",
            "recipientId" : "1014021799359627265",
            "createdAt" : "2022-10-26T01:48:19.456Z"
          }
        }
      ]
    }
  }
]