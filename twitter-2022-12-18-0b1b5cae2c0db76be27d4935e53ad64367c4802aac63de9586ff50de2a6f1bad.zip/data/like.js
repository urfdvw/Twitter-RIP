window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1595010263455264768",
      "fullText" : "https://t.co/zuRPMhynPs",
      "expandedUrl" : "https://twitter.com/i/web/status/1595010263455264768"
    }
  },
  {
    "like" : {
      "tweetId" : "1596661675956252677",
      "fullText" : "リクエストイラスト | てるミ #pixiv https://t.co/Ox1mujRs1e \n\n完成しましたー\nリクエストありがとうございました！",
      "expandedUrl" : "https://twitter.com/i/web/status/1596661675956252677"
    }
  },
  {
    "like" : {
      "tweetId" : "1596819140345761794",
      "fullText" : "いろいろ③ | てるミ #pixiv https://t.co/LwiMbcnRKM",
      "expandedUrl" : "https://twitter.com/i/web/status/1596819140345761794"
    }
  },
  {
    "like" : {
      "tweetId" : "1597579258410733569",
      "fullText" : "今日のらくがき https://t.co/9RSU9Kip9E",
      "expandedUrl" : "https://twitter.com/i/web/status/1597579258410733569"
    }
  },
  {
    "like" : {
      "tweetId" : "1597054288895029249",
      "fullText" : "@anne_engineer Fellow Whittie!",
      "expandedUrl" : "https://twitter.com/i/web/status/1597054288895029249"
    }
  },
  {
    "like" : {
      "tweetId" : "1592919408296398851",
      "fullText" : "Big thank you to @PCBWayOfficial for sponsoring The CircuitPython Show!  When you need a printed circuit board, think of @PCBWayOfficial first and make your designs a reality. https://t.co/aGt8bnJP25",
      "expandedUrl" : "https://twitter.com/i/web/status/1592919408296398851"
    }
  },
  {
    "like" : {
      "tweetId" : "1585521881318293507",
      "fullText" : "Na inšpiráciu... Univerzálne modulárne PCB krabičky\nhttps://t.co/upAJ5t1IJE https://t.co/b8dtHYoEGu",
      "expandedUrl" : "https://twitter.com/i/web/status/1585521881318293507"
    }
  },
  {
    "like" : {
      "tweetId" : "1592653558469791744",
      "fullText" : "#Zepir V ... notebook style, all in PCB enclosure (11PCS).\nZero components, just #Raspberrypi Zero+buttons+and SPI IPS display. No IC = Chip crisis resistant, keyboard is scanned by GPIO. Need some adjustments, first version.\nThanks for Patreon support.\nhttps://t.co/V1yvr0EbAe https://t.co/kAeSLVaNEr",
      "expandedUrl" : "https://twitter.com/i/web/status/1592653558469791744"
    }
  },
  {
    "like" : {
      "tweetId" : "1592424852899901441",
      "fullText" : "PCB actuator designed as adhesive kit which works perfect for origami. How would you use this kit?\n\nProject by @BugejaCarl  \nKit Available at https://t.co/9JeNd9um7z\nPCB made by @PCBWayOfficial  \n\n#pcb #pcbway #electronics #diy \n#actuator #maker https://t.co/xpG9StyePo",
      "expandedUrl" : "https://twitter.com/i/web/status/1592424852899901441"
    }
  },
  {
    "like" : {
      "tweetId" : "1592508382292094976",
      "fullText" : "配信でかいたやつ https://t.co/gmTlE77741",
      "expandedUrl" : "https://twitter.com/i/web/status/1592508382292094976"
    }
  },
  {
    "like" : {
      "tweetId" : "1592494859117633536",
      "fullText" : "New version of the Mu code editor has been released!  https://t.co/BzzXiMOrXh",
      "expandedUrl" : "https://twitter.com/i/web/status/1592494859117633536"
    }
  },
  {
    "like" : {
      "tweetId" : "1592174290543284230",
      "fullText" : "News from MakeZine: Pebble Rocks Again: Rebble Hackathon #001 https://t.co/1klU2Z0yxr https://t.co/QoD1MsMANb",
      "expandedUrl" : "https://twitter.com/i/web/status/1592174290543284230"
    }
  },
  {
    "like" : {
      "tweetId" : "1591938203065659392",
      "fullText" : "Sundays don't get much better than this! https://t.co/1mIQciKrHI",
      "expandedUrl" : "https://twitter.com/i/web/status/1591938203065659392"
    }
  },
  {
    "like" : {
      "tweetId" : "1592131424471379968",
      "fullText" : "パンテーラ\n#インティ絵 https://t.co/9Ykc2zIx4x",
      "expandedUrl" : "https://twitter.com/i/web/status/1592131424471379968"
    }
  },
  {
    "like" : {
      "tweetId" : "1591335010661183489",
      "fullText" : "小庭カフェ https://t.co/GV7XahDeHf",
      "expandedUrl" : "https://twitter.com/i/web/status/1591335010661183489"
    }
  },
  {
    "like" : {
      "tweetId" : "1591573885396594688",
      "fullText" : "And itty bitty bread for the proto toast 🍞🍞🍞 https://t.co/1jZftxxR9U",
      "expandedUrl" : "https://twitter.com/i/web/status/1591573885396594688"
    }
  },
  {
    "like" : {
      "tweetId" : "1591751714679697409",
      "fullText" : "We're now on the Fediverse! Follow us at @AsahiLinux@social.treehouse.systems to stay up to date with Asahi Linux news. Progress Report coming up soon!",
      "expandedUrl" : "https://twitter.com/i/web/status/1591751714679697409"
    }
  },
  {
    "like" : {
      "tweetId" : "1591288485272776704",
      "fullText" : "このユニットが欲しい。\nM0ii060載せたい https://t.co/impXtSfwXK",
      "expandedUrl" : "https://twitter.com/i/web/status/1591288485272776704"
    }
  },
  {
    "like" : {
      "tweetId" : "1591474846285766656",
      "fullText" : "Working on Open Book firmware tweaks for folks who built one. UX note: I literally respun the board to enable this interaction. When you press the Lock button, I wanted message directing you to turn the power off. Obviously I had to move the power switch to align with the banner! https://t.co/kUFDYdASR0",
      "expandedUrl" : "https://twitter.com/i/web/status/1591474846285766656"
    }
  },
  {
    "like" : {
      "tweetId" : "1591386379795464192",
      "fullText" : "配信でかいたの https://t.co/SIm6G7rdWO",
      "expandedUrl" : "https://twitter.com/i/web/status/1591386379795464192"
    }
  },
  {
    "like" : {
      "tweetId" : "1499005690353967112",
      "fullText" : "Fully-fledged RP2040 MicroPython simulator in the browser 😍\n\nIncluding REPL, wires, LEDs, buttons, ... 👀\n\nhttps://t.co/nhxwXPCbtN https://t.co/4w0oOkzjY1",
      "expandedUrl" : "https://twitter.com/i/web/status/1499005690353967112"
    }
  },
  {
    "like" : {
      "tweetId" : "1590888408523866115",
      "fullText" : "G4 Cube Pro will not save you! https://t.co/SEIu74WYqB https://t.co/y4gnd5bVxM",
      "expandedUrl" : "https://twitter.com/i/web/status/1590888408523866115"
    }
  },
  {
    "like" : {
      "tweetId" : "1591123304106323969",
      "fullText" : "Today in \"stupid solutions to stupid problems\" - the iOS app to control our TV doesn't work so I deployed a web app running on a @Raspberry_Pi pico w that we can all use. Took 20 mins, ~100 lines of @CircuitPython code. https://t.co/C6eRABRsIQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1591123304106323969"
    }
  },
  {
    "like" : {
      "tweetId" : "1591123313035661313",
      "fullText" : "While I LOVE how quick/cheap it is spin stuff like this up, I really wish the stuff we bought worked like it's supposed to. As a software dev, I get how hard it is to release bug-free software, but this is core functionality from a company with resources.",
      "expandedUrl" : "https://twitter.com/i/web/status/1591123313035661313"
    }
  },
  {
    "like" : {
      "tweetId" : "1591123309986340865",
      "fullText" : "It's an Android TV device, which can take a USB keyboard as input. The pico is running simultaneously as an http server and a keyboard. There is a tiny html file hosted statically for the UI, and there are endpoints for sending keycodes to be \"pressed\".",
      "expandedUrl" : "https://twitter.com/i/web/status/1591123309986340865"
    }
  },
  {
    "like" : {
      "tweetId" : "1590992891790479360",
      "fullText" : "Oh Snap! 3D Printing Snapping Parts Without Breakage https://t.co/uHIrcJkhKb",
      "expandedUrl" : "https://twitter.com/i/web/status/1590992891790479360"
    }
  },
  {
    "like" : {
      "tweetId" : "1590797826669563904",
      "fullText" : "Did you play with it when you were a kid? :) https://t.co/5uWF66TdzN",
      "expandedUrl" : "https://twitter.com/i/web/status/1590797826669563904"
    }
  },
  {
    "like" : {
      "tweetId" : "1590723686453153794",
      "fullText" : "MicroPython slithers its way into the Arduino ecosystem! 🐍 \n\nToday, we're excited to announce the availability of MicroPython firmware for Arduino boards as well as the new Arduino Lab for MicroPython. https://t.co/QM1LvHaEwE",
      "expandedUrl" : "https://twitter.com/i/web/status/1590723686453153794"
    }
  },
  {
    "like" : {
      "tweetId" : "1590663713664925696",
      "fullText" : "カナ https://t.co/qeDdk7VPOO",
      "expandedUrl" : "https://twitter.com/i/web/status/1590663713664925696"
    }
  },
  {
    "like" : {
      "tweetId" : "1590351262977064961",
      "fullText" : "ICYMI Python on Microcontrollers Newsletter: New Hardware, Python 3.12 Alpha, and much more! #CircuitPython #ICYMI @micropython @Raspberry_Pi https://t.co/nU5VnVSgf1",
      "expandedUrl" : "https://twitter.com/i/web/status/1590351262977064961"
    }
  },
  {
    "like" : {
      "tweetId" : "1590245482143838208",
      "fullText" : "How to create the charging particle animation on the OLED screen using #SeeedXIAO? Upir showed us the specific tutorial on @YouTube and by the end of the video, he also tried the same project on @arduino UNO and Arduino MEGA. https://t.co/4uvAPk6Bto https://t.co/5eE5jTFqcV",
      "expandedUrl" : "https://twitter.com/i/web/status/1590245482143838208"
    }
  },
  {
    "like" : {
      "tweetId" : "1590371912538284033",
      "fullText" : "v1 can be made with no soldering. Just order the board at JLCPCB, flash the firmware, and it's ready! I recommend also 3D printing this cute case. https://t.co/wj2C2v3NUg",
      "expandedUrl" : "https://twitter.com/i/web/status/1590371912538284033"
    }
  },
  {
    "like" : {
      "tweetId" : "1590370566732935170",
      "fullText" : "HID Remapper news! We now have custom boards. All the files are up on GitHub if you want to make one. https://t.co/XiTK9S5Yk7 https://t.co/7YQaKz8on7",
      "expandedUrl" : "https://twitter.com/i/web/status/1590370566732935170"
    }
  },
  {
    "like" : {
      "tweetId" : "1590456039102730241",
      "fullText" : "NEW GUIDE: Pico W HTTP Server with CircuitPython #AdafruitLearningSystem Adafruit BlitzCityDIY  https://t.co/Bsc0DEjcKB",
      "expandedUrl" : "https://twitter.com/i/web/status/1590456039102730241"
    }
  },
  {
    "like" : {
      "tweetId" : "1590390120422985728",
      "fullText" : "ユウカー\n#ブルアカ https://t.co/bN7socmRH4",
      "expandedUrl" : "https://twitter.com/i/web/status/1590390120422985728"
    }
  },
  {
    "like" : {
      "tweetId" : "1590362396194795525",
      "fullText" : "ICYMI Python on Microcontrollers Newsletter: New Hardware, Python 3.12 Alpha, and much more! #CircuitPython #ICYMI micropython Raspberry_Pi  https://t.co/aTbM93hhLz",
      "expandedUrl" : "https://twitter.com/i/web/status/1590362396194795525"
    }
  },
  {
    "like" : {
      "tweetId" : "1590100163107860480",
      "fullText" : "#Picomputer in \"notebook\" style. All parts of case are made in PCB factory.\nProject like this exists thanks to my patreon supporters\nhttps://t.co/V1yvr0VeCe\nMore details about PCB parts in video:\nhttps://t.co/rKDWpjgd9U https://t.co/aX4Dtga50D",
      "expandedUrl" : "https://twitter.com/i/web/status/1590100163107860480"
    }
  },
  {
    "like" : {
      "tweetId" : "1589998330285019138",
      "fullText" : "https://t.co/3pNUe77k6g",
      "expandedUrl" : "https://twitter.com/i/web/status/1589998330285019138"
    }
  },
  {
    "like" : {
      "tweetId" : "1590117106473127938",
      "fullText" : "https://t.co/N8Gbvqcvv9",
      "expandedUrl" : "https://twitter.com/i/web/status/1590117106473127938"
    }
  },
  {
    "like" : {
      "tweetId" : "1590067337465835520",
      "fullText" : "Looks very promising! https://t.co/PHwcPf4q2W",
      "expandedUrl" : "https://twitter.com/i/web/status/1590067337465835520"
    }
  },
  {
    "like" : {
      "tweetId" : "1589812227900846080",
      "fullText" : "新しい名刺です🎮 https://t.co/6ss3Kl5rVa",
      "expandedUrl" : "https://twitter.com/i/web/status/1589812227900846080"
    }
  },
  {
    "like" : {
      "tweetId" : "1589807646156414977",
      "fullText" : "Frequency testing. Also turns out mems microphones already being biased means I can’t use one in the same circuit as the headphone jack. But I think having a built in mic is not necessary. I felt weird shouting into the cartridge slot. https://t.co/p0A1r4FyUt",
      "expandedUrl" : "https://twitter.com/i/web/status/1589807646156414977"
    }
  },
  {
    "like" : {
      "tweetId" : "1589807806156529664",
      "fullText" : "After fixing all the issues I found during my alpha test, I want to announce that #CircuitPython Online IDE is now beta! The pull request is merged and the new help document is also there. Try it out: https://t.co/MbMYEkPBGE and see the repo: https://t.co/hJ0iydRwtx",
      "expandedUrl" : "https://twitter.com/i/web/status/1589807806156529664"
    }
  },
  {
    "like" : {
      "tweetId" : "1589728834554691584",
      "fullText" : "Guess I should say thank you to @JLCPCB for giving newbies like me a way to create PCB’s. Designed entirely with EasyEDA with components from @digikey and @adafruit 16 step switches &amp; LED’s (32 total) only use 4 GPIO pins on the Pico. Still have 10 free GPIO! https://t.co/y6aL1G6W3H",
      "expandedUrl" : "https://twitter.com/i/web/status/1589728834554691584"
    }
  },
  {
    "like" : {
      "tweetId" : "1587087080680673280",
      "fullText" : "🧙‍♀️ https://t.co/ObPpUCVlQQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1587087080680673280"
    }
  },
  {
    "like" : {
      "tweetId" : "1589355015109750784",
      "fullText" : "Usb nugget is ready to be hacking #supercon2022 #supercon6 #supercon #usbnugget https://t.co/nlFwGYUhKZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1589355015109750784"
    }
  },
  {
    "like" : {
      "tweetId" : "1589379349048066048",
      "fullText" : "I was at @OrlMakerFaire https://t.co/nsOgkaAdnq",
      "expandedUrl" : "https://twitter.com/i/web/status/1589379349048066048"
    }
  },
  {
    "like" : {
      "tweetId" : "1589312621765091328",
      "fullText" : ".@Olimex's small, ATtiny85-powered ultrasonic levitation kit includes everything you ned to build a standing sound wave generator. https://t.co/kXl4yVzzKt",
      "expandedUrl" : "https://twitter.com/i/web/status/1589312621765091328"
    }
  },
  {
    "like" : {
      "tweetId" : "1589288929601134596",
      "fullText" : "Mini Ultrasonic Levitation Kit is an Exercise in Sound Minimalist Design https://t.co/OhX84mN4ul",
      "expandedUrl" : "https://twitter.com/i/web/status/1589288929601134596"
    }
  },
  {
    "like" : {
      "tweetId" : "1589028671826063360",
      "fullText" : "Aaaahhhh may the force pcb with you, always https://t.co/PPcl2Rte7F",
      "expandedUrl" : "https://twitter.com/i/web/status/1589028671826063360"
    }
  },
  {
    "like" : {
      "tweetId" : "1576625598163652610",
      "fullText" : "A cyberdeck that fits on your keychain: https://t.co/jlg2hOJh1t https://t.co/9tec9efDyc",
      "expandedUrl" : "https://twitter.com/i/web/status/1576625598163652610"
    }
  },
  {
    "like" : {
      "tweetId" : "1576335900178382849",
      "fullText" : "Apple Extended Keyboard III with Touchbar. https://t.co/DG3yBS43g3",
      "expandedUrl" : "https://twitter.com/i/web/status/1576335900178382849"
    }
  },
  {
    "like" : {
      "tweetId" : "1576310272029265920",
      "fullText" : "The iPod 850 eschewed colour, backlighting, and almost the very concept of a display in order to concentrate on what was most important in a music player — vibes. https://t.co/E1t9rRAtL0",
      "expandedUrl" : "https://twitter.com/i/web/status/1576310272029265920"
    }
  },
  {
    "like" : {
      "tweetId" : "1576106368510984193",
      "fullText" : "It’s alive!!! https://t.co/e1oaWEwwNw",
      "expandedUrl" : "https://twitter.com/i/web/status/1576106368510984193"
    }
  },
  {
    "like" : {
      "tweetId" : "1576015127014363139",
      "fullText" : "L and R buttons need adjustment and footprint change. Header pin location interferences with case also. But… I’d say 85-90% first try!? https://t.co/JNWaIlH1du",
      "expandedUrl" : "https://twitter.com/i/web/status/1576015127014363139"
    }
  },
  {
    "like" : {
      "tweetId" : "1576056947140624385",
      "fullText" : "@River___Wang Make it fit. :) https://t.co/z4KKfvsb6G",
      "expandedUrl" : "https://twitter.com/i/web/status/1576056947140624385"
    }
  },
  {
    "like" : {
      "tweetId" : "1575972587666305024",
      "fullText" : "The case of the #CircuitPython keyboard is sent to the factory. Pray that the dimensions will match. https://t.co/SJX5kFwEZz",
      "expandedUrl" : "https://twitter.com/i/web/status/1575972587666305024"
    }
  },
  {
    "like" : {
      "tweetId" : "1575839862669746177",
      "fullText" : "Shun Ikejima's Egg is a 3D-printed, ultra-compact ortholinear @Raspberry_Pi Zero W laptop: https://t.co/Dj66Rs6Dkf https://t.co/oJp31YB3j8",
      "expandedUrl" : "https://twitter.com/i/web/status/1575839862669746177"
    }
  },
  {
    "like" : {
      "tweetId" : "1575872301043970053",
      "fullText" : "Today I am a very sleepy and grateful new dad 🐣\n\nSo far the craziest thing to me is that her fingernails are the exact right length?? Like are we all born with perfect fingernails???",
      "expandedUrl" : "https://twitter.com/i/web/status/1575872301043970053"
    }
  },
  {
    "like" : {
      "tweetId" : "1575501786781462529",
      "fullText" : "10/2の、かんたん似顔絵(500円)🎀\n\nむいさんにサンプルのモデルをしてもらいました‼️こんな感じでハガキにペンで描く予定です！\n\n描いて欲しい方はなご村に声かけてください🌱\n\n(机がないのですが頑張って描きます！それでもいい人向け…) https://t.co/6tm87xZzbv",
      "expandedUrl" : "https://twitter.com/i/web/status/1575501786781462529"
    }
  },
  {
    "like" : {
      "tweetId" : "1575580410591215616",
      "fullText" : "JOHN PARK'S WORKSHOP LIVE 9/29/22 https://t.co/OHkA1ctjeo",
      "expandedUrl" : "https://twitter.com/i/web/status/1575580410591215616"
    }
  },
  {
    "like" : {
      "tweetId" : "1575518870583988224",
      "fullText" : "I got RTed by @Collabora???????? https://t.co/qeDBWAYVfW",
      "expandedUrl" : "https://twitter.com/i/web/status/1575518870583988224"
    }
  },
  {
    "like" : {
      "tweetId" : "1575428910585634816",
      "fullText" : "My flock box. Custom coded with #circuitpython doing exactly what I designed it for. https://t.co/KwrnnH2tQb",
      "expandedUrl" : "https://twitter.com/i/web/status/1575428910585634816"
    }
  },
  {
    "like" : {
      "tweetId" : "1575185610029289473",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1575185610029289473"
    }
  },
  {
    "like" : {
      "tweetId" : "1575153373384478724",
      "fullText" : "ICYMI Python on Microcontrollers Newsletter: Retrofitting old computers, Pinguin and much more! #CircuitPython #ICYMI @micropython @Raspberry_Pi https://t.co/ufefWn0Vja",
      "expandedUrl" : "https://twitter.com/i/web/status/1575153373384478724"
    }
  },
  {
    "like" : {
      "tweetId" : "1575451690400030720",
      "fullText" : "Apple Adjustable PowerBook. https://t.co/kXYsaoZm1c",
      "expandedUrl" : "https://twitter.com/i/web/status/1575451690400030720"
    }
  },
  {
    "like" : {
      "tweetId" : "1575343067892051968",
      "fullText" : "✨🎊🎉IT WORKS!!!!🎉🎊✨\n🦀🐧🍎🔻🧊🇼👩🔥🦊⚙️\n\nGNOME runs!! Firefox works!! You can watch YouTube, play Neverball, run KDE apps, and more!! No crashes!!!🎉🎉\n\nOn a native Linux GPU driver for Apple M1!!🚀\n\nCheck out the mini stream where I show it off!!!\n▶️https://t.co/g0R1JZI6Pe",
      "expandedUrl" : "https://twitter.com/i/web/status/1575343067892051968"
    }
  },
  {
    "like" : {
      "tweetId" : "1575255653878210560",
      "fullText" : "Congrats to @River___Wang's Circuit Python Online IDE for getting highlighted in this weeks Adafruit newsletter. https://t.co/IGpbyLnzkX  Looks great!",
      "expandedUrl" : "https://twitter.com/i/web/status/1575255653878210560"
    }
  },
  {
    "like" : {
      "tweetId" : "1575152814841397248",
      "fullText" : "💫 We got this far!!!! 💫\n\nKDE gets to the desktop (XWayland problems), GNOME actually launches all the way (but isn't stable), and Weston works great and I can run 3D apps and @Inochi2D! 🎉\n\nThat's it for today, I'll get some dinner and take a look at the stability problem✨ https://t.co/GrbWGcSZMy",
      "expandedUrl" : "https://twitter.com/i/web/status/1575152814841397248"
    }
  },
  {
    "like" : {
      "tweetId" : "1575044025698045952",
      "fullText" : "🥳🥳T-Embed Presold in LILYGO store.\nhttps://t.co/elW17tkff0 https://t.co/8xg1TiVGet",
      "expandedUrl" : "https://twitter.com/i/web/status/1575044025698045952"
    }
  },
  {
    "like" : {
      "tweetId" : "1574778674100211712",
      "fullText" : "やっと…やっとGPD WinにLinuxをインストールする事が出来た！\nUSBメモリとかSDカードをたくさん試した！\n\nあとはsshの設定をしていつもの流れにw\n\nポメラ触ってたからか、異常なほど高速に感じるね、GPD Win。\n\nこれは開発用に使うので、特に実験はしないかも！(^^) https://t.co/R96AjMhBd7",
      "expandedUrl" : "https://twitter.com/i/web/status/1574778674100211712"
    }
  },
  {
    "like" : {
      "tweetId" : "1574946659003310080",
      "fullText" : "らくがき https://t.co/yeezbu8HWN",
      "expandedUrl" : "https://twitter.com/i/web/status/1574946659003310080"
    }
  },
  {
    "like" : {
      "tweetId" : "1574795794225700864",
      "fullText" : "🤣👇 https://t.co/xh0Tf6HMDA",
      "expandedUrl" : "https://twitter.com/i/web/status/1574795794225700864"
    }
  },
  {
    "like" : {
      "tweetId" : "1574647542125469696",
      "fullText" : "I'm preparing a little surprise for the talk too~! ✨✨ https://t.co/ZVHPaS7fK8",
      "expandedUrl" : "https://twitter.com/i/web/status/1574647542125469696"
    }
  },
  {
    "like" : {
      "tweetId" : "1574736717130567680",
      "fullText" : "@LinaAsahi I am still in so much awe that you are getting this working somehow it’s arcane witchcraft it’s cyberpunk technology it’s amazing and it’s happening NOW it’s incredible",
      "expandedUrl" : "https://twitter.com/i/web/status/1574736717130567680"
    }
  },
  {
    "like" : {
      "tweetId" : "1574682152620302339",
      "fullText" : "💫 M1 GPU driver dev stream! 💫\n\nWe got the cube!!!! So next up... can we run a real desktop environment???? 💻\n\nThere are a few bugs to fix first, but it shouldn't take long to do that! And then... will it work?! ✨\n\n🕒 Sep 28th at 15:00 JST / 6:00 UTC\n▶️ https://t.co/pNk4I0rV25 https://t.co/OWtA13lGrS",
      "expandedUrl" : "https://twitter.com/i/web/status/1574682152620302339"
    }
  },
  {
    "like" : {
      "tweetId" : "1574552192786214912",
      "fullText" : "Ehh.. excuse me here just gonna… yeah um.. I kinda need to eehhh just ummm borrow… these gonna…just yeah… scoop them up real quick here. I’m just gonna… use these… just. They are mine now. https://t.co/v8EOdNTeJj",
      "expandedUrl" : "https://twitter.com/i/web/status/1574552192786214912"
    }
  },
  {
    "like" : {
      "tweetId" : "1573754957110673411",
      "fullText" : "⭐ANAVI Macro Pad 10 is a mini #mechanicalkeyboard with @seeedstudio XIAO, #RaspberryPi RP2040 MCU, RGB LED, USB-C and hot-Kailh swap sockets for Gateron and any other Cherry MX compatible switches\n📦Coming soon at @crowd_supply https://t.co/gIMTaJx04I https://t.co/0ktS2htpTq",
      "expandedUrl" : "https://twitter.com/i/web/status/1573754957110673411"
    }
  },
  {
    "like" : {
      "tweetId" : "1573975603002343425",
      "fullText" : "Trackball Macropad\nKeyboard: #su120 &amp; meishi trackball module\nSwitch: Alpaca\nKeycap: KAT Space Cadet\n#KEEB_PD #KEEB_PD_R115 #自作キーボード #俺キー #mechanicalkeyboard https://t.co/djtHwQeeid",
      "expandedUrl" : "https://twitter.com/i/web/status/1573975603002343425"
    }
  },
  {
    "like" : {
      "tweetId" : "1574161580563931136",
      "fullText" : "Happy to report that the brand-new ⁦@FrameworkPuter⁩ ethernet expansion card works flawlessly under Fedora Linux !!! I’ve tested at gig speeds and had no issues. https://t.co/HhN5R1e8W7",
      "expandedUrl" : "https://twitter.com/i/web/status/1574161580563931136"
    }
  },
  {
    "like" : {
      "tweetId" : "1574203612951367681",
      "fullText" : "GSM F88 Phone Watch (2008) https://t.co/6niqghhJUA",
      "expandedUrl" : "https://twitter.com/i/web/status/1574203612951367681"
    }
  },
  {
    "like" : {
      "tweetId" : "1574097573161246722",
      "fullText" : "AI08 8-Ch Capacitive Touch Controller Dev board. Soon to be made at @AislerHQ \n\nNice appnote about capacitive touch by Microchip: \n(Or search for AN2934)\nhttps://t.co/oajV1AHrp1 https://t.co/TS6lYZ7mpP",
      "expandedUrl" : "https://twitter.com/i/web/status/1574097573161246722"
    }
  },
  {
    "like" : {
      "tweetId" : "1574086945185026048",
      "fullText" : "らくがき https://t.co/uZghpLLEmf",
      "expandedUrl" : "https://twitter.com/i/web/status/1574086945185026048"
    }
  },
  {
    "like" : {
      "tweetId" : "1573890042615169024",
      "fullText" : "Nintendo Gamma Boy™ https://t.co/vqinbVa3tC",
      "expandedUrl" : "https://twitter.com/i/web/status/1573890042615169024"
    }
  },
  {
    "like" : {
      "tweetId" : "1573975610019532800",
      "fullText" : "There will be a meeting for procrastinators at 11am tomorrow in discord. It will likely be postponed until next week and then again to 4 years from now.",
      "expandedUrl" : "https://twitter.com/i/web/status/1573975610019532800"
    }
  },
  {
    "like" : {
      "tweetId" : "1573944236067602433",
      "fullText" : "太眉かわいいですよね https://t.co/ioYiDnDS8d",
      "expandedUrl" : "https://twitter.com/i/web/status/1573944236067602433"
    }
  },
  {
    "like" : {
      "tweetId" : "1573937501445804036",
      "fullText" : "@River___Wang Looks very cool! Can’t wait to see what it’s like finished and all dressed up.",
      "expandedUrl" : "https://twitter.com/i/web/status/1573937501445804036"
    }
  },
  {
    "like" : {
      "tweetId" : "1573805136178454528",
      "fullText" : "Loving the look of @decryption's new Apple Watch Ultra with that gorgeous greyscale legacy styled CRT. https://t.co/Lnie2y6Rwd",
      "expandedUrl" : "https://twitter.com/i/web/status/1573805136178454528"
    }
  },
  {
    "like" : {
      "tweetId" : "1573548844138102784",
      "fullText" : "#三連休はフォロワーさんが増える \nｿﾜｿﾜ https://t.co/8yefkz6hL3",
      "expandedUrl" : "https://twitter.com/i/web/status/1573548844138102784"
    }
  },
  {
    "like" : {
      "tweetId" : "1573535156178407429",
      "fullText" : "Apple iPod cube. https://t.co/FJAqwFd1Y5",
      "expandedUrl" : "https://twitter.com/i/web/status/1573535156178407429"
    }
  },
  {
    "like" : {
      "tweetId" : "1573764603103813632",
      "fullText" : "All keys are working now. The plate is sent to the factory. Now, it's time to make a case. #CircuitPython #MechanicalKeyboard https://t.co/Z3J1eaVp8u",
      "expandedUrl" : "https://twitter.com/i/web/status/1573764603103813632"
    }
  },
  {
    "like" : {
      "tweetId" : "1573488917529108482",
      "fullText" : "It’s official since I submitted the board for OSHW certification. It’s called the TR-Cowbell. Next batch of PCBs will have that name on it. My name is going on the back… in Papyrus font. #circuitpython https://t.co/bFOLMp57dI",
      "expandedUrl" : "https://twitter.com/i/web/status/1573488917529108482"
    }
  },
  {
    "like" : {
      "tweetId" : "1573357285786931200",
      "fullText" : "All wheel drive https://t.co/LqQwslF87F",
      "expandedUrl" : "https://twitter.com/i/web/status/1573357285786931200"
    }
  },
  {
    "like" : {
      "tweetId" : "1573401973260681216",
      "fullText" : "We're stoked to finally release our \"official\" Learn to Surface Mount Solder kit, the SMT Garden!  It features a practice area, a cool blinky circuit, and artwork by @Leeborg_ !  Read on to learn more... 🧵 https://t.co/5KV8vVNCzo",
      "expandedUrl" : "https://twitter.com/i/web/status/1573401973260681216"
    }
  },
  {
    "like" : {
      "tweetId" : "1573014780495167488",
      "fullText" : "NEW GUIDE: Adafruit TCA8418 Keypad Matrix and GPIO Expander Breakout #AdafruitLearningSystem #Adafruit @adafruit @blitzcitydiy https://t.co/OYse91BFGr",
      "expandedUrl" : "https://twitter.com/i/web/status/1573014780495167488"
    }
  },
  {
    "like" : {
      "tweetId" : "1573069378421231618",
      "fullText" : "Another look at how we run in-class challenges during #BCPhysComp. Mishal’s engineering and CircuitPython coding skills earn a snack! https://t.co/MkmLK2vqe4",
      "expandedUrl" : "https://twitter.com/i/web/status/1573069378421231618"
    }
  },
  {
    "like" : {
      "tweetId" : "1573260216426430465",
      "fullText" : "Small demo video for the weekend~ (Showing Korean and English Layout and some debug options) Enjoy! #PolyKeyboard #MechanicalKeyboard https://t.co/ccoFraddJK",
      "expandedUrl" : "https://twitter.com/i/web/status/1573260216426430465"
    }
  },
  {
    "like" : {
      "tweetId" : "1573259440425684992",
      "fullText" : "https://t.co/02sGNib6Ie",
      "expandedUrl" : "https://twitter.com/i/web/status/1573259440425684992"
    }
  },
  {
    "like" : {
      "tweetId" : "1573021501137338368",
      "fullText" : "NEW GUIDE: Adafruit TCA8418 Keypad Matrix and GPIO Expander Breakout #AdafruitLearningSystem #Adafruit adafruit blitzcitydiy  https://t.co/q2xCNTDQgV",
      "expandedUrl" : "https://twitter.com/i/web/status/1573021501137338368"
    }
  },
  {
    "like" : {
      "tweetId" : "1573055775077183488",
      "fullText" : "https://t.co/tcJx66y8vE",
      "expandedUrl" : "https://twitter.com/i/web/status/1573055775077183488"
    }
  },
  {
    "like" : {
      "tweetId" : "1572826468828467200",
      "fullText" : "@River___Wang Have no idea what the actual Hz are. I just know it’s capable of going far faster than I’ll probably ever need. I no longer have any concern about i2c expander slowing down response.",
      "expandedUrl" : "https://twitter.com/i/web/status/1572826468828467200"
    }
  },
  {
    "like" : {
      "tweetId" : "1572653018721443841",
      "fullText" : "@River___Wang We can't wait 🎉",
      "expandedUrl" : "https://twitter.com/i/web/status/1572653018721443841"
    }
  },
  {
    "like" : {
      "tweetId" : "1572595267966324736",
      "fullText" : "How to build Raspberry Pi Pico programs with no software installation #RaspberryPi @petewarden @Raspberry_Pi https://t.co/TglICjaiO6",
      "expandedUrl" : "https://twitter.com/i/web/status/1572595267966324736"
    }
  },
  {
    "like" : {
      "tweetId" : "1572381177629265921",
      "fullText" : ".@MarkRober built some machines to beat unscrupulous arcade owners at their own games: https://t.co/g5DSLKQP7I https://t.co/mCJThLw7EO",
      "expandedUrl" : "https://twitter.com/i/web/status/1572381177629265921"
    }
  },
  {
    "like" : {
      "tweetId" : "1572430693392596995",
      "fullText" : "🎉🎉🎉 CircuitPython Online IDE is going to be shown on Philly Maker Faire! @phlmake #CircuitPython",
      "expandedUrl" : "https://twitter.com/i/web/status/1572430693392596995"
    }
  },
  {
    "like" : {
      "tweetId" : "1552745938162270208",
      "fullText" : "a Customizable Macropad to Make Anyone’s Tail Wag https://t.co/FDX8rpxkJH",
      "expandedUrl" : "https://twitter.com/i/web/status/1552745938162270208"
    }
  },
  {
    "like" : {
      "tweetId" : "1572016859402338304",
      "fullText" : "Curious how fast an i2c expander chip can work? I was. Pretty sure it’ll do 64th stepping it’s that fast.  Yeah that’s actually sequentially flashing. No worries for 16th beat stepping. https://t.co/GnS9xC2lIS",
      "expandedUrl" : "https://twitter.com/i/web/status/1572016859402338304"
    }
  },
  {
    "like" : {
      "tweetId" : "1572261154193383424",
      "fullText" : "Galdeano is a DIY handheld computer with a Python OS: https://t.co/JAAxl7qnsA https://t.co/haCFrRPF87",
      "expandedUrl" : "https://twitter.com/i/web/status/1572261154193383424"
    }
  },
  {
    "like" : {
      "tweetId" : "1572254239384125441",
      "fullText" : "#MicroPython MP3 Player https://t.co/b9GiVbzkAn",
      "expandedUrl" : "https://twitter.com/i/web/status/1572254239384125441"
    }
  },
  {
    "like" : {
      "tweetId" : "1572220543239323649",
      "fullText" : "https://t.co/7WLQSEtpVv",
      "expandedUrl" : "https://twitter.com/i/web/status/1572220543239323649"
    }
  },
  {
    "like" : {
      "tweetId" : "1571546018067480576",
      "fullText" : "@River___Wang https://t.co/MaeVXS7Gyx",
      "expandedUrl" : "https://twitter.com/i/web/status/1571546018067480576"
    }
  },
  {
    "like" : {
      "tweetId" : "1571939742564093953",
      "fullText" : "https://t.co/36JhbgwHmT",
      "expandedUrl" : "https://twitter.com/i/web/status/1571939742564093953"
    }
  },
  {
    "like" : {
      "tweetId" : "1571562507004940288",
      "fullText" : "What if I actually wrote a book about Rust Linux driver development or something like that?\n\nA really cute book!!!! ✨✨\n\nSome day... maybe... ????",
      "expandedUrl" : "https://twitter.com/i/web/status/1571562507004940288"
    }
  },
  {
    "like" : {
      "tweetId" : "1571808821785362433",
      "fullText" : "Today marks 10 years since Apple's iOS 6 was released! https://t.co/GXevyUcjhU",
      "expandedUrl" : "https://twitter.com/i/web/status/1571808821785362433"
    }
  },
  {
    "like" : {
      "tweetId" : "1571716053226639360",
      "fullText" : "Gloomy sky https://t.co/DWYUxiqDZu",
      "expandedUrl" : "https://twitter.com/i/web/status/1571716053226639360"
    }
  },
  {
    "like" : {
      "tweetId" : "1571904894252253185",
      "fullText" : "Day 100!  #100DaysOfHomeLab \n\n🎉 We did it!\n\nIt's hard to believe that this challenge started 100 days ago.  Still forever grateful for those in this video and all those who joined.  This isn't the end, for some it's just the beginning. \n\n🪞 Reflecting on my journey\n\n Thank you! https://t.co/XpNiTjAnCv",
      "expandedUrl" : "https://twitter.com/i/web/status/1571904894252253185"
    }
  },
  {
    "like" : {
      "tweetId" : "1572029170510888961",
      "fullText" : "Minitel videotex online service (1982) https://t.co/qa9oNV9j0R",
      "expandedUrl" : "https://twitter.com/i/web/status/1572029170510888961"
    }
  },
  {
    "like" : {
      "tweetId" : "1571862081636536321",
      "fullText" : "Don't miss today's episode with @theavalkyrie! We chat about Winterbloom's CircuitPython powered products including Sol and The Big Honking Button.  Listen or subscribe: https://t.co/aQG35b0pFv",
      "expandedUrl" : "https://twitter.com/i/web/status/1571862081636536321"
    }
  },
  {
    "like" : {
      "tweetId" : "1571849120716931080",
      "fullText" : ".@Intel Becomes First Major Corporate Backer To #Krita #OpenSource Digital Painting Program\n\nhttps://t.co/7Ddn7OGRAf",
      "expandedUrl" : "https://twitter.com/i/web/status/1571849120716931080"
    }
  },
  {
    "like" : {
      "tweetId" : "1571740922421059587",
      "fullText" : "https://t.co/A4Jf7maZe2",
      "expandedUrl" : "https://twitter.com/i/web/status/1571740922421059587"
    }
  },
  {
    "like" : {
      "tweetId" : "1571958762231189504",
      "fullText" : "iOS 6: Released September 19, 2012 https://t.co/zDL4kyNUYy",
      "expandedUrl" : "https://twitter.com/i/web/status/1571958762231189504"
    }
  },
  {
    "like" : {
      "tweetId" : "1571994968339746819",
      "fullText" : "Two features that I have being promised for so long are finally added to CircuitPython Online IDE. One is the file modification indicator. The other is the serial mode indicator showing whether the microcontroller is in REPL or running script. #CircuitPython https://t.co/219zf971ZS",
      "expandedUrl" : "https://twitter.com/i/web/status/1571994968339746819"
    }
  },
  {
    "like" : {
      "tweetId" : "1572002884115664900",
      "fullText" : "@River___Wang Ohh pretty. No idea what it means but if you’re happy then it’s probably a really good thing.",
      "expandedUrl" : "https://twitter.com/i/web/status/1572002884115664900"
    }
  },
  {
    "like" : {
      "tweetId" : "1571967551537836035",
      "fullText" : "So it was just a case of half the pinouts being backwards on the i2c chips due to a horrible footprint mistake. Fixed in software. Success. https://t.co/hnuC46Z8ov",
      "expandedUrl" : "https://twitter.com/i/web/status/1571967551537836035"
    }
  },
  {
    "like" : {
      "tweetId" : "1571382259914928128",
      "fullText" : "ここ数日は雨と台風で荒れ模様の空ですね🌀\nお家にいる方も外出されている方も、ご安全に！🦺 https://t.co/CZ5fKlDOCp",
      "expandedUrl" : "https://twitter.com/i/web/status/1571382259914928128"
    }
  },
  {
    "like" : {
      "tweetId" : "1571513620366000134",
      "fullText" : "Purple Owl is a 60% mechanical keyboard powered by @SeeedStudio's XIAO RP2040: https://t.co/5cuW1TGKeD https://t.co/9liWJTqLzA",
      "expandedUrl" : "https://twitter.com/i/web/status/1571513620366000134"
    }
  },
  {
    "like" : {
      "tweetId" : "1571710422985875456",
      "fullText" : "#絵柄が好みって人にフォローされたい \nよかったら！！！かわいいが大好きです！ https://t.co/TPurlQ6xVg",
      "expandedUrl" : "https://twitter.com/i/web/status/1571710422985875456"
    }
  },
  {
    "like" : {
      "tweetId" : "1571273048526921728",
      "fullText" : "DIY Haptic-Enabled VR Gun Hits All The Targets https://t.co/8t4933KYwm",
      "expandedUrl" : "https://twitter.com/i/web/status/1571273048526921728"
    }
  },
  {
    "like" : {
      "tweetId" : "1571318923643199488",
      "fullText" : "スメール旅行楽しかった https://t.co/7zxFXVJlB6",
      "expandedUrl" : "https://twitter.com/i/web/status/1571318923643199488"
    }
  },
  {
    "like" : {
      "tweetId" : "1571227496892153856",
      "fullText" : "秋と猫日和🍁\n#イラスト https://t.co/09t1IHgYRX",
      "expandedUrl" : "https://twitter.com/i/web/status/1571227496892153856"
    }
  },
  {
    "like" : {
      "tweetId" : "1571378954325594115",
      "fullText" : "@River___Wang I don't understand how I missed this information. Now watching: https://t.co/QGuU1EvIIH\n\nPossible explanation is that there was no #teensy 4.1 available, until PJRC made 4.1 with or without ethernet.\n\nAnd I am already using PyUSB for my Buzzz collection:\nhttps://t.co/LlO3uuX9sf",
      "expandedUrl" : "https://twitter.com/i/web/status/1571378954325594115"
    }
  },
  {
    "like" : {
      "tweetId" : "1571153310752862208",
      "fullText" : "@River___Wang Wait, what? Great, I need to try that.\n\nI am interested in:\n* Transparent passthrough but adding a little bit of mouse/keyboard activity when there is none\n* Reading odd usb device like Buzzz or joystics and converting that to more usual HID\n* Pranks in changing the input",
      "expandedUrl" : "https://twitter.com/i/web/status/1571153310752862208"
    }
  },
  {
    "like" : {
      "tweetId" : "1571151590282919936",
      "fullText" : "Motiviert durch @davedarko auf der #MakerFaireHannover mal wieder ein altes Projekt hervorgeholt und weiter gemacht. Bin mal gespannt wie weit ich dieses WE komme. https://t.co/glnhh1Jvfq",
      "expandedUrl" : "https://twitter.com/i/web/status/1571151590282919936"
    }
  },
  {
    "like" : {
      "tweetId" : "1571084045391388673",
      "fullText" : "Who remembers when Windows Phones were still a thing? https://t.co/5g77dzpwdg",
      "expandedUrl" : "https://twitter.com/i/web/status/1571084045391388673"
    }
  },
  {
    "like" : {
      "tweetId" : "1571188799706726401",
      "fullText" : "A strange game pad. https://t.co/w8FrEYoLlN",
      "expandedUrl" : "https://twitter.com/i/web/status/1571188799706726401"
    }
  },
  {
    "like" : {
      "tweetId" : "1571199931674656769",
      "fullText" : "@River___Wang Always a pleasure to see it used in the real world!",
      "expandedUrl" : "https://twitter.com/i/web/status/1571199931674656769"
    }
  },
  {
    "like" : {
      "tweetId" : "1571167407841988608",
      "fullText" : "This must be the cutest HID Remapper hardware I've seen so far. https://t.co/JwXrNFWsNV",
      "expandedUrl" : "https://twitter.com/i/web/status/1571167407841988608"
    }
  },
  {
    "like" : {
      "tweetId" : "1571167349696258054",
      "fullText" : "@River___Wang They don't allow you? What a shame. And what if you use something like a fume extractor?",
      "expandedUrl" : "https://twitter.com/i/web/status/1571167349696258054"
    }
  },
  {
    "like" : {
      "tweetId" : "1571097154676228096",
      "fullText" : "あまりこだわりがない https://t.co/CwqTKwQvKq",
      "expandedUrl" : "https://twitter.com/i/web/status/1571097154676228096"
    }
  },
  {
    "like" : {
      "tweetId" : "1571137159490322433",
      "fullText" : "Raspberry Pi Quadrascopic Camera https://t.co/MQhE8QeHrx",
      "expandedUrl" : "https://twitter.com/i/web/status/1571137159490322433"
    }
  },
  {
    "like" : {
      "tweetId" : "1571023250725179392",
      "fullText" : "One expander chip led control. Progress! https://t.co/0ZY6rTgyx1",
      "expandedUrl" : "https://twitter.com/i/web/status/1571023250725179392"
    }
  },
  {
    "like" : {
      "tweetId" : "1571123809520066561",
      "fullText" : "@River___Wang What's that carrier board that the Xiao is attached to? With the USB-A port?",
      "expandedUrl" : "https://twitter.com/i/web/status/1571123809520066561"
    }
  },
  {
    "like" : {
      "tweetId" : "1571099162401447937",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1571099162401447937"
    }
  },
  {
    "like" : {
      "tweetId" : "1571129286094102537",
      "fullText" : "@River___Wang I've found that sometimes an oven is better than an air gun.",
      "expandedUrl" : "https://twitter.com/i/web/status/1571129286094102537"
    }
  },
  {
    "like" : {
      "tweetId" : "1571024012821798912",
      "fullText" : "@River___Wang Thank you for sharing the link, this looks ideal for a project I had in mind",
      "expandedUrl" : "https://twitter.com/i/web/status/1571024012821798912"
    }
  },
  {
    "like" : {
      "tweetId" : "1571124062088495104",
      "fullText" : "@River___Wang There are two CircuitPython board that have a physical (or optional) USB Host port but unfortunately not supported:\nhttps://t.co/1BuktMK8S3\nand https://t.co/MSN6qu8Xsq\nBoth have to be programmed in C(++?) and have different API. That's why I want #CircuitPython support.",
      "expandedUrl" : "https://twitter.com/i/web/status/1571124062088495104"
    }
  },
  {
    "like" : {
      "tweetId" : "1571036305664147456",
      "fullText" : "Hmm some soldering issues perhaps. Will look into it tomorrow. Excited and happy about the progress today. 😁 https://t.co/PKITniZjkr",
      "expandedUrl" : "https://twitter.com/i/web/status/1571036305664147456"
    }
  },
  {
    "like" : {
      "tweetId" : "1570917270402273280",
      "fullText" : "@River___Wang That's a great idea.",
      "expandedUrl" : "https://twitter.com/i/web/status/1570917270402273280"
    }
  },
  {
    "like" : {
      "tweetId" : "1570647716304416771",
      "fullText" : "Argon EON All in one Raspberry Pi Computer #ArgonEON #raspberrypi #argon40 @Raspberry_Pi https://t.co/yN871TAfIp",
      "expandedUrl" : "https://twitter.com/i/web/status/1570647716304416771"
    }
  },
  {
    "like" : {
      "tweetId" : "1570802293582462976",
      "fullText" : "@River___Wang @hackaday The ATtiny85 is a remarkable chip - I made the Adafruit Trinket (original) do all sorts of things. In the end, it's easier to have more headroom in better chips without giving anything up.",
      "expandedUrl" : "https://twitter.com/i/web/status/1570802293582462976"
    }
  },
  {
    "like" : {
      "tweetId" : "1570760451050590209",
      "fullText" : "かわいい https://t.co/V0uyEX27Tx",
      "expandedUrl" : "https://twitter.com/i/web/status/1570760451050590209"
    }
  },
  {
    "like" : {
      "tweetId" : "1570618155223093251",
      "fullText" : "\"A librarian's guide to boosting the maker movement\" (MAKE magazine, 2013)  https://t.co/kQijuUh0re  by @philshapiro  @phlmake",
      "expandedUrl" : "https://twitter.com/i/web/status/1570618155223093251"
    }
  },
  {
    "like" : {
      "tweetId" : "1570725617750126593",
      "fullText" : "りんごぉー🍎 https://t.co/RqFYnnjZE8",
      "expandedUrl" : "https://twitter.com/i/web/status/1570725617750126593"
    }
  },
  {
    "like" : {
      "tweetId" : "1570510841585500161",
      "fullText" : "time to design a PCB.\nusing these! Honyone TS Series buttons/lights. https://t.co/skLr33SVOm",
      "expandedUrl" : "https://twitter.com/i/web/status/1570510841585500161"
    }
  },
  {
    "like" : {
      "tweetId" : "1570613599483342851",
      "fullText" : "@adafruit Need🍊please. @todbot snap fit like a glove ❤️ @johnedgarpark you are the wind beneath my featherwings https://t.co/ML32pT9zXs",
      "expandedUrl" : "https://twitter.com/i/web/status/1570613599483342851"
    }
  },
  {
    "like" : {
      "tweetId" : "1570577774074826753",
      "fullText" : "Boards arrived. Assembly and praying to the microcontroller gods tomorrow. https://t.co/vo4yJWZEKB",
      "expandedUrl" : "https://twitter.com/i/web/status/1570577774074826753"
    }
  },
  {
    "like" : {
      "tweetId" : "1570585157069045760",
      "fullText" : "@anne_engineer @River___Wang @makermelissa @CircuitPython \"I'd like to encourage you two to possibly work together\" This. Yes. https://t.co/IBYuFwduCY",
      "expandedUrl" : "https://twitter.com/i/web/status/1570585157069045760"
    }
  },
  {
    "like" : {
      "tweetId" : "1568327236662734848",
      "fullText" : "Build, program, and run hardware projects in the browser\n\nyou can play w/ a very limited demo now\nhttps://t.co/gHDTfJnXUh\n\n(def got some bugs! opted to ship fast, and iterate. only works on desktop rn. )\n\n🚨 https://t.co/JU1wanofcE",
      "expandedUrl" : "https://twitter.com/i/web/status/1568327236662734848"
    }
  },
  {
    "like" : {
      "tweetId" : "1570488524297895942",
      "fullText" : "@TreasureDev @River___Wang @CircuitPython Can that be done with reading boot_out.txt files by an IDE automagically?",
      "expandedUrl" : "https://twitter.com/i/web/status/1570488524297895942"
    }
  },
  {
    "like" : {
      "tweetId" : "1570485538729381888",
      "fullText" : "@River___Wang @CircuitPython I have many boards simultaneously connected via usb, it’s hard to keep track. Showing which device/port serial is connected to is a great feature to have. Unknowingly Auto-connecting to wrong device &amp; saving over wrong code can be a frustrating and costly mistake.",
      "expandedUrl" : "https://twitter.com/i/web/status/1570485538729381888"
    }
  },
  {
    "like" : {
      "tweetId" : "1570483075557236737",
      "fullText" : "@TreasureDev @anne_engineer @River___Wang @CircuitPython Thank you 🙏. Many times it does feel like I have too many things going on at once.",
      "expandedUrl" : "https://twitter.com/i/web/status/1570483075557236737"
    }
  },
  {
    "like" : {
      "tweetId" : "1570481640547438592",
      "fullText" : "@makermelissa @anne_engineer @River___Wang @CircuitPython You’re doing a heck of a job making progress. You juggle so many different things it’s impressive. I’m glad when I see you show off personal projects on show &amp; tell. Don’t forget to have fun for yourself. 👍",
      "expandedUrl" : "https://twitter.com/i/web/status/1570481640547438592"
    }
  },
  {
    "like" : {
      "tweetId" : "1570441549405880323",
      "fullText" : "@anne_engineer @River___Wang @CircuitPython Perhaps. It appears one of River’s goals with this project is to learn React and because I don’t know React, ended up doing the code project in Vanilla JavaScript. Contributions are welcome at https://t.co/0EMgt69vu5.",
      "expandedUrl" : "https://twitter.com/i/web/status/1570441549405880323"
    }
  },
  {
    "like" : {
      "tweetId" : "1570434207205457920",
      "fullText" : "@anne_engineer @River___Wang @CircuitPython Cool. This is similar to https://t.co/t2cuoc3Sqx, but with some of the features that I’d like to eventually add.",
      "expandedUrl" : "https://twitter.com/i/web/status/1570434207205457920"
    }
  },
  {
    "like" : {
      "tweetId" : "1570338464574607361",
      "fullText" : "🐱💕 https://t.co/D3IrxVqXMZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1570338464574607361"
    }
  },
  {
    "like" : {
      "tweetId" : "1570480338127691776",
      "fullText" : "2022 Cyberdeck Contest: The Galdeano is More Than a Graphing Calculator https://t.co/S3yROiknHU",
      "expandedUrl" : "https://twitter.com/i/web/status/1570480338127691776"
    }
  },
  {
    "like" : {
      "tweetId" : "1570366819705049088",
      "fullText" : "Honda's Riding Assist technology, leverages robotics technology to create a self-balancing motorcycle \n\n[read more: https://t.co/sY8YfGpMMa] \n[source, Ali Naqvi: https://t.co/Lf8phbvVEW]\nhttps://t.co/h83aTnPBtA",
      "expandedUrl" : "https://twitter.com/i/web/status/1570366819705049088"
    }
  },
  {
    "like" : {
      "tweetId" : "1570448893091139585",
      "fullText" : "https://t.co/90MFUZn6v0",
      "expandedUrl" : "https://twitter.com/i/web/status/1570448893091139585"
    }
  },
  {
    "like" : {
      "tweetId" : "1570447066593398785",
      "fullText" : "@River___Wang @makermelissa @CircuitPython Well then your code should be compatible, you two. Making an online IDE is such a huge goal - I'd like to encourage you two to possibly work together on https://t.co/i23m6Exu5x",
      "expandedUrl" : "https://twitter.com/i/web/status/1570447066593398785"
    }
  },
  {
    "like" : {
      "tweetId" : "1570440843873652736",
      "fullText" : "@makermelissa @River___Wang @CircuitPython Maybe you two might wish to collaborate?",
      "expandedUrl" : "https://twitter.com/i/web/status/1570440843873652736"
    }
  },
  {
    "like" : {
      "tweetId" : "1570442081558237186",
      "fullText" : "@anne_engineer @River___Wang @CircuitPython I should add that learning React is something I’d like to pick up again soon (I started learning it back in 2017).",
      "expandedUrl" : "https://twitter.com/i/web/status/1570442081558237186"
    }
  },
  {
    "like" : {
      "tweetId" : "1565910830264238080",
      "fullText" : "Got interrupts routed, swd pins hooked up, SPI breakout pins instead of on-board display. Need step switch 3D files to make prettier. #Adafruit Still not sure what to name it, suggestions welcome. @todbot @johnedgarpark @BlitzCityDIY https://t.co/svcfUi0CgI",
      "expandedUrl" : "https://twitter.com/i/web/status/1565910830264238080"
    }
  },
  {
    "like" : {
      "tweetId" : "1570428138009595905",
      "fullText" : "@River___Wang Yup I know what that's like! :) https://t.co/i5InOX8Rkl Never thought to use it to reduce the pins so much for using with a QT Py! I want to redesign my board now because of you and I haven't even received prototypes from fab yet! Looking forward to seeing more of your tweets!",
      "expandedUrl" : "https://twitter.com/i/web/status/1570428138009595905"
    }
  },
  {
    "like" : {
      "tweetId" : "1570426109271089154",
      "fullText" : "@River___Wang @CircuitPython Not a fan of having terminal to the right of editor because if you need to do a manual file compare now you have 6 box areas. Terminal is usually on the bottom of the editor for a good reason.",
      "expandedUrl" : "https://twitter.com/i/web/status/1570426109271089154"
    }
  },
  {
    "like" : {
      "tweetId" : "1570426961973084163",
      "fullText" : "@River___Wang @CircuitPython I like the built in folder view but it should be optional (resize and/or collapse). Folder view should be mandatory with any IDE in my opinion. It's something Mu is sorely lacking and part of the reason why I enjoy VScode and PyCharm more than Mu. 👍",
      "expandedUrl" : "https://twitter.com/i/web/status/1570426961973084163"
    }
  },
  {
    "like" : {
      "tweetId" : "1570391147800924161",
      "fullText" : "Let's make a #CircuitPython keyboard! https://t.co/X1JeKtXobv",
      "expandedUrl" : "https://twitter.com/i/web/status/1570391147800924161"
    }
  },
  {
    "like" : {
      "tweetId" : "1557885438735667200",
      "fullText" : "@MartinNobel_ @NanoRaptor Like the last one before flattening.",
      "expandedUrl" : "https://twitter.com/i/web/status/1557885438735667200"
    }
  },
  {
    "like" : {
      "tweetId" : "1560760811269885952",
      "fullText" : "@LinuxHandbook Avoid preaching Linux as your life's only choice. Instead, try to get people into WSL and alike. You don't have to abandon what you already have for Linux.",
      "expandedUrl" : "https://twitter.com/i/web/status/1560760811269885952"
    }
  },
  {
    "like" : {
      "tweetId" : "1554159242155700225",
      "fullText" : "@PR0GRAMMERHUM0R Control-Z! It fixes everything!",
      "expandedUrl" : "https://twitter.com/i/web/status/1554159242155700225"
    }
  },
  {
    "like" : {
      "tweetId" : "1570046613493788673",
      "fullText" : "https://t.co/lYaUiT6QBt https://t.co/GRN4BWEpYS",
      "expandedUrl" : "https://twitter.com/i/web/status/1570046613493788673"
    }
  },
  {
    "like" : {
      "tweetId" : "1570087682117697537",
      "fullText" : "https://t.co/yRJ78kfX0z  competition ! Cyberdesk contest 2022 https://t.co/WYKWg3msfa",
      "expandedUrl" : "https://twitter.com/i/web/status/1570087682117697537"
    }
  },
  {
    "like" : {
      "tweetId" : "1569808785585373185",
      "fullText" : "@CircuitPython @seeedstudio Hoping to have some up on my Etsy store soon, need to do one more revision. If you want one of the prototypes at a discount, DM me!\n\nhttps://t.co/BIE4kIJdMk",
      "expandedUrl" : "https://twitter.com/i/web/status/1569808785585373185"
    }
  },
  {
    "like" : {
      "tweetId" : "1569754315685765121",
      "fullText" : "New on Lectronz: Raspberry Pi Pico to Uno FlexyPin Adapter https://t.co/aQsUFqmZFJ by @solderparty\n#RaspberryPi #TestEquipement #Technology",
      "expandedUrl" : "https://twitter.com/i/web/status/1569754315685765121"
    }
  },
  {
    "like" : {
      "tweetId" : "1548143383297662976",
      "fullText" : "I know I am late to the party. #惑星のさみだれ https://t.co/HVUQhTQXrY",
      "expandedUrl" : "https://twitter.com/i/web/status/1548143383297662976"
    }
  },
  {
    "like" : {
      "tweetId" : "1569347746426982400",
      "fullText" : "The Philly Maker Faire returns, and is looking for hackers and makers to show their stuff. https://t.co/H5oJUiYWlg",
      "expandedUrl" : "https://twitter.com/i/web/status/1569347746426982400"
    }
  },
  {
    "like" : {
      "tweetId" : "1569068607014932481",
      "fullText" : "1970: One more lane will fix it.\n1980: One more lane will fix it.\n1990: One more lane will fix it.\n2000: One more lane will fix it.\n2010: One more lane will fix it.\n2020s: ?\nvia @avelezig\n https://t.co/NjS1IPORG2",
      "expandedUrl" : "https://twitter.com/i/web/status/1569068607014932481"
    }
  },
  {
    "like" : {
      "tweetId" : "1569161501742604290",
      "fullText" : "北斎ちゃんです https://t.co/QJtWm13UD2",
      "expandedUrl" : "https://twitter.com/i/web/status/1569161501742604290"
    }
  },
  {
    "like" : {
      "tweetId" : "1568409466936377345",
      "fullText" : "ちょっとかわいい……🍇🤭✨ https://t.co/EyApBkYUZu",
      "expandedUrl" : "https://twitter.com/i/web/status/1568409466936377345"
    }
  },
  {
    "like" : {
      "tweetId" : "1567393355767910400",
      "fullText" : "インナー https://t.co/LChA51aQMy",
      "expandedUrl" : "https://twitter.com/i/web/status/1567393355767910400"
    }
  },
  {
    "like" : {
      "tweetId" : "1568454185057910784",
      "fullText" : "お月見うさちゃん🎑\n#中秋の名月 https://t.co/exoFMBV9gi",
      "expandedUrl" : "https://twitter.com/i/web/status/1568454185057910784"
    }
  },
  {
    "like" : {
      "tweetId" : "1568556624641687552",
      "fullText" : "アイコン前描いたこれです https://t.co/qreMeUBDVl",
      "expandedUrl" : "https://twitter.com/i/web/status/1568556624641687552"
    }
  },
  {
    "like" : {
      "tweetId" : "1568355311886426114",
      "fullText" : "We are a small team of mad guys to upset the old balances... https://t.co/V3vrlxB3q0",
      "expandedUrl" : "https://twitter.com/i/web/status/1568355311886426114"
    }
  },
  {
    "like" : {
      "tweetId" : "1567896614458560519",
      "fullText" : "NEW GUIDE: Adafruit MAX17048 LiPoly / LiIon Fuel Gauge and Battery Monitor #AdafruitLearningSystem #Adafruit adafruit blitzcitydiy  https://t.co/rKMakpGnXZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1567896614458560519"
    }
  },
  {
    "like" : {
      "tweetId" : "1568188948987650049",
      "fullText" : "おツキ見。 https://t.co/XRVIzpQMsQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1568188948987650049"
    }
  },
  {
    "like" : {
      "tweetId" : "1568000185204371457",
      "fullText" : "This is probably the 100th time I got trapped in the maze called NY Penn station. Finally find an exit. Wait, something strange here. Should I take this adventure? https://t.co/a3qIROoZxu",
      "expandedUrl" : "https://twitter.com/i/web/status/1568000185204371457"
    }
  },
  {
    "like" : {
      "tweetId" : "1567625770482139138",
      "fullText" : "here i fixed it https://t.co/INZ2P8oeiV",
      "expandedUrl" : "https://twitter.com/i/web/status/1567625770482139138"
    }
  },
  {
    "like" : {
      "tweetId" : "1567489180086980608",
      "fullText" : "双子\n#ブルアカ https://t.co/1XRSzJuMzj",
      "expandedUrl" : "https://twitter.com/i/web/status/1567489180086980608"
    }
  },
  {
    "like" : {
      "tweetId" : "1565975113199407104",
      "fullText" : "いろいろ② | てるミ #pixiv https://t.co/I32SXY4yyR \n\nすみません、ミスがあったので投稿し直しました",
      "expandedUrl" : "https://twitter.com/i/web/status/1565975113199407104"
    }
  },
  {
    "like" : {
      "tweetId" : "1565850425831866368",
      "fullText" : "#ESP33 #Arduino #VNC #ZRLE demo https://t.co/en9uOPVT9u",
      "expandedUrl" : "https://twitter.com/i/web/status/1565850425831866368"
    }
  },
  {
    "like" : {
      "tweetId" : "1565976369821265920",
      "fullText" : "うちのこ立ち絵〈2022〉 https://t.co/WtrusJoWAg",
      "expandedUrl" : "https://twitter.com/i/web/status/1565976369821265920"
    }
  },
  {
    "like" : {
      "tweetId" : "1566154051565146112",
      "fullText" : "ちゃん様 https://t.co/EVI5XfxRFQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1566154051565146112"
    }
  },
  {
    "like" : {
      "tweetId" : "1565716247743893504",
      "fullText" : "デレステ７周年！！！！！！！ https://t.co/RYMeFiMx10",
      "expandedUrl" : "https://twitter.com/i/web/status/1565716247743893504"
    }
  },
  {
    "like" : {
      "tweetId" : "1565112220702457856",
      "fullText" : "Wikihow be like https://t.co/Sa3q3paEUv https://t.co/cLC7pO3PMB",
      "expandedUrl" : "https://twitter.com/i/web/status/1565112220702457856"
    }
  },
  {
    "like" : {
      "tweetId" : "1565445864973164545",
      "fullText" : "I have a Steam Deck now, I can't wait to do all of the gamer things you are meant to with it. Yeah...\n\nAnyway, so here's @kicad_pcb on the Steam Deck https://t.co/8pkTEftjsQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1565445864973164545"
    }
  },
  {
    "like" : {
      "tweetId" : "1565307013638549505",
      "fullText" : "Apple Guitar Air - The air guitar, deimagined. In Classic Spindler styling. https://t.co/Ped3wU3Fzd",
      "expandedUrl" : "https://twitter.com/i/web/status/1565307013638549505"
    }
  },
  {
    "like" : {
      "tweetId" : "1565200532683120640",
      "fullText" : "ジャベリン！ https://t.co/TYzlTQ41ff",
      "expandedUrl" : "https://twitter.com/i/web/status/1565200532683120640"
    }
  },
  {
    "like" : {
      "tweetId" : "1564508242008498177",
      "fullText" : "Stolen https://t.co/XO43uf1Dac https://t.co/h563NICC2P",
      "expandedUrl" : "https://twitter.com/i/web/status/1564508242008498177"
    }
  },
  {
    "like" : {
      "tweetId" : "1564310843713622017",
      "fullText" : "I see there is a new release of CircuitPython on https://t.co/gyFGfqI4Sl - check it out! https://t.co/UdQ60riZxk",
      "expandedUrl" : "https://twitter.com/i/web/status/1564310843713622017"
    }
  },
  {
    "like" : {
      "tweetId" : "1564629102467829763",
      "fullText" : "15周年おめでとう！\n#初音ミク誕生祭2022 https://t.co/ab0nimycn5",
      "expandedUrl" : "https://twitter.com/i/web/status/1564629102467829763"
    }
  },
  {
    "like" : {
      "tweetId" : "1563679696818020357",
      "fullText" : "These comparisons always make me think of “Linux on the desktop!” hype in 00’s. You can use AbiWord instead of Word! Play lots of great games like TuxRacer! Swap Quicken for GnuCash! See, it has everything! https://t.co/k5NJqTs7Zj",
      "expandedUrl" : "https://twitter.com/i/web/status/1563679696818020357"
    }
  },
  {
    "like" : {
      "tweetId" : "1563930719214346240",
      "fullText" : "@aallan https://t.co/odrXoMEAgz",
      "expandedUrl" : "https://twitter.com/i/web/status/1563930719214346240"
    }
  },
  {
    "like" : {
      "tweetId" : "1563887186159644672",
      "fullText" : "仲良し三姉妹✨ https://t.co/kcQ5ObgFX2",
      "expandedUrl" : "https://twitter.com/i/web/status/1563887186159644672"
    }
  },
  {
    "like" : {
      "tweetId" : "1563723153037221889",
      "fullText" : "My code is perfect! https://t.co/Vgg3SUOPyv https://t.co/FQCAj9yPDJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1563723153037221889"
    }
  },
  {
    "like" : {
      "tweetId" : "1563666816492138496",
      "fullText" : "@PR0GRAMMERHUM0R Maybe try something like this: Ś̶̡̗̲͎̳̩̙͊o̸͔̍̔͌̅̆́̊̉͑͆̓̄̓̿͗̇m̶̛͇̫̻͌̊̂̀̊̾̎͗̀e̸̡̙̝̱͚͈̙͈̘̻͎͎̩̯̓̇͆̂̄̂̈́̈̀͜t̶̡̛̲̠̥̗͛̈́̑̇̽̉̌̿́̀̍̋̓̒͛͝h̷̨̧̘̟̮̜̺̫̙̳̉͜ͅi̵̡͉̦̤͈͓̘̭͈͔̝̫̩̳͎̍͑͐̀̈́̓͋͛̀͝͝ͅn̷̻̺̘̗̰̳̋̅̐̂̂̌̎̀̄̊̈́̀̅̽̓͋g̷̡̯̟̹͚̜̞͔͇̲̉̒̃̐̌́̌̓̇̈́̿͋̆̄ͅ ̵͍̀̒̀̈́̊͐͋̏̄e̷̡͕̗͉̙̺̲͈͉̠̬͕̖͕̤̋̅̄̂̿͒̒̂̐̆͛͜ả̴̈́̌͆̎̎̐̚͝",
      "expandedUrl" : "https://twitter.com/i/web/status/1563666816492138496"
    }
  },
  {
    "like" : {
      "tweetId" : "1563708148896219137",
      "fullText" : "A Raspberry Pi Handheld Computer You Might Want To Use https://t.co/vJjQ89j6ac",
      "expandedUrl" : "https://twitter.com/i/web/status/1563708148896219137"
    }
  },
  {
    "like" : {
      "tweetId" : "1563484697602453505",
      "fullText" : "Isn't that baby beautiful? https://t.co/nJBABlHTbT",
      "expandedUrl" : "https://twitter.com/i/web/status/1563484697602453505"
    }
  },
  {
    "like" : {
      "tweetId" : "1563386625245466625",
      "fullText" : "@NanoRaptor https://t.co/u34vQ1d0LP",
      "expandedUrl" : "https://twitter.com/i/web/status/1563386625245466625"
    }
  },
  {
    "like" : {
      "tweetId" : "1562525779526766599",
      "fullText" : "Femto is a ultra compact Raspberry Pi RP2040 module, which has features, as following:\n- small footprint 12x12mm,\n- all 30 GPIO pins connected,\n- stamp form factor,\n- 4-layer PCB board,\n- onboard: QSPI Flash (USON8), 12MHz oscillator, PWR LED,\n- fully open source project (OSHW), https://t.co/mX9KJzrB4B",
      "expandedUrl" : "https://twitter.com/i/web/status/1562525779526766599"
    }
  },
  {
    "like" : {
      "tweetId" : "1562544786887782400",
      "fullText" : "HandiPi is a handheld computer with an ATmega328-controlled keyboard: https://t.co/i0UOqnLKuH https://t.co/poLAZRoVdq",
      "expandedUrl" : "https://twitter.com/i/web/status/1562544786887782400"
    }
  },
  {
    "like" : {
      "tweetId" : "1562846867918008323",
      "fullText" : "Panic! At The Mall https://t.co/T3cZtUeiW0",
      "expandedUrl" : "https://twitter.com/i/web/status/1562846867918008323"
    }
  },
  {
    "like" : {
      "tweetId" : "1562451341418852354",
      "fullText" : "コハルは笑ってる方が好き https://t.co/YOo34ICUqr",
      "expandedUrl" : "https://twitter.com/i/web/status/1562451341418852354"
    }
  },
  {
    "like" : {
      "tweetId" : "1561860220485193728",
      "fullText" : "ゴジラ https://t.co/Igqrg9pfoV",
      "expandedUrl" : "https://twitter.com/i/web/status/1561860220485193728"
    }
  },
  {
    "like" : {
      "tweetId" : "1562317916518748161",
      "fullText" : "https://t.co/8JA6OyNldj",
      "expandedUrl" : "https://twitter.com/i/web/status/1562317916518748161"
    }
  },
  {
    "like" : {
      "tweetId" : "1562319794908577792",
      "fullText" : "Now that's a smart idea to avoid issues with wear. https://t.co/RZSmBLaqbn",
      "expandedUrl" : "https://twitter.com/i/web/status/1562319794908577792"
    }
  },
  {
    "like" : {
      "tweetId" : "1562181424136228864",
      "fullText" : "v https://t.co/ZkaSuyRDJE",
      "expandedUrl" : "https://twitter.com/i/web/status/1562181424136228864"
    }
  },
  {
    "like" : {
      "tweetId" : "1561602961104547840",
      "fullText" : "サムネに使うかもね https://t.co/ndA3Fft200",
      "expandedUrl" : "https://twitter.com/i/web/status/1561602961104547840"
    }
  },
  {
    "like" : {
      "tweetId" : "1561284472636522496",
      "fullText" : "This demonstration seems to defy thermodynamics in that it appears that entropy decreases, but reversible mixing is actually made possible by ensuring that the mixing/unmixing is done without turbulence [source, full video, UNM: https://t.co/YNxFi37B8m] https://t.co/1aEt9Ij3C4",
      "expandedUrl" : "https://twitter.com/i/web/status/1561284472636522496"
    }
  },
  {
    "like" : {
      "tweetId" : "1561231123069382657",
      "fullText" : "原稿しんちょく！ https://t.co/O8Vpvd3qmB",
      "expandedUrl" : "https://twitter.com/i/web/status/1561231123069382657"
    }
  },
  {
    "like" : {
      "tweetId" : "1561367576172797952",
      "fullText" : "When your program just wraps a library but basically does the same with different names https://t.co/owTTRBKgKM https://t.co/ksXZvnXdPP",
      "expandedUrl" : "https://twitter.com/i/web/status/1561367576172797952"
    }
  },
  {
    "like" : {
      "tweetId" : "1561307325171908608",
      "fullText" : "The perfect guy https://t.co/LmvOQPP9nE https://t.co/HWJAnMcEva",
      "expandedUrl" : "https://twitter.com/i/web/status/1561307325171908608"
    }
  },
  {
    "like" : {
      "tweetId" : "1561303020016545792",
      "fullText" : "今夜は背伸びして https://t.co/ir2LHVRqHy",
      "expandedUrl" : "https://twitter.com/i/web/status/1561303020016545792"
    }
  },
  {
    "like" : {
      "tweetId" : "1560709112605937665",
      "fullText" : "CircuitPython 8 Preview https://t.co/bWDQu2GdMK",
      "expandedUrl" : "https://twitter.com/i/web/status/1560709112605937665"
    }
  },
  {
    "like" : {
      "tweetId" : "1560730964246011907",
      "fullText" : "Mirek Folejewski's Femto module is a full-feature @Raspberry_Pi RP2040 in the smallest footprint yet: https://t.co/c0T4Crzgag https://t.co/zoD6dS7ihy",
      "expandedUrl" : "https://twitter.com/i/web/status/1560730964246011907"
    }
  },
  {
    "like" : {
      "tweetId" : "1561111432829321217",
      "fullText" : "@facetimeJS I basically treat Windows as a window manager for Ubuntu in WSL. Best of both worlds most of the time.",
      "expandedUrl" : "https://twitter.com/i/web/status/1561111432829321217"
    }
  },
  {
    "like" : {
      "tweetId" : "1560640596913508353",
      "fullText" : "https://t.co/YPhCTjZv1O",
      "expandedUrl" : "https://twitter.com/i/web/status/1560640596913508353"
    }
  },
  {
    "like" : {
      "tweetId" : "1560945068877430785",
      "fullText" : "Z80 Single-Board Computer Looks Like It Could Have Been a Killer Product https://t.co/Jgdrs4dcZJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1560945068877430785"
    }
  },
  {
    "like" : {
      "tweetId" : "1560200443145650176",
      "fullText" : "#夏休みはフォロワーさんが増える\nよろしくお願いします！ https://t.co/sa6YwumTC1",
      "expandedUrl" : "https://twitter.com/i/web/status/1560200443145650176"
    }
  },
  {
    "like" : {
      "tweetId" : "1560344206668955653",
      "fullText" : "Raspberry Pi-powered music synthesizer – HackSpace Magazine Issue 57 HackSpaceMag Raspberry_Pi  https://t.co/ZT6ZuaNWuc",
      "expandedUrl" : "https://twitter.com/i/web/status/1560344206668955653"
    }
  },
  {
    "like" : {
      "tweetId" : "1560254042936594434",
      "fullText" : "#夏休みはフォロワーさんが増える\nる～～！！ https://t.co/HlJjdjqtze",
      "expandedUrl" : "https://twitter.com/i/web/status/1560254042936594434"
    }
  },
  {
    "like" : {
      "tweetId" : "1560476598285078530",
      "fullText" : "How embarrassing. ¯\\_(ツ)_/¯ https://t.co/QcAD1PODXC",
      "expandedUrl" : "https://twitter.com/i/web/status/1560476598285078530"
    }
  },
  {
    "like" : {
      "tweetId" : "1560392178152652801",
      "fullText" : "CircuitPython 8.0.0 Beta 0 Released! circuitpython  https://t.co/PcEyqedgU3",
      "expandedUrl" : "https://twitter.com/i/web/status/1560392178152652801"
    }
  },
  {
    "like" : {
      "tweetId" : "1560382548940840968",
      "fullText" : "8.0 beta! https://t.co/rDb22Z1Wi6",
      "expandedUrl" : "https://twitter.com/i/web/status/1560382548940840968"
    }
  },
  {
    "like" : {
      "tweetId" : "1560387575029923847",
      "fullText" : "CircuitPython 8.0.0 Beta 0 Released! @circuitpython https://t.co/obh5TV82P5",
      "expandedUrl" : "https://twitter.com/i/web/status/1560387575029923847"
    }
  },
  {
    "like" : {
      "tweetId" : "1560361641577009154",
      "fullText" : "I see there is a new release of CircuitPython on https://t.co/gyFGfqI4Sl - check it out! https://t.co/Yj2X1IBVvp",
      "expandedUrl" : "https://twitter.com/i/web/status/1560361641577009154"
    }
  },
  {
    "like" : {
      "tweetId" : "1559815913205125120",
      "fullText" : "This drawing ruler allows a multifunctional design through a series of shape and a rotating protractor [read more: https://t.co/n6z5Gqrtnm] https://t.co/5uMirhhmuJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1559815913205125120"
    }
  },
  {
    "like" : {
      "tweetId" : "1559725150680952832",
      "fullText" : "オオカミです https://t.co/dL8JAiM5uX",
      "expandedUrl" : "https://twitter.com/i/web/status/1559725150680952832"
    }
  },
  {
    "like" : {
      "tweetId" : "1558272475519242240",
      "fullText" : "Svelte VR Headsets Coming? https://t.co/BOkhFUh6LJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1558272475519242240"
    }
  },
  {
    "like" : {
      "tweetId" : "1558170355239469058",
      "fullText" : "Polyrhythm is the simultaneous use of two or more rhythms. Tapping exercises with the metronome are important to master the most basic of polyrhythms. While apparently easy, it's something that requires huge coordination [source: https://t.co/Khkc7AWBhb] https://t.co/r8QLB0V3Lc",
      "expandedUrl" : "https://twitter.com/i/web/status/1558170355239469058"
    }
  },
  {
    "like" : {
      "tweetId" : "1558078285183172608",
      "fullText" : "Inspired by solar furnaces, this parabolic mirror concentrates light onto a focal point, and can be consequently used for more mundane tasks in place of industrial purposes\n\n[how it works: https://t.co/QAqdPMUgkU]\n[📹 https://t.co/HF2LfdCd7j]\nhttps://t.co/WITWpMMXIV",
      "expandedUrl" : "https://twitter.com/i/web/status/1558078285183172608"
    }
  },
  {
    "like" : {
      "tweetId" : "1557788294313906177",
      "fullText" : "Asahi Linux May Pursue Writing Apple Silicon GPU Driver In Rust\n\nhttps://t.co/1o0ne9ORP9",
      "expandedUrl" : "https://twitter.com/i/web/status/1557788294313906177"
    }
  },
  {
    "like" : {
      "tweetId" : "1557731900910800897",
      "fullText" : "Lesser known Apple Watch Workouts:\nCable Management https://t.co/JOUEIcggFf",
      "expandedUrl" : "https://twitter.com/i/web/status/1557731900910800897"
    }
  },
  {
    "like" : {
      "tweetId" : "1557875868449460225",
      "fullText" : "@geerlingguy I think I have more Pi in my garage than you do.",
      "expandedUrl" : "https://twitter.com/i/web/status/1557875868449460225"
    }
  },
  {
    "like" : {
      "tweetId" : "1557870696776212501",
      "fullText" : "I think I might be the leader in the Raspberry Pi Cloud Clustering Tutorial 2022 Gardener® Magic Quadrant™",
      "expandedUrl" : "https://twitter.com/i/web/status/1557870696776212501"
    }
  },
  {
    "like" : {
      "tweetId" : "1558061563130662912",
      "fullText" : "Running an MNIST model on an ATmega328: https://t.co/VVEp02RBKQ https://t.co/mo84SXGIqs",
      "expandedUrl" : "https://twitter.com/i/web/status/1558061563130662912"
    }
  },
  {
    "like" : {
      "tweetId" : "1557786371124871169",
      "fullText" : "Baby lifting should be another. And let’s not forget mowing the lawn! https://t.co/6PrbY2yypd",
      "expandedUrl" : "https://twitter.com/i/web/status/1557786371124871169"
    }
  },
  {
    "like" : {
      "tweetId" : "1557578522079936512",
      "fullText" : "https://t.co/aaaDCBPPKW",
      "expandedUrl" : "https://twitter.com/i/web/status/1557578522079936512"
    }
  },
  {
    "like" : {
      "tweetId" : "1557829504101498880",
      "fullText" : "Super Mini #RAK3172h communicator with display. @RAKwireless @rakwirelessyu ^@RAKwireless_Roy #lora #lorawab @Kongduino . PCB send to factory. https://t.co/gAFx49GhIM",
      "expandedUrl" : "https://twitter.com/i/web/status/1557829504101498880"
    }
  },
  {
    "like" : {
      "tweetId" : "1557665037723963392",
      "fullText" : "ほしい～？🍩 https://t.co/0Y9UqLlQJM",
      "expandedUrl" : "https://twitter.com/i/web/status/1557665037723963392"
    }
  },
  {
    "like" : {
      "tweetId" : "1557827823951384578",
      "fullText" : "https://t.co/ubjJkaPwU1",
      "expandedUrl" : "https://twitter.com/i/web/status/1557827823951384578"
    }
  },
  {
    "like" : {
      "tweetId" : "1557724314958303238",
      "fullText" : "はい、あげる。 https://t.co/Sh0orWokVt",
      "expandedUrl" : "https://twitter.com/i/web/status/1557724314958303238"
    }
  },
  {
    "like" : {
      "tweetId" : "1557599765738582017",
      "fullText" : "うにゅ～ https://t.co/eADO11chA2",
      "expandedUrl" : "https://twitter.com/i/web/status/1557599765738582017"
    }
  },
  {
    "like" : {
      "tweetId" : "1557414877895196672",
      "fullText" : "虚無 https://t.co/lsNEqFOkyv",
      "expandedUrl" : "https://twitter.com/i/web/status/1557414877895196672"
    }
  },
  {
    "like" : {
      "tweetId" : "1557029056218304512",
      "fullText" : "日記です https://t.co/PiihtY3zx5",
      "expandedUrl" : "https://twitter.com/i/web/status/1557029056218304512"
    }
  },
  {
    "like" : {
      "tweetId" : "1557001611272396805",
      "fullText" : "二ヵ月ぶりにまとめました\n\n最近描いたデレマスまとめ | 日下氏 #pixiv https://t.co/2xWrQbXPeP",
      "expandedUrl" : "https://twitter.com/i/web/status/1557001611272396805"
    }
  },
  {
    "like" : {
      "tweetId" : "1556967624742907905",
      "fullText" : "更新は気まぐれですが(最新に追い付いてない)、\nインスタもやってます。\nhttps://t.co/Nh9M7x1gM6 https://t.co/JIxi026U17",
      "expandedUrl" : "https://twitter.com/i/web/status/1556967624742907905"
    }
  },
  {
    "like" : {
      "tweetId" : "1556251038021292032",
      "fullText" : "https://t.co/OdBFYOD69F",
      "expandedUrl" : "https://twitter.com/i/web/status/1556251038021292032"
    }
  },
  {
    "like" : {
      "tweetId" : "1556398455043641346",
      "fullText" : "a first test of circuitpython on ESP32 web workflow! scott and dan just merged in Web (WiFi) Workflow for circuitpython and ESP32 https://t.co/uqUfLj07oS  which means that it's incredibly easy to start working with chips like the ESP32 which have excellent WiFi networking ... https://t.co/gi44O1N0cH",
      "expandedUrl" : "https://twitter.com/i/web/status/1556398455043641346"
    }
  },
  {
    "like" : {
      "tweetId" : "1556700168187150336",
      "fullText" : "In order to avoid expensive irrigation systems, this farmer lifted the spraying pipes using hydrogen balloons \n\n[📹 https://t.co/EYYsbe6jtA]\nhttps://t.co/7LfBcZ7IsE",
      "expandedUrl" : "https://twitter.com/i/web/status/1556700168187150336"
    }
  },
  {
    "like" : {
      "tweetId" : "1556573080088363010",
      "fullText" : "世界猫の日だそうで🐈🍓 https://t.co/lslvRbZYP2",
      "expandedUrl" : "https://twitter.com/i/web/status/1556573080088363010"
    }
  },
  {
    "like" : {
      "tweetId" : "1556410494839398400",
      "fullText" : "a first test of circuitpython on ESP32 web workflow!  https://t.co/G8BRweJ0fy",
      "expandedUrl" : "https://twitter.com/i/web/status/1556410494839398400"
    }
  },
  {
    "like" : {
      "tweetId" : "1556465596660740097",
      "fullText" : "線香花火が普通に燃えた夢見りあむ https://t.co/9KO9yPvNFC",
      "expandedUrl" : "https://twitter.com/i/web/status/1556465596660740097"
    }
  },
  {
    "like" : {
      "tweetId" : "1556256486179110912",
      "fullText" : "skeb. https://t.co/M1QXfhMu57",
      "expandedUrl" : "https://twitter.com/i/web/status/1556256486179110912"
    }
  },
  {
    "like" : {
      "tweetId" : "1555835994468823040",
      "fullText" : "#ブルアカ \n和楽チセ https://t.co/KZ9igOY31j",
      "expandedUrl" : "https://twitter.com/i/web/status/1555835994468823040"
    }
  },
  {
    "like" : {
      "tweetId" : "1555917041042919426",
      "fullText" : "Is this a bug or a feature? https://t.co/x9iriFGNpZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1555917041042919426"
    }
  },
  {
    "like" : {
      "tweetId" : "1555871357920899072",
      "fullText" : "レディ・アヴァロン\n #FGO https://t.co/zlDtKavgX9",
      "expandedUrl" : "https://twitter.com/i/web/status/1555871357920899072"
    }
  },
  {
    "like" : {
      "tweetId" : "1555655007583686656",
      "fullText" : "photo study of muir woods ☀️🌲 https://t.co/3cvZge5EXs",
      "expandedUrl" : "https://twitter.com/i/web/status/1555655007583686656"
    }
  },
  {
    "like" : {
      "tweetId" : "1556127730173100033",
      "fullText" : "君との毎日☕️ https://t.co/DeBY2buLcU",
      "expandedUrl" : "https://twitter.com/i/web/status/1556127730173100033"
    }
  },
  {
    "like" : {
      "tweetId" : "1549424445177188353",
      "fullText" : "@PR0GRAMMERHUM0R isn't a python https://t.co/WK01zkI0Zt",
      "expandedUrl" : "https://twitter.com/i/web/status/1549424445177188353"
    }
  },
  {
    "like" : {
      "tweetId" : "1549529541097439238",
      "fullText" : "bro, do you even version control? https://t.co/XJu2vtCEAE https://t.co/bGKDYcysJr",
      "expandedUrl" : "https://twitter.com/i/web/status/1549529541097439238"
    }
  },
  {
    "like" : {
      "tweetId" : "1550677103737184257",
      "fullText" : "Honestly, I'm impressed with how much clueless HR/recruiters can be. https://t.co/qxV2NwH1sk https://t.co/GQ4SPm2Xt9",
      "expandedUrl" : "https://twitter.com/i/web/status/1550677103737184257"
    }
  },
  {
    "like" : {
      "tweetId" : "1550770119948832769",
      "fullText" : "@PR0GRAMMERHUM0R Well, c is faster than python, but\nIs your c faster than python?",
      "expandedUrl" : "https://twitter.com/i/web/status/1550770119948832769"
    }
  },
  {
    "like" : {
      "tweetId" : "1554542576568614912",
      "fullText" : "While porting an old 400k lines code-base... https://t.co/hi0IW7AbBl https://t.co/JHdKoPa3YN",
      "expandedUrl" : "https://twitter.com/i/web/status/1554542576568614912"
    }
  },
  {
    "like" : {
      "tweetId" : "1555515892175630337",
      "fullText" : "夏の音色 https://t.co/09JkCVxcjs",
      "expandedUrl" : "https://twitter.com/i/web/status/1555515892175630337"
    }
  },
  {
    "like" : {
      "tweetId" : "1555969240041418753",
      "fullText" : "リクエストいただいてたやつ https://t.co/TEvyBMHWSf",
      "expandedUrl" : "https://twitter.com/i/web/status/1555969240041418753"
    }
  },
  {
    "like" : {
      "tweetId" : "1555660159237599232",
      "fullText" : "Deep Dive w/Scott: Guest Hosting &amp; Web Workflow @tannewt https://t.co/Ip9gLa6BQ9",
      "expandedUrl" : "https://twitter.com/i/web/status/1555660159237599232"
    }
  },
  {
    "like" : {
      "tweetId" : "1555748159686471680",
      "fullText" : "GMです☀️\nFNDの息抜きで突発的に元気な妹（赤いネコミミフード）と気弱な姉（青いウサミミフード）という感じで可愛くお気に入りにデザインできたので、明日KIRAKIRA～にリストします💛\nよろしくお願いします！✨ https://t.co/dxjqMNPYSZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1555748159686471680"
    }
  },
  {
    "like" : {
      "tweetId" : "1555835860419223552",
      "fullText" : "commission https://t.co/tUJTFNcP62",
      "expandedUrl" : "https://twitter.com/i/web/status/1555835860419223552"
    }
  },
  {
    "like" : {
      "tweetId" : "1555820267070439424",
      "fullText" : "via @NekoMichiNyan https://t.co/sflBfH051A",
      "expandedUrl" : "https://twitter.com/i/web/status/1555820267070439424"
    }
  },
  {
    "like" : {
      "tweetId" : "1555871533952008193",
      "fullText" : "登校日の午後 https://t.co/I6OEsP64sE",
      "expandedUrl" : "https://twitter.com/i/web/status/1555871533952008193"
    }
  },
  {
    "like" : {
      "tweetId" : "1555539563715919873",
      "fullText" : "🧁 https://t.co/0yRGnstXCw",
      "expandedUrl" : "https://twitter.com/i/web/status/1555539563715919873"
    }
  },
  {
    "like" : {
      "tweetId" : "1555826286412578816",
      "fullText" : "Here’s How The Precursor Protects Your Privacy https://t.co/gAGeFYa3Vz",
      "expandedUrl" : "https://twitter.com/i/web/status/1555826286412578816"
    }
  },
  {
    "like" : {
      "tweetId" : "1555633570663878656",
      "fullText" : "«Le Petit Chef» restaurants playfully guide diners through an interactive experience where the story behind each course is brought to life through cutting edge projection-mapping created by the world-famous artists of Skullmapping https://t.co/75fbSD1RGG\nhttps://t.co/AV7SWmberr",
      "expandedUrl" : "https://twitter.com/i/web/status/1555633570663878656"
    }
  },
  {
    "like" : {
      "tweetId" : "1555674707403448321",
      "fullText" : "I got 10 ATiny85 and some dumb ideas… let’s start the weekend! https://t.co/cgSHoCUTU6",
      "expandedUrl" : "https://twitter.com/i/web/status/1555674707403448321"
    }
  },
  {
    "like" : {
      "tweetId" : "1555541837493915648",
      "fullText" : "ぐらびあの撮影 https://t.co/NCO5HtxuE6",
      "expandedUrl" : "https://twitter.com/i/web/status/1555541837493915648"
    }
  },
  {
    "like" : {
      "tweetId" : "1555433424894103553",
      "fullText" : "Calculation of π, from rain falling on two wooden plate sensors, one circular and one square: the number of raindrops that landed on each plate during a storm was counted with an Arduino and π was calculated as the ratio [source &amp; credits: https://t.co/NzaqtxOdqF] https://t.co/kuURkKsjDz",
      "expandedUrl" : "https://twitter.com/i/web/status/1555433424894103553"
    }
  },
  {
    "like" : {
      "tweetId" : "1554977948369035264",
      "fullText" : "https://t.co/WFJhxLYUGp",
      "expandedUrl" : "https://twitter.com/i/web/status/1554977948369035264"
    }
  },
  {
    "like" : {
      "tweetId" : "1555322228757381120",
      "fullText" : "くんくん https://t.co/DxN4wbf0qI",
      "expandedUrl" : "https://twitter.com/i/web/status/1555322228757381120"
    }
  },
  {
    "like" : {
      "tweetId" : "1554927673608224769",
      "fullText" : "My son’s first OS was #Linux. @RedHat to be exact. Now he wants to be a Video Game Developer. I’m a great Father!\n\n#DadOps #BlackTechTwitter #Linux https://t.co/9ROI63dutY",
      "expandedUrl" : "https://twitter.com/i/web/status/1554927673608224769"
    }
  },
  {
    "like" : {
      "tweetId" : "1555264162376216577",
      "fullText" : "Good news everybody! (kind of) I have access to the github account back after many years! https://t.co/s6nJH17nsG Problem is all the repos got nuked in the process. Pardon the mess while I get the libraries back in there!",
      "expandedUrl" : "https://twitter.com/i/web/status/1555264162376216577"
    }
  },
  {
    "like" : {
      "tweetId" : "1554839158430236673",
      "fullText" : "oc https://t.co/iI4Zztjqev",
      "expandedUrl" : "https://twitter.com/i/web/status/1554839158430236673"
    }
  },
  {
    "like" : {
      "tweetId" : "1589017910089240578",
      "fullText" : "If I did this right for twitter it should loop infinitely if on auto play. 😋 https://t.co/3euY6R5izz",
      "expandedUrl" : "https://twitter.com/i/web/status/1589017910089240578"
    }
  },
  {
    "like" : {
      "tweetId" : "1588602567939936256",
      "fullText" : "Small cubes with mirrors and the universe inside.\n https://t.co/ruj2FQxWvJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1588602567939936256"
    }
  },
  {
    "like" : {
      "tweetId" : "1588842787205951489",
      "fullText" : "How to create a T-Rex https://t.co/wEoUzcKpVt",
      "expandedUrl" : "https://twitter.com/i/web/status/1588842787205951489"
    }
  },
  {
    "like" : {
      "tweetId" : "1588939242335502336",
      "fullText" : "The Great Resistor Embiggens the Smallest Value https://t.co/8zHPTNNqUq",
      "expandedUrl" : "https://twitter.com/i/web/status/1588939242335502336"
    }
  },
  {
    "like" : {
      "tweetId" : "1588883837760700416",
      "fullText" : "Happy #Caturday y'all https://t.co/XoBRSGw45h",
      "expandedUrl" : "https://twitter.com/i/web/status/1588883837760700416"
    }
  },
  {
    "like" : {
      "tweetId" : "1588933192903405568",
      "fullText" : "So you spend 5 minutes meticulously soldering your new pico and voila beautiful! and realize you actually needed male headers not female. 😞 https://t.co/3TqXIJ71iE",
      "expandedUrl" : "https://twitter.com/i/web/status/1588933192903405568"
    }
  },
  {
    "like" : {
      "tweetId" : "1588725075821273089",
      "fullText" : "@anne_engineer @CaptnAmy Hi Anne 👋",
      "expandedUrl" : "https://twitter.com/i/web/status/1588725075821273089"
    }
  },
  {
    "like" : {
      "tweetId" : "1588594628646752256",
      "fullText" : "I should be at Maker Faire Orlando Sunday - if you see me &amp; @CaptnAmy, say hi! @OrlMakerFaire #Making https://t.co/6P7rV110py",
      "expandedUrl" : "https://twitter.com/i/web/status/1588594628646752256"
    }
  },
  {
    "like" : {
      "tweetId" : "1588871161009836033",
      "fullText" : "@Rento_hal お写真ありがとうございます🥰\n数ある素敵な作品の中から、おすすめの4枚に自分の作品を選んでいただけて光栄です✨✨",
      "expandedUrl" : "https://twitter.com/i/web/status/1588871161009836033"
    }
  },
  {
    "like" : {
      "tweetId" : "1588832701670641665",
      "fullText" : "🍎\n♛List: 11/7 21:00[JST]\n♛Price: 0.2 ETH～\nhttps://t.co/MrI64XHBko\n\n#NFT #NFTart #NFTCommunity #NFTcollection https://t.co/uGgQLB93Af",
      "expandedUrl" : "https://twitter.com/i/web/status/1588832701670641665"
    }
  },
  {
    "like" : {
      "tweetId" : "1588734591409717248",
      "fullText" : "TR-Cowbell 1.2. Just finished soldering. Haven’t tested yet. First look at the new design fully assembled.  😊 https://t.co/f1ZxHHF2Rh",
      "expandedUrl" : "https://twitter.com/i/web/status/1588734591409717248"
    }
  },
  {
    "like" : {
      "tweetId" : "1588622571364581376",
      "fullText" : "Mastodon invitation  https://t.co/Pi2qyIxQkG",
      "expandedUrl" : "https://twitter.com/i/web/status/1588622571364581376"
    }
  },
  {
    "like" : {
      "tweetId" : "1588525359045042176",
      "fullText" : "https://t.co/PymaaUmjOE https://t.co/AtqL4iksSD",
      "expandedUrl" : "https://twitter.com/i/web/status/1588525359045042176"
    }
  },
  {
    "like" : {
      "tweetId" : "1588473181484257281",
      "fullText" : "I'm not really into conventional layouts. Correct me if I'm wrong about the Pi60 PCBs by @1upkeyboards being the first mass-produced 60% ones with RP2040 chip:\nhttps://t.co/2HhFi2wpei",
      "expandedUrl" : "https://twitter.com/i/web/status/1588473181484257281"
    }
  },
  {
    "like" : {
      "tweetId" : "1588224011666063361",
      "fullText" : "Starting a new job at the university on Monday and I’ve taken this week off to recharge. Making actual bread for a change 😋 the garlic confit turned out gorgeous! https://t.co/Na9kPV28BA",
      "expandedUrl" : "https://twitter.com/i/web/status/1588224011666063361"
    }
  },
  {
    "like" : {
      "tweetId" : "1588210247268712449",
      "fullText" : "Raspberry Pi case in Mac mini style\nA few details about the project in🧵\n1/10\n#raspberrypi https://t.co/0uIEqaEBjd",
      "expandedUrl" : "https://twitter.com/i/web/status/1588210247268712449"
    }
  },
  {
    "like" : {
      "tweetId" : "1588169619642122241",
      "fullText" : "@River___Wang @TreasureDev @MakeAugusta @digikey @adafruit You don't have to watch them all but two or three provide some great skills",
      "expandedUrl" : "https://twitter.com/i/web/status/1588169619642122241"
    }
  },
  {
    "like" : {
      "tweetId" : "1588166867071295488",
      "fullText" : "@River___Wang @TreasureDev @MakeAugusta @digikey See some of the videos on @Adafruit's The Great Search as Ladyada shows the tricks of searching @Digikey - it isn't daunting if you learn some tips and tricks. https://t.co/y5JGJKBemA",
      "expandedUrl" : "https://twitter.com/i/web/status/1588166867071295488"
    }
  },
  {
    "like" : {
      "tweetId" : "1588013007115780103",
      "fullText" : "@MakeAugusta @digikey Digikey has a forum? 👀",
      "expandedUrl" : "https://twitter.com/i/web/status/1588013007115780103"
    }
  },
  {
    "like" : {
      "tweetId" : "1587848050030043143",
      "fullText" : "“This robotic drone has legs and acts like a bird.Stanford engineers Mark Cutkosky and David Lentink developed this bird-inspired robotic drone that can mimic how birds fly, perch and carry objects.”\n \nSource @gigadgets_ https://t.co/knBLSoYcfm",
      "expandedUrl" : "https://twitter.com/i/web/status/1587848050030043143"
    }
  },
  {
    "like" : {
      "tweetId" : "1588003205618798594",
      "fullText" : "So happy that I just fixed a bug that has been there in the CircuitPython online IDE since day one. It took me more than a year to locate the real problem. Now it won't freeze any more when receives 2000+ lines of data from the serial.",
      "expandedUrl" : "https://twitter.com/i/web/status/1588003205618798594"
    }
  },
  {
    "like" : {
      "tweetId" : "1587815441585426432",
      "fullText" : "Bionic adjustable wrench👌🏻 https://t.co/jea5Ph3gW6",
      "expandedUrl" : "https://twitter.com/i/web/status/1587815441585426432"
    }
  },
  {
    "like" : {
      "tweetId" : "1587814659155009536",
      "fullText" : "Dheera Venkatraman's ePaper picture frame is a window into an infinitely-scrolling landscape: https://t.co/GJvBBcOF3m https://t.co/qYtosR8Q93",
      "expandedUrl" : "https://twitter.com/i/web/status/1587814659155009536"
    }
  },
  {
    "like" : {
      "tweetId" : "1587837449417461763",
      "fullText" : "Pebble watch updated to work with 64-bit Android like the Pixel 7 #Pebble #Watch https://t.co/hM1GjaetRL",
      "expandedUrl" : "https://twitter.com/i/web/status/1587837449417461763"
    }
  },
  {
    "like" : {
      "tweetId" : "1587816462957289472",
      "fullText" : "@River___Wang @TreasureDev We want Mu to support it at some point",
      "expandedUrl" : "https://twitter.com/i/web/status/1587816462957289472"
    }
  },
  {
    "like" : {
      "tweetId" : "1554880289268178945",
      "fullText" : "First print, first failure... https://t.co/ttGf5r1qUk",
      "expandedUrl" : "https://twitter.com/i/web/status/1554880289268178945"
    }
  },
  {
    "like" : {
      "tweetId" : "1554881875436621825",
      "fullText" : "NEW GUIDE: CircuitPython MIDI to CV Skull #AdafruitLearningSystem Adafruit BlitzCityDIY  https://t.co/QTBzFQPEu3",
      "expandedUrl" : "https://twitter.com/i/web/status/1554881875436621825"
    }
  },
  {
    "like" : {
      "tweetId" : "1554834792960520193",
      "fullText" : "ICYMI: Python on Microcontrollers Newsletter: 300 Adafruit CircuitPython Libraries, Pico W Projects &amp; More! #Python #CircuitPython #ICYMI micropython Raspberry_Pi  https://t.co/WiBrm3btuQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1554834792960520193"
    }
  },
  {
    "like" : {
      "tweetId" : "1554806953414893574",
      "fullText" : "今日は1枚しかかけなかったです https://t.co/9QRrOD3X8K",
      "expandedUrl" : "https://twitter.com/i/web/status/1554806953414893574"
    }
  },
  {
    "like" : {
      "tweetId" : "1554761214877904897",
      "fullText" : "https://t.co/wYIRaRVEQR",
      "expandedUrl" : "https://twitter.com/i/web/status/1554761214877904897"
    }
  },
  {
    "like" : {
      "tweetId" : "1554761198037479424",
      "fullText" : "ふぃーーーっしゅ！！ https://t.co/5uEd91yceT",
      "expandedUrl" : "https://twitter.com/i/web/status/1554761198037479424"
    }
  },
  {
    "like" : {
      "tweetId" : "1554550084758634500",
      "fullText" : "🙃 https://t.co/faaUWSPVm1",
      "expandedUrl" : "https://twitter.com/i/web/status/1554550084758634500"
    }
  },
  {
    "like" : {
      "tweetId" : "1554535205490368515",
      "fullText" : "The Rollercoaster Of Developing The Ultimate Hackable Keyboard https://t.co/dLZetlCZlj",
      "expandedUrl" : "https://twitter.com/i/web/status/1554535205490368515"
    }
  },
  {
    "like" : {
      "tweetId" : "1554534032439971843",
      "fullText" : "CircuitPython 8.0 is coming soon… https://t.co/brUNVEVQe8",
      "expandedUrl" : "https://twitter.com/i/web/status/1554534032439971843"
    }
  },
  {
    "like" : {
      "tweetId" : "1554073250338344961",
      "fullText" : "水着申鶴さん🌴 https://t.co/h7QcXJo4Bh",
      "expandedUrl" : "https://twitter.com/i/web/status/1554073250338344961"
    }
  },
  {
    "like" : {
      "tweetId" : "1554436503807627264",
      "fullText" : "水着セリカ https://t.co/oSFLmUtOsK",
      "expandedUrl" : "https://twitter.com/i/web/status/1554436503807627264"
    }
  },
  {
    "like" : {
      "tweetId" : "1554410698452930567",
      "fullText" : "10日目　綾波レイ🧊 https://t.co/iFZEOHqKKs",
      "expandedUrl" : "https://twitter.com/i/web/status/1554410698452930567"
    }
  },
  {
    "like" : {
      "tweetId" : "1554387100019003392",
      "fullText" : "溢れる https://t.co/nYNw4NvFWz",
      "expandedUrl" : "https://twitter.com/i/web/status/1554387100019003392"
    }
  },
  {
    "like" : {
      "tweetId" : "1554399224611340288",
      "fullText" : "🟠🔴⚫️ https://t.co/XhzRuJRr6I",
      "expandedUrl" : "https://twitter.com/i/web/status/1554399224611340288"
    }
  },
  {
    "like" : {
      "tweetId" : "1554426824067026944",
      "fullText" : "バニー甘雨ちゃん！🐇#バニーの日 https://t.co/P5xAoTMv2T",
      "expandedUrl" : "https://twitter.com/i/web/status/1554426824067026944"
    }
  },
  {
    "like" : {
      "tweetId" : "1554457129364635649",
      "fullText" : "#バニーの日 再掲 https://t.co/nI0nOAggKx",
      "expandedUrl" : "https://twitter.com/i/web/status/1554457129364635649"
    }
  },
  {
    "like" : {
      "tweetId" : "1554513690015170563",
      "fullText" : "This ATmega2560-driven robot can solve a Rubik’s Cube in less than two seconds: https://t.co/UeMoPlS4rz https://t.co/mj81bGXzsH",
      "expandedUrl" : "https://twitter.com/i/web/status/1554513690015170563"
    }
  },
  {
    "like" : {
      "tweetId" : "1554407678041923584",
      "fullText" : "虹色ペトリコール https://t.co/hxEh3N5DhS",
      "expandedUrl" : "https://twitter.com/i/web/status/1554407678041923584"
    }
  },
  {
    "like" : {
      "tweetId" : "1554482235822186496",
      "fullText" : "New episode next Monday!  You’ll meet Joshua Lowe, the creator of EduBlocks and learn all about it.  Subscribe:  https://t.co/P9EwqLC5IX",
      "expandedUrl" : "https://twitter.com/i/web/status/1554482235822186496"
    }
  },
  {
    "like" : {
      "tweetId" : "1554479873967951877",
      "fullText" : "髪型はどうしますか？ https://t.co/rVYHAExAnL",
      "expandedUrl" : "https://twitter.com/i/web/status/1554479873967951877"
    }
  },
  {
    "like" : {
      "tweetId" : "1554457428044918787",
      "fullText" : "@sulfuroid toilet lock",
      "expandedUrl" : "https://twitter.com/i/web/status/1554457428044918787"
    }
  },
  {
    "like" : {
      "tweetId" : "1554217719612014592",
      "fullText" : "\"Ce chinois pendant le confinement a été plus créatif que Logitech en 40 ans\"\n\nDans les coms de ce billet :D\n\nhttps://t.co/6WYXa6pyW6",
      "expandedUrl" : "https://twitter.com/i/web/status/1554217719612014592"
    }
  },
  {
    "like" : {
      "tweetId" : "1554349270513471488",
      "fullText" : "My current setup for PCB Layout 😋 https://t.co/4QOgwu3QiB",
      "expandedUrl" : "https://twitter.com/i/web/status/1554349270513471488"
    }
  },
  {
    "like" : {
      "tweetId" : "1554284672515211264",
      "fullText" : "We already have people running Arch, Fedora, Debian, Gentoo, and more on M1/M2 Macs. \n\nThough our Arch-based reference desktop distro still has a few nice unique touches, like the first-boot wizard with automatic keyboard layout/model and HiDPI detection 😉",
      "expandedUrl" : "https://twitter.com/i/web/status/1554284672515211264"
    }
  },
  {
    "like" : {
      "tweetId" : "1554239377114599429",
      "fullText" : "The ESP32Berry mounts a physical keyboard to ESP32 module for communication or note taking: https://t.co/tC8uVFi9fQ https://t.co/sPLBmlhiCJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1554239377114599429"
    }
  },
  {
    "like" : {
      "tweetId" : "1554147097099780097",
      "fullText" : "https://t.co/G1GiMuGzQT",
      "expandedUrl" : "https://twitter.com/i/web/status/1554147097099780097"
    }
  },
  {
    "like" : {
      "tweetId" : "1554237932948447232",
      "fullText" : "Anti-notch https://t.co/ev9MbZQDSK",
      "expandedUrl" : "https://twitter.com/i/web/status/1554237932948447232"
    }
  },
  {
    "like" : {
      "tweetId" : "1554014165458632705",
      "fullText" : "Self-Hosted Pi Pico Development https://t.co/pqZJmkUB0U",
      "expandedUrl" : "https://twitter.com/i/web/status/1554014165458632705"
    }
  },
  {
    "like" : {
      "tweetId" : "1554003021268680704",
      "fullText" : "@IshSookun Actually, it's an M2! :-)",
      "expandedUrl" : "https://twitter.com/i/web/status/1554003021268680704"
    }
  },
  {
    "like" : {
      "tweetId" : "1553968394734813184",
      "fullText" : "Linux 5.19 is out, and Linus Torvalds released it from an M2 MacBook Air running the Asahi Linux kernel! 🎉\n\nhttps://t.co/4fZ1ziN8Zj",
      "expandedUrl" : "https://twitter.com/i/web/status/1553968394734813184"
    }
  },
  {
    "like" : {
      "tweetId" : "1554008287318003712",
      "fullText" : "不思議の国の橘さん https://t.co/Qw7T43FaWQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1554008287318003712"
    }
  },
  {
    "like" : {
      "tweetId" : "1553331835052048384",
      "fullText" : "陽うらら https://t.co/vHhlDepAFZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1553331835052048384"
    }
  },
  {
    "like" : {
      "tweetId" : "1553349367859675137",
      "fullText" : "https://t.co/XM2lZsCQvb",
      "expandedUrl" : "https://twitter.com/i/web/status/1553349367859675137"
    }
  },
  {
    "like" : {
      "tweetId" : "1553684325824024577",
      "fullText" : "The Apple PowerColorStyleWriter was a PowerPC Macintosh and portable colour inkjet printer all in one. Battery life was measured in pages. https://t.co/XOL8UWtE1v",
      "expandedUrl" : "https://twitter.com/i/web/status/1553684325824024577"
    }
  },
  {
    "like" : {
      "tweetId" : "1553574861401980928",
      "fullText" : "The primary reason to become a computer engineer. https://t.co/Yk2bFf1Cbw",
      "expandedUrl" : "https://twitter.com/i/web/status/1553574861401980928"
    }
  },
  {
    "like" : {
      "tweetId" : "1553672538240086016",
      "fullText" : "Apple Extended Keyboard II with Binary Keypad. https://t.co/KQXoMgJJWu",
      "expandedUrl" : "https://twitter.com/i/web/status/1553672538240086016"
    }
  },
  {
    "like" : {
      "tweetId" : "1553691734630027265",
      "fullText" : "「月が綺麗ですね」と言わせてみせます❣️ https://t.co/O8R49a2J54",
      "expandedUrl" : "https://twitter.com/i/web/status/1553691734630027265"
    }
  },
  {
    "like" : {
      "tweetId" : "1553597338823917569",
      "fullText" : "This mac mini prototype form 2005 integrates an iPod on top for fast access to your music. https://t.co/rnl6JIGVrZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1553597338823917569"
    }
  },
  {
    "like" : {
      "tweetId" : "1553314831209472001",
      "fullText" : "Papercut Light Boxes combine multiple silhouette papers on different layers to obtain a stereoscopic pattern showing sparkling and beautiful colour in the dark https://t.co/jxEmAcRAkK https://t.co/KfShdfTULh",
      "expandedUrl" : "https://twitter.com/i/web/status/1553314831209472001"
    }
  },
  {
    "like" : {
      "tweetId" : "1553355893038776327",
      "fullText" : "Don’t miss @kattni’s CircuitPython talk at PyOhio later this morning:  https://t.co/nHH1UAVYKX",
      "expandedUrl" : "https://twitter.com/i/web/status/1553355893038776327"
    }
  },
  {
    "like" : {
      "tweetId" : "1553161426138570752",
      "fullText" : "Tasteful Noodz 😋🍜 https://t.co/jzldoDQ7zB",
      "expandedUrl" : "https://twitter.com/i/web/status/1553161426138570752"
    }
  },
  {
    "like" : {
      "tweetId" : "1552735426418450433",
      "fullText" : "This smart modular keyboard sports an E Ink display along with a haptic feedback knob: https://t.co/Yt6NT9PKsZ https://t.co/J3ap0lR4yq",
      "expandedUrl" : "https://twitter.com/i/web/status/1552735426418450433"
    }
  },
  {
    "like" : {
      "tweetId" : "1552969367863939073",
      "fullText" : "An aerial view of the Odeleite River reservoir in southern Portugal and its impressive resemblance to a mythical dragon \n\n[read more: https://t.co/WpOikaM3HJ]\n[source: https://t.co/e0fWIYasEo] https://t.co/7anHtrS5ps",
      "expandedUrl" : "https://twitter.com/i/web/status/1552969367863939073"
    }
  },
  {
    "like" : {
      "tweetId" : "1553038696877899778",
      "fullText" : "Three weeks from today is @CircuitPython Day! I'll be hosting a LIVE panel with Kattni, Jeff, Dan, and Tim from Adafruit. I want your questions!  Submit them here:  https://t.co/bfVU2USukj",
      "expandedUrl" : "https://twitter.com/i/web/status/1553038696877899778"
    }
  },
  {
    "like" : {
      "tweetId" : "1552655124597575680",
      "fullText" : "This video by YouTube channel NumaVIG shows how to make a 450 mm wingspan RC airplane out of cardboard box [source, full video: https://t.co/PslWKXwQuY] https://t.co/rNNUeL7Kcm",
      "expandedUrl" : "https://twitter.com/i/web/status/1552655124597575680"
    }
  },
  {
    "like" : {
      "tweetId" : "1552685289965064193",
      "fullText" : "Shh, don’t tell anyone.  (I’m working on some documentation for the Mu code editor) https://t.co/BrtZ5yPXBb",
      "expandedUrl" : "https://twitter.com/i/web/status/1552685289965064193"
    }
  },
  {
    "like" : {
      "tweetId" : "1552678043633713153",
      "fullText" : "Smart Modular Keyboard Sports an E-ink Display and a Haptic Feedback Knob https://t.co/XvsIbyUULa",
      "expandedUrl" : "https://twitter.com/i/web/status/1552678043633713153"
    }
  },
  {
    "like" : {
      "tweetId" : "1552682883646574592",
      "fullText" : "橘さん https://t.co/qKDmauYByg",
      "expandedUrl" : "https://twitter.com/i/web/status/1552682883646574592"
    }
  },
  {
    "like" : {
      "tweetId" : "1552472672721784832",
      "fullText" : "This walnut Johnson solid houses a \"largely impractical\" dual-screen gaming system. Built using a pair of circular displays and a @Raspberry_Pi  4, this compact console may lack practicality but oozes style! @Hacksterio  \n🎮 https://t.co/3njnpOB4yT https://t.co/QtkTHE51zX",
      "expandedUrl" : "https://twitter.com/i/web/status/1552472672721784832"
    }
  },
  {
    "like" : {
      "tweetId" : "1552463521325015040",
      "fullText" : "らくがき https://t.co/smCnq3HxOG",
      "expandedUrl" : "https://twitter.com/i/web/status/1552463521325015040"
    }
  },
  {
    "like" : {
      "tweetId" : "1552399188700405764",
      "fullText" : "Shirt Circuit: #DIY Wearable Breadboard Circuits https://t.co/ghmxyegTIG  #WearableWednesday via @instructables https://t.co/F3dK5OuelJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1552399188700405764"
    }
  },
  {
    "like" : {
      "tweetId" : "1552336445356085257",
      "fullText" : "There are 2,703 guides at the Adafruit Learning System! https://t.co/SolVEAZyO9 Come on by and check out the latest! https://t.co/r1LOLkgq0I https://t.co/Yzr4Hdel52",
      "expandedUrl" : "https://twitter.com/i/web/status/1552336445356085257"
    }
  },
  {
    "like" : {
      "tweetId" : "1552305957434179585",
      "fullText" : "@geerlingguy Time to endorse Jake for \"Jeff Geerling\" on LinkedIn.\n\n\"Jake is highly skilled at Jeff Geerling\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1552305957434179585"
    }
  },
  {
    "like" : {
      "tweetId" : "1551944002152407040",
      "fullText" : "🚨 New digital book out! 🚨\n\nBuild a Raspberry Pi Media Player is free to download right now from https://t.co/P7xyNDJsd6\n\n- Build an all-in-one media centre\n- Set up the ultimate file server\n- Create an amazing, multi-room music system\n\nAnd more! https://t.co/USZEZNiDSN",
      "expandedUrl" : "https://twitter.com/i/web/status/1551944002152407040"
    }
  },
  {
    "like" : {
      "tweetId" : "1552249812979896320",
      "fullText" : "モモフレンズ\n#ブルアカ https://t.co/f99IFIMblb",
      "expandedUrl" : "https://twitter.com/i/web/status/1552249812979896320"
    }
  },
  {
    "like" : {
      "tweetId" : "1552332689839075328",
      "fullText" : "四つ葉のクローバーみつけた！ https://t.co/tjtYufI2ar",
      "expandedUrl" : "https://twitter.com/i/web/status/1552332689839075328"
    }
  },
  {
    "like" : {
      "tweetId" : "1552015610804158464",
      "fullText" : "I just found an old post from when I finally printed the perfect enclosure for my first handheld project. I remember getting on Twitter just to talk to @arturo182 about his BlackBerry Keyboard project. This was four years ago. Started out a maker, now we’re here. https://t.co/59yer5rZCo",
      "expandedUrl" : "https://twitter.com/i/web/status/1552015610804158464"
    }
  },
  {
    "like" : {
      "tweetId" : "1551898230148849664",
      "fullText" : "@NoxGallery Elina＋と申します！\n素晴らしい企画をありがとうございます。\n働き蜂のメイドさんで応募いたします🐝🍯\n\nよろしくお願いいたします！\nhttps://t.co/0YGY9fCs79 https://t.co/iVUlA5LeGv",
      "expandedUrl" : "https://twitter.com/i/web/status/1551898230148849664"
    }
  },
  {
    "like" : {
      "tweetId" : "1551425130366005248",
      "fullText" : "https://t.co/T1oVXZXqpp",
      "expandedUrl" : "https://twitter.com/i/web/status/1551425130366005248"
    }
  },
  {
    "like" : {
      "tweetId" : "1551914599263649792",
      "fullText" : "when I still struggling Pico W not yet have HTTP client, I found I still play with TCP. #Arduino_GFX &amp; #ArduinoVNC https://t.co/UQwSH0lDfd",
      "expandedUrl" : "https://twitter.com/i/web/status/1551914599263649792"
    }
  },
  {
    "like" : {
      "tweetId" : "1551590860227284993",
      "fullText" : "https://t.co/wpWv7C4rIS",
      "expandedUrl" : "https://twitter.com/i/web/status/1551590860227284993"
    }
  },
  {
    "like" : {
      "tweetId" : "1551580913640898562",
      "fullText" : "Design files and test code for the ESP32-C3 1.54” E-Ink board is here: https://t.co/uWtSmTstBc @JLCPCB #esp32 #arduino https://t.co/NNYMhhfBWU",
      "expandedUrl" : "https://twitter.com/i/web/status/1551580913640898562"
    }
  },
  {
    "like" : {
      "tweetId" : "1551610782546378753",
      "fullText" : "The maintainer of tio stopped by the Adafruit Discord this morning after seeing this video.  We all got a chance to say thanks for this great tool.  Was pretty cool. https://t.co/OCIHoGs8mx",
      "expandedUrl" : "https://twitter.com/i/web/status/1551610782546378753"
    }
  },
  {
    "like" : {
      "tweetId" : "1551455975445393411",
      "fullText" : "Rear window sticker. https://t.co/BMX4rmY9N4",
      "expandedUrl" : "https://twitter.com/i/web/status/1551455975445393411"
    }
  },
  {
    "like" : {
      "tweetId" : "1551357637006016513",
      "fullText" : "ファンアートってことー https://t.co/SOAHDLRQWA",
      "expandedUrl" : "https://twitter.com/i/web/status/1551357637006016513"
    }
  },
  {
    "like" : {
      "tweetId" : "1550929284453335040",
      "fullText" : "Though this may look like some @NanoRaptor stuff, it is actually real: Bluetooth mod on a Casio F-91W. Details: https://t.co/O4oO5hBInU https://t.co/7D3s2k4SBQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1550929284453335040"
    }
  },
  {
    "like" : {
      "tweetId" : "1550609619470258176",
      "fullText" : "@TerribleMaps Coincidentally I was just thinking of this (IMO terrible) decision by my neighboring town... https://t.co/J16TyAGd4s",
      "expandedUrl" : "https://twitter.com/i/web/status/1550609619470258176"
    }
  },
  {
    "like" : {
      "tweetId" : "1550477457232261121",
      "fullText" : "Remembering Thinkfriend. I would stroke the top edge of the display, and the Enter key. https://t.co/3TPSPY4fvw",
      "expandedUrl" : "https://twitter.com/i/web/status/1550477457232261121"
    }
  },
  {
    "like" : {
      "tweetId" : "1550842799083425794",
      "fullText" : "@nfactes @Rainmaker1973 Yeah. Should have jumped in his DC-10 and airdropped a tank of fire retardant on it. That’s certainly what you would have done.",
      "expandedUrl" : "https://twitter.com/i/web/status/1550842799083425794"
    }
  },
  {
    "like" : {
      "tweetId" : "1550173086141513729",
      "fullText" : "These printable solar cells created by the University of Newcastle and CSIRO are flexible and can be printed like newspapers [📹: https://t.co/dfYiQ0oG6K]\nhttps://t.co/Nq6wIXZZb0",
      "expandedUrl" : "https://twitter.com/i/web/status/1550173086141513729"
    }
  },
  {
    "like" : {
      "tweetId" : "1549316361716989958",
      "fullText" : "黒猫ちゃん🐈‍⬛ https://t.co/CrimGgK0Z0",
      "expandedUrl" : "https://twitter.com/i/web/status/1549316361716989958"
    }
  },
  {
    "like" : {
      "tweetId" : "1550414886433263616",
      "fullText" : "シナモンミクさん　ぎゅっぎゅ！\n#初音ミク #シナミク https://t.co/huDKKvyohj",
      "expandedUrl" : "https://twitter.com/i/web/status/1550414886433263616"
    }
  },
  {
    "like" : {
      "tweetId" : "1550256932476203008",
      "fullText" : "ちゃん様ー\n#SB69 https://t.co/BmdoCk70Wt",
      "expandedUrl" : "https://twitter.com/i/web/status/1550256932476203008"
    }
  },
  {
    "like" : {
      "tweetId" : "1550107147945615360",
      "fullText" : "Listen to tunes on this @Arduino-driven 'slot-in' record player by inserting the record sleeve instead of the vinyl itself: https://t.co/aiXuoVoWyu https://t.co/hI7wrNU0QM",
      "expandedUrl" : "https://twitter.com/i/web/status/1550107147945615360"
    }
  },
  {
    "like" : {
      "tweetId" : "1550043620857856005",
      "fullText" : "@Rainmaker1973 https://t.co/4UdJgqfUhT",
      "expandedUrl" : "https://twitter.com/i/web/status/1550043620857856005"
    }
  },
  {
    "like" : {
      "tweetId" : "1550137563113213952",
      "fullText" : "はい！ポーズっ！ https://t.co/GN0lkgTk96",
      "expandedUrl" : "https://twitter.com/i/web/status/1550137563113213952"
    }
  },
  {
    "like" : {
      "tweetId" : "1549703944557203456",
      "fullText" : "たねやつさんのノブが届いたので付けました🙌白かわいい https://t.co/vmIgnTq9dL",
      "expandedUrl" : "https://twitter.com/i/web/status/1549703944557203456"
    }
  },
  {
    "like" : {
      "tweetId" : "1549836806904070144",
      "fullText" : "CircuitPython 7.3.2 Released! @circuitpython https://t.co/rm7ybfKrnY",
      "expandedUrl" : "https://twitter.com/i/web/status/1549836806904070144"
    }
  },
  {
    "like" : {
      "tweetId" : "1550075130222886912",
      "fullText" : "苺のハーバリウム🍓 https://t.co/9rNOTUnrHu",
      "expandedUrl" : "https://twitter.com/i/web/status/1550075130222886912"
    }
  },
  {
    "like" : {
      "tweetId" : "1549797018763132929",
      "fullText" : "I see there is a new release of CircuitPython on https://t.co/gyFGfqI4Sl - check it out! https://t.co/lN1JqfURfo",
      "expandedUrl" : "https://twitter.com/i/web/status/1549797018763132929"
    }
  },
  {
    "like" : {
      "tweetId" : "1550012845273800705",
      "fullText" : "Printing the 6000 mAh #sharpikeebo enclosure prototype. https://t.co/NcSisa0RHu",
      "expandedUrl" : "https://twitter.com/i/web/status/1550012845273800705"
    }
  },
  {
    "like" : {
      "tweetId" : "1549847742201176065",
      "fullText" : "CircuitPython 7.3.2 Released! circuitpython  https://t.co/oFz3AybqJ5",
      "expandedUrl" : "https://twitter.com/i/web/status/1549847742201176065"
    }
  },
  {
    "like" : {
      "tweetId" : "1549614621320851462",
      "fullText" : "今日の薫ちゃんひまわりみたい https://t.co/q5fwD23DzW",
      "expandedUrl" : "https://twitter.com/i/web/status/1549614621320851462"
    }
  },
  {
    "like" : {
      "tweetId" : "1549409932688371712",
      "fullText" : "薫ちゃんおめでとう🌻\n#龍崎薫生誕祭2022 https://t.co/Kbaj7soO4g",
      "expandedUrl" : "https://twitter.com/i/web/status/1549409932688371712"
    }
  },
  {
    "like" : {
      "tweetId" : "1548989214641225729",
      "fullText" : "3連休明けに出社するときのワイ https://t.co/zOefNnmmVH",
      "expandedUrl" : "https://twitter.com/i/web/status/1548989214641225729"
    }
  },
  {
    "like" : {
      "tweetId" : "1549357784118198272",
      "fullText" : "乙倉ちゃんと颯ちゃん https://t.co/98NfLX4IkO",
      "expandedUrl" : "https://twitter.com/i/web/status/1549357784118198272"
    }
  },
  {
    "like" : {
      "tweetId" : "1549103470019596291",
      "fullText" : "@DavesArmoury @CobotMy Breakfast with @SimoneGiertz https://t.co/vaJtK25JTd",
      "expandedUrl" : "https://twitter.com/i/web/status/1549103470019596291"
    }
  },
  {
    "like" : {
      "tweetId" : "1548661021501714432",
      "fullText" : "https://t.co/54oCXzl49i",
      "expandedUrl" : "https://twitter.com/i/web/status/1548661021501714432"
    }
  },
  {
    "like" : {
      "tweetId" : "1549027472083226625",
      "fullText" : "A PCB touch keypad with Raspberry Pi Pico #CircuitPython @bobricius @Raspberry_Pi https://t.co/Q2ug8nSaAq",
      "expandedUrl" : "https://twitter.com/i/web/status/1549027472083226625"
    }
  },
  {
    "like" : {
      "tweetId" : "1548959532965318657",
      "fullText" : "nrf52840 circuitpythonであっさりBLEでの接続動作ok。これならメモ帳でkeymapを編集できるから開発環境を整えずに使える https://t.co/vWWHMbWpzO",
      "expandedUrl" : "https://twitter.com/i/web/status/1548959532965318657"
    }
  },
  {
    "like" : {
      "tweetId" : "1549017231228485632",
      "fullText" : "Glare1more やりました\nグレアかわいい https://t.co/67wo3fJyB5",
      "expandedUrl" : "https://twitter.com/i/web/status/1549017231228485632"
    }
  },
  {
    "like" : {
      "tweetId" : "1548850175426400258",
      "fullText" : "#ShaRPIKeebo - New enclosure, leather finish. @Raspberry_Pi @RaspberryPiFR with RPI ZERO 2W and #lora @RAKwireless chip.  https://t.co/dfUOPt5YW2 https://t.co/i25owH1qgt",
      "expandedUrl" : "https://twitter.com/i/web/status/1548850175426400258"
    }
  },
  {
    "like" : {
      "tweetId" : "1548924613396090880",
      "fullText" : "お！プロデューサー！梨沙！ https://t.co/tnPu2z7FZG",
      "expandedUrl" : "https://twitter.com/i/web/status/1548924613396090880"
    }
  },
  {
    "like" : {
      "tweetId" : "1548578252159127552",
      "fullText" : "ふわふわゆめゆめ https://t.co/O60LJDsb3H",
      "expandedUrl" : "https://twitter.com/i/web/status/1548578252159127552"
    }
  },
  {
    "like" : {
      "tweetId" : "1548693134825197568",
      "fullText" : "How is your weekend going?  Anyone work on any fun projects?  I tried learning about displayio and contributed to Mu for the first time!",
      "expandedUrl" : "https://twitter.com/i/web/status/1548693134825197568"
    }
  },
  {
    "like" : {
      "tweetId" : "1548600487003705344",
      "fullText" : "できた！！！！！！！！！ https://t.co/LEGBZkCZ0u",
      "expandedUrl" : "https://twitter.com/i/web/status/1548600487003705344"
    }
  },
  {
    "like" : {
      "tweetId" : "1548593795536523264",
      "fullText" : "❤️🤍🖤 https://t.co/OQWa5r8Cs5",
      "expandedUrl" : "https://twitter.com/i/web/status/1548593795536523264"
    }
  },
  {
    "like" : {
      "tweetId" : "1548599670867386368",
      "fullText" : "Building a LEGO-powered Submarine with automatic depth control\n\n[📹 YouTube's Brick Experiment Channel: https://t.co/HT8gLJMjEt]\n\nhttps://t.co/P03KZDEHmR",
      "expandedUrl" : "https://twitter.com/i/web/status/1548599670867386368"
    }
  },
  {
    "like" : {
      "tweetId" : "1547819869864767490",
      "fullText" : "Playing around with backlighting the Sharp LCD Displays with Side Lit Neopixels. \n\nThis is what it looks like with 6 of them on full brightness. \n\nBeen wanting to do this for for some time now. \n\nI just modified @adafruit white backlight panels to get this example working. https://t.co/Snx7CavtNO",
      "expandedUrl" : "https://twitter.com/i/web/status/1547819869864767490"
    }
  },
  {
    "like" : {
      "tweetId" : "1548091620662185992",
      "fullText" : "I present to you: a bad idea done well. https://t.co/luTkADVt00",
      "expandedUrl" : "https://twitter.com/i/web/status/1548091620662185992"
    }
  },
  {
    "like" : {
      "tweetId" : "1544346359641190400",
      "fullText" : "i look forward to lots more warm days spent with you ✨❤️\n\nart by @yukkieeeeeen\n#sliceofshadow https://t.co/XyJ4hzIwjR",
      "expandedUrl" : "https://twitter.com/i/web/status/1544346359641190400"
    }
  },
  {
    "like" : {
      "tweetId" : "1545106717909868551",
      "fullText" : "Look at THIS! Little Chloe is a little air traveler! She's off to Europe for a few weeks. She is having a blast on the plane! 🌎️✈️ 🌍️\n\nWonderful art delivered by @yukkieeeeeen 💝 Thank you!\n\n https://t.co/PXuuXAHakh #Skeb #Commission via @skeb_jp https://t.co/SALwJJEasq",
      "expandedUrl" : "https://twitter.com/i/web/status/1545106717909868551"
    }
  },
  {
    "like" : {
      "tweetId" : "1544840186265214976",
      "fullText" : "僕の一番好きなイラストレーター(@yukkieeeeeen )が僕の子を描きました！見るよ！可愛くない！？\n\nめっちゃ好き、ありがとうございます！！☺️💕 https://t.co/DagWTiKAZt",
      "expandedUrl" : "https://twitter.com/i/web/status/1544840186265214976"
    }
  },
  {
    "like" : {
      "tweetId" : "1548252703930798082",
      "fullText" : "https://t.co/Wj3HlPvceD",
      "expandedUrl" : "https://twitter.com/i/web/status/1548252703930798082"
    }
  },
  {
    "like" : {
      "tweetId" : "1548213915070636033",
      "fullText" : "その遊具楽しいよね https://t.co/pZF97LbSDb",
      "expandedUrl" : "https://twitter.com/i/web/status/1548213915070636033"
    }
  },
  {
    "like" : {
      "tweetId" : "1548121737736249344",
      "fullText" : "How many times can someone change the display on their open source game system? Sharp memory LCD viewable inside a GBA case. \"Opendate\"? https://t.co/BfwZzQoTzq",
      "expandedUrl" : "https://twitter.com/i/web/status/1548121737736249344"
    }
  },
  {
    "like" : {
      "tweetId" : "1547755539827830784",
      "fullText" : "This is how we digitize the books in our physical library collection. We turn every page by hand to avoid damaging the spine and pages ❤️ 📖 #lovebooks #EmpoweringLibraries https://t.co/axmWLZAe8P",
      "expandedUrl" : "https://twitter.com/i/web/status/1547755539827830784"
    }
  },
  {
    "like" : {
      "tweetId" : "1547938621604343808",
      "fullText" : "Easily program three ATtiny chips at once with this Arduino shield: https://t.co/fPO3NZxMGV https://t.co/lCjz7HlkRd",
      "expandedUrl" : "https://twitter.com/i/web/status/1547938621604343808"
    }
  },
  {
    "like" : {
      "tweetId" : "1547529097483587587",
      "fullText" : "If you missed the PewPew workshops on #EuroPython2022, we are going to do an ad-hoc workshop today after lunch at the makerfest tables at the ground floor. Come and try writing a game in @CircuitPython. https://t.co/gG9ZkrED8B",
      "expandedUrl" : "https://twitter.com/i/web/status/1547529097483587587"
    }
  },
  {
    "like" : {
      "tweetId" : "1547342413970100224",
      "fullText" : "Happy birthday me. 51!",
      "expandedUrl" : "https://twitter.com/i/web/status/1547342413970100224"
    }
  },
  {
    "like" : {
      "tweetId" : "1547323890552160256",
      "fullText" : "The Ceres 1 @Raspberry_Pi cyberdeck repurposes a vintage VTech Talking Whiz Kid: https://t.co/M2WY82H9gH https://t.co/IQfO0TCuXN",
      "expandedUrl" : "https://twitter.com/i/web/status/1547323890552160256"
    }
  },
  {
    "like" : {
      "tweetId" : "1546866287757893634",
      "fullText" : "This chunky spin-off of Penk Chen's Penkēsu @Raspberry_Pi portable packs a Nomu30 keyboard: https://t.co/GlYP2E08Uf https://t.co/dm8RvAyfCY",
      "expandedUrl" : "https://twitter.com/i/web/status/1546866287757893634"
    }
  },
  {
    "like" : {
      "tweetId" : "1546982044219199490",
      "fullText" : "#PicoTouch HMI @Raspberry_Pi PICO based single board panel. Amazing #circuitpython libraries with mp3, touch and ips display support. Minimum components. SD card, RTC and some free GPIO are ready to use in my next projects. https://t.co/2hp8bSUkBU",
      "expandedUrl" : "https://twitter.com/i/web/status/1546982044219199490"
    }
  },
  {
    "like" : {
      "tweetId" : "1547214824706379776",
      "fullText" : "The TinyCADE is a credit card-sized gaming device featuring a grayscale OLED, chiptune synth, and SD card support: https://t.co/Q1Yw3Z7fQD https://t.co/amoR3YyPvV",
      "expandedUrl" : "https://twitter.com/i/web/status/1547214824706379776"
    }
  },
  {
    "like" : {
      "tweetId" : "1546515194612006917",
      "fullText" : "@circuitpyshow So lovely to hear old colleague Nicholas Tollervey talking about CircuitPython, doing such brilliant work! I recently went looking trying to find out how to do dependency management with CircuitPython, and found he'd made the wonderful circup! 💜 https://t.co/H7EbDxJCmk",
      "expandedUrl" : "https://twitter.com/i/web/status/1546515194612006917"
    }
  },
  {
    "like" : {
      "tweetId" : "1546442804607565825",
      "fullText" : "New episode!  Nicholas Tollervey joins the show and shares his coding journey, talks creating the Mu code editor, and we talk about music and coding education.  Listen: https://t.co/pY2KcZe9pz",
      "expandedUrl" : "https://twitter.com/i/web/status/1546442804607565825"
    }
  },
  {
    "like" : {
      "tweetId" : "1546257495295168512",
      "fullText" : "普通のペンむずかしかった https://t.co/XaWqn5ZwpG",
      "expandedUrl" : "https://twitter.com/i/web/status/1546257495295168512"
    }
  },
  {
    "like" : {
      "tweetId" : "1545915174208430080",
      "fullText" : "New jig works perfectly! So much faster than the old way.\n\nI might add a toggle clamp to hold the panel down for me, but a full flash &amp; test cycle is only 12 seconds. https://t.co/qDaMniVfHb https://t.co/HYKrAIolP0",
      "expandedUrl" : "https://twitter.com/i/web/status/1545915174208430080"
    }
  },
  {
    "like" : {
      "tweetId" : "1546153144933298178",
      "fullText" : "What your coffee says about the average Linux user ... https://t.co/jlQH2kUsw4 https://t.co/MRsSki9Pwa",
      "expandedUrl" : "https://twitter.com/i/web/status/1546153144933298178"
    }
  },
  {
    "like" : {
      "tweetId" : "1545831214552154112",
      "fullText" : "@Foone Man Nintendo really genuinely tried with this one too. There are less than 8 total switch-vr games.\nhttps://t.co/3MGwHyaD8o",
      "expandedUrl" : "https://twitter.com/i/web/status/1545831214552154112"
    }
  },
  {
    "like" : {
      "tweetId" : "1545784491670650882",
      "fullText" : "Production has begun for the Popcorn Computer Pocket PC, a handheld Linux computer with a 5 inch 1080p display and a thumb keyboard that was first announced three years ago, and which is up for pre-order for $299. https://t.co/prGrQBUPgH https://t.co/mwl5qoQwAd",
      "expandedUrl" : "https://twitter.com/i/web/status/1545784491670650882"
    }
  },
  {
    "like" : {
      "tweetId" : "1546047530143981571",
      "fullText" : "🏵🧡 https://t.co/7Q2UO6xx93",
      "expandedUrl" : "https://twitter.com/i/web/status/1546047530143981571"
    }
  },
  {
    "like" : {
      "tweetId" : "1546015892613791744",
      "fullText" : "https://t.co/4IGkHNPe39",
      "expandedUrl" : "https://twitter.com/i/web/status/1546015892613791744"
    }
  },
  {
    "like" : {
      "tweetId" : "1546015883507933185",
      "fullText" : "It only looks good from one angle, but it looks very good.  Wallpaper in the next reply. https://t.co/FRlTlrBPMk https://t.co/o50xpydR0f",
      "expandedUrl" : "https://twitter.com/i/web/status/1546015883507933185"
    }
  },
  {
    "like" : {
      "tweetId" : "1545676976085663744",
      "fullText" : "Apple has confirmed due to supply chain issues the M2 MacBook Air will replace MagSafe 3 with the 30 Pin Dock Connector https://t.co/hQJAZlKoH7",
      "expandedUrl" : "https://twitter.com/i/web/status/1545676976085663744"
    }
  },
  {
    "like" : {
      "tweetId" : "1545209112840941568",
      "fullText" : "たまには、ルンバも外ではっちゃけたい。アーティスト、パブロ・ロシャットの作品。\n\n https://t.co/qhDOdbLeJl",
      "expandedUrl" : "https://twitter.com/i/web/status/1545209112840941568"
    }
  },
  {
    "like" : {
      "tweetId" : "1545671053854195712",
      "fullText" : "Ok so I might be going crazy here but what if... custom RF can as a case? How to mount it though, hot air will torch the OLED maybe hand solder from the bottom with little tabs? https://t.co/XA24fLLtwn",
      "expandedUrl" : "https://twitter.com/i/web/status/1545671053854195712"
    }
  },
  {
    "like" : {
      "tweetId" : "1545661002087546881",
      "fullText" : "#絵柄が好みって人にフォローされたい https://t.co/B6ZYNcsnBv",
      "expandedUrl" : "https://twitter.com/i/web/status/1545661002087546881"
    }
  },
  {
    "like" : {
      "tweetId" : "1545344702127505408",
      "fullText" : "On the hunt for nice ways to display sensor data I came across this example using a round display. Have only seen them used as a watch before this. https://t.co/oMkJtsj03b",
      "expandedUrl" : "https://twitter.com/i/web/status/1545344702127505408"
    }
  },
  {
    "like" : {
      "tweetId" : "1545601951135682562",
      "fullText" : "Put your memory to the test with this PIC16F-powered, Simon-like PCB game: https://t.co/5KJF5vv429 https://t.co/3YMQenANvX",
      "expandedUrl" : "https://twitter.com/i/web/status/1545601951135682562"
    }
  },
  {
    "like" : {
      "tweetId" : "1544948344191066112",
      "fullText" : "Happy to show you the first prototype of Humble iCE - an FPGA dev board based on @latticesemi iCE40UP5k and @Raspberry_Pi RP2040. My motivation for designing this board: (1/3) https://t.co/AfMsgPEoBm",
      "expandedUrl" : "https://twitter.com/i/web/status/1544948344191066112"
    }
  },
  {
    "like" : {
      "tweetId" : "1545229183994908674",
      "fullText" : ".@seeedstudio has launched a new XIAO board with #ESP32-C3 wireless MCU, support for LiPo batteries. #arduino #ble #wifi #IoT \n\nhttps://t.co/6Ba8OgiDfX",
      "expandedUrl" : "https://twitter.com/i/web/status/1545229183994908674"
    }
  },
  {
    "like" : {
      "tweetId" : "1392046788706594816",
      "fullText" : "🎠🎂💗(縦長再掲) https://t.co/fjgX6sj2yc",
      "expandedUrl" : "https://twitter.com/i/web/status/1392046788706594816"
    }
  },
  {
    "like" : {
      "tweetId" : "1545458379132473348",
      "fullText" : ".@SeeedStudio launches compact RISC-V XIAO ESP32-C3 for battery-powered wearable and IoT projects: https://t.co/L2PUvmpf5l https://t.co/i2Z8cakILe",
      "expandedUrl" : "https://twitter.com/i/web/status/1545458379132473348"
    }
  },
  {
    "like" : {
      "tweetId" : "1544399463061626882",
      "fullText" : "This years @BornHax badge, will include a @Raspberry_Pi RP2040, color screen and buttons for a great homebrew handheld gaming experience. The badge will have @CircuitPython preloaded for easy hacking. See all the details at https://t.co/X3iJMCJnek https://t.co/N3Qm9whcQ6",
      "expandedUrl" : "https://twitter.com/i/web/status/1544399463061626882"
    }
  },
  {
    "like" : {
      "tweetId" : "1544632489024507904",
      "fullText" : "Look！マリンルック！ https://t.co/9hhyYvzGaM",
      "expandedUrl" : "https://twitter.com/i/web/status/1544632489024507904"
    }
  },
  {
    "like" : {
      "tweetId" : "1544715890238840833",
      "fullText" : "Protip to anyone wanting low latency,high sample rate pointer events in their web apps. Especially useful in drawing apps for smoother strokes.\n\nNew in Chrome/Firefox is PointerEvent.getCoalescedEvents(). Gets you more position samples. Blue dots are positions you miss without it https://t.co/SJ77BM9xan",
      "expandedUrl" : "https://twitter.com/i/web/status/1544715890238840833"
    }
  },
  {
    "like" : {
      "tweetId" : "1544890153650593792",
      "fullText" : "@NanoRaptor IBM 3290 plasma terminal. https://t.co/quCy3aBsyy",
      "expandedUrl" : "https://twitter.com/i/web/status/1544890153650593792"
    }
  },
  {
    "like" : {
      "tweetId" : "1545014079181684737",
      "fullText" : "星飾り #七夕 https://t.co/OtaqduJEmV",
      "expandedUrl" : "https://twitter.com/i/web/status/1545014079181684737"
    }
  },
  {
    "like" : {
      "tweetId" : "1544570682154987521",
      "fullText" : "てるミが「おえかき」でライブ配信中！ https://t.co/NsNaqhwrfZ #pixivSketch",
      "expandedUrl" : "https://twitter.com/i/web/status/1544570682154987521"
    }
  },
  {
    "like" : {
      "tweetId" : "1544804313846915072",
      "fullText" : "I’m playing around with Adafruit’s Wippersnapper firmware and Adafruit IO for a future podcast episode.  Really cool! https://t.co/cxbNFAQqQJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1544804313846915072"
    }
  },
  {
    "like" : {
      "tweetId" : "1544652315684225025",
      "fullText" : "The new @Raspberry_Pi Pico W with the @pimoroni breakout garden submitting MQTT data every second. 35000 successes, 0 failures https://t.co/3yZVB5eJlI",
      "expandedUrl" : "https://twitter.com/i/web/status/1544652315684225025"
    }
  },
  {
    "like" : {
      "tweetId" : "1544378303703760898",
      "fullText" : "https://t.co/25PCwFLaGq is CRAZY fast⚡️ I mean CRAZY 🤯\ncreated by @jarredsumner https://t.co/3ulNGjVIly",
      "expandedUrl" : "https://twitter.com/i/web/status/1544378303703760898"
    }
  },
  {
    "like" : {
      "tweetId" : "1544299303354699777",
      "fullText" : "New Mario Kart DS track https://t.co/q3yHL9QCIu",
      "expandedUrl" : "https://twitter.com/i/web/status/1544299303354699777"
    }
  },
  {
    "like" : {
      "tweetId" : "1544265226199207937",
      "fullText" : "Storm clouds, Texas #NaturePhotography https://t.co/BzbM12Asiz",
      "expandedUrl" : "https://twitter.com/i/web/status/1544265226199207937"
    }
  },
  {
    "like" : {
      "tweetId" : "1544511292526010368",
      "fullText" : "The not yet released Macbook Cinema Pro. With focus on great ergonomics and productivity with the location of a bigger touchpad and a really wide screen. Also a revamped speaker system. https://t.co/p29uaYl9OA",
      "expandedUrl" : "https://twitter.com/i/web/status/1544511292526010368"
    }
  },
  {
    "like" : {
      "tweetId" : "1544443718228385794",
      "fullText" : "preparing something cool with the CM4 https://t.co/r8ogToddEy",
      "expandedUrl" : "https://twitter.com/i/web/status/1544443718228385794"
    }
  },
  {
    "like" : {
      "tweetId" : "1544334004039581696",
      "fullText" : "Petr Vacek's Fluidum kinetic sculpture uses robotic mirrors to create waves and play hypnotic games with visitor's mind [author's Instagram account: https://t.co/1LiXHT1GW7] [author's site: https://t.co/XFNCjcs9mC] https://t.co/JrDnkEzNIf",
      "expandedUrl" : "https://twitter.com/i/web/status/1544334004039581696"
    }
  },
  {
    "like" : {
      "tweetId" : "1544208858033164288",
      "fullText" : "@River___Wang Just three switches! Left and right at the same time is counted as down.",
      "expandedUrl" : "https://twitter.com/i/web/status/1544208858033164288"
    }
  },
  {
    "like" : {
      "tweetId" : "1544237386582081537",
      "fullText" : "#ZUTOMAYO_CARD \n #ずとまよファンアート \n\n応募しました！\n勘ぐれい/お勉強しといてよ https://t.co/mgsCFzS0cg",
      "expandedUrl" : "https://twitter.com/i/web/status/1544237386582081537"
    }
  },
  {
    "like" : {
      "tweetId" : "1544282008335319041",
      "fullText" : "カワイイボクと女子小学生Ｐ！３(2020年2月発行の同人誌)\npixivで全ページ公開しました\nhttps://t.co/MSjXdkY9a4 https://t.co/p7OJWqLu9W",
      "expandedUrl" : "https://twitter.com/i/web/status/1544282008335319041"
    }
  },
  {
    "like" : {
      "tweetId" : "1543958306817019905",
      "fullText" : "Happy 10-year anniversary to the greatest fireworks show in history, when San Diego accidentally shot off 7,000 fireworks at once. \n\n🇺🇸🇺🇸🇺🇸🇺🇸🇺🇸 https://t.co/qihO4zeXP3",
      "expandedUrl" : "https://twitter.com/i/web/status/1543958306817019905"
    }
  },
  {
    "like" : {
      "tweetId" : "1544055232011075584",
      "fullText" : "https://t.co/afZZSsYnWl",
      "expandedUrl" : "https://twitter.com/i/web/status/1544055232011075584"
    }
  },
  {
    "like" : {
      "tweetId" : "1543605665553334273",
      "fullText" : "I think I might have doubled the battery life of the #opensmartwatch mono-edition from 30 to ~80 days. 🤓\n\nBy fiddling with the ArduinoFramework I added a hook before all the software gets initialised. Custom bootloader to skip logging and image verification. https://t.co/0yj8aqMHtI",
      "expandedUrl" : "https://twitter.com/i/web/status/1543605665553334273"
    }
  },
  {
    "like" : {
      "tweetId" : "1543823400669708289",
      "fullText" : "#ZUTOMAYO_CARD\n #ずとまよファンアート \n\nBoooom! https://t.co/6VetghhzjU",
      "expandedUrl" : "https://twitter.com/i/web/status/1543823400669708289"
    }
  },
  {
    "like" : {
      "tweetId" : "1544064703143493633",
      "fullText" : "And as plug https://t.co/YbcCedwxc3",
      "expandedUrl" : "https://twitter.com/i/web/status/1544064703143493633"
    }
  },
  {
    "like" : {
      "tweetId" : "1544030608824963084",
      "fullText" : "5 Minute project: Simple Type C breakout.  Allows you to solder to a cable.  The big hole is for the cable strain relief. https://t.co/GSp8hd1wGz",
      "expandedUrl" : "https://twitter.com/i/web/status/1544030608824963084"
    }
  },
  {
    "like" : {
      "tweetId" : "1544057477242966016",
      "fullText" : "In my headcanon I take credit for and give apologies for the iMac G5 chin. This one, from December 2000. That wasn't just a screenshot of some random classic machine either, it's from the 8100 I used as my main at the time. https://t.co/XMsptv3BAG",
      "expandedUrl" : "https://twitter.com/i/web/status/1544057477242966016"
    }
  },
  {
    "like" : {
      "tweetId" : "1543987135849562113",
      "fullText" : "The PocketRadio is an ATtiny402/412-controlled FM radio with RDS and an OLED display: https://t.co/x4w7ERCoDW https://t.co/Y1dmHKdHYi",
      "expandedUrl" : "https://twitter.com/i/web/status/1543987135849562113"
    }
  },
  {
    "like" : {
      "tweetId" : "1542026595615277056",
      "fullText" : "『思ったより満喫しちゃってるな、ニューヨーク。Pサンも楽しんでる？』\n\nSSレアの砂塚あきらちゃん登場です！\n\nhttps://t.co/mIoEjCkNq4 #デレステ https://t.co/P1aExv1itx",
      "expandedUrl" : "https://twitter.com/i/web/status/1542026595615277056"
    }
  },
  {
    "like" : {
      "tweetId" : "1543017177476829184",
      "fullText" : "Here we go, it's a little more awesome now. New code: https://t.co/EEbOVZRpge https://t.co/kBYvgCJFih",
      "expandedUrl" : "https://twitter.com/i/web/status/1543017177476829184"
    }
  },
  {
    "like" : {
      "tweetId" : "1543629612453957646",
      "fullText" : "@NanoRaptor CapaCity",
      "expandedUrl" : "https://twitter.com/i/web/status/1543629612453957646"
    }
  },
  {
    "like" : {
      "tweetId" : "1543515033623461892",
      "fullText" : "https://t.co/MfKwth2CYs",
      "expandedUrl" : "https://twitter.com/i/web/status/1543515033623461892"
    }
  },
  {
    "like" : {
      "tweetId" : "1543577725272825856",
      "fullText" : "Sometimes you can look back at perfect footprints in the past, of our technology journey \n\nLike this fully working fan from the 1800s, functioning on kerosine, sterling engine technology converting thermal energy into kinetic energy \n https://t.co/wDpOvIapYM",
      "expandedUrl" : "https://twitter.com/i/web/status/1543577725272825856"
    }
  },
  {
    "like" : {
      "tweetId" : "1543567408467562497",
      "fullText" : "🦈 https://t.co/7i1qqYri8D",
      "expandedUrl" : "https://twitter.com/i/web/status/1543567408467562497"
    }
  },
  {
    "like" : {
      "tweetId" : "1543567682704146433",
      "fullText" : "あきらちゃん https://t.co/3alTYr0PI2",
      "expandedUrl" : "https://twitter.com/i/web/status/1543567682704146433"
    }
  },
  {
    "like" : {
      "tweetId" : "1543581274727645185",
      "fullText" : "Curious what's under the shield of the new @Raspberry_Pi Pico W? Wonder no more! ☺️📸 https://t.co/5ZpFjPFSeb",
      "expandedUrl" : "https://twitter.com/i/web/status/1543581274727645185"
    }
  },
  {
    "like" : {
      "tweetId" : "1543588548129210368",
      "fullText" : "Macintosh System 7 https://t.co/mHGyN5vR4m",
      "expandedUrl" : "https://twitter.com/i/web/status/1543588548129210368"
    }
  },
  {
    "like" : {
      "tweetId" : "1543447993525088257",
      "fullText" : "Despite the 3.5\" Magneto-Optical disk's many advantages - Much larger, more reliable and resilient storage, a bright backlight, and a high-resolution active matrix colour screen - it still failed to make inroads against sales of the older ubiquitous 3.5\" floppy disk. https://t.co/7fE2dAzE3u",
      "expandedUrl" : "https://twitter.com/i/web/status/1543447993525088257"
    }
  },
  {
    "like" : {
      "tweetId" : "1542925644459216896",
      "fullText" : "My latest silliness in #CircuitPython: a round display knob like what's been all the rage. Secret sauce is cool hollow rotary encoder and some clever 3d printed structures (if I say so myself). Not done yet but it kinda works! Running on an @adafruit QTPy RP2040 https://t.co/m6clhlt7iC",
      "expandedUrl" : "https://twitter.com/i/web/status/1542925644459216896"
    }
  },
  {
    "like" : {
      "tweetId" : "1542855251145162757",
      "fullText" : "CircuitPython　Seeed XIAO BLE Sense\nBLEで最近覚えたこと\n二つもある。\nlocal nameがつけられる。これは、ソースを読んで気が付いた\nconnectを表示する前にアドバタイジングをやめるコマンドがあることを知った。これは、examplesに入っていた https://t.co/Kl5L4vD71Z",
      "expandedUrl" : "https://twitter.com/i/web/status/1542855251145162757"
    }
  },
  {
    "like" : {
      "tweetId" : "1543191722687348738",
      "fullText" : "IBM ThinkBoy https://t.co/uc7CWq58dz",
      "expandedUrl" : "https://twitter.com/i/web/status/1543191722687348738"
    }
  },
  {
    "like" : {
      "tweetId" : "1543175325323915264",
      "fullText" : "輿水幸子あるある(2019年8月発行の同人誌)\npixivで全ページ公開しました\nhttps://t.co/eEaOEpBjmY https://t.co/aM9AMy1nHH",
      "expandedUrl" : "https://twitter.com/i/web/status/1543175325323915264"
    }
  },
  {
    "like" : {
      "tweetId" : "1543164813102432256",
      "fullText" : "マリン🛟⚓️ https://t.co/e2IrdAomU9",
      "expandedUrl" : "https://twitter.com/i/web/status/1543164813102432256"
    }
  },
  {
    "like" : {
      "tweetId" : "1543209711981719554",
      "fullText" : "あ、凪おねーさんだ https://t.co/vFkSpWQAvH",
      "expandedUrl" : "https://twitter.com/i/web/status/1543209711981719554"
    }
  },
  {
    "like" : {
      "tweetId" : "1542953686787317767",
      "fullText" : "The Cistercian numerals are a forgotten number system, developed by the Cistercian monastic order in the early thirteenth century, much more compact than Arabic or Roman numerals: with a single character you could write any integer from 1 to 9999 [more: https://t.co/8TS1FZkGko] https://t.co/773aUiXQv2",
      "expandedUrl" : "https://twitter.com/i/web/status/1542953686787317767"
    }
  },
  {
    "like" : {
      "tweetId" : "1542938080969203713",
      "fullText" : "Python off by one error? https://t.co/84U5jZvU25",
      "expandedUrl" : "https://twitter.com/i/web/status/1542938080969203713"
    }
  },
  {
    "like" : {
      "tweetId" : "1542636308929347585",
      "fullText" : "４段の倒立に挑戦 https://t.co/FFC5GHMBrD",
      "expandedUrl" : "https://twitter.com/i/web/status/1542636308929347585"
    }
  },
  {
    "like" : {
      "tweetId" : "1542817494280261633",
      "fullText" : "カワイイボクが教える！ポジティブになるための三箇条！(2019年5月発行の同人誌)\npixivで全ページ公開しました\nhttps://t.co/hVcUeEO4B3 https://t.co/DlvEmb4SUI",
      "expandedUrl" : "https://twitter.com/i/web/status/1542817494280261633"
    }
  },
  {
    "like" : {
      "tweetId" : "1542887297292521472",
      "fullText" : "見て……プロデューサー…… https://t.co/afybNJkyBz",
      "expandedUrl" : "https://twitter.com/i/web/status/1542887297292521472"
    }
  },
  {
    "like" : {
      "tweetId" : "1542530194296242176",
      "fullText" : ".@Pimoroni celebrates the @Raspberry_Pi Pico W launch with an explosion of \"Pico W Aboard\" carriers: https://t.co/OKupUEBcnv https://t.co/Wz0Tl0BXLO",
      "expandedUrl" : "https://twitter.com/i/web/status/1542530194296242176"
    }
  },
  {
    "like" : {
      "tweetId" : "1542532819313799169",
      "fullText" : "暑いからスイカ買ってきた https://t.co/HY2G0gBM9P",
      "expandedUrl" : "https://twitter.com/i/web/status/1542532819313799169"
    }
  },
  {
    "like" : {
      "tweetId" : "1542578644261945345",
      "fullText" : "A little gift from @Raspberry_Pi was waiting when I got home. Thank you! Neat! https://t.co/VsUeUuI5LI",
      "expandedUrl" : "https://twitter.com/i/web/status/1542578644261945345"
    }
  },
  {
    "like" : {
      "tweetId" : "1542455292826648576",
      "fullText" : "本当はカワイイおとぎ話(2018年12月発行の同人誌)\npixivで全ページ公開しました\nhttps://t.co/yCoyVApItT https://t.co/bKDLgt7Mdn",
      "expandedUrl" : "https://twitter.com/i/web/status/1542455292826648576"
    }
  },
  {
    "like" : {
      "tweetId" : "1541889525806505988",
      "fullText" : "On the latest episode, @gvy_dvpont joins the show!  We talk his Subaru backup camera project, MacroPad and more.  Watch on YouTube if video is your thing:  https://t.co/gV2fsTrnZw or subscribe to the podcast: https://t.co/P9EwqLC5IX",
      "expandedUrl" : "https://twitter.com/i/web/status/1541889525806505988"
    }
  },
  {
    "like" : {
      "tweetId" : "1542402377164234752",
      "fullText" : "Introducing the $6 Raspberry Pi Pico W, the RP2040-based microcontroller you know and love, now with added wireless connectivity for all your IoT needs. Get yours today: https://t.co/2leMu87zwC https://t.co/OqdwYlw9w0",
      "expandedUrl" : "https://twitter.com/i/web/status/1542402377164234752"
    }
  },
  {
    "like" : {
      "tweetId" : "1542126215116779520",
      "fullText" : "Parallel port. https://t.co/TOY9zFnENp",
      "expandedUrl" : "https://twitter.com/i/web/status/1542126215116779520"
    }
  },
  {
    "like" : {
      "tweetId" : "1542450538167828482",
      "fullText" : "２～４年前に作った同人誌を一日一冊ずつpixiv(https://t.co/zrvwXt2xxw)で公開していきます\n７冊あります https://t.co/FP22bjgP6Y",
      "expandedUrl" : "https://twitter.com/i/web/status/1542450538167828482"
    }
  },
  {
    "like" : {
      "tweetId" : "1542171745163309057",
      "fullText" : "日記です https://t.co/peQG9rS3hW",
      "expandedUrl" : "https://twitter.com/i/web/status/1542171745163309057"
    }
  },
  {
    "like" : {
      "tweetId" : "1542043733935669249",
      "fullText" : "ホシノー\n#ブルアカ https://t.co/7viribs29l",
      "expandedUrl" : "https://twitter.com/i/web/status/1542043733935669249"
    }
  },
  {
    "like" : {
      "tweetId" : "1541932626562678784",
      "fullText" : "休憩時間 https://t.co/lIKrcFant8",
      "expandedUrl" : "https://twitter.com/i/web/status/1541932626562678784"
    }
  },
  {
    "like" : {
      "tweetId" : "1541873213394649089",
      "fullText" : "check out my new cell phone https://t.co/XBABFXH0e9",
      "expandedUrl" : "https://twitter.com/i/web/status/1541873213394649089"
    }
  },
  {
    "like" : {
      "tweetId" : "1541495408811278337",
      "fullText" : "Tired: “Run this Arduino sketch to do one-time setup.” \nWired: https://t.co/WfXxYRscPr",
      "expandedUrl" : "https://twitter.com/i/web/status/1541495408811278337"
    }
  },
  {
    "like" : {
      "tweetId" : "1541731258190876672",
      "fullText" : "おいニシキアナゴ、おい https://t.co/xxpOLaKVTJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1541731258190876672"
    }
  },
  {
    "like" : {
      "tweetId" : "1540853897983582208",
      "fullText" : "Tomorow, we publish a step by step video tutorial on how to flash the ATMEGA32U4 chip and install QMK keyboard layer https://t.co/0vfopJESOe",
      "expandedUrl" : "https://twitter.com/i/web/status/1540853897983582208"
    }
  },
  {
    "like" : {
      "tweetId" : "1541376155537838080",
      "fullText" : "New episode!  @gvy_dvpont joins the show and talks about his predictive text MacroPad, his favorite coding language, and we both talk a little music.  Listen or subscribe here:  https://t.co/wUQrXpAkhm",
      "expandedUrl" : "https://twitter.com/i/web/status/1541376155537838080"
    }
  },
  {
    "like" : {
      "tweetId" : "1540973460951863296",
      "fullText" : "I have it all working so I'll do a BBC Gotek build thread. 🙂 https://t.co/5ecIuoY3qT",
      "expandedUrl" : "https://twitter.com/i/web/status/1540973460951863296"
    }
  },
  {
    "like" : {
      "tweetId" : "1541075609119608836",
      "fullText" : "https://t.co/dlw5EP7lfQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1541075609119608836"
    }
  },
  {
    "like" : {
      "tweetId" : "1541076003350786048",
      "fullText" : "pixivにも載せてきました(/・ω・)/🍨🍈🍒\n#pixiv https://t.co/Elq6lPLVYm",
      "expandedUrl" : "https://twitter.com/i/web/status/1541076003350786048"
    }
  },
  {
    "like" : {
      "tweetId" : "1540795561946689536",
      "fullText" : "Automaton Robotics created this artificial muscles robotic arm operated by water, consuming 200W at peak. Dumbbell weights 7 kg (15,6 lbs) , forearm with hand only 1 kg (2,2 lbs) [read more: https://t.co/hUWEHD7kXy] https://t.co/tmymGHoaG9",
      "expandedUrl" : "https://twitter.com/i/web/status/1540795561946689536"
    }
  },
  {
    "like" : {
      "tweetId" : "1541013833573367808",
      "fullText" : "クリームソーダ ｼｭﾜｼｭﾜ https://t.co/BiWjWsxUly",
      "expandedUrl" : "https://twitter.com/i/web/status/1541013833573367808"
    }
  },
  {
    "like" : {
      "tweetId" : "1541044464420257792",
      "fullText" : "Apple Magic Keyboard+Trackpad works as both a keyboard, and a trackpad. https://t.co/ekG6fLXtsI",
      "expandedUrl" : "https://twitter.com/i/web/status/1541044464420257792"
    }
  },
  {
    "like" : {
      "tweetId" : "1540600840586952704",
      "fullText" : "https://t.co/f3bb4T4DWR",
      "expandedUrl" : "https://twitter.com/i/web/status/1540600840586952704"
    }
  },
  {
    "like" : {
      "tweetId" : "1540484544549515264",
      "fullText" : "トトリ🐚\n#アトリ絵 https://t.co/DdU1wZFTdt",
      "expandedUrl" : "https://twitter.com/i/web/status/1540484544549515264"
    }
  },
  {
    "like" : {
      "tweetId" : "1540518121189953536",
      "fullText" : "MS Dos on M5 FACES. https://t.co/jup9BADoUl",
      "expandedUrl" : "https://twitter.com/i/web/status/1540518121189953536"
    }
  },
  {
    "like" : {
      "tweetId" : "1540244880685174784",
      "fullText" : "んあ～～もうだめだぁ～～ https://t.co/KRZ7fJ3h9j",
      "expandedUrl" : "https://twitter.com/i/web/status/1540244880685174784"
    }
  },
  {
    "like" : {
      "tweetId" : "1540279666958684160",
      "fullText" : "MacBook Pro with TouchBar-only keyboard. Six touchbars; all screen, all the time — except the real escape key. https://t.co/P1liKJ0miy",
      "expandedUrl" : "https://twitter.com/i/web/status/1540279666958684160"
    }
  },
  {
    "like" : {
      "tweetId" : "1540345611123593217",
      "fullText" : "Arduino_GFX 320x480 capatcity touch screen ArduinoVNC demo https://t.co/T0od91PtJl",
      "expandedUrl" : "https://twitter.com/i/web/status/1540345611123593217"
    }
  },
  {
    "like" : {
      "tweetId" : "1540162852245356544",
      "fullText" : "@tomfleet @planetcom2017 MediaTek Dimensity 800, 8 GB/128 GB/microSD (400 GB!), 5G, 6.39\" 2340x1080 AMOLED (13:6), audio jack!, 2x USB-C w/ HDMI out, OTG/hub, NFC, 48MP/13MP cams, Qi charging, 4,000mAh battery, OH AND typeable, individually illuminated keyboard!!! 🤘⌨️🤘 https://t.co/cbCuBOkX4B",
      "expandedUrl" : "https://twitter.com/i/web/status/1540162852245356544"
    }
  },
  {
    "like" : {
      "tweetId" : "1540138999507202048",
      "fullText" : "@SR71_A12 Yes except it's not a phone ;-) It's a Keyboard Featherwing (Blackberry BBQ10 kbd) by @solderparty with a BastWAN by our friends at @electronicats, featuring a RAK4260 by @RAKwireless, and code by, bows, me. https://t.co/1R9CtrNbK9",
      "expandedUrl" : "https://twitter.com/i/web/status/1540138999507202048"
    }
  },
  {
    "like" : {
      "tweetId" : "1540075015776911369",
      "fullText" : "This ATmega328-powered pocket computer sparks some PDA nostalgia: https://t.co/Hzy5gl8iMW https://t.co/rtyBEnJtFt",
      "expandedUrl" : "https://twitter.com/i/web/status/1540075015776911369"
    }
  },
  {
    "like" : {
      "tweetId" : "1539748653165731840",
      "fullText" : "nature is healing https://t.co/SnpA3r8IBW",
      "expandedUrl" : "https://twitter.com/i/web/status/1539748653165731840"
    }
  },
  {
    "like" : {
      "tweetId" : "1539777888580501505",
      "fullText" : "The situation indicator is finished! It beeps three times when things go from bad to worse. It's honestly the most apt thing I've made for the 2020's. https://t.co/cfrRb2optB",
      "expandedUrl" : "https://twitter.com/i/web/status/1539777888580501505"
    }
  },
  {
    "like" : {
      "tweetId" : "1539959739345428482",
      "fullText" : "Starting exciting work on Raspberry Pico based ZX Spectrum 128k with full keyboard, VGA output, USB OTG, Dsub9 joystick, 20x10cm https://t.co/0Y7Ne7enYW",
      "expandedUrl" : "https://twitter.com/i/web/status/1539959739345428482"
    }
  },
  {
    "like" : {
      "tweetId" : "1539946763809062912",
      "fullText" : "ミカのこの表情好き\n#ブルアカ https://t.co/LBfUWN71Sa",
      "expandedUrl" : "https://twitter.com/i/web/status/1539946763809062912"
    }
  },
  {
    "like" : {
      "tweetId" : "1539288360769953792",
      "fullText" : "Just been sent this, M62 apparently. \nMoral of the story is, if stuck in traffic make sure you're behind an ice cream van. https://t.co/TkETVuJCsZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1539288360769953792"
    }
  },
  {
    "like" : {
      "tweetId" : "1539310279557021696",
      "fullText" : "@sulfuroid 😆\nYes, that's cool one!\nhttps://t.co/ibpdAb5LtU",
      "expandedUrl" : "https://twitter.com/i/web/status/1539310279557021696"
    }
  },
  {
    "like" : {
      "tweetId" : "1539496237660971008",
      "fullText" : "点滅を見て心を落ち着かせる https://t.co/z5XeQ4P56a",
      "expandedUrl" : "https://twitter.com/i/web/status/1539496237660971008"
    }
  },
  {
    "like" : {
      "tweetId" : "1539559536708595713",
      "fullText" : "梅雨の花が咲く💠 https://t.co/K4ymleJ2te",
      "expandedUrl" : "https://twitter.com/i/web/status/1539559536708595713"
    }
  },
  {
    "like" : {
      "tweetId" : "1539104618692722689",
      "fullText" : "#linux https://t.co/jcf1PLGXge",
      "expandedUrl" : "https://twitter.com/i/web/status/1539104618692722689"
    }
  },
  {
    "like" : {
      "tweetId" : "1539273216770068480",
      "fullText" : "知らんうちにかつてないほどバズってた😆ﾐﾝﾅﾀﾞｲｽｷ! https://t.co/EygVnUFrQ2",
      "expandedUrl" : "https://twitter.com/i/web/status/1539273216770068480"
    }
  },
  {
    "like" : {
      "tweetId" : "1539352244440952832",
      "fullText" : "Sony PlayStation Pro https://t.co/WZdJpexrGk",
      "expandedUrl" : "https://twitter.com/i/web/status/1539352244440952832"
    }
  },
  {
    "like" : {
      "tweetId" : "1539233101796507649",
      "fullText" : "@ComputerCellar Laptop with a chin and a trackball on the chin? I'm *in*. https://t.co/CrD0epLF9x",
      "expandedUrl" : "https://twitter.com/i/web/status/1539233101796507649"
    }
  },
  {
    "like" : {
      "tweetId" : "1539200395054133252",
      "fullText" : "https://t.co/1qGarPDxIR",
      "expandedUrl" : "https://twitter.com/i/web/status/1539200395054133252"
    }
  },
  {
    "like" : {
      "tweetId" : "1539267591164035072",
      "fullText" : "VNC to a 30% zoom firefox https://t.co/AdBfov4djM",
      "expandedUrl" : "https://twitter.com/i/web/status/1539267591164035072"
    }
  },
  {
    "like" : {
      "tweetId" : "1539233739901116417",
      "fullText" : "@chrisdavidmiles and boom. https://t.co/ASIOpcrRyq",
      "expandedUrl" : "https://twitter.com/i/web/status/1539233739901116417"
    }
  },
  {
    "like" : {
      "tweetId" : "1538897918882627586",
      "fullText" : "Next week Monday is a new episode with @gvy_dvpont!  Here Guy talk about some of his favorite and not-so-favorite projects!  Subscribe:  https://t.co/P9EwqLC5IX",
      "expandedUrl" : "https://twitter.com/i/web/status/1538897918882627586"
    }
  },
  {
    "like" : {
      "tweetId" : "1538458088151298049",
      "fullText" : "https://t.co/e5UEA1YP1d",
      "expandedUrl" : "https://twitter.com/i/web/status/1538458088151298049"
    }
  },
  {
    "like" : {
      "tweetId" : "1538827192637194240",
      "fullText" : "休日の朝 https://t.co/PpIg7TX4x3",
      "expandedUrl" : "https://twitter.com/i/web/status/1538827192637194240"
    }
  },
  {
    "like" : {
      "tweetId" : "1538419936162611200",
      "fullText" : "https://t.co/pRuY9Nk7HN",
      "expandedUrl" : "https://twitter.com/i/web/status/1538419936162611200"
    }
  },
  {
    "like" : {
      "tweetId" : "1538331167862456320",
      "fullText" : "しゅがは https://t.co/sRcFaBaN3d",
      "expandedUrl" : "https://twitter.com/i/web/status/1538331167862456320"
    }
  },
  {
    "like" : {
      "tweetId" : "1537939509358526464",
      "fullText" : "夏コミ新刊のイラストを考えつつ、作業中です。 この工具なら、8sqも楽々ですね。 https://t.co/mGy2Jlzrql",
      "expandedUrl" : "https://twitter.com/i/web/status/1537939509358526464"
    }
  },
  {
    "like" : {
      "tweetId" : "1538394813292105734",
      "fullText" : "日記です https://t.co/2TS1mhZvmF",
      "expandedUrl" : "https://twitter.com/i/web/status/1538394813292105734"
    }
  },
  {
    "like" : {
      "tweetId" : "1538292736184442882",
      "fullText" : "The Apple Newton Multimedia Desktop from 1995 was the first experiment with the Newton OS a light and fast alternative to Mac OS. https://t.co/Eww2rNCuyz",
      "expandedUrl" : "https://twitter.com/i/web/status/1538292736184442882"
    }
  },
  {
    "like" : {
      "tweetId" : "1538159761354530816",
      "fullText" : "Notkia: Building An Open And Linux-Powered Numpad Phone https://t.co/e1nIF41CKL",
      "expandedUrl" : "https://twitter.com/i/web/status/1538159761354530816"
    }
  },
  {
    "like" : {
      "tweetId" : "1538247278409940992",
      "fullText" : "I finished a multi-year project today.  It feels weird to be done.",
      "expandedUrl" : "https://twitter.com/i/web/status/1538247278409940992"
    }
  },
  {
    "like" : {
      "tweetId" : "1537963586391142407",
      "fullText" : "KiCad on the Steam Deck runs better than on a Surface Book 2. https://t.co/JbdFaQ6Hcu",
      "expandedUrl" : "https://twitter.com/i/web/status/1537963586391142407"
    }
  },
  {
    "like" : {
      "tweetId" : "1538153678343127041",
      "fullText" : "通り抜けルーム https://t.co/ALQ62P6zcb",
      "expandedUrl" : "https://twitter.com/i/web/status/1538153678343127041"
    }
  },
  {
    "like" : {
      "tweetId" : "1538109858507296769",
      "fullText" : "見て、ありの行列 https://t.co/aIgftBxZpi",
      "expandedUrl" : "https://twitter.com/i/web/status/1538109858507296769"
    }
  },
  {
    "like" : {
      "tweetId" : "1537791684100116480",
      "fullText" : "GitHub adds math support to markdown @GitHub https://t.co/mMgSQEYNmj",
      "expandedUrl" : "https://twitter.com/i/web/status/1537791684100116480"
    }
  },
  {
    "like" : {
      "tweetId" : "1537734628697853954",
      "fullText" : "わたくしが引いてさしあげますわ https://t.co/iApxH1wukp",
      "expandedUrl" : "https://twitter.com/i/web/status/1537734628697853954"
    }
  },
  {
    "like" : {
      "tweetId" : "1537363711710535680",
      "fullText" : "@xssfox @kyhwana @nz_liam @rukacollie And boom! https://t.co/mj7PgPoFLA",
      "expandedUrl" : "https://twitter.com/i/web/status/1537363711710535680"
    }
  },
  {
    "like" : {
      "tweetId" : "1537420388103499777",
      "fullText" : "日記です https://t.co/F9X60YdQuZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1537420388103499777"
    }
  },
  {
    "like" : {
      "tweetId" : "1537294616545796096",
      "fullText" : "The Power Macintosh G4 All-in-one, also known as the Molar Mac II, was difficult to look at and weighed just under one short ton. https://t.co/Za3BmmSskz",
      "expandedUrl" : "https://twitter.com/i/web/status/1537294616545796096"
    }
  },
  {
    "like" : {
      "tweetId" : "1537288908815208451",
      "fullText" : "完成しましたー\nリクエストありがとうございました\n\nリクエストイラスト | てるミ #pixiv https://t.co/tdEggWCkrw",
      "expandedUrl" : "https://twitter.com/i/web/status/1537288908815208451"
    }
  },
  {
    "like" : {
      "tweetId" : "1537361398451568640",
      "fullText" : "隠し撮り生配信 https://t.co/RrxWjAz821",
      "expandedUrl" : "https://twitter.com/i/web/status/1537361398451568640"
    }
  },
  {
    "like" : {
      "tweetId" : "1537410681913237508",
      "fullText" : "鍵が中で折れた夢見りあむ https://t.co/xny7jiIwwx",
      "expandedUrl" : "https://twitter.com/i/web/status/1537410681913237508"
    }
  },
  {
    "like" : {
      "tweetId" : "1537105352071778305",
      "fullText" : "I hate when that happens... https://t.co/RPfST7MD21",
      "expandedUrl" : "https://twitter.com/i/web/status/1537105352071778305"
    }
  },
  {
    "like" : {
      "tweetId" : "1537087578360672256",
      "fullText" : "お誕生日おめでとう🎊\nいえーい！ https://t.co/rUljMz69an",
      "expandedUrl" : "https://twitter.com/i/web/status/1537087578360672256"
    }
  },
  {
    "like" : {
      "tweetId" : "1537050593969295360",
      "fullText" : "This week, I was with @prcutler on The CircuitPython Show, discussing #Python, the Python on Microcontrollers Newsletter, #VintageComputing / #RetroTech, #CircuitPython, #MicroPython and much more. Check it out &amp; thanks to Paul!! https://t.co/NhME6n8dKG",
      "expandedUrl" : "https://twitter.com/i/web/status/1537050593969295360"
    }
  },
  {
    "like" : {
      "tweetId" : "1587644700323975171",
      "fullText" : "@River___Wang 😯didn’t know that. Thank you!",
      "expandedUrl" : "https://twitter.com/i/web/status/1587644700323975171"
    }
  },
  {
    "like" : {
      "tweetId" : "1587641979407564803",
      "fullText" : "@River___Wang That looks great in the web editors but it’s made a complete and utter mess out of Mu since they introduced it.",
      "expandedUrl" : "https://twitter.com/i/web/status/1587641979407564803"
    }
  },
  {
    "like" : {
      "tweetId" : "1587626530917728256",
      "fullText" : "CircuitPython Online IDE now supports Status Bar introduced in #CircuitPython 8.0.0. Try it out here: https://t.co/MbMYEkP3R6 https://t.co/KqvrqaMAud",
      "expandedUrl" : "https://twitter.com/i/web/status/1587626530917728256"
    }
  },
  {
    "like" : {
      "tweetId" : "1587145450620076033",
      "fullText" : "Just another size comparison of my latest project.\nI think there's no smaller LoRa® Transmitter &amp; Receiver with colour screen, battery &amp; buttons around.\nIt has also Bluetooth® and WiFi® built in but unused at this moment. https://t.co/2MPEYNWRVz https://t.co/xgIHlxnmc3",
      "expandedUrl" : "https://twitter.com/i/web/status/1587145450620076033"
    }
  },
  {
    "like" : {
      "tweetId" : "1585330566324518912",
      "fullText" : "https://t.co/5dNBQ4VuNW",
      "expandedUrl" : "https://twitter.com/i/web/status/1585330566324518912"
    }
  },
  {
    "like" : {
      "tweetId" : "1479155289135869953",
      "fullText" : "So last month I built this lil time/weather/Spotify display from an @adafruit Matrix Portal kit. Very impressed how easy it was (it’s Python!!). The only real difficulty: the Spotify API. They don’t have a “limited input device” API for displays. https://t.co/gsczdpn3WI",
      "expandedUrl" : "https://twitter.com/i/web/status/1479155289135869953"
    }
  },
  {
    "like" : {
      "tweetId" : "1587172727680794624",
      "fullText" : "3D Printed Strain Wave Gearbox https://t.co/xh9vPydGda",
      "expandedUrl" : "https://twitter.com/i/web/status/1587172727680794624"
    }
  },
  {
    "like" : {
      "tweetId" : "1587044119486029824",
      "fullText" : "New episode!  Meet Jason Pecor and the CircuitPython-powered Trolls.  Listen: https://t.co/ba9Tje9f5W",
      "expandedUrl" : "https://twitter.com/i/web/status/1587044119486029824"
    }
  },
  {
    "like" : {
      "tweetId" : "1586887867065835521",
      "fullText" : "@RetroTechDreams Really curious to know whether it still works, especially what “lifetime access” really means.",
      "expandedUrl" : "https://twitter.com/i/web/status/1586887867065835521"
    }
  },
  {
    "like" : {
      "tweetId" : "1586887185449746433",
      "fullText" : "The TwitterPeek (2009) was an always-connected Twitter device with cellular service. The $99 device came with 6 months of service. Users could renew the service for $8 per month or pay $199 for lifetime access. https://t.co/KoGjjkLb5z",
      "expandedUrl" : "https://twitter.com/i/web/status/1586887185449746433"
    }
  },
  {
    "like" : {
      "tweetId" : "1586858059321774083",
      "fullText" : "Size of my X-Drone https://t.co/Kay3OWlcvE",
      "expandedUrl" : "https://twitter.com/i/web/status/1586858059321774083"
    }
  },
  {
    "like" : {
      "tweetId" : "1586630747997151232",
      "fullText" : "meishi trackball moduleの没キーを組み立てました！\nジャンパしてoledをつけようと思っていたのですが、「key microだとオールブラックにできてカッコいいな？」と思い直しこのままに。あとでボトムアクリルかおーっと！ https://t.co/nv3dtI68cC",
      "expandedUrl" : "https://twitter.com/i/web/status/1586630747997151232"
    }
  },
  {
    "like" : {
      "tweetId" : "1586849088246775808",
      "fullText" : "CircuitPython 8.0.0 Beta 4 Released! circuitpython  https://t.co/zHUZeSJjox",
      "expandedUrl" : "https://twitter.com/i/web/status/1586849088246775808"
    }
  },
  {
    "like" : {
      "tweetId" : "1586707178710179841",
      "fullText" : ".@lilygo9  T-Dongle-S3 : ดองเกิล USB ที่ใช้ MCU ESP32-S3 พร้อมหน้าจอสี #ARDUINO #BLUETOOTH #ESP32 #MICROPYTHON #WIFI #หน้าจอ https://t.co/6rKIwOcEIi",
      "expandedUrl" : "https://twitter.com/i/web/status/1586707178710179841"
    }
  },
  {
    "like" : {
      "tweetId" : "1586306057638674432",
      "fullText" : "決戦前夜 https://t.co/rGIzq5wzwe",
      "expandedUrl" : "https://twitter.com/i/web/status/1586306057638674432"
    }
  },
  {
    "like" : {
      "tweetId" : "1585380387760574483",
      "fullText" : "Inflation Buster can help you save hundreds – even thousands – the first year in your new home. Click to see how!",
      "expandedUrl" : "https://twitter.com/i/web/status/1585380387760574483"
    }
  },
  {
    "like" : {
      "tweetId" : "1586668081123770368",
      "fullText" : "ほわー\n#SB69 https://t.co/npR7jqJ7Wf",
      "expandedUrl" : "https://twitter.com/i/web/status/1586668081123770368"
    }
  },
  {
    "like" : {
      "tweetId" : "1586456663351234561",
      "fullText" : "Humble iCE is a low-cost FPGA dev board that combines @latticesemi's iCE40UP5k with a @Raspberry_Pi RP2040: https://t.co/ZjrdWuhzEq https://t.co/5RFeH4idGR",
      "expandedUrl" : "https://twitter.com/i/web/status/1586456663351234561"
    }
  },
  {
    "like" : {
      "tweetId" : "1586091334104145920",
      "fullText" : "Happy Friday, one of my favorite stories about community tech rescue keeps surprising me: https://t.co/9faumwCWKC",
      "expandedUrl" : "https://twitter.com/i/web/status/1586091334104145920"
    }
  },
  {
    "like" : {
      "tweetId" : "1586480873435709443",
      "fullText" : "Screw this, I'm doing it my way https://t.co/F0gaeGv4ga",
      "expandedUrl" : "https://twitter.com/i/web/status/1586480873435709443"
    }
  },
  {
    "like" : {
      "tweetId" : "1586480150480199681",
      "fullText" : "Trying to charge an old dumbphone is fun:\n- starts charging\n- it charges to a few percent\n- starts booting on its own\n- that depletes the battery\n- it turns off\n- starts charging\n- it charges to a few percent...",
      "expandedUrl" : "https://twitter.com/i/web/status/1586480150480199681"
    }
  },
  {
    "like" : {
      "tweetId" : "1585747730529280000",
      "fullText" : "Lol... mega lol https://t.co/5JXy2cPjTT",
      "expandedUrl" : "https://twitter.com/i/web/status/1585747730529280000"
    }
  },
  {
    "like" : {
      "tweetId" : "1585905264418779138",
      "fullText" : "The Landscape PowerBook G4 joined the G4 Cube as a one-off classic in the early 2000s. Designed to use while standing, well-kept examples fetch high prices — if you can manage to separate one from their increasingly devoted owners. https://t.co/u6n5MySonm",
      "expandedUrl" : "https://twitter.com/i/web/status/1585905264418779138"
    }
  },
  {
    "like" : {
      "tweetId" : "1585790349720621056",
      "fullText" : "Under-rated ICs and why? I’ll go first, MCP23017. I think people have been sleeping on this thing. An I2C device that gives you a bunch of bonus GPIO and it has THREE address pins, allowing for up to EIGHT of these on one controller. #ElectronicsTwitter https://t.co/UE1Zw0yLhZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1585790349720621056"
    }
  },
  {
    "like" : {
      "tweetId" : "1585704922712051713",
      "fullText" : "@bateskecom 3M VHB https://t.co/suvQNMdcr1",
      "expandedUrl" : "https://twitter.com/i/web/status/1585704922712051713"
    }
  },
  {
    "like" : {
      "tweetId" : "1537089307558948865",
      "fullText" : "今までに描いたお気に入りの久川姉妹の再掲です https://t.co/ohaMybyw6R",
      "expandedUrl" : "https://twitter.com/i/web/status/1537089307558948865"
    }
  },
  {
    "like" : {
      "tweetId" : "1537087618739208192",
      "fullText" : "久川姉妹 https://t.co/bF6M3mo5rw",
      "expandedUrl" : "https://twitter.com/i/web/status/1537087618739208192"
    }
  },
  {
    "like" : {
      "tweetId" : "1536725988805165058",
      "fullText" : "Rare shiny https://t.co/ojEzjRSgwm",
      "expandedUrl" : "https://twitter.com/i/web/status/1536725988805165058"
    }
  },
  {
    "like" : {
      "tweetId" : "1536993345356337152",
      "fullText" : "VR体験 https://t.co/ZbCL006CME",
      "expandedUrl" : "https://twitter.com/i/web/status/1536993345356337152"
    }
  },
  {
    "like" : {
      "tweetId" : "1536744172782342150",
      "fullText" : "Simple Solder Paste Dispenser! #TindieBlog https://t.co/K2CC7VFjLx",
      "expandedUrl" : "https://twitter.com/i/web/status/1536744172782342150"
    }
  },
  {
    "like" : {
      "tweetId" : "1536436928232321024",
      "fullText" : "The summoning grid is now complete. \nThe bakening is upon us\n(reddit via @garethb2's Tips newsletter) https://t.co/l48q9Iy8MH",
      "expandedUrl" : "https://twitter.com/i/web/status/1536436928232321024"
    }
  },
  {
    "like" : {
      "tweetId" : "1536443662506377220",
      "fullText" : "If anyone wants a build like this, let me know i'll gladly do this as a commission 👀",
      "expandedUrl" : "https://twitter.com/i/web/status/1536443662506377220"
    }
  },
  {
    "like" : {
      "tweetId" : "1536295780696195072",
      "fullText" : "finally received this Mar order🎉🎊 https://t.co/OnmEK6vHks",
      "expandedUrl" : "https://twitter.com/i/web/status/1536295780696195072"
    }
  },
  {
    "like" : {
      "tweetId" : "1535752854144790528",
      "fullText" : "Very quick weekend midnight project. https://t.co/Cm7przSGZu",
      "expandedUrl" : "https://twitter.com/i/web/status/1535752854144790528"
    }
  },
  {
    "like" : {
      "tweetId" : "1536134939384885248",
      "fullText" : "１週間のはじまりは元気なあいさつから https://t.co/xasUM7O6Ha",
      "expandedUrl" : "https://twitter.com/i/web/status/1536134939384885248"
    }
  },
  {
    "like" : {
      "tweetId" : "1535635931587399684",
      "fullText" : "Offering support for new boards, including @adafruit's latest ESP32-S2 Feathers, @CircuitPython 8.0.0 is ready for testing. https://t.co/2N9koswS7p",
      "expandedUrl" : "https://twitter.com/i/web/status/1535635931587399684"
    }
  },
  {
    "like" : {
      "tweetId" : "1535901840558411776",
      "fullText" : "メタルギアライジングの続編が絶望的なので自分で作り始めました(卒業制作) https://t.co/KbPYjqQY6g",
      "expandedUrl" : "https://twitter.com/i/web/status/1535901840558411776"
    }
  },
  {
    "like" : {
      "tweetId" : "1536011761807138817",
      "fullText" : "Planing the first big version of CPy OL IDE. Just started to learn Vue. Any suggestions? @CircuitPython https://t.co/3S11ENTNpw",
      "expandedUrl" : "https://twitter.com/i/web/status/1536011761807138817"
    }
  },
  {
    "like" : {
      "tweetId" : "1534917015995047939",
      "fullText" : "I see there is a new release of CircuitPython on https://t.co/gyFGfqI4Sl - check it out! https://t.co/QAW6H5D1FA",
      "expandedUrl" : "https://twitter.com/i/web/status/1534917015995047939"
    }
  },
  {
    "like" : {
      "tweetId" : "1535942194024140800",
      "fullText" : "I updated the BlakRPI CLIVE cyberdeck  information and created a github with kicad files (GPL3) openhardware to respond to constructive criticism . #BlakRPI \nhttps://t.co/lvnA3FTtSf https://t.co/S2SlW7Z5oQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1535942194024140800"
    }
  },
  {
    "like" : {
      "tweetId" : "1535845619486846976",
      "fullText" : "https://t.co/fqmAyydBxk",
      "expandedUrl" : "https://twitter.com/i/web/status/1535845619486846976"
    }
  },
  {
    "like" : {
      "tweetId" : "1535582869271506944",
      "fullText" : "「瑠璃色の風」 https://t.co/cc4vQ9EZaS",
      "expandedUrl" : "https://twitter.com/i/web/status/1535582869271506944"
    }
  },
  {
    "like" : {
      "tweetId" : "1535731044917612544",
      "fullText" : "@DegreaseNeil I like this one better. https://t.co/X1icNgsiU5",
      "expandedUrl" : "https://twitter.com/i/web/status/1535731044917612544"
    }
  },
  {
    "like" : {
      "tweetId" : "1535650564440137728",
      "fullText" : "Need a new firepit? Consider this 36\" incredibly accurate Death Star one [buy: https://t.co/VU68v9307f] https://t.co/kahFPjVfN6",
      "expandedUrl" : "https://twitter.com/i/web/status/1535650564440137728"
    }
  },
  {
    "like" : {
      "tweetId" : "1535600543300669440",
      "fullText" : "6月17日発売の『私に天使が舞い降りた！11巻 特装版』にイラストを１枚寄稿させて頂きました！\n寄稿されてる方が豪華すぎてひっくり返りました！！\nぜひ！よろしくおねがいします！！ https://t.co/mDx9vFLBcT https://t.co/58pZLtJpmq",
      "expandedUrl" : "https://twitter.com/i/web/status/1535600543300669440"
    }
  },
  {
    "like" : {
      "tweetId" : "1535585412361723904",
      "fullText" : "Crested mynas, as many other birds, are born altricially, which means young are underdeveloped at the time of birth, therefore fed by parents. When they grow up, they have to learn that food doesn't simply jump into their beaks [📽️: Rebecca Gelernter] https://t.co/xhH1TouIwd",
      "expandedUrl" : "https://twitter.com/i/web/status/1535585412361723904"
    }
  },
  {
    "like" : {
      "tweetId" : "1535603753784844288",
      "fullText" : "小依ちゃんと夏音ちゃん！\nいつもの３人＋みゃー姉のイラストは11巻特装版の方に寄稿させて頂いてますので、ぜひお手に取って頂きたく！！おねがいいたします！！！\nhttps://t.co/Plgg9sKl1e https://t.co/sBElPvYYoL",
      "expandedUrl" : "https://twitter.com/i/web/status/1535603753784844288"
    }
  },
  {
    "like" : {
      "tweetId" : "1535598132976726016",
      "fullText" : "ちちきょうあそんでくれるいった！ https://t.co/C6Aq8Vl2jk",
      "expandedUrl" : "https://twitter.com/i/web/status/1535598132976726016"
    }
  },
  {
    "like" : {
      "tweetId" : "1535444730045034496",
      "fullText" : "知らない人だったので楽しかったです https://t.co/O4oPe2jQhD",
      "expandedUrl" : "https://twitter.com/i/web/status/1535444730045034496"
    }
  },
  {
    "like" : {
      "tweetId" : "1535433024438824960",
      "fullText" : "集中しすぎて何も聞こえなかった陸上部員 https://t.co/DwkdD2sHV3",
      "expandedUrl" : "https://twitter.com/i/web/status/1535433024438824960"
    }
  },
  {
    "like" : {
      "tweetId" : "1535203788147068928",
      "fullText" : "This soldering iron uses a 3.5mm jack to attach the heads \n\nTaking bets for what would happen if I plugged some headphones in? 🔥 https://t.co/hOdzlaLXAz",
      "expandedUrl" : "https://twitter.com/i/web/status/1535203788147068928"
    }
  },
  {
    "like" : {
      "tweetId" : "1535111218624868356",
      "fullText" : "【Skeb】かわいい https://t.co/BSzv4qTJoi",
      "expandedUrl" : "https://twitter.com/i/web/status/1535111218624868356"
    }
  },
  {
    "like" : {
      "tweetId" : "1534937313352069120",
      "fullText" : "Sensor Watch tester in @oshpark purple. This was a triumph. https://t.co/15AExvhwkN",
      "expandedUrl" : "https://twitter.com/i/web/status/1534937313352069120"
    }
  },
  {
    "like" : {
      "tweetId" : "1534943670012719106",
      "fullText" : "Wide IC Lead Straightener #3DThursday #3DPrinting https://t.co/lfspBEooWV",
      "expandedUrl" : "https://twitter.com/i/web/status/1534943670012719106"
    }
  },
  {
    "like" : {
      "tweetId" : "1534847633612845058",
      "fullText" : "Yes!! Left side of the split keyboard works!  #MechanicalKeyboard #OLED https://t.co/2shKk43PQw",
      "expandedUrl" : "https://twitter.com/i/web/status/1534847633612845058"
    }
  },
  {
    "like" : {
      "tweetId" : "1534876633307525121",
      "fullText" : "I like them thick and square! Love how this is coming out. Still need to design the back cover and maybe some new features for the front @arturo182 @pimoroni @creality @Raspberry_Pi https://t.co/cbiBlLDgzo",
      "expandedUrl" : "https://twitter.com/i/web/status/1534876633307525121"
    }
  },
  {
    "like" : {
      "tweetId" : "1534828428582883328",
      "fullText" : "日記です https://t.co/RZUl3eo3Nb",
      "expandedUrl" : "https://twitter.com/i/web/status/1534828428582883328"
    }
  },
  {
    "like" : {
      "tweetId" : "1534667370014420997",
      "fullText" : "@geerlingguy Arranging production for my Raspberry Pi CM4 TV Stick project to make it available in August https://t.co/gCA8aTNDiD",
      "expandedUrl" : "https://twitter.com/i/web/status/1534667370014420997"
    }
  },
  {
    "like" : {
      "tweetId" : "1534702825913077761",
      "fullText" : "@RoPirtJansson @Raspberry_Pi Don't forget @ChrisBarnatt and @pimoroni",
      "expandedUrl" : "https://twitter.com/i/web/status/1534702825913077761"
    }
  },
  {
    "like" : {
      "tweetId" : "1534640139703664642",
      "fullText" : "New on Twitter. Who do you recommend me to follow to get updated on cool RaspberryPi, Arduino etc. projects?\n#Arduino #RaspberryPi @Raspberry_Pi",
      "expandedUrl" : "https://twitter.com/i/web/status/1534640139703664642"
    }
  },
  {
    "like" : {
      "tweetId" : "1534627197541040128",
      "fullText" : "今日はお魚釣りに行ってきます https://t.co/QUi4R8czZX",
      "expandedUrl" : "https://twitter.com/i/web/status/1534627197541040128"
    }
  },
  {
    "like" : {
      "tweetId" : "1534495603434016768",
      "fullText" : "ルイズ https://t.co/LvHKbqKfOS",
      "expandedUrl" : "https://twitter.com/i/web/status/1534495603434016768"
    }
  },
  {
    "like" : {
      "tweetId" : "1534360711140638720",
      "fullText" : "https://t.co/RxgJvfVyX9",
      "expandedUrl" : "https://twitter.com/i/web/status/1534360711140638720"
    }
  },
  {
    "like" : {
      "tweetId" : "1534341782779011072",
      "fullText" : "めぐみん https://t.co/Q0fR80VJEV",
      "expandedUrl" : "https://twitter.com/i/web/status/1534341782779011072"
    }
  },
  {
    "like" : {
      "tweetId" : "1534173332945240064",
      "fullText" : "I've been experimenting with ultrasonic data transmission in JavaScript, as a potential payment method 💳. Here's an example of sending a payment link from an offline device via inaudible sounds.\n\nIf you're interested, I wrote about it ✍️\nhttps://t.co/7fgdEoGf9f https://t.co/PwcyyZSDe2",
      "expandedUrl" : "https://twitter.com/i/web/status/1534173332945240064"
    }
  },
  {
    "like" : {
      "tweetId" : "1534177059437944833",
      "fullText" : "このツイートもこのキーボードから打ってるけど、ブラックベリー懐かしむ人にもいいかも。\nAndroidでもトラックパッド使えるし。 https://t.co/yDT131yBjA",
      "expandedUrl" : "https://twitter.com/i/web/status/1534177059437944833"
    }
  },
  {
    "like" : {
      "tweetId" : "1534119789576200192",
      "fullText" : "Fantastic work! https://t.co/7UBn5z8zQC",
      "expandedUrl" : "https://twitter.com/i/web/status/1534119789576200192"
    }
  },
  {
    "like" : {
      "tweetId" : "1534257454908948483",
      "fullText" : "@diyelectromusic I'm also new, but are you limited to routing everything on one side? I think most places charge the same for 1 and 2 sided boards. You could route a few of your longer traces on the bottom (looking at the twisty ones going to R6). Not sure it would make a meaningful difference.",
      "expandedUrl" : "https://twitter.com/i/web/status/1534257454908948483"
    }
  },
  {
    "like" : {
      "tweetId" : "1534257598194753537",
      "fullText" : "Today’s thought: killing sacred cows. Ever since the first plastic E-Book Wing mock-up (ca. 2019), the previous and next page buttons have been at the far left and far right. Today considering the possibility: is it more ergonomic to have them nearer to the center of the device? https://t.co/NzdEbuCiPP",
      "expandedUrl" : "https://twitter.com/i/web/status/1534257598194753537"
    }
  },
  {
    "like" : {
      "tweetId" : "1534127538326609921",
      "fullText" : "今年もうちのチョコミントちゃーん https://t.co/xx994Hr83Z",
      "expandedUrl" : "https://twitter.com/i/web/status/1534127538326609921"
    }
  },
  {
    "like" : {
      "tweetId" : "1533939853305561088",
      "fullText" : "Working on a little project. I would like to connect the pi's usb lines directly to the bbq20kbd's pcb. I'm trying to keep this as simple as can be so no usb connectors, just wires. I'll have to see if there is a schematic for the board @arturo182 @solderparty @bbq20kbd https://t.co/eBYJ4mtOIt",
      "expandedUrl" : "https://twitter.com/i/web/status/1533939853305561088"
    }
  },
  {
    "like" : {
      "tweetId" : "1534038389749473280",
      "fullText" : "お気に入りの千枝ちゃん（と橘さんたち）の再掲です https://t.co/s8O61gyfSI",
      "expandedUrl" : "https://twitter.com/i/web/status/1534038389749473280"
    }
  },
  {
    "like" : {
      "tweetId" : "1533981199827611649",
      "fullText" : "薫ちゃん https://t.co/3jj4JceFnu",
      "expandedUrl" : "https://twitter.com/i/web/status/1533981199827611649"
    }
  },
  {
    "like" : {
      "tweetId" : "1533357310831382528",
      "fullText" : "Dark early here, temps are well into the single digits, and I'm missing Summer. Here, my fave pic of my '69 XW Futura and my sis's '75 XB Falcon, with appropriate ice. https://t.co/g4LyCEId7a",
      "expandedUrl" : "https://twitter.com/i/web/status/1533357310831382528"
    }
  },
  {
    "like" : {
      "tweetId" : "1533755505226551298",
      "fullText" : "「片道切符」 https://t.co/j9wa6Tbjgg",
      "expandedUrl" : "https://twitter.com/i/web/status/1533755505226551298"
    }
  },
  {
    "like" : {
      "tweetId" : "1533866492806283271",
      "fullText" : "Touchscreen controls for everything: Thanks I Hate It",
      "expandedUrl" : "https://twitter.com/i/web/status/1533866492806283271"
    }
  },
  {
    "like" : {
      "tweetId" : "1533494139463032832",
      "fullText" : "it wouldn't be an Open Book board without relentless documentation. New concept: instead of explaining what the parts do, use the space to explain how to get the parts onto the board. https://t.co/ZQLaRjRnJA",
      "expandedUrl" : "https://twitter.com/i/web/status/1533494139463032832"
    }
  },
  {
    "like" : {
      "tweetId" : "1532035506539995136",
      "fullText" : "First triangle ever rendered on an M1 Mac with a fully open source driver! 🎉🎉🎉🎉 https://t.co/cyLeQRpJ4x",
      "expandedUrl" : "https://twitter.com/i/web/status/1532035506539995136"
    }
  },
  {
    "like" : {
      "tweetId" : "1531568708568592384",
      "fullText" : "「雨はお好きですか？」#watercolor https://t.co/8iY19pggew",
      "expandedUrl" : "https://twitter.com/i/web/status/1531568708568592384"
    }
  },
  {
    "like" : {
      "tweetId" : "1533230181330178049",
      "fullText" : "in other saturday accomplishments: lock screen is real. Haven’t measured the current consumption yet, but this goes into the RP2040’s DORMANT sleep mode when locked, and resets on wake. Future goal is to resume from the same place but — this is becoming a refrain — it’s a start. https://t.co/lOHoSVrUvV",
      "expandedUrl" : "https://twitter.com/i/web/status/1533230181330178049"
    }
  },
  {
    "like" : {
      "tweetId" : "1533229725703077888",
      "fullText" : "おしゃまな花嫁 https://t.co/eHbmqiL5XF",
      "expandedUrl" : "https://twitter.com/i/web/status/1533229725703077888"
    }
  },
  {
    "like" : {
      "tweetId" : "1533238067993411584",
      "fullText" : "杏ちゃん https://t.co/YQoH0Vx5RP",
      "expandedUrl" : "https://twitter.com/i/web/status/1533238067993411584"
    }
  },
  {
    "like" : {
      "tweetId" : "1533099901802147841",
      "fullText" : "かかとを床に着けたまましゃがめないPにお手本を見せてくれる乙倉ちゃん https://t.co/NJVvpFC7Te",
      "expandedUrl" : "https://twitter.com/i/web/status/1533099901802147841"
    }
  },
  {
    "like" : {
      "tweetId" : "1533048816881938433",
      "fullText" : "😭😭😭😭😭 https://t.co/JB67idPAtq",
      "expandedUrl" : "https://twitter.com/i/web/status/1533048816881938433"
    }
  },
  {
    "like" : {
      "tweetId" : "1532842230666477569",
      "fullText" : "Some people wear @ROLEX , I‘m wearing skill 😎\n\nLots of work to do though, but it does the basics already ;). Bigger battery = 4 week runtime without software tweaks. screen on all the time. esp32, 2mb ram, 8mb flash, BT, WiFi,… backup battery, vibration motor,… https://t.co/yyhYUbEzFd",
      "expandedUrl" : "https://twitter.com/i/web/status/1532842230666477569"
    }
  },
  {
    "like" : {
      "tweetId" : "1532847654228869120",
      "fullText" : "迷子 https://t.co/zYrOQuDWZc",
      "expandedUrl" : "https://twitter.com/i/web/status/1532847654228869120"
    }
  },
  {
    "like" : {
      "tweetId" : "1532683010696695809",
      "fullText" : "聖職者？いいえ、星職者です https://t.co/apUsot3K0d",
      "expandedUrl" : "https://twitter.com/i/web/status/1532683010696695809"
    }
  },
  {
    "like" : {
      "tweetId" : "1532599499910430720",
      "fullText" : "もう朝か～…？ https://t.co/J0HHU4LEaf",
      "expandedUrl" : "https://twitter.com/i/web/status/1532599499910430720"
    }
  },
  {
    "like" : {
      "tweetId" : "1532522625527848968",
      "fullText" : "This clever, STM32-powered controller aims to be \"one knob to rule 'em all:\" https://t.co/9QnF903CyU https://t.co/t5sCuoIpvr",
      "expandedUrl" : "https://twitter.com/i/web/status/1532522625527848968"
    }
  },
  {
    "like" : {
      "tweetId" : "1532335257021579265",
      "fullText" : "https://t.co/QXBecUEaWG",
      "expandedUrl" : "https://twitter.com/i/web/status/1532335257021579265"
    }
  },
  {
    "like" : {
      "tweetId" : "1532385706991046657",
      "fullText" : "@ShawnHymel Raspberry pico",
      "expandedUrl" : "https://twitter.com/i/web/status/1532385706991046657"
    }
  },
  {
    "like" : {
      "tweetId" : "1532424211976835076",
      "fullText" : "@ShawnHymel rpi pico because it has well designed and documented SDK with a large number of examples",
      "expandedUrl" : "https://twitter.com/i/web/status/1532424211976835076"
    }
  },
  {
    "like" : {
      "tweetId" : "1532448488587694081",
      "fullText" : "ビニールプール出すから手伝って～ https://t.co/FbImUqpVgw",
      "expandedUrl" : "https://twitter.com/i/web/status/1532448488587694081"
    }
  },
  {
    "like" : {
      "tweetId" : "1532404716214358016",
      "fullText" : "@ShawnHymel Rpi Pico seems cool and well documented.",
      "expandedUrl" : "https://twitter.com/i/web/status/1532404716214358016"
    }
  },
  {
    "like" : {
      "tweetId" : "1531946158385504258",
      "fullText" : "Projection mapping, similar to video mapping and spatial augmented reality, is a projection technology used to turn objects, often irregularly shaped, into a display surface for video projection. This was in Bucharest https://t.co/AkWlljscWq [gif: https://t.co/2HXmPq74nT] https://t.co/CFJYKmHXXS",
      "expandedUrl" : "https://twitter.com/i/web/status/1531946158385504258"
    }
  },
  {
    "like" : {
      "tweetId" : "1532360682217566209",
      "fullText" : "日記です https://t.co/lZT9q1jCyQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1532360682217566209"
    }
  },
  {
    "like" : {
      "tweetId" : "1532158618874748928",
      "fullText" : "Is it appropriate to describe a game console ... luscious? https://t.co/g1PvQZhPos",
      "expandedUrl" : "https://twitter.com/i/web/status/1532158618874748928"
    }
  },
  {
    "like" : {
      "tweetId" : "1532202660241149952",
      "fullText" : "もふもふでごぜーます https://t.co/E6WUKcCa1g",
      "expandedUrl" : "https://twitter.com/i/web/status/1532202660241149952"
    }
  },
  {
    "like" : {
      "tweetId" : "1531996242456485888",
      "fullText" : "アーニャちゃんっ！ https://t.co/xr8NangP6e",
      "expandedUrl" : "https://twitter.com/i/web/status/1531996242456485888"
    }
  },
  {
    "like" : {
      "tweetId" : "1531591326218653696",
      "fullText" : "Crotalaria cunninghamii, also known as green birdflower, is a plant of the legume family Fabaceae. Its flower strongly resembles a bird attached by its beak to the central stalk of the flowerhead [read more: https://t.co/HDJg2pytcx] https://t.co/SEhx5Lqwdf",
      "expandedUrl" : "https://twitter.com/i/web/status/1531591326218653696"
    }
  },
  {
    "like" : {
      "tweetId" : "1531781815337635840",
      "fullText" : "リクエストイラスト | てるミ #pixiv https://t.co/gwTdG5JVzC \n\n完成しましたー",
      "expandedUrl" : "https://twitter.com/i/web/status/1531781815337635840"
    }
  },
  {
    "like" : {
      "tweetId" : "1531767232371433472",
      "fullText" : "らき☆すた！！！！！ https://t.co/lXAlndTVZk",
      "expandedUrl" : "https://twitter.com/i/web/status/1531767232371433472"
    }
  },
  {
    "like" : {
      "tweetId" : "1531279762077155328",
      "fullText" : "Do you know? I am emulating a tape recorder TV. Then you may ask, what is tape recorder? https://t.co/etKfq4KeV1",
      "expandedUrl" : "https://twitter.com/i/web/status/1531279762077155328"
    }
  },
  {
    "like" : {
      "tweetId" : "1531615165728411648",
      "fullText" : "This small, ATtiny-based device enables you to temporarily (or permanently) read-only-lock SD/microSD cards: https://t.co/8QJBQbCCDY https://t.co/eIPQpaW3CG",
      "expandedUrl" : "https://twitter.com/i/web/status/1531615165728411648"
    }
  },
  {
    "like" : {
      "tweetId" : "1531642157601157120",
      "fullText" : "作った！！！！！！！！\n伊勢海老のテルミドール！！！！！！！！！！ https://t.co/DLZFrQFRf0",
      "expandedUrl" : "https://twitter.com/i/web/status/1531642157601157120"
    }
  },
  {
    "like" : {
      "tweetId" : "1531224784746729473",
      "fullText" : "Skebキャラデザ依頼🐣 https://t.co/k5x7XqyTVO",
      "expandedUrl" : "https://twitter.com/i/web/status/1531224784746729473"
    }
  },
  {
    "like" : {
      "tweetId" : "1531440772800602113",
      "fullText" : "あこがれの女の子とツーショット https://t.co/abW87VFSOI",
      "expandedUrl" : "https://twitter.com/i/web/status/1531440772800602113"
    }
  },
  {
    "like" : {
      "tweetId" : "1531285509942935553",
      "fullText" : "日記です https://t.co/21XCyaOTSP",
      "expandedUrl" : "https://twitter.com/i/web/status/1531285509942935553"
    }
  },
  {
    "like" : {
      "tweetId" : "1530611339806183424",
      "fullText" : "@gallaugher @GeekMomProjects Is that even possible with normal Python?",
      "expandedUrl" : "https://twitter.com/i/web/status/1530611339806183424"
    }
  },
  {
    "like" : {
      "tweetId" : "1530535611089690630",
      "fullText" : "／\n『この素晴らしい世界に祝福を！３』\nTVアニメ制作決定！！！✨✨✨\n＼\n\nTVアニメ第1期、第2期、そして『紅伝説』を経て、\n第3期である『この素晴らしい世界に祝福を！３』のTVアニメの制作が決定いたしました🎉\n\n制作決定ビジュアルを公開です！\n\n#このすば https://t.co/omeFjeEQWg",
      "expandedUrl" : "https://twitter.com/i/web/status/1530535611089690630"
    }
  },
  {
    "like" : {
      "tweetId" : "1531271900776648704",
      "fullText" : "さっき食べたざるそば、一生途切れんかった https://t.co/ldPBW2IgmA",
      "expandedUrl" : "https://twitter.com/i/web/status/1531271900776648704"
    }
  },
  {
    "like" : {
      "tweetId" : "1531125447903260672",
      "fullText" : "Turns out the Arduino Uno really is used for everything... https://t.co/KMBiflp59Y",
      "expandedUrl" : "https://twitter.com/i/web/status/1531125447903260672"
    }
  },
  {
    "like" : {
      "tweetId" : "1531211653974466562",
      "fullText" : "Finally got my hands on one....it's tiny!\n\n#raspberrypi https://t.co/dLjEzZQe1S",
      "expandedUrl" : "https://twitter.com/i/web/status/1531211653974466562"
    }
  },
  {
    "like" : {
      "tweetId" : "1531150830480437249",
      "fullText" : "@Hi_IamNot_here @PopBase 有層玻璃 應該没事吧",
      "expandedUrl" : "https://twitter.com/i/web/status/1531150830480437249"
    }
  },
  {
    "like" : {
      "tweetId" : "1531244479016882176",
      "fullText" : "温泉に入ったあとは蕎麦を食べるとよいとされていますので https://t.co/SKj4iCZQjP",
      "expandedUrl" : "https://twitter.com/i/web/status/1531244479016882176"
    }
  },
  {
    "like" : {
      "tweetId" : "1530630958331924481",
      "fullText" : "I need to write a new UI framework for the Open Book, but then remembered I already sort of did this for CircuitPython with circuitpyui (which itself was heavily inspired by Apple's UIKit). Anyway I think I'm just going to port it to C++ and call it a day. https://t.co/VqrLKkbwMt",
      "expandedUrl" : "https://twitter.com/i/web/status/1530630958331924481"
    }
  },
  {
    "like" : {
      "tweetId" : "1530922260902846465",
      "fullText" : "The legs are too tiny🤔 https://t.co/GrZ1GI1JOW",
      "expandedUrl" : "https://twitter.com/i/web/status/1530922260902846465"
    }
  },
  {
    "like" : {
      "tweetId" : "1363207736712966148",
      "fullText" : "😂😂😂 https://t.co/o9mRelyOwp",
      "expandedUrl" : "https://twitter.com/i/web/status/1363207736712966148"
    }
  },
  {
    "like" : {
      "tweetId" : "1530517855539810306",
      "fullText" : "@circuitpyshow It works well! Note it's a third party app made not by Adafruit but by River Wang.",
      "expandedUrl" : "https://twitter.com/i/web/status/1530517855539810306"
    }
  },
  {
    "like" : {
      "tweetId" : "1530479410410704896",
      "fullText" : "この子は昨日３秒で考えて５秒で描いた子 https://t.co/R5Wf10m62S",
      "expandedUrl" : "https://twitter.com/i/web/status/1530479410410704896"
    }
  },
  {
    "like" : {
      "tweetId" : "1530674557090078720",
      "fullText" : "りあむと凪 https://t.co/mzCxn92gPW",
      "expandedUrl" : "https://twitter.com/i/web/status/1530674557090078720"
    }
  },
  {
    "like" : {
      "tweetId" : "1530196089730924544",
      "fullText" : "start modeling the TV case https://t.co/PEfMr9OCRq",
      "expandedUrl" : "https://twitter.com/i/web/status/1530196089730924544"
    }
  },
  {
    "like" : {
      "tweetId" : "1529501097995296769",
      "fullText" : "@oicolatcho eating chocolate🍫\n#もち山金魚\nPixiv :https://t.co/HWK7r4osxM https://t.co/EgzxnH3URf",
      "expandedUrl" : "https://twitter.com/i/web/status/1529501097995296769"
    }
  },
  {
    "like" : {
      "tweetId" : "1529957620953538564",
      "fullText" : "Excited to share that the #animation which pushed me to start learning @blender is done! It takes 16 unique parts to make a #MiniVideoPlayer to watch all of your favorite movies on the go — not too bad, all things considered! #arduino #esp32 #opensource #Engineering #3drender #3D https://t.co/aacwiktCmK",
      "expandedUrl" : "https://twitter.com/i/web/status/1529957620953538564"
    }
  },
  {
    "like" : {
      "tweetId" : "1530118618968535041",
      "fullText" : "蝶と睡蓮🦋 https://t.co/umhWmWv9gS",
      "expandedUrl" : "https://twitter.com/i/web/status/1530118618968535041"
    }
  },
  {
    "like" : {
      "tweetId" : "1529903150060425216",
      "fullText" : "シロコ https://t.co/0m4OOw4HQE",
      "expandedUrl" : "https://twitter.com/i/web/status/1529903150060425216"
    }
  },
  {
    "like" : {
      "tweetId" : "1529845280828448770",
      "fullText" : "This coming Monday I’m joined by Pierre Constantineau of BlueMicro Keyboards and we go deep on mechanical keyboards - and how CircuitPython has helped.  https://t.co/zq5dX6JplN",
      "expandedUrl" : "https://twitter.com/i/web/status/1529845280828448770"
    }
  },
  {
    "like" : {
      "tweetId" : "1529656780531302400",
      "fullText" : "@gvy_dvpont Sth like this maybe? ^^\nhttps://t.co/vGVadjP09L",
      "expandedUrl" : "https://twitter.com/i/web/status/1529656780531302400"
    }
  },
  {
    "like" : {
      "tweetId" : "1529753777699315713",
      "fullText" : "https://t.co/8vyjgdSaay",
      "expandedUrl" : "https://twitter.com/i/web/status/1529753777699315713"
    }
  },
  {
    "like" : {
      "tweetId" : "1529737287986053121",
      "fullText" : "イロハちゃんです\n#ブルアカ https://t.co/7VuTStCRuD",
      "expandedUrl" : "https://twitter.com/i/web/status/1529737287986053121"
    }
  },
  {
    "like" : {
      "tweetId" : "1529479179644899329",
      "fullText" : "In 1996 Canon, Kodak and Apple collaborate on this EOS DCS 1, 6 MP Camera. It only got to prototype stages. The difference from de original DCS 1 were the embedded Newton 2000 and the SCSI port. https://t.co/pDLVYHDK9j",
      "expandedUrl" : "https://twitter.com/i/web/status/1529479179644899329"
    }
  },
  {
    "like" : {
      "tweetId" : "1529493895880617985",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1529493895880617985"
    }
  },
  {
    "like" : {
      "tweetId" : "1529316920591192064",
      "fullText" : "Elinaさん (@E2n04n )の月の国のアリスちゃんのアクリルスタンド届きました🃏\n可愛さと色遣いにうっとりします☺️✨ https://t.co/teXoSQYfPF",
      "expandedUrl" : "https://twitter.com/i/web/status/1529316920591192064"
    }
  },
  {
    "like" : {
      "tweetId" : "1529473046658134016",
      "fullText" : "Gotta do something with this right? https://t.co/wDA7pMFWin",
      "expandedUrl" : "https://twitter.com/i/web/status/1529473046658134016"
    }
  },
  {
    "like" : {
      "tweetId" : "1529277811856486403",
      "fullText" : "@den_of_wonder It did.\nhttps://t.co/rAFUOYrvq9",
      "expandedUrl" : "https://twitter.com/i/web/status/1529277811856486403"
    }
  },
  {
    "like" : {
      "tweetId" : "1529398837940572161",
      "fullText" : "Tiny Robot Big Battery! Full video 👉https://t.co/8hPTfRG1XQ https://t.co/bUDooooigo",
      "expandedUrl" : "https://twitter.com/i/web/status/1529398837940572161"
    }
  },
  {
    "like" : {
      "tweetId" : "1529483424829956102",
      "fullText" : "@den_of_wonder I had a theory that the I/O bandwidth defines the usage of electronics. Computers with huge monitors and comfortable keyboards have the largest bandwidth so they are used in serious workflows. Phones in the middle. Watches with tiny screens can barely do more than health tracking",
      "expandedUrl" : "https://twitter.com/i/web/status/1529483424829956102"
    }
  },
  {
    "like" : {
      "tweetId" : "1529443884106846208",
      "fullText" : "財布を忘れたことに気づいた夢見りあむ https://t.co/5yLXmV30FR",
      "expandedUrl" : "https://twitter.com/i/web/status/1529443884106846208"
    }
  },
  {
    "like" : {
      "tweetId" : "1529203619106816000",
      "fullText" : "The rarest thing I own currently https://t.co/7c3fp35mV9",
      "expandedUrl" : "https://twitter.com/i/web/status/1529203619106816000"
    }
  },
  {
    "like" : {
      "tweetId" : "1528856018389639168",
      "fullText" : "Nvidia RTX 4090 TI-84 https://t.co/Vj5KZtPBnO",
      "expandedUrl" : "https://twitter.com/i/web/status/1528856018389639168"
    }
  },
  {
    "like" : {
      "tweetId" : "1529181242154958848",
      "fullText" : "When Steve Jobs introduce the iPhone in 2007, he started presenting 3 devices: a widescreen iPod with touch controls, a revolutionary mobile phone and a breakthrough internet communicator. What almost nobody knew is that those devices existed as internal prototypes. https://t.co/emOOoOzGcx",
      "expandedUrl" : "https://twitter.com/i/web/status/1529181242154958848"
    }
  },
  {
    "like" : {
      "tweetId" : "1529086121044586498",
      "fullText" : "This musical instrument was made from an old rotary telephone and a drum rhythm machine: https://t.co/Euh2ELbx1R https://t.co/dUx40dsKaS",
      "expandedUrl" : "https://twitter.com/i/web/status/1529086121044586498"
    }
  },
  {
    "like" : {
      "tweetId" : "1529089522335555584",
      "fullText" : "アーニャ https://t.co/ULKF2bJeyz",
      "expandedUrl" : "https://twitter.com/i/web/status/1529089522335555584"
    }
  },
  {
    "like" : {
      "tweetId" : "1528433361408036864",
      "fullText" : "Innovative new compact and lightweight design https://t.co/U2jz6AYMka",
      "expandedUrl" : "https://twitter.com/i/web/status/1528433361408036864"
    }
  },
  {
    "like" : {
      "tweetId" : "1528652761323433984",
      "fullText" : "commission https://t.co/AC5mD1deyW",
      "expandedUrl" : "https://twitter.com/i/web/status/1528652761323433984"
    }
  },
  {
    "like" : {
      "tweetId" : "1528525764659974146",
      "fullText" : "Here we go! Day 1 of wearing my North-finding chest harness. It definitely works and is mostly not annoying 😜 #arduino #maker #engineering https://t.co/mJw926P1UY",
      "expandedUrl" : "https://twitter.com/i/web/status/1528525764659974146"
    }
  },
  {
    "like" : {
      "tweetId" : "1528736554088210434",
      "fullText" : "幼なじみ特有の距離感\n待ち合わせ https://t.co/VDYSS5K88V",
      "expandedUrl" : "https://twitter.com/i/web/status/1528736554088210434"
    }
  },
  {
    "like" : {
      "tweetId" : "1528511368990556160",
      "fullText" : "Pico game thingy on breadboard. https://t.co/3bKD2i8pDB",
      "expandedUrl" : "https://twitter.com/i/web/status/1528511368990556160"
    }
  },
  {
    "like" : {
      "tweetId" : "1528369522939666432",
      "fullText" : "先生… https://t.co/U0Akb7w1nW",
      "expandedUrl" : "https://twitter.com/i/web/status/1528369522939666432"
    }
  },
  {
    "like" : {
      "tweetId" : "1528466352276930560",
      "fullText" : "おはよ https://t.co/uVKQxbuUqc",
      "expandedUrl" : "https://twitter.com/i/web/status/1528466352276930560"
    }
  },
  {
    "like" : {
      "tweetId" : "1528017239730962432",
      "fullText" : "EMack game line taping machine. https://t.co/FDNfmhAB37",
      "expandedUrl" : "https://twitter.com/i/web/status/1528017239730962432"
    }
  },
  {
    "like" : {
      "tweetId" : "1527995076089364480",
      "fullText" : "あ、奈緒きたよ https://t.co/EsB4uqXHXJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1527995076089364480"
    }
  },
  {
    "like" : {
      "tweetId" : "1527940948998918144",
      "fullText" : "灯 https://t.co/Lixcqx6EDL",
      "expandedUrl" : "https://twitter.com/i/web/status/1527940948998918144"
    }
  },
  {
    "like" : {
      "tweetId" : "1527967689859338242",
      "fullText" : "TurtleAuth DIY Security Token Gets (Re)designed for Durable, Everyday Use https://t.co/uirK4dPPPK",
      "expandedUrl" : "https://twitter.com/i/web/status/1527967689859338242"
    }
  },
  {
    "like" : {
      "tweetId" : "1527478981150244864",
      "fullText" : "@NanoRaptor I still have one of those IBM microdrives in a CF form factor. It’s a tiiiiny spinning disk! https://t.co/4W5HC9AI8t",
      "expandedUrl" : "https://twitter.com/i/web/status/1527478981150244864"
    }
  },
  {
    "like" : {
      "tweetId" : "1527474605715124225",
      "fullText" : "https://t.co/ynn0kXK06t",
      "expandedUrl" : "https://twitter.com/i/web/status/1527474605715124225"
    }
  },
  {
    "like" : {
      "tweetId" : "1527576401934974976",
      "fullText" : "キメ台詞の練習 https://t.co/RU547gEjke",
      "expandedUrl" : "https://twitter.com/i/web/status/1527576401934974976"
    }
  },
  {
    "like" : {
      "tweetId" : "1525621444356362240",
      "fullText" : "This orange plasma display is being powered by just enough voltage to create a dim glow, but the 405nm laser pointer pushes certain areas into a higher output, which remains until power cycled! A plasma Etch-A-Sketch. https://t.co/t1Oe05TX1r",
      "expandedUrl" : "https://twitter.com/i/web/status/1525621444356362240"
    }
  },
  {
    "like" : {
      "tweetId" : "1527293728867639296",
      "fullText" : "oh what a feeling\n(imac on the ceiling) https://t.co/vjnu6P18Uo",
      "expandedUrl" : "https://twitter.com/i/web/status/1527293728867639296"
    }
  },
  {
    "like" : {
      "tweetId" : "1527336147822645248",
      "fullText" : "This week on the show @BlitzCityDIY stops by.  Did you ever wonder how she picked out her nickname?  Listen in and you can find out!  Subscribe here:  https://t.co/P9EwqLTGAv",
      "expandedUrl" : "https://twitter.com/i/web/status/1527336147822645248"
    }
  },
  {
    "like" : {
      "tweetId" : "1527263394679619584",
      "fullText" : "Analog electronic songbird circuit from 2019 (an ancestor of my Printed Circuit Birds). Her song pattern is created by four oscillators charging a large capacitor #ai #ee #bird https://t.co/fH0yQ5oRls",
      "expandedUrl" : "https://twitter.com/i/web/status/1527263394679619584"
    }
  },
  {
    "like" : {
      "tweetId" : "1527284816219197442",
      "fullText" : "The CircuitPython online IDE for classes #Education #CircuitPython River___Wang  https://t.co/1TEg81hMVS",
      "expandedUrl" : "https://twitter.com/i/web/status/1527284816219197442"
    }
  },
  {
    "like" : {
      "tweetId" : "1526968474462998528",
      "fullText" : "Breathing pleating https://t.co/9kmThs8hwC",
      "expandedUrl" : "https://twitter.com/i/web/status/1526968474462998528"
    }
  },
  {
    "like" : {
      "tweetId" : "1527029915471724545",
      "fullText" : "Coming soon to @crowd_supply, ANT BBPS is a small and portable breadboard power supply with an OLED display. Perfect for solderless prototyping! https://t.co/nGarT6cb2W https://t.co/wOs6U8AAU2",
      "expandedUrl" : "https://twitter.com/i/web/status/1527029915471724545"
    }
  },
  {
    "like" : {
      "tweetId" : "1527283192021012482",
      "fullText" : "The CircuitPython online IDE for classes #Education #CircuitPython @River___Wang https://t.co/Gc6ZF7DA4k",
      "expandedUrl" : "https://twitter.com/i/web/status/1527283192021012482"
    }
  },
  {
    "like" : {
      "tweetId" : "1526716339477368832",
      "fullText" : "More buttons you say?\nHow we feelin the button labels?\nMore buttons more problems. https://t.co/A33oQn73qw",
      "expandedUrl" : "https://twitter.com/i/web/status/1526716339477368832"
    }
  },
  {
    "like" : {
      "tweetId" : "1527190044636680193",
      "fullText" : "At present, we are testing the performance of soldermask ink...\nJust testing. https://t.co/NvbsdVkUJX",
      "expandedUrl" : "https://twitter.com/i/web/status/1527190044636680193"
    }
  },
  {
    "like" : {
      "tweetId" : "1527218632308457472",
      "fullText" : "Favorite様（@Favorite_Onepi）とのコラボで\nうちの子「月の国のアリス」ちゃんの衣装を\n普段でも着られるワンピースにアレンジしました🌙\nとても可愛いデザインにできたと思います！\n\nご予約が一定数に達すると生産決定となります✨\nよろしくお願いいたします☺️！\n↓\nhttps://t.co/wyzTyGsaoQ https://t.co/KPTo5wvk9I",
      "expandedUrl" : "https://twitter.com/i/web/status/1527218632308457472"
    }
  },
  {
    "like" : {
      "tweetId" : "1527237731201728512",
      "fullText" : "設計図 https://t.co/i50ZijAgqS",
      "expandedUrl" : "https://twitter.com/i/web/status/1527237731201728512"
    }
  },
  {
    "like" : {
      "tweetId" : "1526882850053574656",
      "fullText" : "オオカミだよ https://t.co/YyVFnjwQnq",
      "expandedUrl" : "https://twitter.com/i/web/status/1526882850053574656"
    }
  },
  {
    "like" : {
      "tweetId" : "1526402780490964992",
      "fullText" : "I *adore* tiny fold-up travel-size things, and was pondering what minimal-but-usable CircuitPython development might look like without bringing a laptop.\nHere’s Runestone on iPhone with a folding Bluetooth keyboard and Proximity Trinkey as the dev board. 🧵 https://t.co/VkKt3O5ATW",
      "expandedUrl" : "https://twitter.com/i/web/status/1526402780490964992"
    }
  },
  {
    "like" : {
      "tweetId" : "1526515704987385856",
      "fullText" : "お菓子な星の遊園地🎡 https://t.co/Q6pHn0kbU3",
      "expandedUrl" : "https://twitter.com/i/web/status/1526515704987385856"
    }
  },
  {
    "like" : {
      "tweetId" : "1526448517707091968",
      "fullText" : "和風ロリータ黒髪おさげ赤りぼんちゃん！\n#Skeb https://t.co/9DFo2LyKxX",
      "expandedUrl" : "https://twitter.com/i/web/status/1526448517707091968"
    }
  },
  {
    "like" : {
      "tweetId" : "1526274366379540483",
      "fullText" : "Richard Sutherland's Framedeck is a TRS-80 Model 100-inspired cyberdeck with an ATmega32U4-controlled keyboard and trackball: https://t.co/tvdcsJhSE9 https://t.co/Dl0t0V8RAr",
      "expandedUrl" : "https://twitter.com/i/web/status/1526274366379540483"
    }
  },
  {
    "like" : {
      "tweetId" : "1526111963918778368",
      "fullText" : "Straya. https://t.co/f25gkQm1aU",
      "expandedUrl" : "https://twitter.com/i/web/status/1526111963918778368"
    }
  },
  {
    "like" : {
      "tweetId" : "1525944461305745408",
      "fullText" : "Insanely cool Framework Laptop Mainboard-based cyberdeck by brickbots: https://t.co/gREZf6uA9v https://t.co/fEDcMoNL2K",
      "expandedUrl" : "https://twitter.com/i/web/status/1525944461305745408"
    }
  },
  {
    "like" : {
      "tweetId" : "1525097204439998464",
      "fullText" : "@NanoRaptor https://t.co/Mc8jxeRpn6",
      "expandedUrl" : "https://twitter.com/i/web/status/1525097204439998464"
    }
  },
  {
    "like" : {
      "tweetId" : "1525113633851617280",
      "fullText" : "Compliant mechanisms are fun! check out these non-magnetic, 3d printed pliers ⠀⠀⠀⠀⠀⠀⠀⠀⠀\nDownloadable files available https://t.co/IS1bvxnFKQ: ⠀⠀⠀⠀⠀⠀\n#FromTheArchives #compliantMechanism #3dprint #compliant #pliers #maker #makerEd  #STEAM #STEAMEducation https://t.co/vtLpahIX9p",
      "expandedUrl" : "https://twitter.com/i/web/status/1525113633851617280"
    }
  },
  {
    "like" : {
      "tweetId" : "1525214539389739014",
      "fullText" : "Inking Mahjong tiles. https://t.co/itdOHTDrNv",
      "expandedUrl" : "https://twitter.com/i/web/status/1525214539389739014"
    }
  },
  {
    "like" : {
      "tweetId" : "1524733793755664384",
      "fullText" : "PLL in action. https://t.co/80fzohoniz",
      "expandedUrl" : "https://twitter.com/i/web/status/1524733793755664384"
    }
  },
  {
    "like" : {
      "tweetId" : "1525438518608142336",
      "fullText" : "What’s wrong babe? You’ve hardly touched your jabbacado toast. https://t.co/U3wbRzTBx8",
      "expandedUrl" : "https://twitter.com/i/web/status/1525438518608142336"
    }
  },
  {
    "like" : {
      "tweetId" : "1525272148763607040",
      "fullText" : "They were 30MB micro MO disks and they were glorious. https://t.co/6LIV9ZQA4p https://t.co/pUpONhF2l5",
      "expandedUrl" : "https://twitter.com/i/web/status/1525272148763607040"
    }
  },
  {
    "like" : {
      "tweetId" : "1525802807642583041",
      "fullText" : "最強のカレー作った https://t.co/yjkDBGgU06",
      "expandedUrl" : "https://twitter.com/i/web/status/1525802807642583041"
    }
  },
  {
    "like" : {
      "tweetId" : "1525777443138596865",
      "fullText" : "春の出会いをテーマにしました https://t.co/bJOx7Sztf1",
      "expandedUrl" : "https://twitter.com/i/web/status/1525777443138596865"
    }
  },
  {
    "like" : {
      "tweetId" : "1525624392801132545",
      "fullText" : "I just want this with a Raspberry Pi Compute Module 4 and a slim Li-Poly battery inside, is that too much to ask?\nhttps://t.co/hkUfjcmVp9 https://t.co/RfsUr5okD5",
      "expandedUrl" : "https://twitter.com/i/web/status/1525624392801132545"
    }
  },
  {
    "like" : {
      "tweetId" : "1525677207888154624",
      "fullText" : "At this point I think you should all follow Matias. https://t.co/pnpOUKpLVm",
      "expandedUrl" : "https://twitter.com/i/web/status/1525677207888154624"
    }
  },
  {
    "like" : {
      "tweetId" : "1525579011581255682",
      "fullText" : "The SiriBook prototype (2017), with its 19:5 screen, is the pinnacle of Apple getting rid of buttons era. \n@NanoRaptor https://t.co/gVL3LtbV7m",
      "expandedUrl" : "https://twitter.com/i/web/status/1525579011581255682"
    }
  },
  {
    "like" : {
      "tweetId" : "1525095674068738048",
      "fullText" : "Bottom MagSafe https://t.co/en4FcJUw1n",
      "expandedUrl" : "https://twitter.com/i/web/status/1525095674068738048"
    }
  },
  {
    "like" : {
      "tweetId" : "1524765334569635841",
      "fullText" : "メイド浅利七海可愛いねぇ https://t.co/wgqy8831TY",
      "expandedUrl" : "https://twitter.com/i/web/status/1524765334569635841"
    }
  },
  {
    "like" : {
      "tweetId" : "1524336259468251136",
      "fullText" : "龍崎薫(17) https://t.co/LKgCplBDkV",
      "expandedUrl" : "https://twitter.com/i/web/status/1524336259468251136"
    }
  },
  {
    "like" : {
      "tweetId" : "1524717945406246917",
      "fullText" : "作って",
      "expandedUrl" : "https://twitter.com/i/web/status/1524717945406246917"
    }
  },
  {
    "like" : {
      "tweetId" : "1524321637826449410",
      "fullText" : "Remember to check your footprints on paper when in doubt. It is much faster than a respin! https://t.co/oN8OJWZsbW",
      "expandedUrl" : "https://twitter.com/i/web/status/1524321637826449410"
    }
  },
  {
    "like" : {
      "tweetId" : "1524614454935056384",
      "fullText" : "ねこちゃんメイド https://t.co/GOtS26TAhR",
      "expandedUrl" : "https://twitter.com/i/web/status/1524614454935056384"
    }
  },
  {
    "like" : {
      "tweetId" : "1524718891225780229",
      "fullText" : "ごきげんなアーニャちゃん https://t.co/J4pOvkG9SO",
      "expandedUrl" : "https://twitter.com/i/web/status/1524718891225780229"
    }
  },
  {
    "like" : {
      "tweetId" : "1524279890346143745",
      "fullText" : "猫耳メイド 浅利七海ちゃん！ https://t.co/7HK9wBpeWn",
      "expandedUrl" : "https://twitter.com/i/web/status/1524279890346143745"
    }
  },
  {
    "like" : {
      "tweetId" : "1524591948123996160",
      "fullText" : "猫耳メイド 前川みくちゃん！ https://t.co/64JDOsaGTO",
      "expandedUrl" : "https://twitter.com/i/web/status/1524591948123996160"
    }
  },
  {
    "like" : {
      "tweetId" : "1524576946339860482",
      "fullText" : "Fully working Bluetooth password keeper! Data enciphered. https://t.co/kelYVq9OTB",
      "expandedUrl" : "https://twitter.com/i/web/status/1524576946339860482"
    }
  },
  {
    "like" : {
      "tweetId" : "1524578242547625984",
      "fullText" : "https://t.co/EJUygoM5eG",
      "expandedUrl" : "https://twitter.com/i/web/status/1524578242547625984"
    }
  },
  {
    "like" : {
      "tweetId" : "1524578820438822913",
      "fullText" : "3D printed cases for my password keepers came in today. Nicely fit. Left one side open and slided the PCB in. Here are the 52840 feather Bluetooth version. Xiao 2040 version and the Pi Pico version. https://t.co/holfn8asM7",
      "expandedUrl" : "https://twitter.com/i/web/status/1524578820438822913"
    }
  },
  {
    "like" : {
      "tweetId" : "1521177904679460864",
      "fullText" : "Today’s new episode with @makermelissa is also on YouTube.  See us chat about Blinka, being a maintainer, and more.  https://t.co/R2473QUn2o",
      "expandedUrl" : "https://twitter.com/i/web/status/1521177904679460864"
    }
  },
  {
    "like" : {
      "tweetId" : "1515029436734730243",
      "fullText" : "The show will be back on Monday.  @alie_gg joins me and we talk Sparkfun, the Miami tech scene, and more.  Don't miss it, subscribe in your favorite podcast app now:  https://t.co/P9EwqLTGAv",
      "expandedUrl" : "https://twitter.com/i/web/status/1515029436734730243"
    }
  },
  {
    "like" : {
      "tweetId" : "1524133952180858882",
      "fullText" : "How it should have ended. https://t.co/2UyKO0pbeN",
      "expandedUrl" : "https://twitter.com/i/web/status/1524133952180858882"
    }
  },
  {
    "like" : {
      "tweetId" : "1523963023475363840",
      "fullText" : "今日はメイドの日らしいのでドジっ子メイド置いておきます https://t.co/cmUwX6zTJr",
      "expandedUrl" : "https://twitter.com/i/web/status/1523963023475363840"
    }
  },
  {
    "like" : {
      "tweetId" : "1523944684179300352",
      "fullText" : "https://t.co/JO6uihYpj5",
      "expandedUrl" : "https://twitter.com/i/web/status/1523944684179300352"
    }
  },
  {
    "like" : {
      "tweetId" : "1523958914294763521",
      "fullText" : "はたらき蜂と申します🐝\n#メイドの日 https://t.co/aKeWcWPXAa",
      "expandedUrl" : "https://twitter.com/i/web/status/1523958914294763521"
    }
  },
  {
    "like" : {
      "tweetId" : "1523958739875016704",
      "fullText" : "メイド文香さん https://t.co/yvB1YMKwJ2",
      "expandedUrl" : "https://twitter.com/i/web/status/1523958739875016704"
    }
  },
  {
    "like" : {
      "tweetId" : "1523522361881817093",
      "fullText" : "https://t.co/7ZH5PyU6n1",
      "expandedUrl" : "https://twitter.com/i/web/status/1523522361881817093"
    }
  },
  {
    "like" : {
      "tweetId" : "1523528258494636033",
      "fullText" : "Classic Tamagotchi is Reincarnated in Modern Hardware https://t.co/s7dBXK11jj",
      "expandedUrl" : "https://twitter.com/i/web/status/1523528258494636033"
    }
  },
  {
    "like" : {
      "tweetId" : "1523618730416037893",
      "fullText" : "Transfer texture from an @adafruit PyGamer to #GameBuilderGarage on #NintendoSwitch by mouse emulation.\nA translation in #CircuitPython of Arduino code, credit to the original author and community.\nBonus: copy the texture via USB, display on screen.\nCode: https://t.co/zKaBJnnW6L https://t.co/LLSM5u8NQ8",
      "expandedUrl" : "https://twitter.com/i/web/status/1523618730416037893"
    }
  },
  {
    "like" : {
      "tweetId" : "1523672636131135489",
      "fullText" : "Oooh circular lipo cells arrived.\n\na few years ago, I'd have thought this photo was an April fools joke. \n\nWe have so many cool \"hand me down\" products from the consumer industry! https://t.co/os3NEukpmB",
      "expandedUrl" : "https://twitter.com/i/web/status/1523672636131135489"
    }
  },
  {
    "like" : {
      "tweetId" : "1523669967475933184",
      "fullText" : "Build an ATmega328-controlled digital FM receiver design complete with an LCD screen and three push buttons: https://t.co/Lmu1jiNFn7 https://t.co/PENW6W6s9N",
      "expandedUrl" : "https://twitter.com/i/web/status/1523669967475933184"
    }
  },
  {
    "like" : {
      "tweetId" : "1523550664353193984",
      "fullText" : "「「いえーい」」 https://t.co/IHUvdUB03F",
      "expandedUrl" : "https://twitter.com/i/web/status/1523550664353193984"
    }
  },
  {
    "like" : {
      "tweetId" : "1523666164488220672",
      "fullText" : "The show is off this week - catch up with @makermelissa in last week's episode and next week @BlitzCityDIY visits the show!",
      "expandedUrl" : "https://twitter.com/i/web/status/1523666164488220672"
    }
  },
  {
    "like" : {
      "tweetId" : "1522929340564086787",
      "fullText" : "@MarkTomasovic A one-year study of Vietnamese youth who built their own Bugatti out of clay mud... 👏👏 https://t.co/gVlDpQbL2J",
      "expandedUrl" : "https://twitter.com/i/web/status/1522929340564086787"
    }
  },
  {
    "like" : {
      "tweetId" : "1522725730567995392",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1522725730567995392"
    }
  },
  {
    "like" : {
      "tweetId" : "1521771623140917248",
      "fullText" : "What percentage of people would select the same choice as you in this poll?",
      "expandedUrl" : "https://twitter.com/i/web/status/1521771623140917248"
    }
  },
  {
    "like" : {
      "tweetId" : "1522969480271335424",
      "fullText" : "サプライズ https://t.co/nIxpsv40Qq",
      "expandedUrl" : "https://twitter.com/i/web/status/1522969480271335424"
    }
  },
  {
    "like" : {
      "tweetId" : "1523096128174329856",
      "fullText" : "妹尾あいこちゃん！ https://t.co/6LR4BjdNJ6",
      "expandedUrl" : "https://twitter.com/i/web/status/1523096128174329856"
    }
  },
  {
    "like" : {
      "tweetId" : "1522411903381045253",
      "fullText" : "春風どれみちゃん！ https://t.co/fljYQjTCV9",
      "expandedUrl" : "https://twitter.com/i/web/status/1522411903381045253"
    }
  },
  {
    "like" : {
      "tweetId" : "1522165072369315840",
      "fullText" : "＃こどもの日 成長を願う絵。\n「小さな手 大きな空」←→「少し大きな空」 https://t.co/vjbpm2mxO0",
      "expandedUrl" : "https://twitter.com/i/web/status/1522165072369315840"
    }
  },
  {
    "like" : {
      "tweetId" : "1522055270695792640",
      "fullText" : "Solder pasting on a budget? Can't vacuum seal the stencil in an apartment? Super jealous of everyone's fancy paste jig?\n\nBy far, my favorite way has been printed jigs. They take a while to get just right, but once tolerances are good, the results are fine for the price too... https://t.co/V5K1yojz6D",
      "expandedUrl" : "https://twitter.com/i/web/status/1522055270695792640"
    }
  },
  {
    "like" : {
      "tweetId" : "1522346681542623233",
      "fullText" : "The Toast keyboard is an open source split design for those with short index fingers: https://t.co/nwBxWTjpGc https://t.co/x4jDJTz09E",
      "expandedUrl" : "https://twitter.com/i/web/status/1522346681542623233"
    }
  },
  {
    "like" : {
      "tweetId" : "1522216270665420801",
      "fullText" : "Had an idea using a @Raspberry_Pi Pico. \n\nLucky I can just cycle 5 mins to the Pi shop and grab one (or 5...)! https://t.co/QgkHMkUqCJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1522216270665420801"
    }
  },
  {
    "like" : {
      "tweetId" : "1522058829726248960",
      "fullText" : "藤原はづきちゃん！ https://t.co/9cenuRq8Oi",
      "expandedUrl" : "https://twitter.com/i/web/status/1522058829726248960"
    }
  },
  {
    "like" : {
      "tweetId" : "1521461838327734273",
      "fullText" : "Pointers https://t.co/TjfX5K54H7",
      "expandedUrl" : "https://twitter.com/i/web/status/1521461838327734273"
    }
  },
  {
    "like" : {
      "tweetId" : "1521840632146366465",
      "fullText" : "@pwang @River___Wang @mariatta @pyodide Apparently PyScript is CPython that is run using WASM in the browser",
      "expandedUrl" : "https://twitter.com/i/web/status/1521840632146366465"
    }
  },
  {
    "like" : {
      "tweetId" : "1521763355412684800",
      "fullText" : "いろいろ | てるミ #pixiv https://t.co/4sexQzpF2m",
      "expandedUrl" : "https://twitter.com/i/web/status/1521763355412684800"
    }
  },
  {
    "like" : {
      "tweetId" : "1521458850544914433",
      "fullText" : "🍏 https://t.co/g4hHxaDxzH",
      "expandedUrl" : "https://twitter.com/i/web/status/1521458850544914433"
    }
  },
  {
    "like" : {
      "tweetId" : "1521759346069098498",
      "fullText" : "Macintosh Horizontal product was not popular on release, but has developed a cult following. Worshippers meet under sodium lamps and speak arcane languages. https://t.co/4zlbdoYQFf",
      "expandedUrl" : "https://twitter.com/i/web/status/1521759346069098498"
    }
  },
  {
    "like" : {
      "tweetId" : "1521768082112499712",
      "fullText" : "@NanoRaptor Quite like it. https://t.co/RPJVK7bNFx",
      "expandedUrl" : "https://twitter.com/i/web/status/1521768082112499712"
    }
  },
  {
    "like" : {
      "tweetId" : "1521133770459557888",
      "fullText" : "@anne_engineer @River___Wang @mariatta Brython is a re-implementation of the Python language, that transpiles to Javascript. It doesn't support any compiled extension libraries (e.g. Numpy or Pandas etc.)\nPyScript uses @pyodide, which is the same CPython that you run on your laptop, and it *does* support C extension.",
      "expandedUrl" : "https://twitter.com/i/web/status/1521133770459557888"
    }
  },
  {
    "like" : {
      "tweetId" : "1521124519884300288",
      "fullText" : "@River___Wang @mariatta @pwang Good question",
      "expandedUrl" : "https://twitter.com/i/web/status/1521124519884300288"
    }
  },
  {
    "like" : {
      "tweetId" : "1521120959612215298",
      "fullText" : "Hey look! That computer inside a computer thing is real now! It's the PCIe version of the Blicube KVM: https://t.co/I2qzTaATjZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1521120959612215298"
    }
  },
  {
    "like" : {
      "tweetId" : "1520669585929777153",
      "fullText" : "🍧 https://t.co/HrnBovtCUI",
      "expandedUrl" : "https://twitter.com/i/web/status/1520669585929777153"
    }
  },
  {
    "like" : {
      "tweetId" : "1520949744046325760",
      "fullText" : "幼なじみ特有の距離感\n休日 https://t.co/PGuETSp7Ud",
      "expandedUrl" : "https://twitter.com/i/web/status/1520949744046325760"
    }
  },
  {
    "like" : {
      "tweetId" : "1520564916629151744",
      "fullText" : "USB-C powered motherboards are the future. https://t.co/kJfPGIPU2v",
      "expandedUrl" : "https://twitter.com/i/web/status/1520564916629151744"
    }
  },
  {
    "like" : {
      "tweetId" : "1520582206942748672",
      "fullText" : "PCIe type C https://t.co/fe7x2yiY2A https://t.co/RFXyQ5Z4PZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1520582206942748672"
    }
  },
  {
    "like" : {
      "tweetId" : "1520712699893936128",
      "fullText" : "ほわんちゃん誕生日！\n#SB69 https://t.co/oBXbvAFn7T",
      "expandedUrl" : "https://twitter.com/i/web/status/1520712699893936128"
    }
  },
  {
    "like" : {
      "tweetId" : "1520751610334380032",
      "fullText" : "MagSafest. https://t.co/YxatDZsnxI",
      "expandedUrl" : "https://twitter.com/i/web/status/1520751610334380032"
    }
  },
  {
    "like" : {
      "tweetId" : "1520866153123520512",
      "fullText" : "!!! Very cool to see the @TrackrTrain in the MoMA design store https://t.co/y5TRAXhIS7",
      "expandedUrl" : "https://twitter.com/i/web/status/1520866153123520512"
    }
  },
  {
    "like" : {
      "tweetId" : "1431708133307658243",
      "fullText" : "I finished my fully 3D printed marble run! It's now 5 feet tall, motorized, and is a full rainbow\n\n#hotmakes https://t.co/fCi6AGGRt1",
      "expandedUrl" : "https://twitter.com/i/web/status/1431708133307658243"
    }
  },
  {
    "like" : {
      "tweetId" : "1519841357736595456",
      "fullText" : "https://t.co/ZtWnWutFCO",
      "expandedUrl" : "https://twitter.com/i/web/status/1519841357736595456"
    }
  },
  {
    "like" : {
      "tweetId" : "1520112045529702407",
      "fullText" : "I've arm mounted the @easythreed3d K7 with a battery pack so I can print on the go. And it works! https://t.co/d4D07Ti62N https://t.co/2o9NAROp3Y",
      "expandedUrl" : "https://twitter.com/i/web/status/1520112045529702407"
    }
  },
  {
    "like" : {
      "tweetId" : "1520236506484379654",
      "fullText" : "ねぇあんた～私のファンでしょ？サインしてあげようか？ https://t.co/GGDMdaMgAb",
      "expandedUrl" : "https://twitter.com/i/web/status/1520236506484379654"
    }
  },
  {
    "like" : {
      "tweetId" : "1520239489259831296",
      "fullText" : "櫻井桃華ちゃんと橘ありすちゃん https://t.co/dWSka0Um6S",
      "expandedUrl" : "https://twitter.com/i/web/status/1520239489259831296"
    }
  },
  {
    "like" : {
      "tweetId" : "1520241826359222272",
      "fullText" : "Took my door name plate home today. https://t.co/4KKlpr8g82",
      "expandedUrl" : "https://twitter.com/i/web/status/1520241826359222272"
    }
  },
  {
    "like" : {
      "tweetId" : "1520032392068702209",
      "fullText" : "@River___Wang Congratulations!",
      "expandedUrl" : "https://twitter.com/i/web/status/1520032392068702209"
    }
  },
  {
    "like" : {
      "tweetId" : "1520017055365304320",
      "fullText" : "Today is my last day formally as a teacher. I am joining industry as a software engineer. The company is know for good wlb, so I will have more time working on my personal projects which I never had a chance to teach on the stage. You will see me more",
      "expandedUrl" : "https://twitter.com/i/web/status/1520017055365304320"
    }
  },
  {
    "like" : {
      "tweetId" : "1519995190735425537",
      "fullText" : "Chonky Palmtop Will Slide Into Your Heart https://t.co/66UKvCPBYi",
      "expandedUrl" : "https://twitter.com/i/web/status/1519995190735425537"
    }
  },
  {
    "like" : {
      "tweetId" : "1519837706381107202",
      "fullText" : "My latest project on CircuitPython education is a cheap expansion board for Seeed Xiao to be used in classes and camps. I also slimed down the CPy display library so that it can run on Xiao (SAMD21). https://t.co/ZtWnWutFCO #CircuitPython https://t.co/srRqXqNaBI",
      "expandedUrl" : "https://twitter.com/i/web/status/1519837706381107202"
    }
  },
  {
    "like" : {
      "tweetId" : "1519672299535929345",
      "fullText" : "@sulfuroid @arcbtc https://t.co/umwUKivQMg",
      "expandedUrl" : "https://twitter.com/i/web/status/1519672299535929345"
    }
  },
  {
    "like" : {
      "tweetId" : "1519379917426810886",
      "fullText" : "Ooh, a \"Parcel from HK\" is on its way today.",
      "expandedUrl" : "https://twitter.com/i/web/status/1519379917426810886"
    }
  },
  {
    "like" : {
      "tweetId" : "1519406196477812738",
      "fullText" : "I’m still learning about MIDI and the multiple MIDI Learn Guides by @BlitzCityDIY have been so helpful.  AND she’ll be on the show in a few weeks and we’ll talk a little beginner MIDI! https://t.co/2UGWNIZpi3",
      "expandedUrl" : "https://twitter.com/i/web/status/1519406196477812738"
    }
  },
  {
    "like" : {
      "tweetId" : "1519343253262245888",
      "fullText" : "@NanoRaptor DANA NO",
      "expandedUrl" : "https://twitter.com/i/web/status/1519343253262245888"
    }
  },
  {
    "like" : {
      "tweetId" : "1519294957479411712",
      "fullText" : "パヴリチェンコー https://t.co/iteev6yk9c",
      "expandedUrl" : "https://twitter.com/i/web/status/1519294957479411712"
    }
  },
  {
    "like" : {
      "tweetId" : "1519194710849597442",
      "fullText" : "Anyone else remember when they used to mail out Stroop-untu Live CDs? https://t.co/NhRysvf3t4",
      "expandedUrl" : "https://twitter.com/i/web/status/1519194710849597442"
    }
  },
  {
    "like" : {
      "tweetId" : "1518324079308115968",
      "fullText" : "https://t.co/IUDSLyQGXw",
      "expandedUrl" : "https://twitter.com/i/web/status/1518324079308115968"
    }
  },
  {
    "like" : {
      "tweetId" : "1518199371036508160",
      "fullText" : "日記です https://t.co/RqX3jjMdfM",
      "expandedUrl" : "https://twitter.com/i/web/status/1518199371036508160"
    }
  },
  {
    "like" : {
      "tweetId" : "1518144276051668992",
      "fullText" : "おはよ、雪美ちゃん https://t.co/ZlomOJVJQZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1518144276051668992"
    }
  },
  {
    "like" : {
      "tweetId" : "1517703984923901952",
      "fullText" : "銀ちゃん https://t.co/HdoOpqElhP",
      "expandedUrl" : "https://twitter.com/i/web/status/1517703984923901952"
    }
  },
  {
    "like" : {
      "tweetId" : "1517598030308032515",
      "fullText" : "Red Shirt Jeff says subscribe or he'll break this @45Drives Storinator.\n\nPlus, you'll be the first to find out if we can actually make the #PetabytePi happen.\n\nhttps://t.co/QAmZ8SB2pn https://t.co/ccB5YyM7xV",
      "expandedUrl" : "https://twitter.com/i/web/status/1517598030308032515"
    }
  },
  {
    "like" : {
      "tweetId" : "1517329838134206464",
      "fullText" : "I got a cut above my eyebrow today  from a graphics card.\n\nI think that's the strangest injury I've sustained working on a Raspberry Pi. But far from the worst.",
      "expandedUrl" : "https://twitter.com/i/web/status/1517329838134206464"
    }
  },
  {
    "like" : {
      "tweetId" : "1517267793728651264",
      "fullText" : "Watched The Batman the other night, and when I went to bed I jokingly said \"Hey Google, UNLEASH THE DARKNESS\" and she actually turned the lights off",
      "expandedUrl" : "https://twitter.com/i/web/status/1517267793728651264"
    }
  },
  {
    "like" : {
      "tweetId" : "1517138947872542720",
      "fullText" : "#SPY_FAMILY \n#SPYxFamily https://t.co/368PY2QFYs",
      "expandedUrl" : "https://twitter.com/i/web/status/1517138947872542720"
    }
  },
  {
    "like" : {
      "tweetId" : "1517166635123052544",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1517166635123052544"
    }
  },
  {
    "like" : {
      "tweetId" : "1517140131940945920",
      "fullText" : "日記です https://t.co/0jZbToJX3q",
      "expandedUrl" : "https://twitter.com/i/web/status/1517140131940945920"
    }
  },
  {
    "like" : {
      "tweetId" : "1517035569825517568",
      "fullText" : "杏ちゃんとこずえちゃん https://t.co/iFAe3wQbnR",
      "expandedUrl" : "https://twitter.com/i/web/status/1517035569825517568"
    }
  },
  {
    "like" : {
      "tweetId" : "1516780448004804612",
      "fullText" : "LILYGO T-WATCH-2021 Test new firmware. https://t.co/gDbq7vzpn2",
      "expandedUrl" : "https://twitter.com/i/web/status/1516780448004804612"
    }
  },
  {
    "like" : {
      "tweetId" : "1516694103890665473",
      "fullText" : "あまりにも天使 https://t.co/DxeRJWbKba",
      "expandedUrl" : "https://twitter.com/i/web/status/1516694103890665473"
    }
  },
  {
    "like" : {
      "tweetId" : "1516520274845437959",
      "fullText" : "The last figure is a tool monitoring students' code online in real time. Please see this github page for details: https://t.co/xAEhLRtdFK",
      "expandedUrl" : "https://twitter.com/i/web/status/1516520274845437959"
    }
  },
  {
    "like" : {
      "tweetId" : "1516523639893467142",
      "fullText" : "1999 Apple 23\" Studio Display (Blueberry). https://t.co/wILzpHQLVf",
      "expandedUrl" : "https://twitter.com/i/web/status/1516523639893467142"
    }
  },
  {
    "like" : {
      "tweetId" : "1516400867326406658",
      "fullText" : "https://t.co/vyQ5XYi9KI",
      "expandedUrl" : "https://twitter.com/i/web/status/1516400867326406658"
    }
  },
  {
    "like" : {
      "tweetId" : "1516518964142161922",
      "fullText" : "🎉 🎉 🎉 My educational paper is finally accepted to ASEE (American Society for Engineering Education) 2022 conference. ✌️It talked about how we use CircuitPython and CircuitPython Online IDE to teach microcontroller programming in remote classes. Is anyone coming as well?😊 https://t.co/F66igapM1x",
      "expandedUrl" : "https://twitter.com/i/web/status/1516518964142161922"
    }
  },
  {
    "like" : {
      "tweetId" : "1516159213504176128",
      "fullText" : "苺のパンケーキ https://t.co/pNMB9hrQ4B",
      "expandedUrl" : "https://twitter.com/i/web/status/1516159213504176128"
    }
  },
  {
    "like" : {
      "tweetId" : "1515882633581973508",
      "fullText" : "A rare item https://t.co/NcJ2YOE2bm",
      "expandedUrl" : "https://twitter.com/i/web/status/1515882633581973508"
    }
  },
  {
    "like" : {
      "tweetId" : "1585746079525793792",
      "fullText" : "10/28朝のSangria\n\nPiZero2 を外してダミーボードに戻す。\nやはり rp2040のファーム開発は、こちらの方が早い。 https://t.co/7Hqp6wEduJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1585746079525793792"
    }
  },
  {
    "like" : {
      "tweetId" : "1585265638242586625",
      "fullText" : "第一版支架 https://t.co/cLRgVyFZLE",
      "expandedUrl" : "https://twitter.com/i/web/status/1585265638242586625"
    }
  },
  {
    "like" : {
      "tweetId" : "1585328716930072591",
      "fullText" : "New Learn Guide: Split Ortho Keyboard with TCA8418 Matrix Expanders @adafruit #adafruit https://t.co/qnP78OMane",
      "expandedUrl" : "https://twitter.com/i/web/status/1585328716930072591"
    }
  },
  {
    "like" : {
      "tweetId" : "1585400449817272320",
      "fullText" : "@RAKwireless @Kongduino Is this the smallest long range radio communicator in the world ? With buttons to compose msgs or navigate into menus and 32x128 oled display and USB C plug https://t.co/WiujRDvFAq",
      "expandedUrl" : "https://twitter.com/i/web/status/1585400449817272320"
    }
  },
  {
    "like" : {
      "tweetId" : "1585305311724056576",
      "fullText" : "This \"relatively accurate\" prediction about future telephones was made by Mark R. Sullivan, president and director of the Pacific Telephone and Telegraph Co. in 1953 \n\n[read more: https://t.co/n1n1NyI5Jm] https://t.co/HZdm1ZwbXW",
      "expandedUrl" : "https://twitter.com/i/web/status/1585305311724056576"
    }
  },
  {
    "like" : {
      "tweetId" : "1585329161694056449",
      "fullText" : "NEW GUIDE: John Park’s Split Ortho Keyboard adafruit johnedgarpark #adafruit #mechanicalkeyboards  https://t.co/lpVyjz3MQy",
      "expandedUrl" : "https://twitter.com/i/web/status/1585329161694056449"
    }
  },
  {
    "like" : {
      "tweetId" : "1585310102701342720",
      "fullText" : "⏳12 days left to support the #crowdfunding campaign for our cute little #opensource mechanical keyboards with @seeedstudio xiao #raspberrypi rp2040 at @crowd_supply \nhttps://t.co/gIMTaJxxUg https://t.co/ZXmK1YUPLq",
      "expandedUrl" : "https://twitter.com/i/web/status/1585310102701342720"
    }
  },
  {
    "like" : {
      "tweetId" : "1585266510456655872",
      "fullText" : "ICYMI Python on Microcontrollers Newsletter: Halloween Projects, CircuitPython 8 beta 3 &amp; CPython 3.11 out, and more! #CircuitPython #Python #ICYMI micropython Raspberry_Pi  https://t.co/9xSxuoBOWl",
      "expandedUrl" : "https://twitter.com/i/web/status/1585266510456655872"
    }
  },
  {
    "like" : {
      "tweetId" : "1582674236044214272",
      "fullText" : "3 API’s down 1 to go. Give me a follow on GitHub if you like what you see so I can watch it go up. Updates every 15 minutes. https://t.co/EWQJ3QGm2r Projects for #circuitpython https://t.co/jgz6h8vHkm",
      "expandedUrl" : "https://twitter.com/i/web/status/1582674236044214272"
    }
  },
  {
    "like" : {
      "tweetId" : "1585233104637071360",
      "fullText" : "Wild animal escaped from the laboratory..  genetically modified. PSP joystick, ili9341 2.8 spi color, usbC, complete oc keyboard with RPI2040 chip. https://t.co/NYbAMWfL55",
      "expandedUrl" : "https://twitter.com/i/web/status/1585233104637071360"
    }
  },
  {
    "like" : {
      "tweetId" : "1585114104863522816",
      "fullText" : "マリー！\n#ブルアカ https://t.co/tpTYGsNWfW",
      "expandedUrl" : "https://twitter.com/i/web/status/1585114104863522816"
    }
  },
  {
    "like" : {
      "tweetId" : "1584979546558062594",
      "fullText" : "spent some time on the MNT Pocket Reform prototype today. it even fits in my pocket (which is admittedly huge ^^) https://t.co/FASJ8A2YhT",
      "expandedUrl" : "https://twitter.com/i/web/status/1584979546558062594"
    }
  },
  {
    "like" : {
      "tweetId" : "1585034922276040705",
      "fullText" : "@zackfreedman Smoke emitting diode🔥",
      "expandedUrl" : "https://twitter.com/i/web/status/1585034922276040705"
    }
  },
  {
    "like" : {
      "tweetId" : "1585015311589593089",
      "fullText" : "I just entered to win a #StarTrek MEGA Giveaway from @TheTrekCentral, to celebrate hitting 100k Subscribers! #TC100 https://t.co/CxLZNKnrMl",
      "expandedUrl" : "https://twitter.com/i/web/status/1585015311589593089"
    }
  },
  {
    "like" : {
      "tweetId" : "1583099398111625218",
      "fullText" : "Pybricks newsflash: Multi-file support coming soon!\n\nNow you can easily create multiple code tabs and  import your own modules. Even without a file system on the hub.\n\nThis works using an upcoming @micropython feature (PR 8381) based on the awesome new MPY6 format. https://t.co/Q2Yx7tbJRc https://t.co/2wek94iJn1",
      "expandedUrl" : "https://twitter.com/i/web/status/1583099398111625218"
    }
  },
  {
    "like" : {
      "tweetId" : "1584923875984408578",
      "fullText" : "New LiPo battery holder just dropped https://t.co/4f9MZxhUTK",
      "expandedUrl" : "https://twitter.com/i/web/status/1584923875984408578"
    }
  },
  {
    "like" : {
      "tweetId" : "1584871292238692352",
      "fullText" : "ThinkPad, with Multi-touch. https://t.co/MAL6L9UBgo",
      "expandedUrl" : "https://twitter.com/i/web/status/1584871292238692352"
    }
  },
  {
    "like" : {
      "tweetId" : "1584898974229860353",
      "fullText" : "又有新玩具可以買🤔 https://t.co/35cQ2x2Z6C",
      "expandedUrl" : "https://twitter.com/i/web/status/1584898974229860353"
    }
  },
  {
    "like" : {
      "tweetId" : "1584895839407083522",
      "fullText" : "Introducing uConsole, a real \"Fantasy Console\" is coming! With all metal construction, ultra-portable QWERTY backlit keyboard, HD screen, support #RaspberryPi 4 and #RISC-V even 4G cellular networks... Learn more https://t.co/2fgUdgrLUe #clockworkpi https://t.co/7SAFkRJKBG",
      "expandedUrl" : "https://twitter.com/i/web/status/1584895839407083522"
    }
  },
  {
    "like" : {
      "tweetId" : "1584860145183780864",
      "fullText" : "閣置了一年的項目，是時候要再動了🤔 https://t.co/tw2iTzG52v",
      "expandedUrl" : "https://twitter.com/i/web/status/1584860145183780864"
    }
  },
  {
    "like" : {
      "tweetId" : "1574779358468014080",
      "fullText" : "@River___Wang Thank you!\n\nI'd never heard of Pop!OS before!\nI've successfully installed Linux on GPD Win, so I'll try Pop!OS another time (^^)",
      "expandedUrl" : "https://twitter.com/i/web/status/1574779358468014080"
    }
  },
  {
    "like" : {
      "tweetId" : "1584784611074519041",
      "fullText" : "Moon rabbit. https://t.co/A4RU8d25dT",
      "expandedUrl" : "https://twitter.com/i/web/status/1584784611074519041"
    }
  },
  {
    "like" : {
      "tweetId" : "1584737601080082435",
      "fullText" : "When I was ten years old, I wanted to make my own caramel apples.  So, I melted sugar in a pan, grabbed an apple, and then accidentally poured molten sugar over my thumb.\n\n           I am no longer fond of caramel apples.",
      "expandedUrl" : "https://twitter.com/i/web/status/1584737601080082435"
    }
  },
  {
    "like" : {
      "tweetId" : "1584730114385858560",
      "fullText" : "シアンー\n#インティ絵 https://t.co/RI5MJqBUpb",
      "expandedUrl" : "https://twitter.com/i/web/status/1584730114385858560"
    }
  },
  {
    "like" : {
      "tweetId" : "1584308450498351105",
      "fullText" : "10/24朝の Sangria\n\n例の回転デモ。\n最後、キーが効かなくなったと思ってポチポチ押しまくってますが、CTRL LOCK が掛かってるから入力出来ないと言うことに録画停止後に気が付く🤣 https://t.co/GykxMABkX1",
      "expandedUrl" : "https://twitter.com/i/web/status/1584308450498351105"
    }
  },
  {
    "like" : {
      "tweetId" : "1516110605052170243",
      "fullText" : "Ultimate Raspberry Pi Ceph cluster?\n\n(h/t to @will_whang and @soveryevil for putting this on my radar) https://t.co/LKkBzQm3Yp",
      "expandedUrl" : "https://twitter.com/i/web/status/1516110605052170243"
    }
  },
  {
    "like" : {
      "tweetId" : "1515704288097574916",
      "fullText" : "@rappet_ Very Retro 😀, Reminds of of the issue 1 ZX Spectrum PCB. https://t.co/NsHs3h1jPf",
      "expandedUrl" : "https://twitter.com/i/web/status/1515704288097574916"
    }
  },
  {
    "like" : {
      "tweetId" : "1515938046793105410",
      "fullText" : "Another #RaspberryPi deployed with an SDCard, the sdcard is now dead. #StopSDCardTorture \nSay yes to ro and no to rw. https://t.co/KBrVAi3p6C",
      "expandedUrl" : "https://twitter.com/i/web/status/1515938046793105410"
    }
  },
  {
    "like" : {
      "tweetId" : "1515423607857557505",
      "fullText" : "@bateskecom Playing with boids and attractors from @shiffman's amazing \"The Nature of Code\": https://t.co/bCCWSkTGsv\nAll running in Arduino code on an @adafruit QT Py mounted on the back. Will share the code soon. https://t.co/tnX3JammDt",
      "expandedUrl" : "https://twitter.com/i/web/status/1515423607857557505"
    }
  },
  {
    "like" : {
      "tweetId" : "1515678515005431810",
      "fullText" : "Gaming Cranks are the hot rage in handheld input devices right now. Its a great input for games and applications! Files + guide: https://t.co/oz09uUBT3w https://t.co/R1yMluiLxb #3DPrinting #Adafruit #gaming https://t.co/hjG6Z7Uebb",
      "expandedUrl" : "https://twitter.com/i/web/status/1515678515005431810"
    }
  },
  {
    "like" : {
      "tweetId" : "1515649680687857667",
      "fullText" : "#HappyEaster https://t.co/cfwnZiwQVi",
      "expandedUrl" : "https://twitter.com/i/web/status/1515649680687857667"
    }
  },
  {
    "like" : {
      "tweetId" : "1515410260596596745",
      "fullText" : "I guess it's official. I was a software developer until sometime this year.\n\nNow, according to Google, I'm a \"YouTuber\" 🤷‍♂️ https://t.co/NXWJIDpuTC",
      "expandedUrl" : "https://twitter.com/i/web/status/1515410260596596745"
    }
  },
  {
    "like" : {
      "tweetId" : "1515282438427398149",
      "fullText" : "しまりんとなでしこ https://t.co/EAgeAxp2OM",
      "expandedUrl" : "https://twitter.com/i/web/status/1515282438427398149"
    }
  },
  {
    "like" : {
      "tweetId" : "1514754402128887813",
      "fullText" : "カッコイイな\n分離型のキーボードと相性よさそう\n#keyboard #自作キーボード #Adafruit https://t.co/M1q3UsM5bL",
      "expandedUrl" : "https://twitter.com/i/web/status/1514754402128887813"
    }
  },
  {
    "like" : {
      "tweetId" : "1514889606847639552",
      "fullText" : "『トロッコ問題』で全員助かる方法\nこんな答えはどうかな？\n#鉄道模型 #Nゲージ https://t.co/F4qtX83ZNm",
      "expandedUrl" : "https://twitter.com/i/web/status/1514889606847639552"
    }
  },
  {
    "like" : {
      "tweetId" : "1515138625297874945",
      "fullText" : "2021年に描いたデレマスのイラストまとめ本！\n委託させて頂いている本の在庫が少なくなってきたので興味がある方はぜひ！よろしくおねがいいたします！\nBOOTHは4月18日に非公開にします！\n\n🍈 https://t.co/oF3YBWpSL2\n🐯 https://t.co/HBR2h5uV0a\n🅱 https://t.co/Qd1P6ULie8 https://t.co/x6niBXmZWt",
      "expandedUrl" : "https://twitter.com/i/web/status/1515138625297874945"
    }
  },
  {
    "like" : {
      "tweetId" : "1514991911115046917",
      "fullText" : "new case for ESP8266 gadgets https://t.co/bie9dpwWBX",
      "expandedUrl" : "https://twitter.com/i/web/status/1514991911115046917"
    }
  },
  {
    "like" : {
      "tweetId" : "1515098301598617602",
      "fullText" : "お世辞 https://t.co/Bw6KkD2MT0",
      "expandedUrl" : "https://twitter.com/i/web/status/1515098301598617602"
    }
  },
  {
    "like" : {
      "tweetId" : "1514512750504038402",
      "fullText" : "Enclosure fits well https://t.co/DXmDXmfZUq",
      "expandedUrl" : "https://twitter.com/i/web/status/1514512750504038402"
    }
  },
  {
    "like" : {
      "tweetId" : "1514251256298098691",
      "fullText" : "I plug computers into my computers... https://t.co/UKS6KKClD2",
      "expandedUrl" : "https://twitter.com/i/web/status/1514251256298098691"
    }
  },
  {
    "like" : {
      "tweetId" : "1514418500713934850",
      "fullText" : "日記です https://t.co/NDJ7ZQMpcK",
      "expandedUrl" : "https://twitter.com/i/web/status/1514418500713934850"
    }
  },
  {
    "like" : {
      "tweetId" : "1514411146731667458",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1514411146731667458"
    }
  },
  {
    "like" : {
      "tweetId" : "1514407299892199425",
      "fullText" : "ロボット掃除機とありすちゃん https://t.co/iiGmG4N2Fp",
      "expandedUrl" : "https://twitter.com/i/web/status/1514407299892199425"
    }
  },
  {
    "like" : {
      "tweetId" : "1514320926384398339",
      "fullText" : "It's got CHILL_CODES!  Cool enclosure and great project, @BlitzCityDIY! https://t.co/T91qQBHVRI",
      "expandedUrl" : "https://twitter.com/i/web/status/1514320926384398339"
    }
  },
  {
    "like" : {
      "tweetId" : "1508090427458883589",
      "fullText" : "ジャパニーズ幼稚園スタイル https://t.co/lVC6joYG34",
      "expandedUrl" : "https://twitter.com/i/web/status/1508090427458883589"
    }
  },
  {
    "like" : {
      "tweetId" : "1514275984719101954",
      "fullText" : "UPDATED GUIDE: Adafruit ESP32-S2 TFT Feather #Adafruit @Adafruit @AdafruitIO #WipperSnapper #NoCode #IoT https://t.co/4DkiGpljcC",
      "expandedUrl" : "https://twitter.com/i/web/status/1514275984719101954"
    }
  },
  {
    "like" : {
      "tweetId" : "1514064954294382593",
      "fullText" : "I FINALLY UNDERSTAND THE DATASHEET https://t.co/uOKmiA2om2",
      "expandedUrl" : "https://twitter.com/i/web/status/1514064954294382593"
    }
  },
  {
    "like" : {
      "tweetId" : "1514197172409016321",
      "fullText" : "https://t.co/oA4L0ckDIa",
      "expandedUrl" : "https://twitter.com/i/web/status/1514197172409016321"
    }
  },
  {
    "like" : {
      "tweetId" : "1490258547023753228",
      "fullText" : "#Bitcoin Point of Sale (@btc_pos) works exactly as predicted 🤓\n\n1. Lightning ⚡️ Payment\n2. OnChain ⛓ Payment (xpub)\n3. Lightning ⚡️ Withdraw/Refund\n\nEverything free open source and low budget hardware(~30$). h/t @arcbtc https://t.co/gu2FDaA8mT",
      "expandedUrl" : "https://twitter.com/i/web/status/1490258547023753228"
    }
  },
  {
    "like" : {
      "tweetId" : "1513805978654765058",
      "fullText" : "ひふみー\n#ブルアカ https://t.co/c5Z6QrdHKt",
      "expandedUrl" : "https://twitter.com/i/web/status/1513805978654765058"
    }
  },
  {
    "like" : {
      "tweetId" : "1513896184108261381",
      "fullText" : "@River___Wang not project in particular. just wanted a bunch of gpios :) and a board which has never been designed before :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1513896184108261381"
    }
  },
  {
    "like" : {
      "tweetId" : "1513859387386994688",
      "fullText" : "RP2040 keyboard stamp prototype arrived ... mamamia ... any  resemblance to a project by @arturo182  would be completely on purpose... https://t.co/yG0uEfZCRb",
      "expandedUrl" : "https://twitter.com/i/web/status/1513859387386994688"
    }
  },
  {
    "like" : {
      "tweetId" : "1512960198045941761",
      "fullText" : "とどいた！！！！！！！！！ https://t.co/Ki7L39U3gz",
      "expandedUrl" : "https://twitter.com/i/web/status/1512960198045941761"
    }
  },
  {
    "like" : {
      "tweetId" : "1513789756899209219",
      "fullText" : "日記です https://t.co/gyAARFPBZV",
      "expandedUrl" : "https://twitter.com/i/web/status/1513789756899209219"
    }
  },
  {
    "like" : {
      "tweetId" : "1513804215549792259",
      "fullText" : "Some days make less sense than others. https://t.co/sVfYUnvxTI",
      "expandedUrl" : "https://twitter.com/i/web/status/1513804215549792259"
    }
  },
  {
    "like" : {
      "tweetId" : "1513835922382462978",
      "fullText" : "Power Macintosh G3 Server with built-in monochrome LCD &amp; electroluminescent backlight. https://t.co/FApSSTAwVR",
      "expandedUrl" : "https://twitter.com/i/web/status/1513835922382462978"
    }
  },
  {
    "like" : {
      "tweetId" : "1513850270286942212",
      "fullText" : "@spirovskib The iMac via a usb-serial adaptor",
      "expandedUrl" : "https://twitter.com/i/web/status/1513850270286942212"
    }
  },
  {
    "like" : {
      "tweetId" : "1513857620607750145",
      "fullText" : "My crypto point of sale board has arrived. Tonight I will solder ... https://t.co/j6dMYnX7jQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1513857620607750145"
    }
  },
  {
    "like" : {
      "tweetId" : "1513607659743846400",
      "fullText" : "I'll be a guest on season 2 of the CircuitPython Show! Had a great time talking to @prcutler. Will make sure my episode gets posted on my TL but subscribe in the meantime  😁 https://t.co/KzrxmK8gNo",
      "expandedUrl" : "https://twitter.com/i/web/status/1513607659743846400"
    }
  },
  {
    "like" : {
      "tweetId" : "1513489257822044167",
      "fullText" : "うさぎさんのお庭🍓 https://t.co/OohTH6YLQN",
      "expandedUrl" : "https://twitter.com/i/web/status/1513489257822044167"
    }
  },
  {
    "like" : {
      "tweetId" : "1512842898433261572",
      "fullText" : "Makercast again tomorrow! Excited to meet the new folks. https://t.co/x8el5OuZnq",
      "expandedUrl" : "https://twitter.com/i/web/status/1512842898433261572"
    }
  },
  {
    "like" : {
      "tweetId" : "1512994596565168132",
      "fullText" : "あれ、もう全部食べちゃったんだ https://t.co/SnzGjCSDx4",
      "expandedUrl" : "https://twitter.com/i/web/status/1512994596565168132"
    }
  },
  {
    "like" : {
      "tweetId" : "1513064446922473479",
      "fullText" : "Retrotechtacular: A DIY Television for Very Early Adopters https://t.co/8vqlDFdR6j",
      "expandedUrl" : "https://twitter.com/i/web/status/1513064446922473479"
    }
  },
  {
    "like" : {
      "tweetId" : "1512400910441492484",
      "fullText" : "🌊🌟\n\n #自分が何度も投稿してしまう画像 https://t.co/u8JdTlzY9t",
      "expandedUrl" : "https://twitter.com/i/web/status/1512400910441492484"
    }
  },
  {
    "like" : {
      "tweetId" : "1512469225675591681",
      "fullText" : "Diving back in to my T9 Keypad project! I have a hard time getting excited about old stuff but I have been inspired by the fact that this project is actually helping some folks type. I wish I had been thinking harder about a11y from the start... 1/x \n\nhttps://t.co/KPEtaDnVdY",
      "expandedUrl" : "https://twitter.com/i/web/status/1512469225675591681"
    }
  },
  {
    "like" : {
      "tweetId" : "1512414719952531462",
      "fullText" : "ZX Spectrum Raspberry Pi Cassette #piday #raspberrypi @Raspberry_Pi https://t.co/rpto3jSegv",
      "expandedUrl" : "https://twitter.com/i/web/status/1512414719952531462"
    }
  },
  {
    "like" : {
      "tweetId" : "1512462955757121537",
      "fullText" : "Behind the scenes picture getting ready to record another podcast episode this morning.  Glad the camera doesn’t pick up my messy desk.  Not that my workbench is much better. https://t.co/ShBeGZJ1fQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1512462955757121537"
    }
  },
  {
    "like" : {
      "tweetId" : "1512294348716609538",
      "fullText" : "日記です https://t.co/nkg8lmlrPj",
      "expandedUrl" : "https://twitter.com/i/web/status/1512294348716609538"
    }
  },
  {
    "like" : {
      "tweetId" : "1511497879285809154",
      "fullText" : "It seems the design is so popular that the motors are sold out on Aliexpress (for now?)\n \nDid anyone happen to buy more than they needed and would like to sell 1-3 to me? 🥺 https://t.co/b3Atrc2qrR",
      "expandedUrl" : "https://twitter.com/i/web/status/1511497879285809154"
    }
  },
  {
    "like" : {
      "tweetId" : "1511735768498282496",
      "fullText" : "New Guide: Todbot’s CircuitPython Tricks adafruit johnedgarpark todbot  https://t.co/1AOfVpGtOP",
      "expandedUrl" : "https://twitter.com/i/web/status/1511735768498282496"
    }
  },
  {
    "like" : {
      "tweetId" : "1511888880563556356",
      "fullText" : "見て！！！！\n10時間くらいかけて初めて作ったLive2Dです！！！！ https://t.co/r1QU1MpJPX",
      "expandedUrl" : "https://twitter.com/i/web/status/1511888880563556356"
    }
  },
  {
    "like" : {
      "tweetId" : "1511486187562668037",
      "fullText" : "If you want a nice CircuitPython-based iOS notification displayer, this one by @johnedgarpark is pretty great, and what I started with: https://t.co/I84XUnwYmV",
      "expandedUrl" : "https://twitter.com/i/web/status/1511486187562668037"
    }
  },
  {
    "like" : {
      "tweetId" : "1511323646702219269",
      "fullText" : "Apple Adjustable PowerBook https://t.co/8Ax2VR3aUh",
      "expandedUrl" : "https://twitter.com/i/web/status/1511323646702219269"
    }
  },
  {
    "like" : {
      "tweetId" : "1511360383155642374",
      "fullText" : "Neat analog watchface design with world time by @plaid333! https://t.co/Hhj6lnwVbp",
      "expandedUrl" : "https://twitter.com/i/web/status/1511360383155642374"
    }
  },
  {
    "like" : {
      "tweetId" : "1511370888884719621",
      "fullText" : "The podcast is also on YouTube if that’s more your thing.  You can watch @tannewt and I talk CircuitPython, Raspberry Pi, ESP32 development and more:  https://t.co/xbjeOVUJKN",
      "expandedUrl" : "https://twitter.com/i/web/status/1511370888884719621"
    }
  },
  {
    "like" : {
      "tweetId" : "1511321657792552965",
      "fullText" : "Apple Adjustable Keyboard https://t.co/CwcBdreOl2",
      "expandedUrl" : "https://twitter.com/i/web/status/1511321657792552965"
    }
  },
  {
    "like" : {
      "tweetId" : "1511301904759894019",
      "fullText" : "なーの広告みつけた！ https://t.co/go4r0uHLfW",
      "expandedUrl" : "https://twitter.com/i/web/status/1511301904759894019"
    }
  },
  {
    "like" : {
      "tweetId" : "1511065841613348874",
      "fullText" : "Tomorrow we’ll wrap up season one with CircuitPython’s project lead, Scott Shawcroft (@tannewt).  Subscribe now so you don’t miss it: https://t.co/P9EwqLC5IX",
      "expandedUrl" : "https://twitter.com/i/web/status/1511065841613348874"
    }
  },
  {
    "like" : {
      "tweetId" : "1511066570805723138",
      "fullText" : "@sulfuroid If you need help about drones and FPV ask me ;)",
      "expandedUrl" : "https://twitter.com/i/web/status/1511066570805723138"
    }
  },
  {
    "like" : {
      "tweetId" : "1510560306237485057",
      "fullText" : "@TechAmazing @alvinfoo Someone lifts it from the other side in a way.. Focus",
      "expandedUrl" : "https://twitter.com/i/web/status/1510560306237485057"
    }
  },
  {
    "like" : {
      "tweetId" : "1510799478336286725",
      "fullText" : "TshWatch Helps You Learn More About Yourself https://t.co/e9tsA62AWn",
      "expandedUrl" : "https://twitter.com/i/web/status/1510799478336286725"
    }
  },
  {
    "like" : {
      "tweetId" : "1510882838773645319",
      "fullText" : "I've just released a video about the Esp web tools, which allow you to flash full projects to your Esp in about a minute without installing any software (not even the Arduino IDE) or downloading any code.\n\nI think this an amazing way of sharing projects with people! https://t.co/nonWJJF6Ne",
      "expandedUrl" : "https://twitter.com/i/web/status/1510882838773645319"
    }
  },
  {
    "like" : {
      "tweetId" : "1510274630476574722",
      "fullText" : "Prototype 33mm Fibonacci128 Pico touch demo works! Using the new APA104-1212 1.2mm², and an @adafruit QT Py with @MicrochipMakes SAMD21\nStill need to create the Voronoi grid design and make a laser cut acrylic enclosure. https://t.co/tLZ7ScrYRv https://t.co/24RvR8fFRS",
      "expandedUrl" : "https://twitter.com/i/web/status/1510274630476574722"
    }
  },
  {
    "like" : {
      "tweetId" : "1510557388788858881",
      "fullText" : "高台カフェ https://t.co/l6DzwlJMKS",
      "expandedUrl" : "https://twitter.com/i/web/status/1510557388788858881"
    }
  },
  {
    "like" : {
      "tweetId" : "1510731174330699777",
      "fullText" : "Enclosure for my Point Of Sale add on to the cash register in my medical office.  Now we are capable of accepting BTC for visits. https://t.co/HGGidyhojZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1510731174330699777"
    }
  },
  {
    "like" : {
      "tweetId" : "1510195340699447297",
      "fullText" : "Welcome to cube puzzle labyrinth！\n#オリジナル\n#創作 https://t.co/WFF41cSQ4p",
      "expandedUrl" : "https://twitter.com/i/web/status/1510195340699447297"
    }
  },
  {
    "like" : {
      "tweetId" : "1510614923939704844",
      "fullText" : "Apple Magic Keyboard III has larger keys that can be used in a neutral wrist position for stress-free typing. https://t.co/Ijg8z2tLZw",
      "expandedUrl" : "https://twitter.com/i/web/status/1510614923939704844"
    }
  },
  {
    "like" : {
      "tweetId" : "1169605919811850240",
      "fullText" : "幕張公演での久川姉妹まとめレポ https://t.co/yHp7K2kkmR",
      "expandedUrl" : "https://twitter.com/i/web/status/1169605919811850240"
    }
  },
  {
    "like" : {
      "tweetId" : "1510581697397641229",
      "fullText" : "https://t.co/zu1rsCd3Q1",
      "expandedUrl" : "https://twitter.com/i/web/status/1510581697397641229"
    }
  },
  {
    "like" : {
      "tweetId" : "1510566741654528001",
      "fullText" : "barbecue level 10 000 &lt;3 https://t.co/n7hFU17W06",
      "expandedUrl" : "https://twitter.com/i/web/status/1510566741654528001"
    }
  },
  {
    "like" : {
      "tweetId" : "1510577572303994881",
      "fullText" : "https://t.co/2Vl0HJDVKN",
      "expandedUrl" : "https://twitter.com/i/web/status/1510577572303994881"
    }
  },
  {
    "like" : {
      "tweetId" : "1510058853005950976",
      "fullText" : "和風メイドなライスちゃん https://t.co/4PBqfEZCtH",
      "expandedUrl" : "https://twitter.com/i/web/status/1510058853005950976"
    }
  },
  {
    "like" : {
      "tweetId" : "1510388712533893131",
      "fullText" : "New Learn Guide: Todbot's CircuitPython Tricks @adafruit #adafruit https://t.co/0mIAydQl4t",
      "expandedUrl" : "https://twitter.com/i/web/status/1510388712533893131"
    }
  },
  {
    "like" : {
      "tweetId" : "1510227257406763009",
      "fullText" : "@BenEmmerich i feel the pain in the picture. i hope you have a spare tip. cleanin ll be another pain.",
      "expandedUrl" : "https://twitter.com/i/web/status/1510227257406763009"
    }
  },
  {
    "like" : {
      "tweetId" : "1510238929928085504",
      "fullText" : "日記です https://t.co/CkweXQUcTB",
      "expandedUrl" : "https://twitter.com/i/web/status/1510238929928085504"
    }
  },
  {
    "like" : {
      "tweetId" : "1510059740378058752",
      "fullText" : "これは和風メイドライスちゃんのラフです https://t.co/pZahJ7VO8r",
      "expandedUrl" : "https://twitter.com/i/web/status/1510059740378058752"
    }
  },
  {
    "like" : {
      "tweetId" : "1510065814816190467",
      "fullText" : "The PowerBook 150s was designed for people with bilateral symmetry across the sagittal plane. https://t.co/CLlH8Hvkjh",
      "expandedUrl" : "https://twitter.com/i/web/status/1510065814816190467"
    }
  },
  {
    "like" : {
      "tweetId" : "1510179973243363329",
      "fullText" : "ここすき https://t.co/bl9cmlUPDK",
      "expandedUrl" : "https://twitter.com/i/web/status/1510179973243363329"
    }
  },
  {
    "like" : {
      "tweetId" : "1509799432392708104",
      "fullText" : "T-keyboard https://t.co/42qaU9nPSH",
      "expandedUrl" : "https://twitter.com/i/web/status/1509799432392708104"
    }
  },
  {
    "like" : {
      "tweetId" : "1509865352234258455",
      "fullText" : "@sad_electronics @kicad_pcb @JLCPCB, your move",
      "expandedUrl" : "https://twitter.com/i/web/status/1509865352234258455"
    }
  },
  {
    "like" : {
      "tweetId" : "1509959936339439616",
      "fullText" : "Sure, the @synology floppy drive NAS is great, but what about the Zip drive NAS? https://t.co/2urAIraXfD",
      "expandedUrl" : "https://twitter.com/i/web/status/1509959936339439616"
    }
  },
  {
    "like" : {
      "tweetId" : "1509974869911515146",
      "fullText" : "@River___Wang I thought I remember @todbot telling me that CircuitPython likes WAV files more than MP3 files, but not 100% sure",
      "expandedUrl" : "https://twitter.com/i/web/status/1509974869911515146"
    }
  },
  {
    "like" : {
      "tweetId" : "1509297704454742016",
      "fullText" : "Autocomplete for your terminal?!? Yes please! Fig introduces of all that and more. \n\nAvailable now for macOS and with a waitlist for Windows + Linux: https://t.co/DqXNPZNcNK https://t.co/o57fdK0jmc",
      "expandedUrl" : "https://twitter.com/i/web/status/1509297704454742016"
    }
  },
  {
    "like" : {
      "tweetId" : "1509965314418778122",
      "fullText" : "Don't know if it is a bad idea to stream online mp3 podcasts on an ESP32S2 with CircuitPython. Wifi is fine. I2S DAC is fine. However, did not have any luck decompressing mp3 files. Might either switch to C/C++ or Raspberry Pi. Wish I don't have to.",
      "expandedUrl" : "https://twitter.com/i/web/status/1509965314418778122"
    }
  },
  {
    "like" : {
      "tweetId" : "1509878654943248387",
      "fullText" : "Infinity Macro Pad Using Pi Pico #piday #raspberrypi @Raspberry_Pi https://t.co/MfOeKtxAda",
      "expandedUrl" : "https://twitter.com/i/web/status/1509878654943248387"
    }
  },
  {
    "like" : {
      "tweetId" : "1509707339087101957",
      "fullText" : "An elegant way to connect the native USB on the esp32 s2 Saola board. https://t.co/fy51hWuJFm",
      "expandedUrl" : "https://twitter.com/i/web/status/1509707339087101957"
    }
  },
  {
    "like" : {
      "tweetId" : "1509587218238742539",
      "fullText" : "Put down some solder paste on your pcbs with the help of a vacuum cleaner #pcb #pcbuild #circuitboard #electronics #pcbdesign #diy #soldering #solderpaste https://t.co/zni88g9zk2",
      "expandedUrl" : "https://twitter.com/i/web/status/1509587218238742539"
    }
  },
  {
    "like" : {
      "tweetId" : "1509470732736405504",
      "fullText" : "冬溶けて春が舞う https://t.co/VS6G3Tj9Wo",
      "expandedUrl" : "https://twitter.com/i/web/status/1509470732736405504"
    }
  },
  {
    "like" : {
      "tweetId" : "1509667135387312129",
      "fullText" : "Modern, Frugal PCB Breathes New Life Into Soviet-Made LED Watch https://t.co/VwGFys4Pgv",
      "expandedUrl" : "https://twitter.com/i/web/status/1509667135387312129"
    }
  },
  {
    "like" : {
      "tweetId" : "1509494092073299971",
      "fullText" : "桜の魔女🌸 https://t.co/dam66t8aM2",
      "expandedUrl" : "https://twitter.com/i/web/status/1509494092073299971"
    }
  },
  {
    "like" : {
      "tweetId" : "1509029333075070976",
      "fullText" : "#ESP32-S3 with Circuitpython https://t.co/wYa8Rfpmif",
      "expandedUrl" : "https://twitter.com/i/web/status/1509029333075070976"
    }
  },
  {
    "like" : {
      "tweetId" : "1508716634382512137",
      "fullText" : "🕹️ I'm working on a morse themed arcade style rhythm game #gamedev #morse https://t.co/VIW8uoa5CT",
      "expandedUrl" : "https://twitter.com/i/web/status/1508716634382512137"
    }
  },
  {
    "like" : {
      "tweetId" : "1509101631966781442",
      "fullText" : "SystemSix: a love letter letter to old Macs for your desk.\n\nhttps://t.co/5l3MqlVqJJ https://t.co/1XHck44gkF",
      "expandedUrl" : "https://twitter.com/i/web/status/1509101631966781442"
    }
  },
  {
    "like" : {
      "tweetId" : "1509019551064805381",
      "fullText" : "⚡️LIGHTNING!!⚡️ \n\nAbsolutely insane lightning strike just captured in Wichita, Kansas by @therealskicast. I’ve never seen anything like that. Mother Nature y’all https://t.co/UUsMBA5GIF",
      "expandedUrl" : "https://twitter.com/i/web/status/1509019551064805381"
    }
  },
  {
    "like" : {
      "tweetId" : "1509064853117235200",
      "fullText" : "The way things used to be. https://t.co/qUjRuJJfeR",
      "expandedUrl" : "https://twitter.com/i/web/status/1509064853117235200"
    }
  },
  {
    "like" : {
      "tweetId" : "1508880080889692160",
      "fullText" : "New Learn Guide: 3D Printed Book Sleeve @adafruit #adafruit https://t.co/9YoLzgBVvO",
      "expandedUrl" : "https://twitter.com/i/web/status/1508880080889692160"
    }
  },
  {
    "like" : {
      "tweetId" : "1386805059544092677",
      "fullText" : "https://t.co/AHX8BHyTt3",
      "expandedUrl" : "https://twitter.com/i/web/status/1386805059544092677"
    }
  },
  {
    "like" : {
      "tweetId" : "1386804846062407682",
      "fullText" : "https://t.co/qVlvFNUUeO",
      "expandedUrl" : "https://twitter.com/i/web/status/1386804846062407682"
    }
  },
  {
    "like" : {
      "tweetId" : "1386652953004724233",
      "fullText" : "Cloning the nokia e63 pcb to have a rpi zero @Raspberry_Pi inside and a 320x240 color display + keyboard https://t.co/tmPGuQO1PC",
      "expandedUrl" : "https://twitter.com/i/web/status/1386652953004724233"
    }
  },
  {
    "like" : {
      "tweetId" : "1386762898048000012",
      "fullText" : "Yeah... iteration number 1. Fits in like a charm https://t.co/Y3P6AyQtCf",
      "expandedUrl" : "https://twitter.com/i/web/status/1386762898048000012"
    }
  },
  {
    "like" : {
      "tweetId" : "1386793287885983744",
      "fullText" : "https://t.co/cMRHEDmRkC",
      "expandedUrl" : "https://twitter.com/i/web/status/1386793287885983744"
    }
  },
  {
    "like" : {
      "tweetId" : "1508567782421852164",
      "fullText" : "#sharpikeebo\nゲームパッドボタンの認識テスト\n問題なさそうですね😊 https://t.co/gKW6ghfla5",
      "expandedUrl" : "https://twitter.com/i/web/status/1508567782421852164"
    }
  },
  {
    "like" : {
      "tweetId" : "1507110631907868706",
      "fullText" : "I did it. I made my dream nail. Nokia 3310 with a real working light inside the screen. Y2K all day baby 🚀 #nails #nailart #Nokia https://t.co/vClRrTuWGU",
      "expandedUrl" : "https://twitter.com/i/web/status/1507110631907868706"
    }
  },
  {
    "like" : {
      "tweetId" : "1508671779136434180",
      "fullText" : "$20 for a used polarizing filter and some polarizing film to cover the ring light and I have my soldering scope set up with polarized light! \n\nI need to figure out something for a fancy microscope camera next... https://t.co/zYz1KqcItM",
      "expandedUrl" : "https://twitter.com/i/web/status/1508671779136434180"
    }
  },
  {
    "like" : {
      "tweetId" : "1508451323754262538",
      "fullText" : "Unsurprinsigly, the Tesla E-bike looks like it was designed by someone who NEVER bikes. https://t.co/Z3CMInamoX",
      "expandedUrl" : "https://twitter.com/i/web/status/1508451323754262538"
    }
  },
  {
    "like" : {
      "tweetId" : "1508766798795223043",
      "fullText" : "Meet Rose Hooper (@krayola)!  Rose is the author of CircuitPython’s LED Animations library.  We chat about that, CPython, Home Assistant, and more in Episode 5:  https://t.co/nAD4SADpTD",
      "expandedUrl" : "https://twitter.com/i/web/status/1508766798795223043"
    }
  },
  {
    "like" : {
      "tweetId" : "1508776245135351814",
      "fullText" : "Could a Podcast Make Itself? https://t.co/uDbu9qsjiP",
      "expandedUrl" : "https://twitter.com/i/web/status/1508776245135351814"
    }
  },
  {
    "like" : {
      "tweetId" : "1506256171987996677",
      "fullText" : "@hackaday Had to search for this one https://t.co/pXwDzDJLOQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1506256171987996677"
    }
  },
  {
    "like" : {
      "tweetId" : "1506148334884605952",
      "fullText" : "@hackaday Definitely this classic. https://t.co/ocUFOWz7s1",
      "expandedUrl" : "https://twitter.com/i/web/status/1506148334884605952"
    }
  },
  {
    "like" : {
      "tweetId" : "1506255034060886017",
      "fullText" : "@hackaday Also whoever Adobe has on staff to write error dialogs is getting paid too much. https://t.co/bWxFoNdcTO",
      "expandedUrl" : "https://twitter.com/i/web/status/1506255034060886017"
    }
  },
  {
    "like" : {
      "tweetId" : "1506149650079883265",
      "fullText" : "@hackaday don't know if this one is real, but that's my favorite 😂 https://t.co/yKuv2g3n86",
      "expandedUrl" : "https://twitter.com/i/web/status/1506149650079883265"
    }
  },
  {
    "like" : {
      "tweetId" : "1506149270663049218",
      "fullText" : "@hackaday @candeira From an internet sharing app I can't for the life of me remember, back when I actually used os9 as my main. https://t.co/Q72Uu23xIb",
      "expandedUrl" : "https://twitter.com/i/web/status/1506149270663049218"
    }
  },
  {
    "like" : {
      "tweetId" : "1506169325962604553",
      "fullText" : "@hackaday My favorite twitter find. Unfortunately I can't remember the source. https://t.co/Jb17fmIyxG",
      "expandedUrl" : "https://twitter.com/i/web/status/1506169325962604553"
    }
  },
  {
    "like" : {
      "tweetId" : "1508479184049426432",
      "fullText" : "This iPhone 13 Pro Max has been hacked to add USB Type-C and headphone jacks, 2X the battery capacity, and dual cooling fans which help bring better performance in benchmarks. Of course it's thicker &amp; heavier than most phones. https://t.co/JKbYhEjrRn",
      "expandedUrl" : "https://twitter.com/i/web/status/1508479184049426432"
    }
  },
  {
    "like" : {
      "tweetId" : "1508397881547538433",
      "fullText" : "PCB delivery! https://t.co/66ZsAYg4Cg",
      "expandedUrl" : "https://twitter.com/i/web/status/1508397881547538433"
    }
  },
  {
    "like" : {
      "tweetId" : "1507650871785816070",
      "fullText" : "It's smaller than an SD card, and it runs (Tina-Linux)  1080p60 via HDMI 😍\nnext step, #armbian https://t.co/iGxqgkMeiE",
      "expandedUrl" : "https://twitter.com/i/web/status/1507650871785816070"
    }
  },
  {
    "like" : {
      "tweetId" : "1508458080987926528",
      "fullText" : "My new tyre pump has real “I backed a lossless music player Kickstarter” vibes. https://t.co/yrhws8LlCI",
      "expandedUrl" : "https://twitter.com/i/web/status/1508458080987926528"
    }
  },
  {
    "like" : {
      "tweetId" : "1508530572695519232",
      "fullText" : "https://t.co/KjzRCeHYxf",
      "expandedUrl" : "https://twitter.com/i/web/status/1508530572695519232"
    }
  },
  {
    "like" : {
      "tweetId" : "1508428299730575364",
      "fullText" : "These NeoPixels makes you wanna jump! Learn how to upgrade a cheap trampoline with interactive #NeoPixel #LED s, Adafruits ItsyBitsy and a vibration sensor! Guide: https://t.co/5p6dRYiCt1 #diy #electronics #adafruit #3dprinting https://t.co/wBhxB5xwsZ https://t.co/7H1btfUZ5s",
      "expandedUrl" : "https://twitter.com/i/web/status/1508428299730575364"
    }
  },
  {
    "like" : {
      "tweetId" : "1508384350349717511",
      "fullText" : "SunPhone https://t.co/eTLEiwbeen",
      "expandedUrl" : "https://twitter.com/i/web/status/1508384350349717511"
    }
  },
  {
    "like" : {
      "tweetId" : "1508395944173535235",
      "fullText" : "星欲しがりの星狩りの魔女さん。 https://t.co/VrfAV3d8Ku",
      "expandedUrl" : "https://twitter.com/i/web/status/1508395944173535235"
    }
  },
  {
    "like" : {
      "tweetId" : "1507473005101862912",
      "fullText" : "Alternate timeline Apple: Following in the footsteps of the #MacStudio, they also announced the iPod Studio. https://t.co/mU1Ewu1AFy",
      "expandedUrl" : "https://twitter.com/i/web/status/1507473005101862912"
    }
  },
  {
    "like" : {
      "tweetId" : "1508041860534530049",
      "fullText" : "好き…薄いピンク最強…お花モチーフどれも好き…\nもうちょっと全身見たくなるぐらい可愛い https://t.co/DRkAuje5CZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1508041860534530049"
    }
  },
  {
    "like" : {
      "tweetId" : "1507894412441010177",
      "fullText" : "https://t.co/ue4Ds0Hdmb",
      "expandedUrl" : "https://twitter.com/i/web/status/1507894412441010177"
    }
  },
  {
    "like" : {
      "tweetId" : "1508025918849417226",
      "fullText" : "#さくらの日 https://t.co/pvw7RdJBck",
      "expandedUrl" : "https://twitter.com/i/web/status/1508025918849417226"
    }
  },
  {
    "like" : {
      "tweetId" : "1507518177604866051",
      "fullText" : "iPod server. https://t.co/lBjdGiQOrK",
      "expandedUrl" : "https://twitter.com/i/web/status/1507518177604866051"
    }
  },
  {
    "like" : {
      "tweetId" : "1507522501534011392",
      "fullText" : "Coming soon! TSC2007 resistive touch screen Python driver  https://t.co/ppv8Nsp5v8",
      "expandedUrl" : "https://twitter.com/i/web/status/1507522501534011392"
    }
  },
  {
    "like" : {
      "tweetId" : "1507637101826699266",
      "fullText" : "Improved arrow key layout. https://t.co/jRmd38mTHl",
      "expandedUrl" : "https://twitter.com/i/web/status/1507637101826699266"
    }
  },
  {
    "like" : {
      "tweetId" : "1507649145242361859",
      "fullText" : "What about combining woodworking with electronics to build a cyberdeck? Not the most exciting keyboard but an inspiring project anyway: \nhttps://t.co/F7HhceIsmX",
      "expandedUrl" : "https://twitter.com/i/web/status/1507649145242361859"
    }
  },
  {
    "like" : {
      "tweetId" : "1507286998561615872",
      "fullText" : "https://t.co/ahrRwLS8wb",
      "expandedUrl" : "https://twitter.com/i/web/status/1507286998561615872"
    }
  },
  {
    "like" : {
      "tweetId" : "1507362423216525316",
      "fullText" : "#Robotics Class using @adafruit CPX to #gamify balance boards. @AshlandClockers @kstcoeur @MrsELachapelle @Ms_Sullivan_AHS https://t.co/oOcx7oBIdW",
      "expandedUrl" : "https://twitter.com/i/web/status/1507362423216525316"
    }
  },
  {
    "like" : {
      "tweetId" : "1507365064801931269",
      "fullText" : "イベントに来たもりくぼ https://t.co/8JDowvRBhy",
      "expandedUrl" : "https://twitter.com/i/web/status/1507365064801931269"
    }
  },
  {
    "like" : {
      "tweetId" : "1507067910258409477",
      "fullText" : "Amy Rose 💕 https://t.co/ApllI7xdBS",
      "expandedUrl" : "https://twitter.com/i/web/status/1507067910258409477"
    }
  },
  {
    "like" : {
      "tweetId" : "1507311333334736929",
      "fullText" : "マヤー\n#ウマ娘 https://t.co/uIVFhnCCIO",
      "expandedUrl" : "https://twitter.com/i/web/status/1507311333334736929"
    }
  },
  {
    "like" : {
      "tweetId" : "1507147857635250179",
      "fullText" : "あと少しで完成\nEマウント58mm F1.4\nレンズ自体は、焦点距離100mmのものを2つ買って組み合わせてます https://t.co/MTUB8niVUk",
      "expandedUrl" : "https://twitter.com/i/web/status/1507147857635250179"
    }
  },
  {
    "like" : {
      "tweetId" : "1506984727496085506",
      "fullText" : "Another product to shout about! This time it isn't Crumble related 😱 Meet the DataHive Green. It's a multipurpose device which can monitor voltage, resistance, temperature charge and light. 1/3 https://t.co/fJfgocRyzY",
      "expandedUrl" : "https://twitter.com/i/web/status/1506984727496085506"
    }
  },
  {
    "like" : {
      "tweetId" : "1507355615777198084",
      "fullText" : "exploring possibilities with my @adafruit midi foot pedal and finger drumming. using it to control a cutoff filter to make expressive drum rolls 🦶🥁🎛 https://t.co/uX1xp24JrP",
      "expandedUrl" : "https://twitter.com/i/web/status/1507355615777198084"
    }
  },
  {
    "like" : {
      "tweetId" : "1507153467273580551",
      "fullText" : "Experimentation. Creating a point of sale gateway to accept cryptocurrency in small shops https://t.co/NRVq0g1a31",
      "expandedUrl" : "https://twitter.com/i/web/status/1507153467273580551"
    }
  },
  {
    "like" : {
      "tweetId" : "1506983614311014407",
      "fullText" : "Hard to ignore a cute girl who whispers either \"Kernigan and Ritchie\" or \"op-amp\" in my ear https://t.co/Ny975hRuKG",
      "expandedUrl" : "https://twitter.com/i/web/status/1506983614311014407"
    }
  },
  {
    "like" : {
      "tweetId" : "1506998420287856647",
      "fullText" : "ぷにるはかわいいスライム https://t.co/cA7lLzYPIj",
      "expandedUrl" : "https://twitter.com/i/web/status/1506998420287856647"
    }
  },
  {
    "like" : {
      "tweetId" : "1506929187864866821",
      "fullText" : "日記です https://t.co/x9JuV0gyzp",
      "expandedUrl" : "https://twitter.com/i/web/status/1506929187864866821"
    }
  },
  {
    "like" : {
      "tweetId" : "1506700408198160392",
      "fullText" : "Making a thing https://t.co/EQ3B1cWU3d",
      "expandedUrl" : "https://twitter.com/i/web/status/1506700408198160392"
    }
  },
  {
    "like" : {
      "tweetId" : "1506634886815404036",
      "fullText" : "Making a Small Candle-Fired Convection Heater for a Tiny Camper https://t.co/1Iitgk7abM",
      "expandedUrl" : "https://twitter.com/i/web/status/1506634886815404036"
    }
  },
  {
    "like" : {
      "tweetId" : "1506722688097681408",
      "fullText" : "Lego Car Demonstrates Proper Use of Ball Wheels https://t.co/jeCkdvG5a9",
      "expandedUrl" : "https://twitter.com/i/web/status/1506722688097681408"
    }
  },
  {
    "like" : {
      "tweetId" : "1506665891471273984",
      "fullText" : "Dinky RDS FM Radio Board! An engaging exploration of FM radio #TindieBlog https://t.co/dgErfNRJpn",
      "expandedUrl" : "https://twitter.com/i/web/status/1506665891471273984"
    }
  },
  {
    "like" : {
      "tweetId" : "1506722509122584584",
      "fullText" : "Quick update on my watch project: 23days runtime already, refreshing every minute. Autosleep at night will push this to a month. New LDO will go even further. 10mm thickness, kinda water proof already. Baro, thermo, compass, rtc, WiFi, BT, 8mb rom, 2mb ram. Esp32picoV302 https://t.co/IzCNMbElPM",
      "expandedUrl" : "https://twitter.com/i/web/status/1506722509122584584"
    }
  },
  {
    "like" : {
      "tweetId" : "1502980834155851782",
      "fullText" : "iPod with Clock Wheel. https://t.co/AZGg3k6aCV",
      "expandedUrl" : "https://twitter.com/i/web/status/1502980834155851782"
    }
  },
  {
    "like" : {
      "tweetId" : "1503419966879526916",
      "fullText" : "The iPod 850 managed to extend battery life to several months through the omission of a backlight, and use of an anachronistic LED display. Moments after release references were found in dozens of historical documents, proving its upcoming popularity among temporal travellers. https://t.co/8yL9HWHJBK",
      "expandedUrl" : "https://twitter.com/i/web/status/1503419966879526916"
    }
  },
  {
    "like" : {
      "tweetId" : "1506170222385905664",
      "fullText" : "いい感じの絞りが作れた https://t.co/qjjc438RSI",
      "expandedUrl" : "https://twitter.com/i/web/status/1506170222385905664"
    }
  },
  {
    "like" : {
      "tweetId" : "1506407329201156096",
      "fullText" : "iPod µ doubled as an external key replacement for the Keyboard µ which lacked arrows. https://t.co/tgxAkZ9CRy",
      "expandedUrl" : "https://twitter.com/i/web/status/1506407329201156096"
    }
  },
  {
    "like" : {
      "tweetId" : "1506411631139602434",
      "fullText" : "https://t.co/olOy2XldkP",
      "expandedUrl" : "https://twitter.com/i/web/status/1506411631139602434"
    }
  },
  {
    "like" : {
      "tweetId" : "1506338479747350531",
      "fullText" : "The show has its first sponsor!  If you, too would like to sponsor the show, it goes towards podcast hosting, transcripts and sound editing.  Thanks for your support.  https://t.co/HghARaiHcm",
      "expandedUrl" : "https://twitter.com/i/web/status/1506338479747350531"
    }
  },
  {
    "like" : {
      "tweetId" : "1506150907402395648",
      "fullText" : "ディオナちゃん調査隊 https://t.co/2NrBMRbRBp",
      "expandedUrl" : "https://twitter.com/i/web/status/1506150907402395648"
    }
  },
  {
    "like" : {
      "tweetId" : "1505328717429710856",
      "fullText" : "Doesn't get much smaller than this 😅\n\nhttps://t.co/XPRdOjFK0I https://t.co/4c2F25LTjD",
      "expandedUrl" : "https://twitter.com/i/web/status/1505328717429710856"
    }
  },
  {
    "like" : {
      "tweetId" : "1505635399745605636",
      "fullText" : "ElectronBot: A Sweet Mini Desktop Robot That Ticks All The Boxes https://t.co/27Q8vucLn2",
      "expandedUrl" : "https://twitter.com/i/web/status/1505635399745605636"
    }
  },
  {
    "like" : {
      "tweetId" : "1505681669658918917",
      "fullText" : "https://t.co/v3JcXs9ZXd",
      "expandedUrl" : "https://twitter.com/i/web/status/1505681669658918917"
    }
  },
  {
    "like" : {
      "tweetId" : "1505077817423249408",
      "fullText" : "Macintosh Studio https://t.co/uJTbDAqnzq",
      "expandedUrl" : "https://twitter.com/i/web/status/1505077817423249408"
    }
  },
  {
    "like" : {
      "tweetId" : "1406245980274495493",
      "fullText" : "I've always wondered what an Official #Apple GamePad for the #AppleTV could look like to I took the buttons and Click Wheel from the new #SiriRemote and threw it all together in #Figma :) I'm in no way a hardware designer but I thought it looked fun, versatile and pretty useable! https://t.co/xSr5iPeRI4",
      "expandedUrl" : "https://twitter.com/i/web/status/1406245980274495493"
    }
  },
  {
    "like" : {
      "tweetId" : "1505121982144151552",
      "fullText" : "@zapakitul @NanoRaptor Oops, the floppy was there the whole time! https://t.co/7caAMer4ZM",
      "expandedUrl" : "https://twitter.com/i/web/status/1505121982144151552"
    }
  },
  {
    "like" : {
      "tweetId" : "1505693898244440064",
      "fullText" : "IBM ThinkPod Classic https://t.co/GWg9FgASRh",
      "expandedUrl" : "https://twitter.com/i/web/status/1505693898244440064"
    }
  },
  {
    "like" : {
      "tweetId" : "1426137895618838531",
      "fullText" : "おてんばアリスと月の国🌙 https://t.co/ijDTEm7b88",
      "expandedUrl" : "https://twitter.com/i/web/status/1426137895618838531"
    }
  },
  {
    "like" : {
      "tweetId" : "1505572730535522306",
      "fullText" : "日記です https://t.co/mIGAKCVQMH",
      "expandedUrl" : "https://twitter.com/i/web/status/1505572730535522306"
    }
  },
  {
    "like" : {
      "tweetId" : "1504226427402862592",
      "fullText" : "#sharpikeebo で自作の表示更新プログラムで画面更新できました😊\n昨日、地震＆停電で作業中断したので今朝続き。\n\n結構高速に更新できますね。 https://t.co/zNsCiU27JA",
      "expandedUrl" : "https://twitter.com/i/web/status/1504226427402862592"
    }
  },
  {
    "like" : {
      "tweetId" : "1505438310621388802",
      "fullText" : "https://t.co/fGJ9hA9Cyj",
      "expandedUrl" : "https://twitter.com/i/web/status/1505438310621388802"
    }
  },
  {
    "like" : {
      "tweetId" : "1505497122623295490",
      "fullText" : "フタを押さえなかった夢見りあむ https://t.co/skhyzff2fA",
      "expandedUrl" : "https://twitter.com/i/web/status/1505497122623295490"
    }
  },
  {
    "like" : {
      "tweetId" : "1505529630584885252",
      "fullText" : "Alright friends of the show, we’re halfway through season 1 and I hope you’re caught up.  Next up: @todbot; then Rose Hooper, creator of the LED Animations library; and in episode 6: @tannewt, #CircuitPython’s project lead.  Subscribe to the show: https://t.co/P9EwqLC5IX",
      "expandedUrl" : "https://twitter.com/i/web/status/1505529630584885252"
    }
  },
  {
    "like" : {
      "tweetId" : "1505531026885705728",
      "fullText" : "夜空のお茶会🌙 https://t.co/PemvyvZe7r",
      "expandedUrl" : "https://twitter.com/i/web/status/1505531026885705728"
    }
  },
  {
    "like" : {
      "tweetId" : "1504087842531983364",
      "fullText" : "お顔直したハーバリウムちゃん。 https://t.co/vmHnKZSBZz",
      "expandedUrl" : "https://twitter.com/i/web/status/1504087842531983364"
    }
  },
  {
    "like" : {
      "tweetId" : "1504417015666470917",
      "fullText" : "あ、おかえりなさい https://t.co/olnQpCN1nS",
      "expandedUrl" : "https://twitter.com/i/web/status/1504417015666470917"
    }
  },
  {
    "like" : {
      "tweetId" : "1503710545601515522",
      "fullText" : "https://t.co/Pvxsud8shv",
      "expandedUrl" : "https://twitter.com/i/web/status/1503710545601515522"
    }
  },
  {
    "like" : {
      "tweetId" : "1503453262636371980",
      "fullText" : "Bill Sideris' Ljinux puts \"a Linux written in Python\" onto your Raspberry Pi Pico's RP2040: https://t.co/YUFfWqFocu https://t.co/kWdX7t35gb",
      "expandedUrl" : "https://twitter.com/i/web/status/1503453262636371980"
    }
  },
  {
    "like" : {
      "tweetId" : "1503407186407436294",
      "fullText" : "$189? This is not interesting at all. Last April I purchased a few 8GB versions for $75 from @adafruit \n\nGuess I will go back to a 555 timer on a breadboard until the prices come back to Earth. 🤪 https://t.co/pK5aOBJFo4",
      "expandedUrl" : "https://twitter.com/i/web/status/1503407186407436294"
    }
  },
  {
    "like" : {
      "tweetId" : "1503511253704413190",
      "fullText" : "日記です https://t.co/yoO5CHzKZV",
      "expandedUrl" : "https://twitter.com/i/web/status/1503511253704413190"
    }
  },
  {
    "like" : {
      "tweetId" : "1503567269867270146",
      "fullText" : "New Learn Guide: Adafruit QT Py ESP32-C3 WiFi Dev Board @adafruit #adafruit https://t.co/3eDR095317",
      "expandedUrl" : "https://twitter.com/i/web/status/1503567269867270146"
    }
  },
  {
    "like" : {
      "tweetId" : "1503587687256969219",
      "fullText" : "だ～れだっ！ https://t.co/QPItwCh1Px",
      "expandedUrl" : "https://twitter.com/i/web/status/1503587687256969219"
    }
  },
  {
    "like" : {
      "tweetId" : "1503671457322508289",
      "fullText" : "Twitterのフォロワーさん30万人超えてました！！！\nいつもリツイート、いいね、リプライなどなど！！！\nありがとうございます！！！！！！！！！！ https://t.co/yBJnEgSBAm",
      "expandedUrl" : "https://twitter.com/i/web/status/1503671457322508289"
    }
  },
  {
    "like" : {
      "tweetId" : "1503008124697030656",
      "fullText" : "Haptic Smart Knob Does Several Jobs https://t.co/EXjyq9wrzz",
      "expandedUrl" : "https://twitter.com/i/web/status/1503008124697030656"
    }
  },
  {
    "like" : {
      "tweetId" : "1503180995171741699",
      "fullText" : "Joey is continuing his great work with segmented LCDs - check out his great talk from Remoticon last year that tells you how to get up to speed with these devices!\n\nhttps://t.co/DftcaldI4k https://t.co/VsM4oWzCai",
      "expandedUrl" : "https://twitter.com/i/web/status/1503180995171741699"
    }
  },
  {
    "like" : {
      "tweetId" : "1503286888588877825",
      "fullText" : "@josecastillo @oshpark I have made a similar board with an MSP430 MCU in 2018 as it seems 🙂 https://t.co/TT8WSkoDuh",
      "expandedUrl" : "https://twitter.com/i/web/status/1503286888588877825"
    }
  },
  {
    "like" : {
      "tweetId" : "1503034077833838599",
      "fullText" : "Are you caught up with the first two episodes of the show?  Two days until the next episode with Professor John Gallaugher (@gallaugher)!  It’s a great chat about CircuitPython in higher ed.  Subscribe now! https://t.co/P9EwqLC5IX",
      "expandedUrl" : "https://twitter.com/i/web/status/1503034077833838599"
    }
  },
  {
    "like" : {
      "tweetId" : "1502703591764938753",
      "fullText" : "日記です https://t.co/4aXKMRgOQg",
      "expandedUrl" : "https://twitter.com/i/web/status/1502703591764938753"
    }
  },
  {
    "like" : {
      "tweetId" : "1502893998230294532",
      "fullText" : "幸子ちゃんにもその子、見えてるんだ… https://t.co/ut2etkd5Rg",
      "expandedUrl" : "https://twitter.com/i/web/status/1502893998230294532"
    }
  },
  {
    "like" : {
      "tweetId" : "1502983575364255747",
      "fullText" : "りあむさん https://t.co/3FTbcQqwzp",
      "expandedUrl" : "https://twitter.com/i/web/status/1502983575364255747"
    }
  },
  {
    "like" : {
      "tweetId" : "1502670129758355459",
      "fullText" : "😮 I want. https://t.co/RvMohjfiiJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1502670129758355459"
    }
  },
  {
    "like" : {
      "tweetId" : "1502360644888436737",
      "fullText" : "https://t.co/mBJEogdYfK",
      "expandedUrl" : "https://twitter.com/i/web/status/1502360644888436737"
    }
  },
  {
    "like" : {
      "tweetId" : "1502335685918814212",
      "fullText" : "When I get some more free time I'll put together a proper assembly video and cover the design in more depth.\n\nThis thing turned out way better than expected and there are lots of little details that I'm pretty proud of! https://t.co/NkoMidTLQM",
      "expandedUrl" : "https://twitter.com/i/web/status/1502335685918814212"
    }
  },
  {
    "like" : {
      "tweetId" : "1502338282490892293",
      "fullText" : "@scottbez1 amazing project! i want to build one🤩",
      "expandedUrl" : "https://twitter.com/i/web/status/1502338282490892293"
    }
  },
  {
    "like" : {
      "tweetId" : "1502335672153034753",
      "fullText" : "BLDC gimbal motor + magnetic encoder + round LCD = SmartKnob View: An open-source haptic input knob\n\nQuick teaser below, and a slightly longer overview is on YouTube: https://t.co/rOFJSY2ySV https://t.co/fRtoODSq1g",
      "expandedUrl" : "https://twitter.com/i/web/status/1502335672153034753"
    }
  },
  {
    "like" : {
      "tweetId" : "1502298539166416899",
      "fullText" : "3/21シンステ合わせの新刊「2021年に描いたイラストまとめ本」\n2021年に描いたデレマスのイラストと2020年までに描いてたモノクロ４コマ＋αをまとめました！全80P！！\nぜひ！よろしくお願いします！！\n\n🍈 https://t.co/oF3YBWpSL2\n🐯 https://t.co/HBR2h5uV0a\n🅱️ https://t.co/Qd1P6ULie8 https://t.co/KFQzVkoWfr",
      "expandedUrl" : "https://twitter.com/i/web/status/1502298539166416899"
    }
  },
  {
    "like" : {
      "tweetId" : "1502064554897186819",
      "fullText" : "幼なじみ特有の距離感\nなあこっち向いて https://t.co/Jqx78bnKgE",
      "expandedUrl" : "https://twitter.com/i/web/status/1502064554897186819"
    }
  },
  {
    "like" : {
      "tweetId" : "1502058647005937670",
      "fullText" : "NEW GUIDE: Personal and Portable ESP32-S2 Web Server @adafruit @johnedgarpark #adafruit https://t.co/pKDzPCjTIl",
      "expandedUrl" : "https://twitter.com/i/web/status/1502058647005937670"
    }
  },
  {
    "like" : {
      "tweetId" : "1502045338563227649",
      "fullText" : "https://t.co/iK8t07oU24",
      "expandedUrl" : "https://twitter.com/i/web/status/1502045338563227649"
    }
  },
  {
    "like" : {
      "tweetId" : "1499732058607960070",
      "fullText" : "Updtaed to #qmk 0.16.0 and added some icons to the font =) #MechanicalKeyboard https://t.co/AAFLbUo8Wa",
      "expandedUrl" : "https://twitter.com/i/web/status/1499732058607960070"
    }
  },
  {
    "like" : {
      "tweetId" : "1501818630522114049",
      "fullText" : "Skebリクエスト絵！！\nありがとうございました！！！ https://t.co/jrZy2hVyAq",
      "expandedUrl" : "https://twitter.com/i/web/status/1501818630522114049"
    }
  },
  {
    "like" : {
      "tweetId" : "1501690419612160006",
      "fullText" : "COMING SOON – Adafruit QT Py ESP32-C3 WiFi Dev Board with STEMMA QT https://t.co/8GFGSTp81A",
      "expandedUrl" : "https://twitter.com/i/web/status/1501690419612160006"
    }
  },
  {
    "like" : {
      "tweetId" : "1501708119742816260",
      "fullText" : "https://t.co/en1Y2Efjrn",
      "expandedUrl" : "https://twitter.com/i/web/status/1501708119742816260"
    }
  },
  {
    "like" : {
      "tweetId" : "1501620059764101120",
      "fullText" : "Just got my #FlipperZero today!\nHack all the things. https://t.co/h2ZKxWFPhf",
      "expandedUrl" : "https://twitter.com/i/web/status/1501620059764101120"
    }
  },
  {
    "like" : {
      "tweetId" : "1501211977246560257",
      "fullText" : "I love old tech, and now I have a new obsession to find one of these things. The Seiko TV Watch (1982)! https://t.co/NOPuRYzlaC",
      "expandedUrl" : "https://twitter.com/i/web/status/1501211977246560257"
    }
  },
  {
    "like" : {
      "tweetId" : "1501540782578155532",
      "fullText" : "ぼくのめーーーーっちゃ好きなアニメがｄアニメストアで配信開始されたのでおすすめさせていただきたい https://t.co/NMR7IDiXKp",
      "expandedUrl" : "https://twitter.com/i/web/status/1501540782578155532"
    }
  },
  {
    "like" : {
      "tweetId" : "1501271812424011780",
      "fullText" : "@hackaday There was a tiny size- issue at my colleague's footprint :) https://t.co/XNcVQ8sxWl",
      "expandedUrl" : "https://twitter.com/i/web/status/1501271812424011780"
    }
  },
  {
    "like" : {
      "tweetId" : "1501505654913368071",
      "fullText" : "新しいスマホを手に入れた凪ちゃん https://t.co/TvQElD5DUE",
      "expandedUrl" : "https://twitter.com/i/web/status/1501505654913368071"
    }
  },
  {
    "like" : {
      "tweetId" : "1501287967159169026",
      "fullText" : "Thanks @pythonbytes @mkennedy for having me on the show live today. Great fun. #Python #CircuitPython #MicroPython https://t.co/Q29rxbFpsQ https://t.co/Vp9Go0TY9H",
      "expandedUrl" : "https://twitter.com/i/web/status/1501287967159169026"
    }
  },
  {
    "like" : {
      "tweetId" : "1501301993293422597",
      "fullText" : "G4 iMac Gets an M1 Heart Transplant https://t.co/gNZYdFRUJX",
      "expandedUrl" : "https://twitter.com/i/web/status/1501301993293422597"
    }
  },
  {
    "like" : {
      "tweetId" : "1501211160271790081",
      "fullText" : "この愛は、サメナイ・トケナイ！\n#ミクの日2022\n#ミクの日 https://t.co/ZFXIKn4fK1",
      "expandedUrl" : "https://twitter.com/i/web/status/1501211160271790081"
    }
  },
  {
    "like" : {
      "tweetId" : "1500888194916704256",
      "fullText" : "Daniel Norris' \"Chonky Palmtop\" build packs a clever swing-out ergonomic mechanical keyboard: https://t.co/vU2ipLE59s https://t.co/1xyIBn3szD",
      "expandedUrl" : "https://twitter.com/i/web/status/1500888194916704256"
    }
  },
  {
    "like" : {
      "tweetId" : "1501146179719266305",
      "fullText" : "初サイゼで困惑するお嬢様 https://t.co/7ssUDdcBsj",
      "expandedUrl" : "https://twitter.com/i/web/status/1501146179719266305"
    }
  },
  {
    "like" : {
      "tweetId" : "1501038241818243072",
      "fullText" : "New Japanese energy drink. https://t.co/2BTGR6A3iI",
      "expandedUrl" : "https://twitter.com/i/web/status/1501038241818243072"
    }
  },
  {
    "like" : {
      "tweetId" : "1500810534949879811",
      "fullText" : "https://t.co/MYgD5Udb1L",
      "expandedUrl" : "https://twitter.com/i/web/status/1500810534949879811"
    }
  },
  {
    "like" : {
      "tweetId" : "1500937862983794688",
      "fullText" : "Love it! https://t.co/d1CRhtGHAa",
      "expandedUrl" : "https://twitter.com/i/web/status/1500937862983794688"
    }
  },
  {
    "like" : {
      "tweetId" : "1500980323202572291",
      "fullText" : ".@Raspberry_Pi Pico adapter using @solderparty FlexyPins. Cortex-10 header for SWD - yay or nay? The SWD pins are also in the breadboard header. Any other suggestions/wishes? https://t.co/v29YlOLnmo",
      "expandedUrl" : "https://twitter.com/i/web/status/1500980323202572291"
    }
  },
  {
    "like" : {
      "tweetId" : "1501084862333157378",
      "fullText" : "これは幸子 https://t.co/UKwwihtRbE",
      "expandedUrl" : "https://twitter.com/i/web/status/1501084862333157378"
    }
  },
  {
    "like" : {
      "tweetId" : "1501081040886308867",
      "fullText" : "デレマスのイラストまとめ本脱稿した！！！！！！！！！！ https://t.co/o0qC1Awwpb",
      "expandedUrl" : "https://twitter.com/i/web/status/1501081040886308867"
    }
  },
  {
    "like" : {
      "tweetId" : "1363694789363781633",
      "fullText" : "ちなみに504050の1500mAhのLipoバッテリーはこんな風に入ってます😊\n#BLAK_RPI https://t.co/Hka37OMwQ0",
      "expandedUrl" : "https://twitter.com/i/web/status/1363694789363781633"
    }
  },
  {
    "like" : {
      "tweetId" : "1500830447097417728",
      "fullText" : "リハビリ中・・・ https://t.co/QmSXnardj8",
      "expandedUrl" : "https://twitter.com/i/web/status/1500830447097417728"
    }
  },
  {
    "like" : {
      "tweetId" : "1500800692055064582",
      "fullText" : "Linuxやるなら、WinとかMacじゃなくて、ハンドヘルドLinux端末だろ。 https://t.co/yLkhrpgM5G",
      "expandedUrl" : "https://twitter.com/i/web/status/1500800692055064582"
    }
  },
  {
    "like" : {
      "tweetId" : "1500222466492354563",
      "fullText" : "Ohhhhhh\nOHHHHH\n\nWe printing in ✨️3 DIMENSIONS✨️ now!!! \n\n🔥🔥🔥🔥🔥 https://t.co/BQsN5sthhE",
      "expandedUrl" : "https://twitter.com/i/web/status/1500222466492354563"
    }
  },
  {
    "like" : {
      "tweetId" : "1500607165056360452",
      "fullText" : "Starting to work on my \"Hackberry\" devices https://t.co/SOgybmw3pX",
      "expandedUrl" : "https://twitter.com/i/web/status/1500607165056360452"
    }
  },
  {
    "like" : {
      "tweetId" : "1500631799751266304",
      "fullText" : "自主練してるあずにゃん https://t.co/wU640VYauQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1500631799751266304"
    }
  },
  {
    "like" : {
      "tweetId" : "1500474800820695043",
      "fullText" : "My Oscilloscope too. \n#WeStandWithUkraine https://t.co/K4umyN2AZi https://t.co/noR1OjTWFQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1500474800820695043"
    }
  },
  {
    "like" : {
      "tweetId" : "1500445526617116684",
      "fullText" : "@tachiniererin 😂😂now i need to find that image where I used jumper cables to tie my hair 😳😅",
      "expandedUrl" : "https://twitter.com/i/web/status/1500445526617116684"
    }
  },
  {
    "like" : {
      "tweetId" : "1500246125487472640",
      "fullText" : "Damn remember when we could just run desktop linux apps on phones... out of the box?\nF to webtop https://t.co/jGldSA8Y8m",
      "expandedUrl" : "https://twitter.com/i/web/status/1500246125487472640"
    }
  },
  {
    "like" : {
      "tweetId" : "1499873441352142849",
      "fullText" : "@River___Wang Nah it’s perfect for that and I miss my ipod",
      "expandedUrl" : "https://twitter.com/i/web/status/1499873441352142849"
    }
  },
  {
    "like" : {
      "tweetId" : "1499745775794126852",
      "fullText" : "少しきつめなので、ねじ止めしなくても外れません😅\n\n赤い線の代わりに電源スイッチ内蔵したら、おしまいかな。\nバッテリー内蔵はなんか怖いのでやめておきます。\n残量表示も背面にLEDで付いてるのですが、ケース付けたら見えないし。\n薄モバイルバッテリー張り付けて使うのが良さげです。 https://t.co/Xj6Um9Zt7l",
      "expandedUrl" : "https://twitter.com/i/web/status/1499745775794126852"
    }
  },
  {
    "like" : {
      "tweetId" : "1499742476793688071",
      "fullText" : "入った。けどRasPiのUSBx2とHDMI端子が少し高い？\n無理矢理入れてるから斜めになってる😅 https://t.co/i7tuLQewF4",
      "expandedUrl" : "https://twitter.com/i/web/status/1499742476793688071"
    }
  },
  {
    "like" : {
      "tweetId" : "1499745329079787520",
      "fullText" : "チルノちゃん https://t.co/7lXWhVERHA",
      "expandedUrl" : "https://twitter.com/i/web/status/1499745329079787520"
    }
  },
  {
    "like" : {
      "tweetId" : "1499484139933863938",
      "fullText" : "@albpermar @solderparty https://t.co/Nr0OkJKDXu",
      "expandedUrl" : "https://twitter.com/i/web/status/1499484139933863938"
    }
  },
  {
    "like" : {
      "tweetId" : "1499468213951815680",
      "fullText" : "https://t.co/CtGLc9RKmc",
      "expandedUrl" : "https://twitter.com/i/web/status/1499468213951815680"
    }
  },
  {
    "like" : {
      "tweetId" : "1499869615740096513",
      "fullText" : "Looks like I was unfortunately right 😔. I would have wished that the connector had the data pair internally connected like some suggested. https://t.co/eTEIqAwvM3 https://t.co/CNGPVRbeQ2",
      "expandedUrl" : "https://twitter.com/i/web/status/1499869615740096513"
    }
  },
  {
    "like" : {
      "tweetId" : "1499827481498599438",
      "fullText" : "And it even fits! 😊 https://t.co/tQt3N8zyjO",
      "expandedUrl" : "https://twitter.com/i/web/status/1499827481498599438"
    }
  },
  {
    "like" : {
      "tweetId" : "1499805947870515202",
      "fullText" : "Next time you say \"women have always been in programming\" and you get a bunch of replies asking you to prove it, you can link them this blog.\nhttps://t.co/NXNUfuMT7V",
      "expandedUrl" : "https://twitter.com/i/web/status/1499805947870515202"
    }
  },
  {
    "like" : {
      "tweetId" : "1491348148757082112",
      "fullText" : "ちまエナガちゃん https://t.co/JAGOzRgLWC",
      "expandedUrl" : "https://twitter.com/i/web/status/1491348148757082112"
    }
  },
  {
    "like" : {
      "tweetId" : "1499575988946374657",
      "fullText" : "クレーちゃんのフィギュア届いた！！かわいい https://t.co/v9aSt8tYcP",
      "expandedUrl" : "https://twitter.com/i/web/status/1499575988946374657"
    }
  },
  {
    "like" : {
      "tweetId" : "1499390149884534789",
      "fullText" : "Macro keypad adds large RGB knob and eInk display #Python @diconx https://t.co/6RlCxawlgw",
      "expandedUrl" : "https://twitter.com/i/web/status/1499390149884534789"
    }
  },
  {
    "like" : {
      "tweetId" : "1499379622852833282",
      "fullText" : "この辺の塗りも好き。統一できぬ。 https://t.co/ZJrf6YhsXR",
      "expandedUrl" : "https://twitter.com/i/web/status/1499379622852833282"
    }
  },
  {
    "like" : {
      "tweetId" : "1499168007050113025",
      "fullText" : "さくらティー飲みませんか🌸 https://t.co/XFN72Qwhaz",
      "expandedUrl" : "https://twitter.com/i/web/status/1499168007050113025"
    }
  },
  {
    "like" : {
      "tweetId" : "1499035481824272385",
      "fullText" : "The Steph Curry of sanitation #whatisnewyork https://t.co/97hi2kCv6F",
      "expandedUrl" : "https://twitter.com/i/web/status/1499035481824272385"
    }
  },
  {
    "like" : {
      "tweetId" : "1497872169631555585",
      "fullText" : "カエル https://t.co/h2tmxZotbG",
      "expandedUrl" : "https://twitter.com/i/web/status/1497872169631555585"
    }
  },
  {
    "like" : {
      "tweetId" : "1499304255098089472",
      "fullText" : "#うさぎの日 https://t.co/Y5em7HvS5U",
      "expandedUrl" : "https://twitter.com/i/web/status/1499304255098089472"
    }
  },
  {
    "like" : {
      "tweetId" : "1499023427319250944",
      "fullText" : "日記です https://t.co/DLXIfwZXJl",
      "expandedUrl" : "https://twitter.com/i/web/status/1499023427319250944"
    }
  },
  {
    "like" : {
      "tweetId" : "1498825985688489986",
      "fullText" : "@candidoneto89 https://t.co/2pRvkbg6Ib",
      "expandedUrl" : "https://twitter.com/i/web/status/1498825985688489986"
    }
  },
  {
    "like" : {
      "tweetId" : "1498823294014926861",
      "fullText" : "Little demo moving a dot around a matrix with a rotary encoder 🎛 https://t.co/4mmlXCvHXc",
      "expandedUrl" : "https://twitter.com/i/web/status/1498823294014926861"
    }
  },
  {
    "like" : {
      "tweetId" : "1498971607230193664",
      "fullText" : "月の花🌕 https://t.co/eKYDXisTd6",
      "expandedUrl" : "https://twitter.com/i/web/status/1498971607230193664"
    }
  },
  {
    "like" : {
      "tweetId" : "1498738351993757697",
      "fullText" : "A Gamecube Keyboard Controller (Preonic modded) #Keyboards #Nintendo @peachewire https://t.co/3pH3B0kNoc",
      "expandedUrl" : "https://twitter.com/i/web/status/1498738351993757697"
    }
  },
  {
    "like" : {
      "tweetId" : "1498686160733941761",
      "fullText" : "https://t.co/mtn11IMWOY",
      "expandedUrl" : "https://twitter.com/i/web/status/1498686160733941761"
    }
  },
  {
    "like" : {
      "tweetId" : "1498666929975877643",
      "fullText" : "The CircuitPython Show Episode 1 – A Talk with Kattni Rembor #CircuitPython #Podcast https://t.co/JY1KjZYoEL",
      "expandedUrl" : "https://twitter.com/i/web/status/1498666929975877643"
    }
  },
  {
    "like" : {
      "tweetId" : "1498670966699872256",
      "fullText" : "Good guesses! Zodiac the Astrology Computer by Coleco (1979)\n\nThe Zodiac Astrology computer was a consumer product created by Coleco in 1979 intended as a “personal astrology assistant” - photos, videos, and how to use it!\n\nhttps://t.co/ptvl2zUuOn https://t.co/yX4DbwyX6Y",
      "expandedUrl" : "https://twitter.com/i/web/status/1498670966699872256"
    }
  },
  {
    "like" : {
      "tweetId" : "1498681258674724870",
      "fullText" : "The CircuitPython Show Episode 1 – A Talk with Kattni Rembor #CircuitPython #Podcast  https://t.co/1i3tZsdPve",
      "expandedUrl" : "https://twitter.com/i/web/status/1498681258674724870"
    }
  },
  {
    "like" : {
      "tweetId" : "1498535083900235779",
      "fullText" : "SD cards cosplaying as floppy disks 💾😁\n\nAll the work @adafruit has been doing around floppy disks made me wish I still had my collection, so I designed these and printed them on sticker paper! Bonus: it makes the card more writeable ✨ https://t.co/kztuqUDSBg",
      "expandedUrl" : "https://twitter.com/i/web/status/1498535083900235779"
    }
  },
  {
    "like" : {
      "tweetId" : "1498694169434689536",
      "fullText" : "おいしくなーれっ！ https://t.co/R0DVdnA1dE",
      "expandedUrl" : "https://twitter.com/i/web/status/1498694169434689536"
    }
  },
  {
    "like" : {
      "tweetId" : "1498297766887718912",
      "fullText" : "https://t.co/zQ1KtR7Pct",
      "expandedUrl" : "https://twitter.com/i/web/status/1498297766887718912"
    }
  },
  {
    "like" : {
      "tweetId" : "1498651384832536579",
      "fullText" : "Episode 1 with @Kattni Rembor is now officially out!  Episode info, show notes, and podcast player are here:  https://t.co/Cr0gPJibCf",
      "expandedUrl" : "https://twitter.com/i/web/status/1498651384832536579"
    }
  },
  {
    "like" : {
      "tweetId" : "1498060185394421767",
      "fullText" : "Here's a thought... polymer clay bakes at around 110 degrees C right? Most electronics can survive that for a little while, so why not embed electronics in polymer clay? easy enclosures? etc. 🤔",
      "expandedUrl" : "https://twitter.com/i/web/status/1498060185394421767"
    }
  },
  {
    "like" : {
      "tweetId" : "1498300401182932997",
      "fullText" : "https://t.co/Ryy39f8uQi",
      "expandedUrl" : "https://twitter.com/i/web/status/1498300401182932997"
    }
  },
  {
    "like" : {
      "tweetId" : "1498411629234511876",
      "fullText" : "https://t.co/3e0lt2gKki",
      "expandedUrl" : "https://twitter.com/i/web/status/1498411629234511876"
    }
  },
  {
    "like" : {
      "tweetId" : "1498411685794693121",
      "fullText" : "The Watch Upitchu https://t.co/ummfUlDAsY",
      "expandedUrl" : "https://twitter.com/i/web/status/1498411685794693121"
    }
  },
  {
    "like" : {
      "tweetId" : "1584455684917035008",
      "fullText" : "Nothing makes me happier than the package from China @JLCPCB well done!\n\nOK, maybe the new hardware parts :) https://t.co/rApwKinhL8",
      "expandedUrl" : "https://twitter.com/i/web/status/1584455684917035008"
    }
  },
  {
    "like" : {
      "tweetId" : "1584524334759956481",
      "fullText" : "New post on the Arduino Engineering blog! Read about Christian Sarnataro's journey to adding Web Serial API support to the Arduino Cloud Editor. https://t.co/FZltNygzk7",
      "expandedUrl" : "https://twitter.com/i/web/status/1584524334759956481"
    }
  },
  {
    "like" : {
      "tweetId" : "1584286879217643520",
      "fullText" : "Digging through old projects we found an Arduino based handheld we designed back in 2019. It still works! https://t.co/UzoVM59MlC",
      "expandedUrl" : "https://twitter.com/i/web/status/1584286879217643520"
    }
  },
  {
    "like" : {
      "tweetId" : "1584321296187686913",
      "fullText" : "@River___Wang @CedarGroveMakr - have a sec to help?",
      "expandedUrl" : "https://twitter.com/i/web/status/1584321296187686913"
    }
  },
  {
    "like" : {
      "tweetId" : "1584325747149504512",
      "expandedUrl" : "https://twitter.com/i/web/status/1584325747149504512"
    }
  },
  {
    "like" : {
      "tweetId" : "1584327426863435777",
      "expandedUrl" : "https://twitter.com/i/web/status/1584327426863435777"
    }
  },
  {
    "like" : {
      "tweetId" : "1584035652005351426",
      "fullText" : "らくがき https://t.co/V15hf6Y3Wq",
      "expandedUrl" : "https://twitter.com/i/web/status/1584035652005351426"
    }
  },
  {
    "like" : {
      "tweetId" : "1583775277842583552",
      "fullText" : "デジタルな砂時計を作りました。\nよろしくお願いします。 https://t.co/igrhRP8ouV",
      "expandedUrl" : "https://twitter.com/i/web/status/1583775277842583552"
    }
  },
  {
    "like" : {
      "tweetId" : "1581315855194853381",
      "fullText" : "https://t.co/I5vd26bZJ7",
      "expandedUrl" : "https://twitter.com/i/web/status/1581315855194853381"
    }
  },
  {
    "like" : {
      "tweetId" : "1584180769722728448",
      "fullText" : "I installed Chrome Flex on a Dell Vostro 1510 laptop last night. \n\n    Works great. \n\n          It did take several updates to reach ChromeOS 106, though.",
      "expandedUrl" : "https://twitter.com/i/web/status/1584180769722728448"
    }
  },
  {
    "like" : {
      "tweetId" : "1583956699949322240",
      "fullText" : "2022 Cyberdeck Contest: QAZ Personal Terminal https://t.co/YTck4AZbu1",
      "expandedUrl" : "https://twitter.com/i/web/status/1583956699949322240"
    }
  },
  {
    "like" : {
      "tweetId" : "1584007607810871298",
      "fullText" : "@River___Wang Ohhh I might actually use that. Sounds like a good fit for my sequencer which is on hold until after Halloween projects. Starred. Also in the read me it's RP2040, short for Raspberry Pi ;)",
      "expandedUrl" : "https://twitter.com/i/web/status/1584007607810871298"
    }
  },
  {
    "like" : {
      "tweetId" : "1583889713945251841",
      "fullText" : "JamHamster built this virtual tape deck with a cassette tape shell and the head from a cassette audio adapter using an Arduino Nano to store tape data files and replay them to load software on a ZX Spectrum +2 \n\n[read more: https://t.co/Hc3EK3odnl]\nhttps://t.co/YqtgOuphtc",
      "expandedUrl" : "https://twitter.com/i/web/status/1583889713945251841"
    }
  },
  {
    "like" : {
      "tweetId" : "1583881618506534912",
      "fullText" : "きゅるるん♡ https://t.co/zP6ySWMHvc",
      "expandedUrl" : "https://twitter.com/i/web/status/1583881618506534912"
    }
  },
  {
    "like" : {
      "tweetId" : "1583949972122181632",
      "fullText" : "TODO: learn how to publish a #CircuitPython library.\nhttps://t.co/scQ1Q0zh46",
      "expandedUrl" : "https://twitter.com/i/web/status/1583949972122181632"
    }
  },
  {
    "like" : {
      "tweetId" : "1583949377072033792",
      "fullText" : "As a side product of my CircuitPython Keyboard project. I wrote a #CircuitPython library that \"extends\" the native keypad library to support MCP I2C IO expanders, where each IO pin is connected to a key switch.  \nhttps://t.co/LqKgj6DLJ7",
      "expandedUrl" : "https://twitter.com/i/web/status/1583949377072033792"
    }
  },
  {
    "like" : {
      "tweetId" : "1583758032659308545",
      "fullText" : "Sun SPARCpad 5, 1996 https://t.co/mZgE7VipKX",
      "expandedUrl" : "https://twitter.com/i/web/status/1583758032659308545"
    }
  },
  {
    "like" : {
      "tweetId" : "1583524068963164160",
      "fullText" : "Want 10x faster #CircuitPython LED animations? Me too! I did a little write up on my results: https://t.co/NBXiskv6mX\nJust a dab of \"ulab\" makes it all better! https://t.co/4jmuSFcB4o",
      "expandedUrl" : "https://twitter.com/i/web/status/1583524068963164160"
    }
  },
  {
    "like" : {
      "tweetId" : "1583444549648543744",
      "fullText" : "🎉🎉🎉 My Linux M1 GPU driver passes &gt;99% of the dEQP-GLES2 compliance tests!!!!! 🎉🎉🎉\n\nMost of this is thanks to @alyssarzg's prior work on macOS, but now I can replicate it on Linux! ^^ https://t.co/BTI4AIUTkC",
      "expandedUrl" : "https://twitter.com/i/web/status/1583444549648543744"
    }
  },
  {
    "like" : {
      "tweetId" : "1583596798236446720",
      "fullText" : "Out with the old in with the new https://t.co/etJntm1CPb",
      "expandedUrl" : "https://twitter.com/i/web/status/1583596798236446720"
    }
  },
  {
    "like" : {
      "tweetId" : "1583519325452783616",
      "fullText" : "60% Per-key RGB, Hot Swap, RP2040, VIA out of the box. That's our new pi60RGB, the newest addition to our pi60 lineup. Save $5 when you preorder today!\n\n#mechanicalkeyboards #rp2040 #raspberrypi #1upkeyboards\n\nhttps://t.co/xVyboubU6e https://t.co/AZQjxyTfNo",
      "expandedUrl" : "https://twitter.com/i/web/status/1583519325452783616"
    }
  },
  {
    "like" : {
      "tweetId" : "1583371110753525761",
      "fullText" : "I did what now...?\n\n邊個話我係傻瓜啊？ https://t.co/TwsWPbncyo",
      "expandedUrl" : "https://twitter.com/i/web/status/1583371110753525761"
    }
  },
  {
    "like" : {
      "tweetId" : "1583477007953772544",
      "fullText" : "News from MakeZine: TinyCircuits Tiny TV 2 is a Teeny Televisual Triumph https://t.co/VJVkGQCKL0 https://t.co/HUTORyOzTN",
      "expandedUrl" : "https://twitter.com/i/web/status/1583477007953772544"
    }
  },
  {
    "like" : {
      "tweetId" : "1583226170086023168",
      "fullText" : "CircuitPython 8.0.0 Beta 3 Released! circuitpython  https://t.co/cFl3XHuo8U",
      "expandedUrl" : "https://twitter.com/i/web/status/1583226170086023168"
    }
  },
  {
    "like" : {
      "tweetId" : "1583087909506539521",
      "fullText" : "@RetroTechDreams 🦙⚡️ https://t.co/3byD2slL3e",
      "expandedUrl" : "https://twitter.com/i/web/status/1583087909506539521"
    }
  },
  {
    "like" : {
      "tweetId" : "1498371938326294529",
      "fullText" : "へい、おまち https://t.co/8CPGAn8H32",
      "expandedUrl" : "https://twitter.com/i/web/status/1498371938326294529"
    }
  },
  {
    "like" : {
      "tweetId" : "1498296263556874241",
      "fullText" : "モニター認識設定を修正して、にじみを除去。少しくっきり表示されるようになりました😊 https://t.co/TIJOR5PcOz",
      "expandedUrl" : "https://twitter.com/i/web/status/1498296263556874241"
    }
  },
  {
    "like" : {
      "tweetId" : "1498228881379188746",
      "fullText" : "2 pcba board assembled by @JLCPCB . Very clean built.  Small esp32 watch with accelerometer and RTC https://t.co/KVbatjyy2X",
      "expandedUrl" : "https://twitter.com/i/web/status/1498228881379188746"
    }
  },
  {
    "like" : {
      "tweetId" : "1498242661546823688",
      "fullText" : "これはちょっと前に描いてたいーあるふぁんくらぶ久川姉妹 https://t.co/C3TJpUM1zs",
      "expandedUrl" : "https://twitter.com/i/web/status/1498242661546823688"
    }
  },
  {
    "like" : {
      "tweetId" : "1497831429803483140",
      "fullText" : "加減速走行出来た https://t.co/0FvmjKXnlo",
      "expandedUrl" : "https://twitter.com/i/web/status/1497831429803483140"
    }
  },
  {
    "like" : {
      "tweetId" : "1497998780188135425",
      "fullText" : "https://t.co/VCR6TWAVNZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1497998780188135425"
    }
  },
  {
    "like" : {
      "tweetId" : "1497769930535899138",
      "fullText" : "もっちもちの聖ちゃん https://t.co/ajeJqcBru5",
      "expandedUrl" : "https://twitter.com/i/web/status/1497769930535899138"
    }
  },
  {
    "like" : {
      "tweetId" : "1497754484142792706",
      "fullText" : "図書館で本を取ろうとしたら手が重なってキュンみたいなやつが体験できるロボットを作りました（2018年くらい） https://t.co/SdFNbWSU75",
      "expandedUrl" : "https://twitter.com/i/web/status/1497754484142792706"
    }
  },
  {
    "like" : {
      "tweetId" : "1497963896396787717",
      "fullText" : "@adafruit Mine is build ... a bit late but done .... with a radio (short waves 0 to 30 MHZ) receiver. Now testing https://t.co/lDSbvIj9T4",
      "expandedUrl" : "https://twitter.com/i/web/status/1497963896396787717"
    }
  },
  {
    "like" : {
      "tweetId" : "1497875145595453440",
      "fullText" : "プロデューサーさん\nどこかにお出かけですかぁ？ https://t.co/zV7JZMqcvp",
      "expandedUrl" : "https://twitter.com/i/web/status/1497875145595453440"
    }
  },
  {
    "like" : {
      "tweetId" : "1497893864807743488",
      "fullText" : "https://t.co/X6N7Rtqd16",
      "expandedUrl" : "https://twitter.com/i/web/status/1497893864807743488"
    }
  },
  {
    "like" : {
      "tweetId" : "1497587270790090758",
      "fullText" : "One-handed PlayStation controller #3DPrinting https://t.co/ZYv7Omuc33",
      "expandedUrl" : "https://twitter.com/i/web/status/1497587270790090758"
    }
  },
  {
    "like" : {
      "tweetId" : "1497270168371744771",
      "fullText" : "@CNC_Kitchen ‘s video on non-planar printing inspired me to write a web tool for bending GCode:\nhttps://t.co/9jX6ZhdGvi\n\nYou can play with it here:\nhttps://t.co/RBPqhLaRDP https://t.co/2V6nWcWFES",
      "expandedUrl" : "https://twitter.com/i/web/status/1497270168371744771"
    }
  },
  {
    "like" : {
      "tweetId" : "1497178053071753218",
      "fullText" : "break time☕ https://t.co/Wi8i1daBft",
      "expandedUrl" : "https://twitter.com/i/web/status/1497178053071753218"
    }
  },
  {
    "like" : {
      "tweetId" : "1497590708605456387",
      "fullText" : "日記です https://t.co/7RhTREkjQf",
      "expandedUrl" : "https://twitter.com/i/web/status/1497590708605456387"
    }
  },
  {
    "like" : {
      "tweetId" : "1497386147261009921",
      "fullText" : "Skebありがとうございました！ https://t.co/kWKf9A5baz",
      "expandedUrl" : "https://twitter.com/i/web/status/1497386147261009921"
    }
  },
  {
    "like" : {
      "tweetId" : "1497349816325709829",
      "fullText" : ".@XRobotsUK's bicycle robot self-balances with an omni wheel: https://t.co/wI3XOHdSvA https://t.co/SlW5w983mx",
      "expandedUrl" : "https://twitter.com/i/web/status/1497349816325709829"
    }
  },
  {
    "like" : {
      "tweetId" : "1497314387299749888",
      "fullText" : "ずっと廊下に立ってる笹塚 https://t.co/Sw3Inl2R49",
      "expandedUrl" : "https://twitter.com/i/web/status/1497314387299749888"
    }
  },
  {
    "like" : {
      "tweetId" : "1497203171122647046",
      "fullText" : "ええええええ😥 https://t.co/Hwx6MfgflD",
      "expandedUrl" : "https://twitter.com/i/web/status/1497203171122647046"
    }
  },
  {
    "like" : {
      "tweetId" : "1497225358235553792",
      "fullText" : "@thara1129 :) https://t.co/QR7Bsl7lWN",
      "expandedUrl" : "https://twitter.com/i/web/status/1497225358235553792"
    }
  },
  {
    "like" : {
      "tweetId" : "1497170735797735426",
      "fullText" : "mayaビューポート上のCGをディープフェイクで顔を差し替えテスト。リアルタイムで差し替え出来るDeepFaceLiveを使用。先日ツイッターで見たBrielle GarciaによるUE5とDeepFaceLiveを組み合わせたCGキャラへのリアルタイムの顔差し替えを自分でもやってみたいので下準備 https://t.co/7RjZVwleXP",
      "expandedUrl" : "https://twitter.com/i/web/status/1497170735797735426"
    }
  },
  {
    "like" : {
      "tweetId" : "1497215019301638158",
      "fullText" : "@sulfuroid Oh!!!!! Thank you! https://t.co/PJ6MgDerhR",
      "expandedUrl" : "https://twitter.com/i/web/status/1497215019301638158"
    }
  },
  {
    "like" : {
      "tweetId" : "1496781239851782146",
      "fullText" : "Hi guys, do you have these feelings when you are new to 3D printer? 🤣🤣🤣\n#3D #3dprinting #3dprint  #3dprinted https://t.co/XfAAmjibIW",
      "expandedUrl" : "https://twitter.com/i/web/status/1496781239851782146"
    }
  },
  {
    "like" : {
      "tweetId" : "1496856295697272838",
      "fullText" : "@thebotmakes cool!!!!!!!!!!!!!!! https://t.co/cTKEQO2YqI",
      "expandedUrl" : "https://twitter.com/i/web/status/1496856295697272838"
    }
  },
  {
    "like" : {
      "tweetId" : "1497024689717522433",
      "fullText" : "私も画面が届くのが待ちきれずに使ってます🤣\n\n画面が載る側の6個の穴などいくつか絶縁しておいた方が良いみたいですね。今晩テープ貼ります😊 https://t.co/xuhGCemsbO https://t.co/7kfspoZhva",
      "expandedUrl" : "https://twitter.com/i/web/status/1497024689717522433"
    }
  },
  {
    "like" : {
      "tweetId" : "1496855755172941834",
      "fullText" : "日記です https://t.co/xXc7ZR43ms",
      "expandedUrl" : "https://twitter.com/i/web/status/1496855755172941834"
    }
  },
  {
    "like" : {
      "tweetId" : "1496806126096351235",
      "fullText" : "無知かわいい妹 https://t.co/qO0M3TApVR",
      "expandedUrl" : "https://twitter.com/i/web/status/1496806126096351235"
    }
  },
  {
    "like" : {
      "tweetId" : "1496617030811799555",
      "fullText" : "https://t.co/IUeAUyXtnA",
      "expandedUrl" : "https://twitter.com/i/web/status/1496617030811799555"
    }
  },
  {
    "like" : {
      "tweetId" : "1496292955971362818",
      "fullText" : "Is all epaper this grey or just these gray level ones? Contrast is meh, rez is insane https://t.co/v0WJmHgxz0",
      "expandedUrl" : "https://twitter.com/i/web/status/1496292955971362818"
    }
  },
  {
    "like" : {
      "tweetId" : "1496409760157118467",
      "fullText" : "TshWatch #WearableWednesday https://t.co/nMBlOL7YQS",
      "expandedUrl" : "https://twitter.com/i/web/status/1496409760157118467"
    }
  },
  {
    "like" : {
      "tweetId" : "1487863699926884359",
      "fullText" : "@yukkieeeeeen https://t.co/1vZSfoGGGU",
      "expandedUrl" : "https://twitter.com/i/web/status/1487863699926884359"
    }
  },
  {
    "like" : {
      "tweetId" : "1492220740539666434",
      "fullText" : "Last and final modification on the \"Upitchu Model 27\". PCB size optimisation. RFM95 moved to a different SPI bus to avoid interaction with display. Accelerometer change. Buzzer added. https://t.co/urRFd2919r",
      "expandedUrl" : "https://twitter.com/i/web/status/1492220740539666434"
    }
  },
  {
    "like" : {
      "tweetId" : "1492220804821659652",
      "fullText" : "https://t.co/6hyieTOj1I",
      "expandedUrl" : "https://twitter.com/i/web/status/1492220804821659652"
    }
  },
  {
    "like" : {
      "tweetId" : "1495791434540199936",
      "fullText" : "The ShortWave listener esp32 pcb has arrived ... so coooooolllll https://t.co/4a7l7APvQp",
      "expandedUrl" : "https://twitter.com/i/web/status/1495791434540199936"
    }
  },
  {
    "like" : {
      "tweetId" : "1495458029856305154",
      "fullText" : "👀 https://t.co/3ieCE8gm2j https://t.co/uOs6Xucckq",
      "expandedUrl" : "https://twitter.com/i/web/status/1495458029856305154"
    }
  },
  {
    "like" : {
      "tweetId" : "1495209844965445633",
      "fullText" : "JVC Television and Radio, 1972. Japan Victor Company, Tokyo. (Source:https://t.co/J1ZvibabuT) #industrialdesign #tech https://t.co/xLkV5Han9D",
      "expandedUrl" : "https://twitter.com/i/web/status/1495209844965445633"
    }
  },
  {
    "like" : {
      "tweetId" : "1495465350405754888",
      "fullText" : "So majestic, seeing them fly free from our man made habitats. https://t.co/iPlsO0TJ1X",
      "expandedUrl" : "https://twitter.com/i/web/status/1495465350405754888"
    }
  },
  {
    "like" : {
      "tweetId" : "1495763966865383427",
      "fullText" : "カヨコちゃんです\n#ブルアカ https://t.co/EwGFg2a0n1",
      "expandedUrl" : "https://twitter.com/i/web/status/1495763966865383427"
    }
  },
  {
    "like" : {
      "tweetId" : "1495095949013798913",
      "fullText" : "It’s Bad Apple, But On A 32K EPROM https://t.co/gwtSYXB8XH",
      "expandedUrl" : "https://twitter.com/i/web/status/1495095949013798913"
    }
  },
  {
    "like" : {
      "tweetId" : "1494935577459761152",
      "fullText" : "https://t.co/vwj4lA3mbV",
      "expandedUrl" : "https://twitter.com/i/web/status/1494935577459761152"
    }
  },
  {
    "like" : {
      "tweetId" : "1494987776705855490",
      "fullText" : "問題です https://t.co/WIWm9cMmMG",
      "expandedUrl" : "https://twitter.com/i/web/status/1494987776705855490"
    }
  },
  {
    "like" : {
      "tweetId" : "1494675626141560835",
      "fullText" : "きららMAX4月号の大人気連載『桔香ちゃんは悪役令嬢になりたい！』は、\n桔香ちゃんのイケメンムーブによって心を奪われた、\n手芸部の冬子ちゃんのおはなしです。\n【ニコニコ静画でも無料連載中！今すぐ読めます。】\nhttps://t.co/f11xoi9vJC https://t.co/SDotBgY2PX",
      "expandedUrl" : "https://twitter.com/i/web/status/1494675626141560835"
    }
  },
  {
    "like" : {
      "tweetId" : "1489798651375501315",
      "fullText" : "I'm doing a daily countdown of the 18 best Macs that never existed! 🤓\n\n18: \"Slab\" Mac study, Harmut Esslinger / @frogdesign, 1982\n\nThis cutie was part of frog's winning entry in a 3 agency bake-off, and represents the design language which would come to be known \"Snow White.\" https://t.co/RUo52gZtLg",
      "expandedUrl" : "https://twitter.com/i/web/status/1489798651375501315"
    }
  },
  {
    "like" : {
      "tweetId" : "1494703305649446912",
      "fullText" : "Penkesu Computer – A Homebrew Retro-style Handheld PC #piday #raspberrypi @Raspberry_Pi https://t.co/D6TqlliRnX",
      "expandedUrl" : "https://twitter.com/i/web/status/1494703305649446912"
    }
  },
  {
    "like" : {
      "tweetId" : "1493776011627884548",
      "fullText" : "PCBWay delivered today! @lynaghk nerd sniped me into moving magnets around on PCBs a while back, so I made this little race track demo. It's basically an unrolled stepper motor; driven just the same. Very satisfying. https://t.co/nGH5FbdvCN",
      "expandedUrl" : "https://twitter.com/i/web/status/1493776011627884548"
    }
  },
  {
    "like" : {
      "tweetId" : "1494373308057501699",
      "fullText" : "A little #lora on my lunch break with the rfm95, rp2040, #circuitpython, and #hackrf https://t.co/txbs4sos5H",
      "expandedUrl" : "https://twitter.com/i/web/status/1494373308057501699"
    }
  },
  {
    "like" : {
      "tweetId" : "1494553668690931715",
      "fullText" : "ミニSLを運転するハチロクちゃん https://t.co/c016lG5mNA",
      "expandedUrl" : "https://twitter.com/i/web/status/1494553668690931715"
    }
  },
  {
    "like" : {
      "tweetId" : "1493778318348648448",
      "fullText" : "@RendersbyIan One of the many photo I've taken with my S21 ultra 10x optical camera... Just because iPhone doesn’t have it, doesn’t mean it's useless!\n\nAs someone who's doing photography for a long time, having a better 10x optical zoom in an phone is just a blessing that many doesn’t know https://t.co/TmvKSL4EpJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1493778318348648448"
    }
  },
  {
    "like" : {
      "tweetId" : "1493862595933401099",
      "fullText" : "@RendersbyIan I don't understand this fuss about the 13 pro max being faster in benchmarks than the S22 Ultra. How many videos will you be rendering?",
      "expandedUrl" : "https://twitter.com/i/web/status/1493862595933401099"
    }
  },
  {
    "like" : {
      "tweetId" : "1493738866800353286",
      "fullText" : "@RendersbyIan When Apple gets around to delivering the same thing, you'll be praising Apple. Your analogy about the moon is ridiculous. Taking close-up photos of Wildlife at a safe distance is fantastic and Apple is clearly behind Samsung on Zoom by a long shot",
      "expandedUrl" : "https://twitter.com/i/web/status/1493738866800353286"
    }
  },
  {
    "like" : {
      "tweetId" : "1494443618873982996",
      "fullText" : "Adam was inspired by our recent article on iPod modding, and dived in for himself!\n\nWhat are some of the projects that have inspired your own tinkering?\n\nhttps://t.co/d1IefINdhr https://t.co/gIoyp7wHOJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1494443618873982996"
    }
  },
  {
    "like" : {
      "tweetId" : "1494319484995309570",
      "fullText" : "A functional Star Trek tricorder prop build #StarTrek #Props https://t.co/Ms3F6cGr0N",
      "expandedUrl" : "https://twitter.com/i/web/status/1494319484995309570"
    }
  },
  {
    "like" : {
      "tweetId" : "1493497102562992129",
      "fullText" : "in production .... so excited to get it ... https://t.co/1QDAW5tKLB",
      "expandedUrl" : "https://twitter.com/i/web/status/1493497102562992129"
    }
  },
  {
    "like" : {
      "tweetId" : "1493310695907094530",
      "fullText" : "iPod Cube. https://t.co/TqNHoOaY5P",
      "expandedUrl" : "https://twitter.com/i/web/status/1493310695907094530"
    }
  },
  {
    "like" : {
      "tweetId" : "1493465220651573251",
      "fullText" : "A Hombrew Retro Laptop https://t.co/Yg56guNpy3",
      "expandedUrl" : "https://twitter.com/i/web/status/1493465220651573251"
    }
  },
  {
    "like" : {
      "tweetId" : "1493508466681401348",
      "fullText" : "同じクラスの名取さな https://t.co/ZVBo0isLbq",
      "expandedUrl" : "https://twitter.com/i/web/status/1493508466681401348"
    }
  },
  {
    "like" : {
      "tweetId" : "1493527963656404997",
      "fullText" : "歴女アイドル！丹羽仁美ちゃん！！ https://t.co/P1308mS8Cf",
      "expandedUrl" : "https://twitter.com/i/web/status/1493527963656404997"
    }
  },
  {
    "like" : {
      "tweetId" : "1493540601245151232",
      "fullText" : "ヒフミちゃんです\n#ブルアカ https://t.co/NPPTEcidhv",
      "expandedUrl" : "https://twitter.com/i/web/status/1493540601245151232"
    }
  },
  {
    "like" : {
      "tweetId" : "1493408740913344516",
      "fullText" : "Oh my, thanks for the coverage! 🥺\n\nI guess handhelds do have a larger user base than Linux tablets, but the CutiePi is still my favorite! (crawl back to work) https://t.co/24rZTGyEbO",
      "expandedUrl" : "https://twitter.com/i/web/status/1493408740913344516"
    }
  },
  {
    "like" : {
      "tweetId" : "1493284120574803972",
      "fullText" : "Penkesu Computer : un netbook au coeur de Raspberry Pi Zero 2 W\nLe Penkesu Computer est un projet d'ultra ultraportable au format très origonal qui emploie une carte Raspberry Pi Zero 2 W pour fonctionner....\nhttps://t.co/X2bXQJMdOm https://t.co/Ae9WNsqtqQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1493284120574803972"
    }
  },
  {
    "like" : {
      "tweetId" : "1493179908641951745",
      "fullText" : "「受け取ってくれる…？🍫」 https://t.co/tqvwWF8DcA",
      "expandedUrl" : "https://twitter.com/i/web/status/1493179908641951745"
    }
  },
  {
    "like" : {
      "tweetId" : "1493168734839660544",
      "fullText" : "We saw this at the end of last week, but only had a chance to look in more detail this morning. It looks like it'll be super useful. Here's a short thread:\n\nhttps://t.co/Sev6BzSSZS",
      "expandedUrl" : "https://twitter.com/i/web/status/1493168734839660544"
    }
  },
  {
    "like" : {
      "tweetId" : "1493122927386316801",
      "fullText" : "バレンタインですって https://t.co/CShEvpfO59",
      "expandedUrl" : "https://twitter.com/i/web/status/1493122927386316801"
    }
  },
  {
    "like" : {
      "tweetId" : "1493007041052483587",
      "fullText" : "40x20mm https://t.co/s4xtbzFl0O",
      "expandedUrl" : "https://twitter.com/i/web/status/1493007041052483587"
    }
  },
  {
    "like" : {
      "tweetId" : "1492956450292998158",
      "fullText" : "How many of you owned and used the original Motorola Razr flip phones?\n\nI still have my blue version (2006) tucked away. https://t.co/cbz13LDaQI",
      "expandedUrl" : "https://twitter.com/i/web/status/1492956450292998158"
    }
  },
  {
    "like" : {
      "tweetId" : "1492304968715411456",
      "fullText" : "After Jerry's unfortunate accident, Ostriches were never allowed to work in the lumber mill ever again. https://t.co/pbzdHHFgFH",
      "expandedUrl" : "https://twitter.com/i/web/status/1492304968715411456"
    }
  },
  {
    "like" : {
      "tweetId" : "1492791287288045569",
      "fullText" : "渡す直前でチキった子 https://t.co/7yfzy1Nhvj",
      "expandedUrl" : "https://twitter.com/i/web/status/1492791287288045569"
    }
  },
  {
    "like" : {
      "tweetId" : "1492403951349604353",
      "fullText" : "アロナちゃんです\n#ブルアカ https://t.co/DsjUCBqY3e",
      "expandedUrl" : "https://twitter.com/i/web/status/1492403951349604353"
    }
  },
  {
    "like" : {
      "tweetId" : "1492198689175187458",
      "fullText" : "42 days runtime refreshing every minute, with wifi and bt switched off. 10mm build height. One more hardware revision. 84 uA deepsleep. :) https://t.co/O7K1o6D4KV",
      "expandedUrl" : "https://twitter.com/i/web/status/1492198689175187458"
    }
  },
  {
    "like" : {
      "tweetId" : "1491995289510727683",
      "fullText" : "The 64x32 @adafruit Matrix Portal is a great device, just possibly a little too low res for an external macOS screen. #notquiteretina 😆 https://t.co/MUzGMQQ3Xi",
      "expandedUrl" : "https://twitter.com/i/web/status/1491995289510727683"
    }
  },
  {
    "like" : {
      "tweetId" : "1492123676296499200",
      "fullText" : "大人気ですね、プロデューサーさん https://t.co/phuBIdkUJU",
      "expandedUrl" : "https://twitter.com/i/web/status/1492123676296499200"
    }
  },
  {
    "like" : {
      "tweetId" : "1491757839093743617",
      "fullText" : "I just realized I have to listen to or watch every podcast episode to make sure I get the show notes right.  Will I ever get used to the sound of my own voice?  Ick.",
      "expandedUrl" : "https://twitter.com/i/web/status/1491757839093743617"
    }
  },
  {
    "like" : {
      "tweetId" : "1491255683773497345",
      "fullText" : "スケブ納品しました！ https://t.co/vZOjLDPYDN",
      "expandedUrl" : "https://twitter.com/i/web/status/1491255683773497345"
    }
  },
  {
    "like" : {
      "tweetId" : "1491457050534035456",
      "fullText" : "@type__error I do a “main display” directly in front of me that’s for a neutral neck position then the second one as a side alternative monitor that’s just for terminal/docs/slack shitposting",
      "expandedUrl" : "https://twitter.com/i/web/status/1491457050534035456"
    }
  },
  {
    "like" : {
      "tweetId" : "1491537398861381641",
      "fullText" : "#ShaRPIKeebo V1.2 pre release presentation. Everything is tested and working. So excited. Finishing the documentation and the enclosure design. @crowd_supply campaign by end of fev, beginning of march. @Hacksterio @anne_engineer @adafruit @fast_code_r_us @Raspberry_Pi https://t.co/6uMD34Ey54",
      "expandedUrl" : "https://twitter.com/i/web/status/1491537398861381641"
    }
  },
  {
    "like" : {
      "tweetId" : "1491541249685438465",
      "fullText" : "I see people saying how bad this Image is and bash China. In Germany there are many old industry buildings which are repurposed.  A rave between coal/steel industry buildings? Hipster AF!  It's all perspective. https://t.co/zde83SQiaL",
      "expandedUrl" : "https://twitter.com/i/web/status/1491541249685438465"
    }
  },
  {
    "like" : {
      "tweetId" : "1491445545734672386",
      "fullText" : "食堂にライスさんを確認、接近します https://t.co/7it284VNjD",
      "expandedUrl" : "https://twitter.com/i/web/status/1491445545734672386"
    }
  },
  {
    "like" : {
      "tweetId" : "1488486276244606978",
      "fullText" : "ういうい誕生日！\n#SB69 https://t.co/Y9lkC7O27W",
      "expandedUrl" : "https://twitter.com/i/web/status/1488486276244606978"
    }
  },
  {
    "like" : {
      "tweetId" : "1490940970858610688",
      "fullText" : "双子ちゃんです\n#ブルアカ https://t.co/90VCq0Ulyg",
      "expandedUrl" : "https://twitter.com/i/web/status/1490940970858610688"
    }
  },
  {
    "like" : {
      "tweetId" : "1491064058489217030",
      "fullText" : "Ooh! I hope they pull out of the US next!\n\nFacebook Threatened to Pull Out of Europe. Is It Bluffing? https://t.co/poKAaK68iO",
      "expandedUrl" : "https://twitter.com/i/web/status/1491064058489217030"
    }
  },
  {
    "like" : {
      "tweetId" : "1491098457666469894",
      "fullText" : "Toast Up Your Breadboard Ideas! #TindieBlog #BreadBoard #Prototyping #Soldering https://t.co/2se1LBEDkG",
      "expandedUrl" : "https://twitter.com/i/web/status/1491098457666469894"
    }
  },
  {
    "like" : {
      "tweetId" : "1491421655008169989",
      "fullText" : "Making a macro keypad with CircuitPython and a Show and Tell Demo #CircuitPython #ShowAndTell  https://t.co/XnejWw9pD4",
      "expandedUrl" : "https://twitter.com/i/web/status/1491421655008169989"
    }
  },
  {
    "like" : {
      "tweetId" : "1491420908577247234",
      "fullText" : "Making a macro keypad with CircuitPython and a Show and Tell Demo #CircuitPython #ShowAndTell https://t.co/6xKpr9EZum",
      "expandedUrl" : "https://twitter.com/i/web/status/1491420908577247234"
    }
  },
  {
    "like" : {
      "tweetId" : "1491396152348053514",
      "fullText" : "Build a USB foot switch using 3D printed parts and CircuitPython! Use the QT Py RP2040 or KB2040 to make a customize USB HID controller! Guide https://t.co/gEiq0t6OWQ https://t.co/OxgC54oTDR #Adafruit #3DPrinting https://t.co/PG1ahpm9GF",
      "expandedUrl" : "https://twitter.com/i/web/status/1491396152348053514"
    }
  },
  {
    "like" : {
      "tweetId" : "1490642805005295623",
      "fullText" : "のんちゃん\n#プリパラ #pripara https://t.co/ORNSReTBVF",
      "expandedUrl" : "https://twitter.com/i/web/status/1490642805005295623"
    }
  },
  {
    "like" : {
      "tweetId" : "1490704432568446981",
      "fullText" : "This pair of DIY smart glasses looks like a spectacular project: https://t.co/1prTggjfla https://t.co/AxUH7Bgci3",
      "expandedUrl" : "https://twitter.com/i/web/status/1490704432568446981"
    }
  },
  {
    "like" : {
      "tweetId" : "1490850632139423745",
      "fullText" : "500 Adafruit projects have been certified as open-source by OSHWA #OSHW #OSHWA @Adafruit @ohsummit https://t.co/a1Chdu42GE",
      "expandedUrl" : "https://twitter.com/i/web/status/1490850632139423745"
    }
  },
  {
    "like" : {
      "tweetId" : "1490776793535582209",
      "fullText" : "サメちゃん https://t.co/Va9pWXkc9m",
      "expandedUrl" : "https://twitter.com/i/web/status/1490776793535582209"
    }
  },
  {
    "like" : {
      "tweetId" : "1490907568495292418",
      "fullText" : "仁奈ちゃん！！ https://t.co/9JuiqxvyZQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1490907568495292418"
    }
  },
  {
    "like" : {
      "tweetId" : "1490841263276396546",
      "fullText" : "ハッピーバレンタイン https://t.co/ToX4jlaf51",
      "expandedUrl" : "https://twitter.com/i/web/status/1490841263276396546"
    }
  },
  {
    "like" : {
      "tweetId" : "1490971924717277185",
      "fullText" : "「傷んでるところだけ切って下さい」\n「かしこまりました」 https://t.co/W3eJYwOjK3",
      "expandedUrl" : "https://twitter.com/i/web/status/1490971924717277185"
    }
  },
  {
    "like" : {
      "tweetId" : "1490452321226088451",
      "fullText" : "Somebody is out there re-writing how the whole game is played. https://t.co/d89umNYSzH",
      "expandedUrl" : "https://twitter.com/i/web/status/1490452321226088451"
    }
  },
  {
    "like" : {
      "tweetId" : "1489247612591284226",
      "fullText" : "みんな顔かわいい https://t.co/uUyTGJGt6t",
      "expandedUrl" : "https://twitter.com/i/web/status/1489247612591284226"
    }
  },
  {
    "like" : {
      "tweetId" : "1490348496536231940",
      "fullText" : "Project Penkesu - First pass with beige paint https://t.co/Mi2xIzWNrp",
      "expandedUrl" : "https://twitter.com/i/web/status/1490348496536231940"
    }
  },
  {
    "like" : {
      "tweetId" : "1490345710188957701",
      "fullText" : "tryin out another photo filter app for fun, this time @Prequel_app this is the cartoon filter with @ladyada and @ptorrone @adafruit ... would watch this cartoon. https://t.co/myWRmbggxr",
      "expandedUrl" : "https://twitter.com/i/web/status/1490345710188957701"
    }
  },
  {
    "like" : {
      "tweetId" : "1490031062097010696",
      "fullText" : "😏😏😏 https://t.co/mYmszwHRRH",
      "expandedUrl" : "https://twitter.com/i/web/status/1490031062097010696"
    }
  },
  {
    "like" : {
      "tweetId" : "1489903762936594432",
      "fullText" : "LEDs tonightttttt!!!! https://t.co/Og7VOst4fU",
      "expandedUrl" : "https://twitter.com/i/web/status/1489903762936594432"
    }
  },
  {
    "like" : {
      "tweetId" : "1489669441575358465",
      "fullText" : "とくとーせき https://t.co/RwLnbIvnKs",
      "expandedUrl" : "https://twitter.com/i/web/status/1489669441575358465"
    }
  },
  {
    "like" : {
      "tweetId" : "1489199754026565632",
      "fullText" : "こういうふとした日常を体感したい人生だった。 https://t.co/LUKFqkdh5d",
      "expandedUrl" : "https://twitter.com/i/web/status/1489199754026565632"
    }
  },
  {
    "like" : {
      "tweetId" : "1489209496031219712",
      "fullText" : "🍭 https://t.co/m5Vd4Va9E6",
      "expandedUrl" : "https://twitter.com/i/web/status/1489209496031219712"
    }
  },
  {
    "like" : {
      "tweetId" : "1489229999269945347",
      "fullText" : "I'm sure Twitter will butcher this video, but I can't believe how good #LVGL looks and runs on the @EspressifSystem ESP32-S3 https://t.co/911nqldZI9",
      "expandedUrl" : "https://twitter.com/i/web/status/1489229999269945347"
    }
  },
  {
    "like" : {
      "tweetId" : "1489250625489862656",
      "fullText" : "できた！！まとめ本の表紙！！！ https://t.co/wLf60qHyFl",
      "expandedUrl" : "https://twitter.com/i/web/status/1489250625489862656"
    }
  },
  {
    "like" : {
      "tweetId" : "1488998660239413248",
      "fullText" : "チョコを大量に誤発注したソラちゃんかわいい https://t.co/GrfXi8IrkK",
      "expandedUrl" : "https://twitter.com/i/web/status/1488998660239413248"
    }
  },
  {
    "like" : {
      "tweetId" : "1488705136927019009",
      "fullText" : "ら https://t.co/nRybuhVWL3",
      "expandedUrl" : "https://twitter.com/i/web/status/1488705136927019009"
    }
  },
  {
    "like" : {
      "tweetId" : "1488759924213440522",
      "fullText" : "ねこ❤︎ https://t.co/4WfG3D2kYm",
      "expandedUrl" : "https://twitter.com/i/web/status/1488759924213440522"
    }
  },
  {
    "like" : {
      "tweetId" : "1396086092856578060",
      "fullText" : "ゲームに夢中なきりたんと遊んでほしいゆかりさん https://t.co/bI8AZvG8Ks",
      "expandedUrl" : "https://twitter.com/i/web/status/1396086092856578060"
    }
  },
  {
    "like" : {
      "tweetId" : "1488512633598885889",
      "fullText" : "Create this card-dealing robot to streamline your poker nights: https://t.co/AqwmbGIwRu https://t.co/ETNqtroidk",
      "expandedUrl" : "https://twitter.com/i/web/status/1488512633598885889"
    }
  },
  {
    "like" : {
      "tweetId" : "1488467424987029508",
      "fullText" : "Making a 27,000,000-mAh Portable Power Bank https://t.co/1S0JKSH2g0",
      "expandedUrl" : "https://twitter.com/i/web/status/1488467424987029508"
    }
  },
  {
    "like" : {
      "tweetId" : "1488316028857815040",
      "fullText" : "Watch case... https://t.co/bbpJ7qEuKD",
      "expandedUrl" : "https://twitter.com/i/web/status/1488316028857815040"
    }
  },
  {
    "like" : {
      "tweetId" : "1488116326430576641",
      "fullText" : "今月もありがとうございました😇来月もがんばるぞい！ #今月描いた絵を晒そう https://t.co/ubi6JxL0Sn",
      "expandedUrl" : "https://twitter.com/i/web/status/1488116326430576641"
    }
  },
  {
    "like" : {
      "tweetId" : "1487560089552973824",
      "fullText" : "https://t.co/0swUHLO1aP",
      "expandedUrl" : "https://twitter.com/i/web/status/1487560089552973824"
    }
  },
  {
    "like" : {
      "tweetId" : "1488159070527889410",
      "fullText" : "ESP32-S3 looking 🔥 https://t.co/hirbnaIvFG",
      "expandedUrl" : "https://twitter.com/i/web/status/1488159070527889410"
    }
  },
  {
    "like" : {
      "tweetId" : "1487707832065859584",
      "fullText" : "#今月描いた絵を晒そう\nSkeb❸ https://t.co/0B8vW8bFAW",
      "expandedUrl" : "https://twitter.com/i/web/status/1487707832065859584"
    }
  },
  {
    "like" : {
      "tweetId" : "1487577744288452608",
      "fullText" : "https://t.co/aq3DqpGj4L",
      "expandedUrl" : "https://twitter.com/i/web/status/1487577744288452608"
    }
  },
  {
    "like" : {
      "tweetId" : "1488103324247334916",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1488103324247334916"
    }
  },
  {
    "like" : {
      "tweetId" : "1487667989470072837",
      "fullText" : "今年もよろしくお願いしまーす🐯 https://t.co/cFVz2U9Ycf",
      "expandedUrl" : "https://twitter.com/i/web/status/1487667989470072837"
    }
  },
  {
    "like" : {
      "tweetId" : "1487372809349517314",
      "fullText" : "https://t.co/j2IJqIe6fN",
      "expandedUrl" : "https://twitter.com/i/web/status/1487372809349517314"
    }
  },
  {
    "like" : {
      "tweetId" : "1487720659216379905",
      "fullText" : "🐮🥛 https://t.co/E7ZygWboQE",
      "expandedUrl" : "https://twitter.com/i/web/status/1487720659216379905"
    }
  },
  {
    "like" : {
      "tweetId" : "1487401728710705153",
      "fullText" : "先ほどの #シンデレラ10周年_トロピカルday1 のライブ前告知であった通り、【4月8日】に同時発売決定した「U149」９巻10巻ですが、「第３芸能課だよ」冊子付き同梱版も同時発売です！「第３芸能課だよ」のカバーデザインも公開しますので、是非よろしくお願いします！\n#imas_cg #U149 #第３芸能課だよ https://t.co/IqX76nO6RO",
      "expandedUrl" : "https://twitter.com/i/web/status/1487401728710705153"
    }
  },
  {
    "like" : {
      "tweetId" : "1487770674894884867",
      "fullText" : "ずるじゃん https://t.co/2fkCAD0qbt",
      "expandedUrl" : "https://twitter.com/i/web/status/1487770674894884867"
    }
  },
  {
    "like" : {
      "tweetId" : "1487717652978024448",
      "fullText" : "https://t.co/wMe006TuHv",
      "expandedUrl" : "https://twitter.com/i/web/status/1487717652978024448"
    }
  },
  {
    "like" : {
      "tweetId" : "1487205346644951044",
      "fullText" : "DOOM est jouable... sur un minuscule circuit imprimé !\n\nOn doit la prouesse à Adafruit Industries, deux programmeurs qui ont réussi à émuler le jeu de 1993 sur un écran 1,3 pouce. #TweetDeNuit\n\nDécouvrez leur chaîne : https://t.co/YXWz5dHzdN https://t.co/HOaE3J0zp5",
      "expandedUrl" : "https://twitter.com/i/web/status/1487205346644951044"
    }
  },
  {
    "like" : {
      "tweetId" : "1487080505912672257",
      "fullText" : "https://t.co/vdJSEzohrQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1487080505912672257"
    }
  },
  {
    "like" : {
      "tweetId" : "1487537178615828481",
      "fullText" : "Not my cat https://t.co/1ib3mXdZ9G",
      "expandedUrl" : "https://twitter.com/i/web/status/1487537178615828481"
    }
  },
  {
    "like" : {
      "tweetId" : "1487652051433758722",
      "fullText" : "Star Trek fan constructs tricorder from Voyager TV series #SciFiSunday https://t.co/Vpea81hYhM",
      "expandedUrl" : "https://twitter.com/i/web/status/1487652051433758722"
    }
  },
  {
    "like" : {
      "tweetId" : "1487574884762800128",
      "fullText" : "特技 https://t.co/G7RC0jeC94",
      "expandedUrl" : "https://twitter.com/i/web/status/1487574884762800128"
    }
  },
  {
    "like" : {
      "tweetId" : "1487029582825992193",
      "fullText" : "#𝙎𝙥𝙖𝙘𝙚 𝙎𝙖𝙫𝙞𝙣𝙜 𝙒𝙤𝙤𝙙𝙚𝙣 𝙁𝙪𝙧𝙣𝙞𝙩𝙪𝙧𝙚𝙨.\n#𝐒𝐜𝐢𝐞𝐧𝐜𝐞𝐀𝐧𝐝𝐓𝐞𝐜𝐡𝐧𝐨𝐥𝐨𝐠𝐲 #𝐈𝐧𝐧𝐨𝐯𝐚𝐭𝐢𝐨𝐧𝐅𝐨𝐫𝐄𝐯𝐞𝐫𝐲𝐨𝐧𝐞 https://t.co/jsMPuavtUL",
      "expandedUrl" : "https://twitter.com/i/web/status/1487029582825992193"
    }
  },
  {
    "like" : {
      "tweetId" : "1487160654142361600",
      "fullText" : "One more for my prototype collection! :) https://t.co/TrbIw6atlO",
      "expandedUrl" : "https://twitter.com/i/web/status/1487160654142361600"
    }
  },
  {
    "like" : {
      "tweetId" : "1487343702380998656",
      "fullText" : "告知遅くなりましたが、まんがタイムきららMAXにて連載させて頂いている「桔香(きっか)ちゃんは悪役令嬢になりたい！(原作:相馬先生)」の単行本一巻が1月26日に発売しました！！\n書店などでお見かけの際には、ぜひ！お手にとって頂けたら嬉しいです！！ https://t.co/ZleI5WyLXK https://t.co/9QDUPMc02a",
      "expandedUrl" : "https://twitter.com/i/web/status/1487343702380998656"
    }
  },
  {
    "like" : {
      "tweetId" : "1486942375301861379",
      "fullText" : "PI DIY Music Player #piday #raspberrypi @Raspberry_Pi https://t.co/futlrdhS4m",
      "expandedUrl" : "https://twitter.com/i/web/status/1486942375301861379"
    }
  },
  {
    "like" : {
      "tweetId" : "1486783810176008195",
      "fullText" : "Reject Modernity; Return To Tamagotchi https://t.co/NEGV5jzfbH",
      "expandedUrl" : "https://twitter.com/i/web/status/1486783810176008195"
    }
  },
  {
    "like" : {
      "tweetId" : "1486535569874165765",
      "fullText" : "I figured out why this player isn't working...\nLASERDISC SPIDERS! https://t.co/l5TuQfWNLk",
      "expandedUrl" : "https://twitter.com/i/web/status/1486535569874165765"
    }
  },
  {
    "like" : {
      "tweetId" : "1486777841341530112",
      "fullText" : "@__femb0t cursed",
      "expandedUrl" : "https://twitter.com/i/web/status/1486777841341530112"
    }
  },
  {
    "like" : {
      "tweetId" : "1486777181313413123",
      "fullText" : "https://t.co/Fxw8UIRYAT",
      "expandedUrl" : "https://twitter.com/i/web/status/1486777181313413123"
    }
  },
  {
    "like" : {
      "tweetId" : "1486791663272009736",
      "fullText" : "@adafruit @ladyada Hey pt, did you see the sweet PinOuts shirt from N-O-D-E?\nhttps://t.co/wpGIVE1wa8",
      "expandedUrl" : "https://twitter.com/i/web/status/1486791663272009736"
    }
  },
  {
    "like" : {
      "tweetId" : "1486470020997726208",
      "fullText" : "@sad_electronics Besonders das Max TDP oder was das auch immer sein mag https://t.co/qlVqeQXrjX",
      "expandedUrl" : "https://twitter.com/i/web/status/1486470020997726208"
    }
  },
  {
    "like" : {
      "tweetId" : "1486442884173901828",
      "fullText" : "Wow.. uv light on the #ShaRPIKeebo RPI pcb. UV light to harden the enclosure ... https://t.co/D4kNtSTtSx",
      "expandedUrl" : "https://twitter.com/i/web/status/1486442884173901828"
    }
  },
  {
    "like" : {
      "tweetId" : "1486666184824999943",
      "fullText" : "Solderboy https://t.co/V7IVNWgAq0",
      "expandedUrl" : "https://twitter.com/i/web/status/1486666184824999943"
    }
  },
  {
    "like" : {
      "tweetId" : "1486707165901504514",
      "fullText" : "@natalie_thenerd Thanks I hate it",
      "expandedUrl" : "https://twitter.com/i/web/status/1486707165901504514"
    }
  },
  {
    "like" : {
      "tweetId" : "1486588123219841027",
      "fullText" : "Building tiny pocket computer/PDA with keyboard featherwing from @solderparty #pocketcomputer https://t.co/EAZQYLJDKn",
      "expandedUrl" : "https://twitter.com/i/web/status/1486588123219841027"
    }
  },
  {
    "like" : {
      "tweetId" : "1486277176089583616",
      "fullText" : "https://t.co/hBAfcPsTIc",
      "expandedUrl" : "https://twitter.com/i/web/status/1486277176089583616"
    }
  },
  {
    "like" : {
      "tweetId" : "1486378424314695685",
      "fullText" : "@kiwapebretech Nose hair remover and laser pointer?",
      "expandedUrl" : "https://twitter.com/i/web/status/1486378424314695685"
    }
  },
  {
    "like" : {
      "tweetId" : "1486306022801264644",
      "fullText" : "Maybe someday the phone will arrive too 😁 https://t.co/88Wsp5B0UK",
      "expandedUrl" : "https://twitter.com/i/web/status/1486306022801264644"
    }
  },
  {
    "like" : {
      "tweetId" : "1486189056845254658",
      "fullText" : "@River___Wang Nice! Good clean nozzle!",
      "expandedUrl" : "https://twitter.com/i/web/status/1486189056845254658"
    }
  },
  {
    "like" : {
      "tweetId" : "1485992395925823493",
      "fullText" : "This is a bit too close https://t.co/oBWVbKZBEu",
      "expandedUrl" : "https://twitter.com/i/web/status/1485992395925823493"
    }
  },
  {
    "like" : {
      "tweetId" : "1485313689129558017",
      "fullText" : "First protoype of the monochrono v2 almost finished. \n\nWhat do you think? 😎 https://t.co/1VfPzKU91g",
      "expandedUrl" : "https://twitter.com/i/web/status/1485313689129558017"
    }
  },
  {
    "like" : {
      "tweetId" : "1485615494971465736",
      "fullText" : ".@RealJamHamster designed another TZXDuino using an Arduino to load ZX Spectrum games, this one with a curved display: https://t.co/oK6Rp4BTgF https://t.co/fdR0mOKLlp",
      "expandedUrl" : "https://twitter.com/i/web/status/1485615494971465736"
    }
  },
  {
    "like" : {
      "tweetId" : "1485659049903333376",
      "expandedUrl" : "https://twitter.com/i/web/status/1485659049903333376"
    }
  },
  {
    "like" : {
      "tweetId" : "1485287482979762176",
      "fullText" : "I love when she leaves me little notes like this ☺️ https://t.co/LGicxZOKN5",
      "expandedUrl" : "https://twitter.com/i/web/status/1485287482979762176"
    }
  },
  {
    "like" : {
      "tweetId" : "1485476094023446528",
      "fullText" : "Vim, the editor. https://t.co/9CwytxptN1",
      "expandedUrl" : "https://twitter.com/i/web/status/1485476094023446528"
    }
  },
  {
    "like" : {
      "tweetId" : "1485505493405732864",
      "fullText" : "MQ-Pro V1.1,  no bugs , ready for mass production \nHow about $19.9 ? https://t.co/u04yT8URQb",
      "expandedUrl" : "https://twitter.com/i/web/status/1485505493405732864"
    }
  },
  {
    "like" : {
      "tweetId" : "1485281161861636104",
      "fullText" : "Sigh Its hard to readjust your printer to get back on the same level as before. https://t.co/sIc8ZYmrA1",
      "expandedUrl" : "https://twitter.com/i/web/status/1485281161861636104"
    }
  },
  {
    "like" : {
      "tweetId" : "1483709371452428288",
      "fullText" : "@bradanlane My favorite CircuitPython moments was giving my friend a silly keyboard I had designed for their birthday, and getting back a video of them showing off their mods to the code. I never told them about the CIRCUITPY drive, and they’d never written Python or MCU code before!",
      "expandedUrl" : "https://twitter.com/i/web/status/1483709371452428288"
    }
  },
  {
    "like" : {
      "tweetId" : "1481548122824208389",
      "fullText" : "おやつ我慢できたらあとで２個あげるね https://t.co/FmmzgiuuuL",
      "expandedUrl" : "https://twitter.com/i/web/status/1481548122824208389"
    }
  },
  {
    "like" : {
      "tweetId" : "1484666563148058626",
      "fullText" : "😭 Darn this IC pinout. https://t.co/EyA4O1oQ3Y",
      "expandedUrl" : "https://twitter.com/i/web/status/1484666563148058626"
    }
  },
  {
    "like" : {
      "tweetId" : "1484573198201290755",
      "fullText" : "大槻唯ちゃん！ https://t.co/H9EuqKTwx9",
      "expandedUrl" : "https://twitter.com/i/web/status/1484573198201290755"
    }
  },
  {
    "like" : {
      "tweetId" : "1484540507749556230",
      "fullText" : "@pojntfx Your nails 💖",
      "expandedUrl" : "https://twitter.com/i/web/status/1484540507749556230"
    }
  },
  {
    "like" : {
      "tweetId" : "1484179027703504900",
      "fullText" : "見てくださいっ！ https://t.co/7yKTwEa3U7",
      "expandedUrl" : "https://twitter.com/i/web/status/1484179027703504900"
    }
  },
  {
    "like" : {
      "tweetId" : "1484370062958280707",
      "fullText" : "高校のときの制服に…着替えたけど… https://t.co/PERoAjXGFi",
      "expandedUrl" : "https://twitter.com/i/web/status/1484370062958280707"
    }
  },
  {
    "like" : {
      "tweetId" : "1484311299941040132",
      "fullText" : "I believe I'm having too much fun, need to end the day here.\n\n_On today's episode of 'Will it RAID?'_ https://t.co/YwH7Tjeopg",
      "expandedUrl" : "https://twitter.com/i/web/status/1484311299941040132"
    }
  },
  {
    "like" : {
      "tweetId" : "1484261499828785155",
      "fullText" : "@jeffeb3 @River___Wang Or put it in the oven at said temp. The molded plastic housing is likely designed for higher temp.",
      "expandedUrl" : "https://twitter.com/i/web/status/1484261499828785155"
    }
  },
  {
    "like" : {
      "tweetId" : "1484164310339395593",
      "fullText" : "@River___Wang Can it still heat itself up? If the plastic gets warm, but not hot, it can come off cleanly (somewhere between 100-120C for PLA). Flush trim cutters are too tools to use to cut off chunks with precision too.",
      "expandedUrl" : "https://twitter.com/i/web/status/1484164310339395593"
    }
  },
  {
    "like" : {
      "tweetId" : "1484266249928409090",
      "fullText" : "@River___Wang @LewisWorkshop @anne_engineer a makeshift shield and A heat gun will likely let you soften and bend/clip away areas.",
      "expandedUrl" : "https://twitter.com/i/web/status/1484266249928409090"
    }
  },
  {
    "like" : {
      "tweetId" : "1483812716519510017",
      "fullText" : "https://t.co/cyaVZhuQ9l",
      "expandedUrl" : "https://twitter.com/i/web/status/1483812716519510017"
    }
  },
  {
    "like" : {
      "tweetId" : "1484225659694202887",
      "fullText" : "‘King to K9…’ https://t.co/vUOK1dKwhj",
      "expandedUrl" : "https://twitter.com/i/web/status/1484225659694202887"
    }
  },
  {
    "like" : {
      "tweetId" : "1484016752413458433",
      "fullText" : "https://t.co/WV9x8dcl83",
      "expandedUrl" : "https://twitter.com/i/web/status/1484016752413458433"
    }
  },
  {
    "like" : {
      "tweetId" : "1483495252430397446",
      "fullText" : "Commuting #digitalart https://t.co/F94qsYoh7H",
      "expandedUrl" : "https://twitter.com/i/web/status/1483495252430397446"
    }
  },
  {
    "like" : {
      "tweetId" : "1484152388286136326",
      "fullText" : "@River___Wang if you have a hot air gun you might be able to pull it out by softening it a little",
      "expandedUrl" : "https://twitter.com/i/web/status/1484152388286136326"
    }
  },
  {
    "like" : {
      "tweetId" : "1484027283820187650",
      "fullText" : "Anyone know if there is any way to rescue this extruder? #3Dprinter https://t.co/PZtMru69Sz",
      "expandedUrl" : "https://twitter.com/i/web/status/1484027283820187650"
    }
  },
  {
    "like" : {
      "tweetId" : "1483952517675372549",
      "fullText" : "Monowheel Mayhem: When Good Gyroscopic Precession Goes Bad https://t.co/1I6ecopguZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1483952517675372549"
    }
  },
  {
    "like" : {
      "tweetId" : "1483952190654156800",
      "fullText" : "TI92 Plus with Amber CRT https://t.co/jIyNe0ydb2",
      "expandedUrl" : "https://twitter.com/i/web/status/1483952190654156800"
    }
  },
  {
    "like" : {
      "tweetId" : "1483912622756016131",
      "fullText" : "Oooh our QT PY ESP32-S3 is up and running! https://t.co/IqTPzplvzj",
      "expandedUrl" : "https://twitter.com/i/web/status/1483912622756016131"
    }
  },
  {
    "like" : {
      "tweetId" : "1483410914921807873",
      "fullText" : "前に描いたディオナちゃん\n#原神 #GenshinImapct #Genshin https://t.co/ovPh1t9ixi",
      "expandedUrl" : "https://twitter.com/i/web/status/1483410914921807873"
    }
  },
  {
    "like" : {
      "tweetId" : "1483482826213593091",
      "fullText" : "🍮 https://t.co/KfoBHhg9Ox",
      "expandedUrl" : "https://twitter.com/i/web/status/1483482826213593091"
    }
  },
  {
    "like" : {
      "tweetId" : "1483790373491134465",
      "fullText" : "制服バーバラちゃん https://t.co/fWk1HWGN12",
      "expandedUrl" : "https://twitter.com/i/web/status/1483790373491134465"
    }
  },
  {
    "like" : {
      "tweetId" : "1483130485874200576",
      "fullText" : ":O https://t.co/TieRfH6hwO",
      "expandedUrl" : "https://twitter.com/i/web/status/1483130485874200576"
    }
  },
  {
    "like" : {
      "tweetId" : "1483618733855760384",
      "fullText" : "somebody call an ambulance... but not for me https://t.co/VsCifIPpSV",
      "expandedUrl" : "https://twitter.com/i/web/status/1483618733855760384"
    }
  },
  {
    "like" : {
      "tweetId" : "1483496458364268546",
      "fullText" : "#Remote Control Stair Climbing Wheelchair.\n#𝐒𝐜𝐢𝐞𝐧𝐜𝐞𝐀𝐧𝐝𝐓𝐞𝐜𝐡𝐧𝐨𝐥𝐨𝐠𝐲 #𝐈𝐧𝐧𝐨𝐯𝐚𝐭𝐢𝐨𝐧𝐅𝐨𝐫𝐄𝐯𝐞𝐫𝐲𝐨𝐧𝐞 https://t.co/6EYt5Ocfy5",
      "expandedUrl" : "https://twitter.com/i/web/status/1483496458364268546"
    }
  },
  {
    "like" : {
      "tweetId" : "1483444389619896328",
      "fullText" : "Received a XIAO BLE from @seeedstudio last night! Worked on getting it driving a Fibonacci64 Nano, using FastLED and/or #CircuitPython. More progress tonight hopefully!\n@NordicTweets #nRF52840 https://t.co/qLcQWfygnn",
      "expandedUrl" : "https://twitter.com/i/web/status/1483444389619896328"
    }
  },
  {
    "like" : {
      "tweetId" : "1483593494388416514",
      "fullText" : "Skebにて 日下氏さん ( @yukkieeeeeen ) に、\n可愛いイラストを描いていただきました！！\n大変ありがとうございますっ！\n家宝にしますっ！✨\n\n#壬生谷静乃 \n#光鴉絵馬 https://t.co/kqixJSvd71",
      "expandedUrl" : "https://twitter.com/i/web/status/1483593494388416514"
    }
  },
  {
    "like" : {
      "tweetId" : "1483415614869757955",
      "fullText" : "仲良しあくび https://t.co/pBsvxixvHE",
      "expandedUrl" : "https://twitter.com/i/web/status/1483415614869757955"
    }
  },
  {
    "like" : {
      "tweetId" : "1483454979017154562",
      "fullText" : "ぼくのお絵描き環境です https://t.co/4LPoEIae6z",
      "expandedUrl" : "https://twitter.com/i/web/status/1483454979017154562"
    }
  },
  {
    "like" : {
      "tweetId" : "1483041550787497984",
      "fullText" : "白いきつねさんラフ(*´ω｀*)\nシロコちゃん https://t.co/IXnyj90kFN",
      "expandedUrl" : "https://twitter.com/i/web/status/1483041550787497984"
    }
  },
  {
    "like" : {
      "tweetId" : "1483122868988911616",
      "fullText" : "An exciting and long-awaited update is coming this week!\n\n🐬➞📦➞✈️ https://t.co/KP4d36PAuT",
      "expandedUrl" : "https://twitter.com/i/web/status/1483122868988911616"
    }
  },
  {
    "like" : {
      "tweetId" : "1481903103096102913",
      "fullText" : "got some esp32 pico modules in and they're smol!\n\nwe got some samples of the esp32 pico v3 02 modules in from @EspressifSystem and they're smaller than we expected! we thought they were the same size as the esp32-s2 mini modules we've been using ... https://t.co/9McQt93TKE",
      "expandedUrl" : "https://twitter.com/i/web/status/1481903103096102913"
    }
  },
  {
    "like" : {
      "tweetId" : "1483024257726648321",
      "fullText" : "ごめんなさい💦再々投稿だけど…目がおかしかったので修正しました…ファボリツ頂いた方々申し訳ありませんm(__)m\n#ほしまちぎゃらりー https://t.co/QvxYgDX7dP",
      "expandedUrl" : "https://twitter.com/i/web/status/1483024257726648321"
    }
  },
  {
    "like" : {
      "tweetId" : "1482638746277199873",
      "fullText" : "あまくち https://t.co/4531AZIA6u",
      "expandedUrl" : "https://twitter.com/i/web/status/1482638746277199873"
    }
  },
  {
    "like" : {
      "tweetId" : "1482609538490458114",
      "fullText" : "🐇 https://t.co/mEGSrCOYtB",
      "expandedUrl" : "https://twitter.com/i/web/status/1482609538490458114"
    }
  },
  {
    "like" : {
      "tweetId" : "1482573281022517250",
      "fullText" : "https://t.co/Q9yTTIUt6s",
      "expandedUrl" : "https://twitter.com/i/web/status/1482573281022517250"
    }
  },
  {
    "like" : {
      "tweetId" : "1482535429459308544",
      "fullText" : "雪国とょう〇ょ https://t.co/3Eq7rm6XLo",
      "expandedUrl" : "https://twitter.com/i/web/status/1482535429459308544"
    }
  },
  {
    "like" : {
      "tweetId" : "1482779945319673856",
      "fullText" : "Alright, I think that's sufficiently terrifying.\n#picotron https://t.co/S5eembv7JV",
      "expandedUrl" : "https://twitter.com/i/web/status/1482779945319673856"
    }
  },
  {
    "like" : {
      "tweetId" : "1482671471801430017",
      "fullText" : "A remarkable underwater RC Enterprise model, obtained from a 1/350 original model kit made by Pola Lights [video: https://t.co/liB4Tm3lsP] https://t.co/sBJQUN3T2c",
      "expandedUrl" : "https://twitter.com/i/web/status/1482671471801430017"
    }
  },
  {
    "like" : {
      "tweetId" : "1482438648645648385",
      "fullText" : "https://t.co/T2TzfY8Ueu",
      "expandedUrl" : "https://twitter.com/i/web/status/1482438648645648385"
    }
  },
  {
    "like" : {
      "tweetId" : "1482649587701927936",
      "fullText" : "パンフレットの記載ミスに気付いた夢見りあむ https://t.co/OpKD67WpT2",
      "expandedUrl" : "https://twitter.com/i/web/status/1482649587701927936"
    }
  },
  {
    "like" : {
      "tweetId" : "1482475853216952320",
      "expandedUrl" : "https://twitter.com/i/web/status/1482475853216952320"
    }
  },
  {
    "like" : {
      "tweetId" : "1482210822160289793",
      "fullText" : "幼なじみ特有の距離感\n動物園のおみやげ https://t.co/1VbDh1rdBf",
      "expandedUrl" : "https://twitter.com/i/web/status/1482210822160289793"
    }
  },
  {
    "like" : {
      "tweetId" : "1482300659563171847",
      "fullText" : "どっちがほんとのフグかわかるれすか～？ https://t.co/8tNnBBZfJl",
      "expandedUrl" : "https://twitter.com/i/web/status/1482300659563171847"
    }
  },
  {
    "like" : {
      "tweetId" : "1482023651612532738",
      "fullText" : "And the GitHub Contributor of the Year award goes to... 🏆💥 https://t.co/AHv1cyHhGB",
      "expandedUrl" : "https://twitter.com/i/web/status/1482023651612532738"
    }
  },
  {
    "like" : {
      "tweetId" : "1482284007278931968",
      "fullText" : "🎂\n#秋山澪生誕祭2022 https://t.co/GteAQK8oNt",
      "expandedUrl" : "https://twitter.com/i/web/status/1482284007278931968"
    }
  },
  {
    "like" : {
      "tweetId" : "1482421073123676163",
      "fullText" : "Guess I should have added podcast to my #Circuitpython2022 goals. @circuitpyshow https://t.co/teDmczfpS4",
      "expandedUrl" : "https://twitter.com/i/web/status/1482421073123676163"
    }
  },
  {
    "like" : {
      "tweetId" : "1481601505342160901",
      "fullText" : "とらドラ！15周年おめでとうございます😊 https://t.co/XgyYbmuQyF",
      "expandedUrl" : "https://twitter.com/i/web/status/1481601505342160901"
    }
  },
  {
    "like" : {
      "tweetId" : "1481631981658316804",
      "fullText" : "#ヌォンタート https://t.co/X7khWiPB5r",
      "expandedUrl" : "https://twitter.com/i/web/status/1481631981658316804"
    }
  },
  {
    "like" : {
      "tweetId" : "1482098249913802764",
      "fullText" : "My version of the Guardian blade ! 3D model by @adafruit, handle was modified by me with a PVC pipe so it can hide a phone external battery #TheLegendOfZelda #breathofthewild #cosplay https://t.co/4D2OVuUtJB",
      "expandedUrl" : "https://twitter.com/i/web/status/1482098249913802764"
    }
  },
  {
    "like" : {
      "tweetId" : "1482369134889476100",
      "fullText" : "【CircuitPython IDE】A new Cpy library that does line-by-line debugging #CircuitPython\nhttps://t.co/e6G3MlxAW6",
      "expandedUrl" : "https://twitter.com/i/web/status/1482369134889476100"
    }
  },
  {
    "like" : {
      "tweetId" : "1481714477129207813",
      "fullText" : "High-speed Color Projector “DynaFlash v2” uses dynamic color projection and it allows you to do things like these [full video by Ishikawa Group Laboratory: https://t.co/HOynbMSoW0] https://t.co/Cy9wLQsycC",
      "expandedUrl" : "https://twitter.com/i/web/status/1481714477129207813"
    }
  },
  {
    "like" : {
      "tweetId" : "1481278149782560771",
      "fullText" : "New blog post:  Introducing The CircuitPython Show podcast - https://t.co/WIc7jUiU07",
      "expandedUrl" : "https://twitter.com/i/web/status/1481278149782560771"
    }
  },
  {
    "like" : {
      "tweetId" : "1481796806421929984",
      "fullText" : "What's just one step above @CursedFootprint ? https://t.co/6Nlj7IFXww",
      "expandedUrl" : "https://twitter.com/i/web/status/1481796806421929984"
    }
  },
  {
    "like" : {
      "tweetId" : "1481727201066483712",
      "fullText" : "日記です https://t.co/0ZFnsbcgA7",
      "expandedUrl" : "https://twitter.com/i/web/status/1481727201066483712"
    }
  },
  {
    "like" : {
      "tweetId" : "1481732348827811840",
      "fullText" : "You may be familiar with the boards that are compatible with #CircuitPython on https://t.co/D6VYRP1uMD\n\nThere is also a similar list of #MicroPython compatible boards at https://t.co/kRzMRRFzVo https://t.co/UoYFgOmDOu",
      "expandedUrl" : "https://twitter.com/i/web/status/1481732348827811840"
    }
  },
  {
    "like" : {
      "tweetId" : "1481412302637346817",
      "fullText" : "#MaxCoolBeans: Meet and Greet the Seeed XIAO BLE Sense https://t.co/YwpB4cWY3C In addition to sporting a powerful processor and supporting Bluetooth wireless communications, the XIAO BLE Sense also boasts a microphone and a 6DOF IMU. @seeedstudio @eetimes @EDNcom @DesignNews https://t.co/3vqghhMa0I",
      "expandedUrl" : "https://twitter.com/i/web/status/1481412302637346817"
    }
  },
  {
    "like" : {
      "tweetId" : "1481420321047592962",
      "fullText" : "So excited. With the new quality soldering station. I was able to solder the Sharpikeebo computer. Tomorow will be the tests day.. @anne_engineer @morpheans @adafruit @BeBoXoS @fast_code_r_us @Hacksterio @Kongduino @Raspberry_Pi @Taki_____ @TaroKichijo @groguard @mikerankin https://t.co/cp3wZLOAsF",
      "expandedUrl" : "https://twitter.com/i/web/status/1481420321047592962"
    }
  },
  {
    "like" : {
      "tweetId" : "1481353070411923456",
      "fullText" : "Controlling NeoPixels with asyncio in CircuitPython @circuitpython https://t.co/hy4FXbNLgB",
      "expandedUrl" : "https://twitter.com/i/web/status/1481353070411923456"
    }
  },
  {
    "like" : {
      "tweetId" : "1481267947838615557",
      "fullText" : "Exploding CAD, my thing 💥 https://t.co/Oax9MmZOyA",
      "expandedUrl" : "https://twitter.com/i/web/status/1481267947838615557"
    }
  },
  {
    "like" : {
      "tweetId" : "1481272043765125126",
      "fullText" : "this is what happens when someone successfully goes outside and touches grass https://t.co/sgHenvqMAt",
      "expandedUrl" : "https://twitter.com/i/web/status/1481272043765125126"
    }
  },
  {
    "like" : {
      "tweetId" : "1481299326244724745",
      "fullText" : "CAD chat in #Fusion360 #3DHangouts -  https://t.co/xFSZS8Qq2Y #3DPrinting https://t.co/iw0nMqPZfT",
      "expandedUrl" : "https://twitter.com/i/web/status/1481299326244724745"
    }
  },
  {
    "like" : {
      "tweetId" : "1481169014873538561",
      "fullText" : "https://t.co/YfE4A96744",
      "expandedUrl" : "https://twitter.com/i/web/status/1481169014873538561"
    }
  },
  {
    "like" : {
      "tweetId" : "1481108390201937921",
      "fullText" : "this gaming pcb is just so smol! we routed out this gamer bff for qt py boards. routing is just so much fun! this board is just 1.5\"x2\" but we got the head phone jack and amp in there. the battery situation is still in flux, and we stuck a 1.69\" TFT footprint on the top in case https://t.co/Zxt5xHCaEg",
      "expandedUrl" : "https://twitter.com/i/web/status/1481108390201937921"
    }
  },
  {
    "like" : {
      "tweetId" : "1481092013034409986",
      "fullText" : "The name!  😂  So great. https://t.co/crpttU53iU",
      "expandedUrl" : "https://twitter.com/i/web/status/1481092013034409986"
    }
  },
  {
    "like" : {
      "tweetId" : "1481088737866129414",
      "fullText" : "also LOL, I am bad at marketing. The link, if you want to join the club: https://t.co/dXsVVcJbkX",
      "expandedUrl" : "https://twitter.com/i/web/status/1481088737866129414"
    }
  },
  {
    "like" : {
      "tweetId" : "1480880406228619265",
      "fullText" : "Tune in tomorrow! We'll be posting up the @Logitech Cyberman ! (1997) https://t.co/NC07p4XYBR https://t.co/2WujQBWrKx",
      "expandedUrl" : "https://twitter.com/i/web/status/1480880406228619265"
    }
  },
  {
    "like" : {
      "tweetId" : "1480955435817607171",
      "fullText" : "Gamer BFF - QT Py mini gaming add-on\n\nfrom ladyada - girls only want one thing - and thats a tiny lil console game emulator. this 'gamer bff' is something a QT Py can plug into - and provides a 1.3\" 240x240 TFT, 10 buttons, micro SD card, on/off switch and lipo charger. https://t.co/jJ1SeWI0RI",
      "expandedUrl" : "https://twitter.com/i/web/status/1480955435817607171"
    }
  },
  {
    "like" : {
      "tweetId" : "1480630941005467650",
      "fullText" : "@femtoduino It's a problem in the US. Not the tech industry per se.",
      "expandedUrl" : "https://twitter.com/i/web/status/1480630941005467650"
    }
  },
  {
    "like" : {
      "tweetId" : "1480615437847220228",
      "fullText" : "WiFi Game Boy Cartridge https://t.co/CJGrmSPien",
      "expandedUrl" : "https://twitter.com/i/web/status/1480615437847220228"
    }
  },
  {
    "like" : {
      "tweetId" : "1479904441608380420",
      "fullText" : "How we used to do HTML table rounded corners in the 90s https://t.co/AotP7SztSI",
      "expandedUrl" : "https://twitter.com/i/web/status/1479904441608380420"
    }
  },
  {
    "like" : {
      "tweetId" : "1480431062547263494",
      "fullText" : "#That’s the jacked I need - anyone else?\n#𝐒𝐜𝐢𝐞𝐧𝐜𝐞𝐀𝐧𝐝𝐓𝐞𝐜𝐡𝐧𝐨𝐥𝐨𝐠𝐲 #𝐈𝐧𝐧𝐨𝐯𝐚𝐭𝐢𝐨𝐧𝐅𝐨𝐫𝐄𝐯𝐞𝐫𝐲𝐨𝐧𝐞 https://t.co/oBpcfoit1y",
      "expandedUrl" : "https://twitter.com/i/web/status/1480431062547263494"
    }
  },
  {
    "like" : {
      "tweetId" : "1480542862580273158",
      "fullText" : "girthy boy https://t.co/sFwshSqTGv",
      "expandedUrl" : "https://twitter.com/i/web/status/1480542862580273158"
    }
  },
  {
    "like" : {
      "tweetId" : "1480281213696806915",
      "fullText" : "The Palmtex Super Micro is a very interesting cart-based handheld released in 1983. Over time, most of the carts have disintegrated over time, making their displays illegible and blackened. I have found a way to restore the games back to their original, clean state (1/3) https://t.co/YM7EkgOqaY",
      "expandedUrl" : "https://twitter.com/i/web/status/1480281213696806915"
    }
  },
  {
    "like" : {
      "tweetId" : "1480507949529378817",
      "fullText" : "Every pupil, student should own this: a ruler 😜 to check the airquality in their classroom! We support QT PY (ESP32/RP2040) plus SCD4x and BME68x on board … ton of NeoPixels and QWIIC for extensions: sensors, displays etc #CO2covid #AirQuality @adafruit @BoschMEMS @sensirion https://t.co/8R9haGmpZo",
      "expandedUrl" : "https://twitter.com/i/web/status/1480507949529378817"
    }
  },
  {
    "like" : {
      "tweetId" : "1480509835171016710",
      "fullText" : "This tiny keyboard PCB is designed to mount to the back of the Pi Pico microcontroller. https://t.co/Zu5gSYKKB3",
      "expandedUrl" : "https://twitter.com/i/web/status/1480509835171016710"
    }
  },
  {
    "like" : {
      "tweetId" : "1480192771986178053",
      "fullText" : "Portable PI Powered Music Player https://t.co/5aBGcP6lB8",
      "expandedUrl" : "https://twitter.com/i/web/status/1480192771986178053"
    }
  },
  {
    "like" : {
      "tweetId" : "1480258552564436997",
      "fullText" : "New design pattern just dropped https://t.co/PhJ3lLK1Pf",
      "expandedUrl" : "https://twitter.com/i/web/status/1480258552564436997"
    }
  },
  {
    "like" : {
      "tweetId" : "1479235489223913482",
      "fullText" : "QT Py Bluefruit Routin' Party\n\nNow we've got the QT Py SAMD21, RP2040 and ESP32-S2 designed and fabricated, we're going to follow up with an NRF52840 version! We've been using the @nordictweets  nRF series for a loooooong time (anyone else remember the nRF8001? https://t.co/vr7dBVg2tF",
      "expandedUrl" : "https://twitter.com/i/web/status/1479235489223913482"
    }
  },
  {
    "like" : {
      "tweetId" : "1480165547996291076",
      "fullText" : "@adafruit @Google Is this just for information or are you trying to tell me something? Just wondering that's all. It's the \"not supported after May 2013\" that has me wondering. TIA",
      "expandedUrl" : "https://twitter.com/i/web/status/1480165547996291076"
    }
  },
  {
    "like" : {
      "tweetId" : "1479524161311678467",
      "fullText" : "Blog Post Alert!\n\nAfter being frustrated with spreadsheets, I \"somewhat\" overengineered my coffee bean inventory and storage system. Including its own custom web-app, storage canisters from Fellow, and MagTags from @adafruit to label them!\n\nhttps://t.co/i8CfjXEJzB https://t.co/xMWpVL68Vm",
      "expandedUrl" : "https://twitter.com/i/web/status/1479524161311678467"
    }
  },
  {
    "like" : {
      "tweetId" : "1479397270114430993",
      "fullText" : "Very happy with the @JLCPCB 3D Printed Cartridge Case.   Very good finish and fit for the #C64 Kung Fu Flash Cartridge.  Will need to paint it now. https://t.co/bnKzdOgJrb",
      "expandedUrl" : "https://twitter.com/i/web/status/1479397270114430993"
    }
  },
  {
    "like" : {
      "tweetId" : "1479496167851536396",
      "fullText" : ".@gallaugher - have you tried this editor? https://t.co/YGKQyHvmDP",
      "expandedUrl" : "https://twitter.com/i/web/status/1479496167851536396"
    }
  },
  {
    "like" : {
      "tweetId" : "1478746719215046659",
      "fullText" : "Pcb are here ... https://t.co/2RNhPHjejI",
      "expandedUrl" : "https://twitter.com/i/web/status/1478746719215046659"
    }
  },
  {
    "like" : {
      "tweetId" : "1478927707308113923",
      "fullText" : "Super fun #soldersesh tonight, thanks to everyone for joining!  We had a great time rehashing the last year, and even had time for a quick SR-71 kit by Phyx on @tindie . https://t.co/rDT7mha9vi",
      "expandedUrl" : "https://twitter.com/i/web/status/1478927707308113923"
    }
  },
  {
    "like" : {
      "tweetId" : "1478811354043666442",
      "fullText" : "Forget cutting up flimsy USB cables to power your solderless breadboards. https://t.co/s9mH337aQC",
      "expandedUrl" : "https://twitter.com/i/web/status/1478811354043666442"
    }
  },
  {
    "like" : {
      "tweetId" : "1478680958522044421",
      "fullText" : "Neatly neatly, tucky tucky.\n\nHere’s how to build a digital cartridge, using Raspberry Pi Zero W, that can slot into almost any of the old Super 8mm cameras...\n\nhttps://t.co/w1B6mePlRB https://t.co/nLV6ox2Fh3",
      "expandedUrl" : "https://twitter.com/i/web/status/1478680958522044421"
    }
  },
  {
    "like" : {
      "tweetId" : "1479000041440399364",
      "fullText" : "Auto Solder Feeder #3DThursday #3DPrinting https://t.co/YMxAOI5SyV",
      "expandedUrl" : "https://twitter.com/i/web/status/1479000041440399364"
    }
  },
  {
    "like" : {
      "tweetId" : "1478043946920124419",
      "fullText" : "Me: posting memes about running DRC\nAlso me: https://t.co/v6Ycj8HNV4",
      "expandedUrl" : "https://twitter.com/i/web/status/1478043946920124419"
    }
  },
  {
    "like" : {
      "tweetId" : "1477633104928178176",
      "fullText" : "スケッチからイラストをリアルタイムで自動生成する実験をしています。\nこれまで全く絵を描いたことがない人でも、それなりのクオリティのイラストを短時間で描けるようになればいいなと考えています。\n次はパラメータスライダーを追加して、描いた後に画風や形状を変更できるようにする予定です。 https://t.co/NgE2xFhzsh",
      "expandedUrl" : "https://twitter.com/i/web/status/1477633104928178176"
    }
  },
  {
    "like" : {
      "tweetId" : "1478142617070489601",
      "fullText" : "STEAM Tokyoストア商品紹介36\nMACROPAD RP2040ケース\n¥900\n\nAdafruit MACROPAD RP2040スターターキットに含まれているものと同じケースの単品販売です。MACROPAD RP2040ベアボーンとご一緒にいかがでしょう？\nhttps://t.co/Pbe3NuBZ6K",
      "expandedUrl" : "https://twitter.com/i/web/status/1478142617070489601"
    }
  },
  {
    "like" : {
      "tweetId" : "1478228697182318592",
      "fullText" : "How to build your own small⌚️Pip-Boy with Feather #RP2040 and #CircuitPython. 😍👏👍\n\n#RaspberryPi #Coding #DIY #arduino #IoT\n\nKnow More - https://t.co/Uckn5BDvdB https://t.co/9ruBkyr2cI",
      "expandedUrl" : "https://twitter.com/i/web/status/1478228697182318592"
    }
  },
  {
    "like" : {
      "tweetId" : "1478283521475104768",
      "fullText" : "Released the open-smartwatch a year ago. Get it on https://t.co/kYYVSMx1J1\n\n@MakerfabsTech \n\n(The current Monochrono will take some time to finish) https://t.co/lUQEf2DV9m",
      "expandedUrl" : "https://twitter.com/i/web/status/1478283521475104768"
    }
  },
  {
    "like" : {
      "tweetId" : "1478414203211894789",
      "fullText" : "More fun with edge lit acrylic. I’m prototyping a zoetrope using a dc motor and 3d printed gears. There’s a neopixel led mounted inside the turntable. I engraved ten panels of the infamous party parrot GIF🦜 https://t.co/8Ajs59OHVI",
      "expandedUrl" : "https://twitter.com/i/web/status/1478414203211894789"
    }
  },
  {
    "like" : {
      "tweetId" : "1478403398202368000",
      "fullText" : "@LIV2 Did you have them labelled as \"Almost Ground\"?",
      "expandedUrl" : "https://twitter.com/i/web/status/1478403398202368000"
    }
  },
  {
    "like" : {
      "tweetId" : "1478109038831415298",
      "fullText" : "Homemade Scrapyard Security Mech Gives Uncle Super Powers https://t.co/E6c8Tm2200",
      "expandedUrl" : "https://twitter.com/i/web/status/1478109038831415298"
    }
  },
  {
    "like" : {
      "tweetId" : "1478021984307249153",
      "fullText" : "@River___Wang I tried it. I always use fire fox, but it dose not work.\nThen, I tried MS Edge. I connected the board, opened and edited the source file,then saved and run it. I didn't refer any help. So,it is easy to use, and very nice. https://t.co/kVGXB9W9hB",
      "expandedUrl" : "https://twitter.com/i/web/status/1478021984307249153"
    }
  },
  {
    "like" : {
      "tweetId" : "1582804261330558976",
      "fullText" : "@River___Wang Hopefully will end up being a three phase motor.",
      "expandedUrl" : "https://twitter.com/i/web/status/1582804261330558976"
    }
  },
  {
    "like" : {
      "tweetId" : "1582717227328892928",
      "fullText" : "This may actually work! https://t.co/fgVKLBYsDW",
      "expandedUrl" : "https://twitter.com/i/web/status/1582717227328892928"
    }
  },
  {
    "like" : {
      "tweetId" : "1582716467425878016",
      "fullText" : "Elina+先生の絵目当てに初めて池袋PARCO行きました✨\n実際に見てみるととても丁寧に描かれていて素敵でした🥳\n#Emotions183 https://t.co/2HRRc4jchq",
      "expandedUrl" : "https://twitter.com/i/web/status/1582716467425878016"
    }
  },
  {
    "like" : {
      "tweetId" : "1582604636812242945",
      "fullText" : "Building a split ortho keyboard that runs CircuitPython, @adafruit Learn Guide in the works. https://t.co/wYgpVUzxwI",
      "expandedUrl" : "https://twitter.com/i/web/status/1582604636812242945"
    }
  },
  {
    "like" : {
      "tweetId" : "1582741350230786048",
      "fullText" : "ICYMI Python on Microcontrollers Newsletter: Ladyada at Espressif DevCon this week, CircuitPython 8 beta 2 and more! #CircuitPython #ICYMI #RaspberryPi micropython Raspberry_Pi  https://t.co/8bY0ULSkPw",
      "expandedUrl" : "https://twitter.com/i/web/status/1582741350230786048"
    }
  },
  {
    "like" : {
      "tweetId" : "1582495094518603776",
      "fullText" : "Reposted from @sweeney2400 Few pictures I forgot to post from last weekends @phillymakerfaire with an awesome retro Printrbot box run on a battery, and my new friends @itsinventable showing off their awesome prototypes🤖⚙️🪚\n#printrbot #phillymakerfair… https://t.co/d7tXNtCuFP https://t.co/jrfcRTFoZ7",
      "expandedUrl" : "https://twitter.com/i/web/status/1582495094518603776"
    }
  },
  {
    "like" : {
      "tweetId" : "1581135411555880960",
      "fullText" : "SAVE THE DATE!\n\nOctober 6-8 2023\n\nThe Greatest Show and Tell On Earth comes back to NYC! https://t.co/wkEIZKXlPy",
      "expandedUrl" : "https://twitter.com/i/web/status/1581135411555880960"
    }
  },
  {
    "like" : {
      "tweetId" : "1582379527627735041",
      "fullText" : "@GreatScottLab Liquid cooling 🥶",
      "expandedUrl" : "https://twitter.com/i/web/status/1582379527627735041"
    }
  },
  {
    "like" : {
      "tweetId" : "1582102872468389888",
      "fullText" : "https://t.co/hcLNL0GJid",
      "expandedUrl" : "https://twitter.com/i/web/status/1582102872468389888"
    }
  },
  {
    "like" : {
      "tweetId" : "1582104540165595136",
      "fullText" : "Nice! https://t.co/BkVORlJArw",
      "expandedUrl" : "https://twitter.com/i/web/status/1582104540165595136"
    }
  },
  {
    "like" : {
      "tweetId" : "1582078728695205888",
      "fullText" : "RECORD RUNNER - “Reverse engineering leads to “Chorocco” (1976) https://t.co/KvhQ3ofjjG https://t.co/a5MC9ISMai",
      "expandedUrl" : "https://twitter.com/i/web/status/1582078728695205888"
    }
  },
  {
    "like" : {
      "tweetId" : "1581905548395413505",
      "fullText" : "@engineers_feed https://t.co/IpMoGM1RrY",
      "expandedUrl" : "https://twitter.com/i/web/status/1581905548395413505"
    }
  },
  {
    "like" : {
      "tweetId" : "1581880718757543936",
      "fullText" : "@engineers_feed All paths from a to g pass through 3 resistors, in 3 “layers”, consisting of:\n\nLayer 1 (edges to corner A) is 3 resist in parallel, so =r/3\nLayer 2 (intermediate) is 6 resist in parallel, =r/6\nLayer 3 (edged to corner g) is identical to layer 1, so r/3\n\nSum of layers 1,2,3 = 5r/6",
      "expandedUrl" : "https://twitter.com/i/web/status/1581880718757543936"
    }
  },
  {
    "like" : {
      "tweetId" : "1582001246407647233",
      "fullText" : "Spooky Python on Hardware: subscribe to the newsletter now #CircuitPython #Python @micropython @ThePSF https://t.co/aFnDyWIe2Q",
      "expandedUrl" : "https://twitter.com/i/web/status/1582001246407647233"
    }
  },
  {
    "like" : {
      "tweetId" : "1581093132715728896",
      "fullText" : "Raspberry Pi Pico WとCircuitPython8の組み合わせはコスパ最強だな。WebAPIを叩くコードがかなり自然。技適の状況が気になるな。 https://t.co/IZTFoIuvll",
      "expandedUrl" : "https://twitter.com/i/web/status/1581093132715728896"
    }
  },
  {
    "like" : {
      "tweetId" : "1581705082973786112",
      "fullText" : "Kirigami (切り紙) is a variation of origami, where the paper is cut as well as being folded\n\nThis paper investigates the creation of shape-morphing material structure with Kirigami &amp; this is how you square the circle\n\n[full paper: https://t.co/Q8KBscAc66]\nhttps://t.co/TBUPDyZDc4",
      "expandedUrl" : "https://twitter.com/i/web/status/1581705082973786112"
    }
  },
  {
    "like" : {
      "tweetId" : "1581840016955052032",
      "fullText" : "フォローして頂けて嬉しかったので、ファンアート描きました🚀\n\n#さよならポニーテール https://t.co/fcxO8gsCH7",
      "expandedUrl" : "https://twitter.com/i/web/status/1581840016955052032"
    }
  },
  {
    "like" : {
      "tweetId" : "1581217004446699521",
      "fullText" : "A 95% built prototype v2. ~50% thinner than v1 / v1.5. Still awaiting a couple more parts for a complete test and I want to make a couple of minor changes. But it works 🙂 https://t.co/DIMFYqmVQg",
      "expandedUrl" : "https://twitter.com/i/web/status/1581217004446699521"
    }
  },
  {
    "like" : {
      "tweetId" : "1581727489344163840",
      "fullText" : "https://t.co/IRf3tjKkrT",
      "expandedUrl" : "https://twitter.com/i/web/status/1581727489344163840"
    }
  },
  {
    "like" : {
      "tweetId" : "1581673285276033024",
      "fullText" : "これで誰を描いてるか分かったらすごい https://t.co/mmDFZFDLWk",
      "expandedUrl" : "https://twitter.com/i/web/status/1581673285276033024"
    }
  },
  {
    "like" : {
      "tweetId" : "1581611032375484416",
      "fullText" : "三船美優さん26歳 https://t.co/NPLtn6O4xD",
      "expandedUrl" : "https://twitter.com/i/web/status/1581611032375484416"
    }
  },
  {
    "like" : {
      "tweetId" : "1580219325226835968",
      "fullText" : "I'm gathering stories and projects for the next #Python on Microcontrollers newsletter coming next week. Do you have something to share? Send them to cpnews (at) adafruit (dot) com or tag #CircuitPython (even if about #MicroPython or #RaspberryPi / Single Board Computers). https://t.co/r9HkSHGVqa",
      "expandedUrl" : "https://twitter.com/i/web/status/1580219325226835968"
    }
  },
  {
    "like" : {
      "tweetId" : "1581322479485607936",
      "fullText" : "I've been told by my sister that this cat likes laser pointers so I am going to build him a little laser turret to keep him entertained (hopefully) https://t.co/2RNclZmp4u",
      "expandedUrl" : "https://twitter.com/i/web/status/1581322479485607936"
    }
  },
  {
    "like" : {
      "tweetId" : "1581389479066992640",
      "fullText" : "Most of us have been there https://t.co/bbEhKt9isu https://t.co/jSwnbd7OkE",
      "expandedUrl" : "https://twitter.com/i/web/status/1581389479066992640"
    }
  },
  {
    "like" : {
      "tweetId" : "1581331078073417729",
      "fullText" : "We're at the #phillymakerfaire today until 5pm!\n\nCome check it out at the Independence Seaport Museum!\n\n@phlmake @epochboats @phillyseaport https://t.co/gi5JOteIRD",
      "expandedUrl" : "https://twitter.com/i/web/status/1581331078073417729"
    }
  },
  {
    "like" : {
      "tweetId" : "1478005140833865728",
      "fullText" : "@River___Wang It's interesting.I will try it.",
      "expandedUrl" : "https://twitter.com/i/web/status/1478005140833865728"
    }
  },
  {
    "like" : {
      "tweetId" : "1477651182525227011",
      "fullText" : "12月に秋月に行ったときについでに買った Cytron Maker Pi RP2040 を試してみた。すごくいいと思った。\n・安い(秋月で1240円）\n・エディタのみで開発できる。（CircuitPython)\n・DCモータ2台、サーボ4台制御できる。\n・電源スイッチ付きで便利\n・USBシリアル通信でデバッグが楽 https://t.co/kAlCMC6AJ8",
      "expandedUrl" : "https://twitter.com/i/web/status/1477651182525227011"
    }
  },
  {
    "like" : {
      "tweetId" : "1430198690883411969",
      "fullText" : "Minimum viable @EspressifSystem ESP32-C3! Yes, it's running code, programming and console is through the built-in USB, powered by LiFePO4. 😁 #ESP32 #IoT @ESP32net @esp32com #MVP https://t.co/mSXCczyICZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1430198690883411969"
    }
  },
  {
    "like" : {
      "tweetId" : "1439202877893791746",
      "fullText" : "4 custom function OLED Keys on Sipeed Opensource Mechanical Keyboard~ https://t.co/zJSBnHVA66",
      "expandedUrl" : "https://twitter.com/i/web/status/1439202877893791746"
    }
  },
  {
    "like" : {
      "tweetId" : "1477608862832340992",
      "fullText" : "にゃんにゃんにゃん（2022）！今年もよろしくお願いします！✨🎍✨ https://t.co/BBXuQT2GxJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1477608862832340992"
    }
  },
  {
    "like" : {
      "tweetId" : "1477567467811909632",
      "fullText" : "ゆき https://t.co/wdYIvMlRG8",
      "expandedUrl" : "https://twitter.com/i/web/status/1477567467811909632"
    }
  },
  {
    "like" : {
      "tweetId" : "1477025496441540611",
      "fullText" : "We need more digital fireworks! https://t.co/awWb12Nrx4",
      "expandedUrl" : "https://twitter.com/i/web/status/1477025496441540611"
    }
  },
  {
    "like" : {
      "tweetId" : "1477480817085530114",
      "fullText" : "click ... click ... click ... that is the sound of a @Raspberry_Pi Pico RP2040 controlling read/write/imaging a floppy! postin' longer vid, post, and more in a bit! 🐇 💾 🌈 https://t.co/ZhmbTGovtA",
      "expandedUrl" : "https://twitter.com/i/web/status/1477480817085530114"
    }
  },
  {
    "like" : {
      "tweetId" : "1477492636487454720",
      "fullText" : "【CircuitPython IDE】Introduction to CircuitPython Online IDE #CircuitPython https://t.co/1ItIPwHRNX",
      "expandedUrl" : "https://twitter.com/i/web/status/1477492636487454720"
    }
  },
  {
    "like" : {
      "tweetId" : "1476803069727834113",
      "expandedUrl" : "https://twitter.com/i/web/status/1476803069727834113"
    }
  },
  {
    "like" : {
      "tweetId" : "1477293751265599494",
      "fullText" : "The BlackBerry is officially dead; may its keyboard live on in hacker's hearts. https://t.co/8r5AdPHdaX",
      "expandedUrl" : "https://twitter.com/i/web/status/1477293751265599494"
    }
  },
  {
    "like" : {
      "tweetId" : "1477142554235838464",
      "fullText" : "Happy New Year: 2022 https://t.co/jcQT4LspX7",
      "expandedUrl" : "https://twitter.com/i/web/status/1477142554235838464"
    }
  },
  {
    "like" : {
      "tweetId" : "1477141204546510850",
      "fullText" : "Happy New Year!🥳🥳\nI am glad to announce that CircuitPython Online IDE is now based on the Ace editor. You will find it much nicer and easier to use. Enjoy Coding! #CircuitPython https://t.co/MbMYEkP3R6",
      "expandedUrl" : "https://twitter.com/i/web/status/1477141204546510850"
    }
  },
  {
    "like" : {
      "tweetId" : "1476762251889876994",
      "fullText" : "20211231「お大事に」 https://t.co/4DKGdzGqst",
      "expandedUrl" : "https://twitter.com/i/web/status/1476762251889876994"
    }
  },
  {
    "like" : {
      "tweetId" : "1476931914393337856",
      "fullText" : "Happy New Year !!\nWishing you a happy new year✨ https://t.co/RqlUbPdbev",
      "expandedUrl" : "https://twitter.com/i/web/status/1476931914393337856"
    }
  },
  {
    "like" : {
      "tweetId" : "1476932556046024707",
      "fullText" : "2🐯22 https://t.co/U1FmGrCHMk",
      "expandedUrl" : "https://twitter.com/i/web/status/1476932556046024707"
    }
  },
  {
    "like" : {
      "tweetId" : "1476931323084247049",
      "fullText" : "おめ🌞 https://t.co/FiFccO8vwY",
      "expandedUrl" : "https://twitter.com/i/web/status/1476931323084247049"
    }
  },
  {
    "like" : {
      "tweetId" : "1476942204128346112",
      "fullText" : "あけましておめみおーん\n#みおーん絵 https://t.co/pxH1MUs5Id",
      "expandedUrl" : "https://twitter.com/i/web/status/1476942204128346112"
    }
  },
  {
    "like" : {
      "tweetId" : "1476701054066737154",
      "fullText" : "For the french speakers. #s3lamandra_watch . @Esp32S2 @EspressifSystem #circuitpython #opensourge #pearfree #metaversefree #dontbeevilfree #amzfree https://t.co/z002uzrDLu",
      "expandedUrl" : "https://twitter.com/i/web/status/1476701054066737154"
    }
  },
  {
    "like" : {
      "tweetId" : "1476699619337908226",
      "fullText" : "https://t.co/6PAkly335H",
      "expandedUrl" : "https://twitter.com/i/web/status/1476699619337908226"
    }
  },
  {
    "like" : {
      "tweetId" : "1476118135283798021",
      "fullText" : "今日から年末休みです。seeeduino XIAO RP2040を入手しました。このサイズでCortex M0+, クロック113MHz, 2MBフラッシュ搭載。CircuitPythonやMicroPythonでなんか作ってみます。 https://t.co/f6vROo4J13",
      "expandedUrl" : "https://twitter.com/i/web/status/1476118135283798021"
    }
  },
  {
    "like" : {
      "tweetId" : "1476390099625680899",
      "fullText" : "I started rewriting CircuitPython Online IDE based on Ace editor, which will be much nicer than the current version. I should have listened to @tannewt and abandoned CodeMirrow 5 earlier. https://t.co/OuTeMQUmvJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1476390099625680899"
    }
  },
  {
    "like" : {
      "tweetId" : "1395550114777817091",
      "fullText" : "@arturo182 https://t.co/q3O4a1xWvN",
      "expandedUrl" : "https://twitter.com/i/web/status/1395550114777817091"
    }
  },
  {
    "like" : {
      "tweetId" : "1475897217496104966",
      "fullText" : "【CircuitPython DIY】Bounce Ball: Can't resist writing a tiny game in the mid of a DIY project. The full project vlog is coming. No, it's not a handheld console.\n #CircuitPython https://t.co/WvtdLoOeXr",
      "expandedUrl" : "https://twitter.com/i/web/status/1475897217496104966"
    }
  },
  {
    "like" : {
      "tweetId" : "1475254821858988036",
      "fullText" : "Sex on a stick. It’s a pumpkintosh! Built on my most recent livestream! https://t.co/VBffmPCynP",
      "expandedUrl" : "https://twitter.com/i/web/status/1475254821858988036"
    }
  },
  {
    "like" : {
      "tweetId" : "1475501236657045518",
      "fullText" : "The world’s first cloud-controlled Etch-a-Sketch #Huzzah https://t.co/8KwgyeBxcp",
      "expandedUrl" : "https://twitter.com/i/web/status/1475501236657045518"
    }
  },
  {
    "like" : {
      "tweetId" : "1473398355841716229",
      "fullText" : "I've joined the #Raspberrypi controlled addressable RGB LEDs club: https://t.co/m3crHQuUzA",
      "expandedUrl" : "https://twitter.com/i/web/status/1473398355841716229"
    }
  },
  {
    "like" : {
      "tweetId" : "1474401021749338133",
      "fullText" : "【CircuitPython 入门】02 点灯：用Python的“交互式编程”开发单片机程序，一边探索一边开发。Blink: REPL assisted Script development #CircuitPython https://t.co/Ie3x4jaWPA",
      "expandedUrl" : "https://twitter.com/i/web/status/1474401021749338133"
    }
  },
  {
    "like" : {
      "tweetId" : "1473399611322732549",
      "fullText" : "@River___Wang Luckily I have infinite amount of Stamps ;)",
      "expandedUrl" : "https://twitter.com/i/web/status/1473399611322732549"
    }
  },
  {
    "like" : {
      "tweetId" : "1474348592588595208",
      "fullText" : "In case you missed it: HDMI on the Stamp! https://t.co/8f1pxeSHMl",
      "expandedUrl" : "https://twitter.com/i/web/status/1474348592588595208"
    }
  },
  {
    "like" : {
      "tweetId" : "1474220670129254400",
      "fullText" : "Metro RP2040 with ESP32 AirLift  #comingsoon https://t.co/N9gkYBytUw",
      "expandedUrl" : "https://twitter.com/i/web/status/1474220670129254400"
    }
  },
  {
    "like" : {
      "tweetId" : "1474217151003303938",
      "fullText" : "Metro RP2040 with ESP32 AirLift\n\nWe are noodling through some old designs we did not finis routing. There's still some ground plane work to do here, but all the pins are routed and assigned...somehow our designs always use *all* available GPIO, nothing left over! https://t.co/O1wsHQuQHh",
      "expandedUrl" : "https://twitter.com/i/web/status/1474217151003303938"
    }
  },
  {
    "like" : {
      "tweetId" : "1473959210048430080",
      "fullText" : "モルカーとモルモットのコラボレーション\nモルモットはビックリして動きませんでした https://t.co/clVyWG73Hl",
      "expandedUrl" : "https://twitter.com/i/web/status/1473959210048430080"
    }
  },
  {
    "like" : {
      "tweetId" : "1473690878107701253",
      "fullText" : "This, frankly, is pure genius https://t.co/PvS8xeb9TY",
      "expandedUrl" : "https://twitter.com/i/web/status/1473690878107701253"
    }
  },
  {
    "like" : {
      "tweetId" : "1473987008603340800",
      "fullText" : "Magnetic cable attachment clip #3DThursday #3DPrinting https://t.co/1vt0uSjAON",
      "expandedUrl" : "https://twitter.com/i/web/status/1473987008603340800"
    }
  },
  {
    "like" : {
      "tweetId" : "1473723796960026629",
      "fullText" : "Want a super miniaturized RPI with a sharp memory display and a USB keyboard ? https://t.co/1ZNdL6dHQB",
      "expandedUrl" : "https://twitter.com/i/web/status/1473723796960026629"
    }
  },
  {
    "like" : {
      "tweetId" : "1473652411155861512",
      "fullText" : "Something new popped up on @pimoroni 😋 https://t.co/2ROXIoC74p",
      "expandedUrl" : "https://twitter.com/i/web/status/1473652411155861512"
    }
  },
  {
    "like" : {
      "tweetId" : "1473473769935183874",
      "fullText" : "Yay! Got to meet @BlitzCityDIY in person over the weekend! https://t.co/k9CVZ7cygp",
      "expandedUrl" : "https://twitter.com/i/web/status/1473473769935183874"
    }
  },
  {
    "like" : {
      "tweetId" : "1473339763784663051",
      "fullText" : "Remember my flashing+testing POP jig?\n\nThe board that it's testing,  the RP2040 Stamp, is now available!\n\nhttps://t.co/A8rxZNrPsP https://t.co/dLqVFNdb8Q",
      "expandedUrl" : "https://twitter.com/i/web/status/1473339763784663051"
    }
  },
  {
    "like" : {
      "tweetId" : "1452803261275295744",
      "fullText" : "\"Hello, World!\" with CircuitPython online IDE.\n#circuitpython\nhttps://t.co/skTErSfv8k",
      "expandedUrl" : "https://twitter.com/i/web/status/1452803261275295744"
    }
  },
  {
    "like" : {
      "tweetId" : "1455609463696678912",
      "fullText" : "【Cpy IDE】Plot and Help: New Features of CircuitPython Online IDE #CircuitPython https://t.co/RA8UXaefy8",
      "expandedUrl" : "https://twitter.com/i/web/status/1455609463696678912"
    }
  },
  {
    "like" : {
      "tweetId" : "1460620832200433678",
      "fullText" : "I am sorry that my plan for posting the CircuitPython Chinese Video Series is slower than expected. I had some issues with my bilibili account. I will switch focus to other sites in the future. 抱歉遇到了一些困难,教程我还是会发,请期待. #circuitpython",
      "expandedUrl" : "https://twitter.com/i/web/status/1460620832200433678"
    }
  },
  {
    "like" : {
      "tweetId" : "1462491976771772416",
      "fullText" : "【CircuitPython IDE】中文开发环境上线了！ #cirtuitpython https://t.co/PeP48lNIZq",
      "expandedUrl" : "https://twitter.com/i/web/status/1462491976771772416"
    }
  },
  {
    "like" : {
      "tweetId" : "1462945531764875266",
      "fullText" : "【CircuitPython 简介】用 Python 开发单片机？简单易学的单片机开发语言！CircuitPython introduction in Chinese. #circuitpython  https://t.co/RWynOBnZYV",
      "expandedUrl" : "https://twitter.com/i/web/status/1462945531764875266"
    }
  },
  {
    "like" : {
      "tweetId" : "1464340658102194176",
      "fullText" : "【CircuitPython IDE】The new update allows you to run a Code Cell (starts with `#%%`) in REPL by shortcut [Ctrl-Enter]. #circuitpython https://t.co/yVCn6wmzRH",
      "expandedUrl" : "https://twitter.com/i/web/status/1464340658102194176"
    }
  },
  {
    "like" : {
      "tweetId" : "1466811803002880003",
      "fullText" : "【CircuitPython 入门】01. 从零开始，在单片机上运行你的第一个 CircuitPython 程序！Entry level Cpy tutorial in Chinese 01: From zero to Hello World #circuitpython https://t.co/2M1wc3eR14",
      "expandedUrl" : "https://twitter.com/i/web/status/1466811803002880003"
    }
  },
  {
    "like" : {
      "tweetId" : "1469706975302848513",
      "fullText" : "【CircuitPython 入门】01.1 在 ESP32 S2 单片机上安装 CircuitPython，与单片机上交互式编程。 Installing CircuitPython on ESP32S2, and demo of simple REPL on it. #CircuitPython  https://t.co/zhtjdOnvcS",
      "expandedUrl" : "https://twitter.com/i/web/status/1469706975302848513"
    }
  },
  {
    "like" : {
      "tweetId" : "1473006926141272074",
      "fullText" : "【CircuitPython IDE】New Editor shortcuts in REPL mode help you explore while writing the script #CircuitPython https://t.co/uRfRjGZMWq",
      "expandedUrl" : "https://twitter.com/i/web/status/1473006926141272074"
    }
  },
  {
    "like" : {
      "tweetId" : "1472574246832381956",
      "fullText" : "You’re unable to view this Tweet because this account owner limits who can view their Tweets. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1472574246832381956"
    }
  },
  {
    "like" : {
      "tweetId" : "1471465925908082692",
      "fullText" : "This Arduboy has no buttons! https://t.co/I7qAz4r3Rw https://t.co/EzTjCH7bFY",
      "expandedUrl" : "https://twitter.com/i/web/status/1471465925908082692"
    }
  },
  {
    "like" : {
      "tweetId" : "1471253400297689090",
      "fullText" : "Considering releasing publicly my new \"fork\" of @adafruit's CircuitPython... https://t.co/OHhuAmMW4S",
      "expandedUrl" : "https://twitter.com/i/web/status/1471253400297689090"
    }
  },
  {
    "like" : {
      "tweetId" : "1471159187317088270",
      "fullText" : "Raspberry Pi RP2040 Pip-Boy is Apocalypse Ready https://t.co/Aooqdd3yuo https://t.co/e4VtNULa6r",
      "expandedUrl" : "https://twitter.com/i/web/status/1471159187317088270"
    }
  },
  {
    "like" : {
      "tweetId" : "1470815867751604224",
      "fullText" : "Digital Painting on an iPad with Brushes #ArtTuesday https://t.co/BoVNPWtlRs",
      "expandedUrl" : "https://twitter.com/i/web/status/1470815867751604224"
    }
  },
  {
    "like" : {
      "tweetId" : "1470426546775199754",
      "fullText" : "Follow me... there will be amazing news in the next couple of weeks !!!!! https://t.co/8wr5BhmWDN",
      "expandedUrl" : "https://twitter.com/i/web/status/1470426546775199754"
    }
  },
  {
    "like" : {
      "tweetId" : "1470406791351648261",
      "fullText" : "Sent to @JLCPCB factory ... 100 pcs ordered... 1st batch... there will be giveaways to some retweets.... https://t.co/FYV1oBFmNH",
      "expandedUrl" : "https://twitter.com/i/web/status/1470406791351648261"
    }
  },
  {
    "like" : {
      "tweetId" : "1469780972333846535",
      "expandedUrl" : "https://twitter.com/i/web/status/1469780972333846535"
    }
  },
  {
    "like" : {
      "tweetId" : "1466046480880386048",
      "fullText" : "Today in the HackSpace mag lab we're testing out the@CircuitPython neopixel animations library. https://t.co/DrE387RAF8",
      "expandedUrl" : "https://twitter.com/i/web/status/1466046480880386048"
    }
  },
  {
    "like" : {
      "tweetId" : "1465794480343191552",
      "fullText" : "Alpha builds of @CircuitPython for the @Raspberry_Pi are now on https://t.co/D6uObH4xah. Please try it out and help us squash bugs.",
      "expandedUrl" : "https://twitter.com/i/web/status/1465794480343191552"
    }
  },
  {
    "like" : {
      "tweetId" : "1469866073008791552",
      "fullText" : "MOAR PINK FEATHERS (putting in store soon!) ... ! @adafruit https://t.co/y6uQ5Uv3qs",
      "expandedUrl" : "https://twitter.com/i/web/status/1469866073008791552"
    }
  },
  {
    "like" : {
      "tweetId" : "1469357437077622787",
      "fullText" : "I shill @adafruit, as I work for them, but they have some way cool stuff. This is something that I would buy from any shop: Small SD cards. Why? Some old tech doesn't work with large cards. These run in SPI mode only, so devices won't get confused. And they're inexpensive! https://t.co/sQGkqauNnh",
      "expandedUrl" : "https://twitter.com/i/web/status/1469357437077622787"
    }
  },
  {
    "like" : {
      "tweetId" : "1467677698826936323",
      "fullText" : "Just got to Colorado to visit @sparkfun HQ for the week. I of course had to stop by the office before tomorrow morning.\n\nMy jaw is on the floor. I suspect it will stay there for the rest of the week. 🤯😆 https://t.co/Kb0L17GAoS",
      "expandedUrl" : "https://twitter.com/i/web/status/1467677698826936323"
    }
  },
  {
    "like" : {
      "tweetId" : "1287990412758487040",
      "fullText" : "Seeeduino #XIAO power consumption:\nTested data：\n1) loop() 0.0133A\n2) sleep() 0.0127A\n3) deepSleep() 0.0004A\n\nUsing：https://t.co/q2cHiUn8y9\n😶😶Is there a way to reduce more power consumption？ https://t.co/slS119ENjl",
      "expandedUrl" : "https://twitter.com/i/web/status/1287990412758487040"
    }
  },
  {
    "like" : {
      "tweetId" : "1466916352552161281",
      "fullText" : "3D printed a simple rear case for the @adafruit #pygamer to contain the battery and wires and give a nice texture to the hand, while keeping the fun exposed PCB front. https://t.co/WyeA84zYnz",
      "expandedUrl" : "https://twitter.com/i/web/status/1466916352552161281"
    }
  },
  {
    "like" : {
      "tweetId" : "1466813114486296579",
      "fullText" : "NEW GUIDE: Adafruit ESP32-S2 Feather #AdafruitLearningSystem #Adafruit adafruit  https://t.co/YaGc1yOkAE",
      "expandedUrl" : "https://twitter.com/i/web/status/1466813114486296579"
    }
  },
  {
    "like" : {
      "tweetId" : "1466779517066924032",
      "fullText" : "Printed Circuit Bird #Art #Electronics @kelly_heaton https://t.co/PZlglEA1yj",
      "expandedUrl" : "https://twitter.com/i/web/status/1466779517066924032"
    }
  },
  {
    "like" : {
      "tweetId" : "1466795371389145092",
      "fullText" : "FTC Sues to Block $40 Billion Semiconductor Chip Merger @arm @nvidia https://t.co/neEbANiLdC",
      "expandedUrl" : "https://twitter.com/i/web/status/1466795371389145092"
    }
  },
  {
    "like" : {
      "tweetId" : "1466452561842651137",
      "fullText" : "This Tweet is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1466452561842651137"
    }
  },
  {
    "like" : {
      "tweetId" : "1462526351743893504",
      "fullText" : "This Tweet is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1462526351743893504"
    }
  },
  {
    "like" : {
      "tweetId" : "1464386501157007365",
      "fullText" : "CircuitPython works with QT Py ESP32-S2 board :) Plus, get a free Pink RP2040 Feather in our Feather Friday sale! https://t.co/W5nEuZ2lOK",
      "expandedUrl" : "https://twitter.com/i/web/status/1464386501157007365"
    }
  },
  {
    "like" : {
      "tweetId" : "1464911867466461187",
      "fullText" : "Another view of the upcoming @EspressifSystem  ESP32-S2 QT Py ... (from Desk of Ladyada) - https://t.co/L7fOOa4CvO https://t.co/po8HC5wSmH",
      "expandedUrl" : "https://twitter.com/i/web/status/1464911867466461187"
    }
  },
  {
    "like" : {
      "tweetId" : "1463165453602377776",
      "fullText" : "Develop your CircuitPython code in a browser with two tools #CircuitPython #Bluetooth @River___Wang https://t.co/gP5v9qg7A7",
      "expandedUrl" : "https://twitter.com/i/web/status/1463165453602377776"
    }
  },
  {
    "like" : {
      "tweetId" : "1463165667759345679",
      "fullText" : "Fantastic work with online IDEs by @River___Wang and @makermelissa ! #CircuitPython https://t.co/xS8WN9ePEn",
      "expandedUrl" : "https://twitter.com/i/web/status/1463165667759345679"
    }
  },
  {
    "like" : {
      "tweetId" : "1461983225765670925",
      "fullText" : "iPod Mod Puts Pi Zero in New Bod https://t.co/5fHoxB7Kw2",
      "expandedUrl" : "https://twitter.com/i/web/status/1461983225765670925"
    }
  },
  {
    "like" : {
      "tweetId" : "1462778550923186176",
      "fullText" : "#3dprint your own magnetic shoe lace closures. This can be really useful for anyone with dexterity problems, or if you just want to make tying your shoes a whole lot easier! Full guide on: https://t.co/25d8udFzez #3DPrintng #Adafruit #DIY #Timelapse https://t.co/krQQA9qJPt https://t.co/yLuknIugrH",
      "expandedUrl" : "https://twitter.com/i/web/status/1462778550923186176"
    }
  },
  {
    "like" : {
      "tweetId" : "1462832205881823235",
      "fullText" : "Early Internet Minitel ESP32 Adapter! #TindieBlog https://t.co/AvovuEj8LO https://t.co/qJ7utBMSKS",
      "expandedUrl" : "https://twitter.com/i/web/status/1462832205881823235"
    }
  },
  {
    "like" : {
      "tweetId" : "1462914555391234050",
      "fullText" : "Will be posting a video up in a bit, here is a preview :) https://t.co/aarCiz2eSp",
      "expandedUrl" : "https://twitter.com/i/web/status/1462914555391234050"
    }
  },
  {
    "like" : {
      "tweetId" : "1462842200262328328",
      "fullText" : "@River___Wang No worries, I have traveled the world and I like contributions to open source from all sources, thank you for developing and sharing this.",
      "expandedUrl" : "https://twitter.com/i/web/status/1462842200262328328"
    }
  },
  {
    "like" : {
      "tweetId" : "1462834543178702851",
      "fullText" : "@River___Wang Hi River! I'm going to publish info on your ide in the Python on Microcontrollers newsletter coming out tomorrow. May I say you wrote it and provide this Twitter account?",
      "expandedUrl" : "https://twitter.com/i/web/status/1462834543178702851"
    }
  },
  {
    "like" : {
      "tweetId" : "1458506957485084672",
      "fullText" : "想激情下单单片机",
      "expandedUrl" : "https://twitter.com/i/web/status/1458506957485084672"
    }
  },
  {
    "like" : {
      "tweetId" : "1407352525825716242",
      "fullText" : "An online editor for CircuitPython #CircuitPython  https://t.co/ikJA6WcyYn",
      "expandedUrl" : "https://twitter.com/i/web/status/1407352525825716242"
    }
  },
  {
    "like" : {
      "tweetId" : "1581114304488607745",
      "fullText" : "So I'm going to my first tech conference since the pandemic. (#AnsibleFest)\n\nWhat things should I make sure I do up in Chicago, wrong answers only.",
      "expandedUrl" : "https://twitter.com/i/web/status/1581114304488607745"
    }
  },
  {
    "like" : {
      "tweetId" : "1581048274815188992",
      "fullText" : "New Learn Guide: Adafruit Learning System User Pages @adafruit #adafruit https://t.co/0CnwfW8rSn",
      "expandedUrl" : "https://twitter.com/i/web/status/1581048274815188992"
    }
  },
  {
    "like" : {
      "tweetId" : "1581060621121908737",
      "fullText" : "And our number 1 reason is to stop by and meet MythBuster, Jr., Elijah Horland! Drop by for maker-mischief fun, MythBuster’s style with MythBuster Jr., Elijah Horland to l levitate matter with sound and play with the worst video game controllers ever des… https://t.co/H9wXbZdzZn https://t.co/0JIuCWggVJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1581060621121908737"
    }
  },
  {
    "like" : {
      "tweetId" : "1581310185770872833",
      "fullText" : "NEW GUIDE: Quick-Start the Pico W WiFi with CircuitPython #AdafruitLearningSystem #Adafruit adafruit blitzcitydiy  https://t.co/386zd3uJhg",
      "expandedUrl" : "https://twitter.com/i/web/status/1581310185770872833"
    }
  },
  {
    "like" : {
      "tweetId" : "1581311596940636160",
      "fullText" : "Come and see #CircuitPython online IDE live at @phlmake Philly Maker Faire! https://t.co/kGD9VdfHBO",
      "expandedUrl" : "https://twitter.com/i/web/status/1581311596940636160"
    }
  },
  {
    "like" : {
      "tweetId" : "1581124770309214208",
      "fullText" : "Behold, the brand new #CircuitPython Online IDE is here. \nIDE: https://t.co/MbMYEkPBGE\nGithub Repo: https://t.co/PeDBULdBRW https://t.co/x89sYkIxRi",
      "expandedUrl" : "https://twitter.com/i/web/status/1581124770309214208"
    }
  },
  {
    "like" : {
      "tweetId" : "1580876139576557568",
      "fullText" : "An Open-Source HDMI Capture Card https://t.co/s8hNOEo7EU",
      "expandedUrl" : "https://twitter.com/i/web/status/1580876139576557568"
    }
  },
  {
    "like" : {
      "tweetId" : "1580864758487470080",
      "fullText" : "News from MakeZine: Live: Maker Faire Lille 2022 https://t.co/0mUTVQTRQT https://t.co/eMP1CJOptl",
      "expandedUrl" : "https://twitter.com/i/web/status/1580864758487470080"
    }
  },
  {
    "like" : {
      "tweetId" : "1580764531181359104",
      "fullText" : "CircuitPython 8.0.0 Beta 2 Released! circuitpython  https://t.co/KQ09KUGoep",
      "expandedUrl" : "https://twitter.com/i/web/status/1580764531181359104"
    }
  },
  {
    "like" : {
      "tweetId" : "1580692462154104832",
      "fullText" : "@arturo182 @bwshockley Had",
      "expandedUrl" : "https://twitter.com/i/web/status/1580692462154104832"
    }
  },
  {
    "like" : {
      "tweetId" : "1580636281637285888",
      "fullText" : "AdafruitIO with WipperSnapper can now send an SMS alert based on an action. That's a nice feature update. https://t.co/0gTPs0S52j",
      "expandedUrl" : "https://twitter.com/i/web/status/1580636281637285888"
    }
  },
  {
    "like" : {
      "tweetId" : "1580637237204881408",
      "fullText" : "@River___Wang Need to find a keycap manufacturer that actually has silkscreened caps with the words \"copy\" &amp; \"paste\"for macro keys. :)  I'm right there with you. Not just copying other peoples code but also snippets from my own past projects.",
      "expandedUrl" : "https://twitter.com/i/web/status/1580637237204881408"
    }
  },
  {
    "like" : {
      "tweetId" : "1580592683864584193",
      "fullText" : "@Mirko_DIY To my credit it was an error on the board layout not the schematics 😅",
      "expandedUrl" : "https://twitter.com/i/web/status/1580592683864584193"
    }
  },
  {
    "like" : {
      "tweetId" : "1580532162751000577",
      "fullText" : "iMac Pro. https://t.co/gJz64RstcS",
      "expandedUrl" : "https://twitter.com/i/web/status/1580532162751000577"
    }
  },
  {
    "like" : {
      "tweetId" : "1580559810277216257",
      "fullText" : "@River___Wang As long as you’re happy with it! How do you like the spacing? Was thinking of designing one based on your design.",
      "expandedUrl" : "https://twitter.com/i/web/status/1580559810277216257"
    }
  },
  {
    "like" : {
      "tweetId" : "1580440061853605888",
      "fullText" : "@River___Wang Looks great! At first I thought it was just one arrow out of place. Ummm they’re all pointing in the same direction. 😆",
      "expandedUrl" : "https://twitter.com/i/web/status/1580440061853605888"
    }
  },
  {
    "like" : {
      "tweetId" : "1580406111513251841",
      "fullText" : "Despite a 1 mm mismatched dimension I got my first Keyboard made, with magnetic palm rest. Firmware is still developing in #CircuitPython, of course with the brand new Online IDE. https://t.co/Nv2sHR0wiC",
      "expandedUrl" : "https://twitter.com/i/web/status/1580406111513251841"
    }
  },
  {
    "like" : {
      "tweetId" : "1580275558508032001",
      "fullText" : "3 days until the Philly Maker Faire. Buy your tickets now!\n\n2022 Philly Maker Faire 10 am – 5 pm on October 15 at the @phillyseaport \n\nhttps://t.co/IGFgBGCKFl\n\nor see Linktree in bio\n\n#PhillyMakerFaire #phillymakerfaire2022 #PhillyMakers #make #makers #… https://t.co/emaUcOUjya https://t.co/nr3yCRYAxL",
      "expandedUrl" : "https://twitter.com/i/web/status/1580275558508032001"
    }
  },
  {
    "like" : {
      "tweetId" : "1580309640440868864",
      "fullText" : "らくがき https://t.co/GuCZWnFdbf",
      "expandedUrl" : "https://twitter.com/i/web/status/1580309640440868864"
    }
  },
  {
    "like" : {
      "tweetId" : "1579988726687891457",
      "fullText" : "Don't miss out on the fun! Buy your tickets now!\n\n2022 Philly Maker Faire 10 am – 5 pm on October 15 at the @phillyseaport \n\nhttps://t.co/KFasmvRVze\n\nor see Linktree in bio\n\n#PhillyMakerFaire #phillymakerfaire2022 #PhillyMakers #make #makers #DIY #MakeM… https://t.co/0dLbDKTAZF https://t.co/q2GbitnRmb",
      "expandedUrl" : "https://twitter.com/i/web/status/1579988726687891457"
    }
  },
  {
    "like" : {
      "tweetId" : "1579746755624984578",
      "fullText" : "@PR0GRAMMERHUM0R Highly recommend reading up on \"Item 7: Distinguish between () and {} when creating objects.\" from Scott Meyers \"Effective Modern C++\" ... that tries to clarify this mess. https://t.co/zQfzx7k9Zq",
      "expandedUrl" : "https://twitter.com/i/web/status/1579746755624984578"
    }
  },
  {
    "like" : {
      "tweetId" : "1579921262671187969",
      "fullText" : "LILYGO's new T-RGB ESP32-S3 is the company's first round touchscreen display: https://t.co/K0pgr24gIx https://t.co/BXXps9k5hq",
      "expandedUrl" : "https://twitter.com/i/web/status/1579921262671187969"
    }
  },
  {
    "like" : {
      "tweetId" : "1579799716761853952",
      "fullText" : "らくがき https://t.co/e3cnwWcaf5",
      "expandedUrl" : "https://twitter.com/i/web/status/1579799716761853952"
    }
  },
  {
    "like" : {
      "tweetId" : "1579633639754993664",
      "expandedUrl" : "https://twitter.com/i/web/status/1579633639754993664"
    }
  },
  {
    "like" : {
      "tweetId" : "1579789108205203456",
      "fullText" : "Don’t Miss the Philadelphia Maker Faire this Weekend https://t.co/NHCT8Uj3p4",
      "expandedUrl" : "https://twitter.com/i/web/status/1579789108205203456"
    }
  },
  {
    "like" : {
      "tweetId" : "1579834971803779072",
      "fullText" : "Happy Ada Lovelace Day today, an international celebration of the achievements of women in STEM. Every day I am in awe of all the hard work and achievement of women in STEM. Keep it up ladies!",
      "expandedUrl" : "https://twitter.com/i/web/status/1579834971803779072"
    }
  },
  {
    "like" : {
      "tweetId" : "1579552619613519873",
      "fullText" : "Alpha version of the new #CircuitPython online IDE is out! 🎉🎉🎉 If you want to help me test it out, please visit https://t.co/tuaSp2Yf2S Sorry the Github repo is a bit messy right now. It is going public soon. For now, please use \"Help-&gt;Feedback\" to send me some suggestions. https://t.co/0rZiWHOIS1",
      "expandedUrl" : "https://twitter.com/i/web/status/1579552619613519873"
    }
  },
  {
    "like" : {
      "tweetId" : "1579501236080246785",
      "fullText" : "A 3D printer is simultaneously my most loved and hated tool I own. https://t.co/roVmoMx7KS",
      "expandedUrl" : "https://twitter.com/i/web/status/1579501236080246785"
    }
  },
  {
    "like" : {
      "tweetId" : "1579277619392315393",
      "fullText" : "@leonardovallem @T0anto @_ricardoboss @PR0GRAMMERHUM0R Not everyone knows that mac has a different keyboard layout...",
      "expandedUrl" : "https://twitter.com/i/web/status/1579277619392315393"
    }
  },
  {
    "like" : {
      "tweetId" : "1579073077509386240",
      "fullText" : "#三連休はフォロワーさんが増える\nわーい！ https://t.co/FT9De9TUWD",
      "expandedUrl" : "https://twitter.com/i/web/status/1579073077509386240"
    }
  },
  {
    "like" : {
      "tweetId" : "1578711585702699009",
      "fullText" : "@PR0GRAMMERHUM0R 22/7",
      "expandedUrl" : "https://twitter.com/i/web/status/1578711585702699009"
    }
  },
  {
    "like" : {
      "tweetId" : "1578478390415613952",
      "fullText" : ".@ArtillectYT's Brother AX-25 typewriter is reborn as an Arduino and Raspberry Pi-powered Linux terminal: https://t.co/pPqWwwKx1T https://t.co/OyWM6pR1XR",
      "expandedUrl" : "https://twitter.com/i/web/status/1578478390415613952"
    }
  },
  {
    "like" : {
      "tweetId" : "1578353676414222336",
      "fullText" : "マウスいらないかも https://t.co/91NBBVVQIi",
      "expandedUrl" : "https://twitter.com/i/web/status/1578353676414222336"
    }
  },
  {
    "like" : {
      "tweetId" : "1578345472892469248",
      "fullText" : "🥳 https://t.co/d8ixkijVQS",
      "expandedUrl" : "https://twitter.com/i/web/status/1578345472892469248"
    }
  },
  {
    "like" : {
      "tweetId" : "1578384918610075648",
      "fullText" : "5″ UMPC with Pi 3 B+ #piday #raspberrypi @Raspberry_Pi https://t.co/g9FxOhnFMo",
      "expandedUrl" : "https://twitter.com/i/web/status/1578384918610075648"
    }
  },
  {
    "like" : {
      "tweetId" : "1578188289097764865",
      "fullText" : "Just tried out a quick wifi test with CircuitPython on the pico w with absolute newest uf2 🥧 🐄 much excite, amazing work @jeffepler https://t.co/LW1ZZGRE5H",
      "expandedUrl" : "https://twitter.com/i/web/status/1578188289097764865"
    }
  },
  {
    "like" : {
      "tweetId" : "1578183147052752896",
      "fullText" : "I was reminded today why I love the CircuitPython community.  You all rock.",
      "expandedUrl" : "https://twitter.com/i/web/status/1578183147052752896"
    }
  },
  {
    "like" : {
      "tweetId" : "1578067656468561921",
      "fullText" : ".@solderparty launches three new \"Flux project\" carriers for the RP2040 Stamp: https://t.co/S45H2wHd8J https://t.co/GK16Okk8X9",
      "expandedUrl" : "https://twitter.com/i/web/status/1578067656468561921"
    }
  },
  {
    "like" : {
      "tweetId" : "1578058864582352896",
      "fullText" : "#circuitpython Finished with the physical build. Only coding API’s left to do.  Social Media Counter inspired by @bekathwia https://t.co/tlQeWQaScQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1578058864582352896"
    }
  },
  {
    "like" : {
      "tweetId" : "1578067537509638145",
      "fullText" : "V1.2 TR-Cowbell. Hopefully no bodge wire needed. Name in Papyrus font.  #Adafruit.  😁 https://t.co/FlQT09NjWd",
      "expandedUrl" : "https://twitter.com/i/web/status/1578067537509638145"
    }
  },
  {
    "like" : {
      "tweetId" : "1578055951852224512",
      "fullText" : "Reposted from @hellosticklets Hey Philly!\nWe’ll be at Maker Faire next weekend, Saturday, Oct 15th from 1:00pm to 5:00pm. Our all ages event is family friendly — great fun for those looking for open-ended play and fort building! \n\n@phillymakerfaire \n\nLoc… https://t.co/22k24xmJ8E https://t.co/aw1pIuZ188",
      "expandedUrl" : "https://twitter.com/i/web/status/1578055951852224512"
    }
  },
  {
    "like" : {
      "tweetId" : "1577400725478510608",
      "fullText" : "Build your own T-COMPUTER and start emulating vintage computers: https://t.co/jBDmHESzOk https://t.co/5y0g03nvjT",
      "expandedUrl" : "https://twitter.com/i/web/status/1577400725478510608"
    }
  },
  {
    "like" : {
      "tweetId" : "1453036011626323988",
      "fullText" : "PyDOS+PyBasic + @CircuitPython (https://t.co/CnvcnKg3xH) on @adafruit Feather RP2040 + keyboard featherwing. Memories of my early days but in pocket form. https://t.co/gTga7AC0OQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1453036011626323988"
    }
  },
  {
    "like" : {
      "tweetId" : "1577633033179504640",
      "fullText" : "GRIN Quern is an ergonomic, @SeeedStudio XIAO RP2040-powered keyboard with a rotary dial trackpad in the center: https://t.co/j2JmMDrpsp https://t.co/g27PMojzv2",
      "expandedUrl" : "https://twitter.com/i/web/status/1577633033179504640"
    }
  },
  {
    "like" : {
      "tweetId" : "1577728122467794944",
      "fullText" : "Retro Speaker Becomes The Perfect Micro PC https://t.co/LA2JUpWZkk",
      "expandedUrl" : "https://twitter.com/i/web/status/1577728122467794944"
    }
  },
  {
    "like" : {
      "tweetId" : "1577716908715307008",
      "fullText" : "@madzadev Lately I’ve been making browser-based apps that work with microcontrollers that run mostly on desktop, but also mobile.",
      "expandedUrl" : "https://twitter.com/i/web/status/1577716908715307008"
    }
  },
  {
    "like" : {
      "tweetId" : "1447230860105814017",
      "fullText" : "Starting writing a little @CircuitPython library that lets you talk to the CH559 USB -&gt; Serial chip. It's a quick way to add keyboard/mouse/gamepad input to your projects! (I've only got keyboard so far)\n\nhttps://t.co/A18HgxEcgh",
      "expandedUrl" : "https://twitter.com/i/web/status/1447230860105814017"
    }
  },
  {
    "like" : {
      "tweetId" : "1577540390407675906",
      "fullText" : "RoRo！\n#インティ絵 https://t.co/BLQNFaK0fq",
      "expandedUrl" : "https://twitter.com/i/web/status/1577540390407675906"
    }
  },
  {
    "like" : {
      "tweetId" : "1577426906835996672",
      "fullText" : "I found the \"disk\" that Captain Picard had the data on - it's an @Adafruit Circuit Playground Express from the 21st century. Perhaps programmed in #CircuitPython with the data files added via thumb drive plug &amp; play? https://t.co/HiDWL8Uxws https://t.co/fFzXjxbSbo",
      "expandedUrl" : "https://twitter.com/i/web/status/1577426906835996672"
    }
  },
  {
    "like" : {
      "tweetId" : "1577491239766663168",
      "fullText" : "The basic UI is done. Now it is time for some business logic. https://t.co/LZf7wyjIqo",
      "expandedUrl" : "https://twitter.com/i/web/status/1577491239766663168"
    }
  },
  {
    "like" : {
      "tweetId" : "1577391498030886912",
      "fullText" : "BUY TICKETS NOW!\n\n2022 Philly Maker Faire on October 15 at the @phillyseaport \n\nhttps://t.co/8HaezzWlBC\n\nor see Linktree in bio\n\n#PhillyMakerFaire #phillymakerfaire2022 #PhillyMakers #make #makers #DIY #MakeMagazine #workshops #panels #steam #design #fa… https://t.co/YQCDLi1Ne1 https://t.co/jyROe6U5Te",
      "expandedUrl" : "https://twitter.com/i/web/status/1577391498030886912"
    }
  },
  {
    "like" : {
      "tweetId" : "1577269352931262464",
      "fullText" : "一粒にとじこめて https://t.co/YOvYvTRHFk",
      "expandedUrl" : "https://twitter.com/i/web/status/1577269352931262464"
    }
  },
  {
    "like" : {
      "tweetId" : "1577225274789199873",
      "fullText" : "VISIONS https://t.co/mTfudpsIe6",
      "expandedUrl" : "https://twitter.com/i/web/status/1577225274789199873"
    }
  },
  {
    "like" : {
      "tweetId" : "1577191794097508352",
      "fullText" : "This candle holder is made up of a clear tube that collects all the melted wax, and once the candle is fully melted, it automatically creates a new candle by forming a new candle from the melted wax [source, read more: https://t.co/mrpvJSc5eo] https://t.co/V1LJUZaBOJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1577191794097508352"
    }
  },
  {
    "like" : {
      "tweetId" : "1577203436915130368",
      "fullText" : "@River___Wang Looking much better! Great progress.",
      "expandedUrl" : "https://twitter.com/i/web/status/1577203436915130368"
    }
  },
  {
    "like" : {
      "tweetId" : "1577202598389907456",
      "fullText" : "新たなスタート\n#夢夏日記 https://t.co/aoGZ4ifbJF",
      "expandedUrl" : "https://twitter.com/i/web/status/1577202598389907456"
    }
  },
  {
    "like" : {
      "tweetId" : "1577242811283668992",
      "fullText" : "らくがき https://t.co/FFDt5qtWhg",
      "expandedUrl" : "https://twitter.com/i/web/status/1577242811283668992"
    }
  },
  {
    "like" : {
      "tweetId" : "1577236171733991424",
      "fullText" : "#私の個性はきっと誰かにささる\n極力シンプルな塗りで映える絵を目指してます。 https://t.co/6YBT9UVPdo",
      "expandedUrl" : "https://twitter.com/i/web/status/1577236171733991424"
    }
  },
  {
    "like" : {
      "tweetId" : "1577293724362719232",
      "fullText" : "Raspberry Pi + mechanical keyboard = DIY handheld PC https://t.co/OoM8wGVuoW",
      "expandedUrl" : "https://twitter.com/i/web/status/1577293724362719232"
    }
  },
  {
    "like" : {
      "tweetId" : "1576930058089816064",
      "fullText" : "Success. This “untested” PET 2001-8N is now back in service. The whole thing was filthy and had some corrosion. Every keyboard plunger needed Cailkote and it had two bad linear regulators. Fairly easy repair. Happy Monday! #commodore #PET https://t.co/540N6uJdxB",
      "expandedUrl" : "https://twitter.com/i/web/status/1576930058089816064"
    }
  },
  {
    "like" : {
      "tweetId" : "1577185649743962112",
      "fullText" : "I'm giving a talk about the Apple M1 GPU at @XOrgDevConf 2022 with @alyssarzg TODAY!!! ✨✨\n\n🕑October 4th 14:00 CDT / 19:00 UTC / 28:00 JST\n▶https://t.co/mvvBglzVVP\n🌎https://t.co/cHKfBkK11B https://t.co/zVXlUbGDSM",
      "expandedUrl" : "https://twitter.com/i/web/status/1577185649743962112"
    }
  },
  {
    "like" : {
      "tweetId" : "1577131516911824896",
      "fullText" : "Finally, I have found all the tech pieces needed for the coming CircuitPython Online IDE. It is such a pleasure putting things together. Construction progress is like 20% now. Stay tuned. #CircuitPython https://t.co/IBPYYWGmT9",
      "expandedUrl" : "https://twitter.com/i/web/status/1577131516911824896"
    }
  },
  {
    "like" : {
      "tweetId" : "1577060712148410369",
      "fullText" : "LILYGO unveils the T-Embed ESP32-S3-powered universal remote for smart home projects and more: https://t.co/AmtNBraTsa https://t.co/UdheAEywSu",
      "expandedUrl" : "https://twitter.com/i/web/status/1577060712148410369"
    }
  },
  {
    "like" : {
      "tweetId" : "1577043018435203091",
      "fullText" : "What are the odds? Went looking for a macropad with a wheel and a former podcast guest is selling exactly what I want: https://t.co/Doe45q8lI7",
      "expandedUrl" : "https://twitter.com/i/web/status/1577043018435203091"
    }
  },
  {
    "like" : {
      "tweetId" : "1577012377324748803",
      "fullText" : "All this for minor hand surgery.  Which was a success. https://t.co/BSdLmtHe7V",
      "expandedUrl" : "https://twitter.com/i/web/status/1577012377324748803"
    }
  },
  {
    "like" : {
      "tweetId" : "1576618912224976896",
      "fullText" : "Cats are liquids 💦\n\n#cat #art #digitalart https://t.co/RS8DAFRKaz",
      "expandedUrl" : "https://twitter.com/i/web/status/1576618912224976896"
    }
  },
  {
    "like" : {
      "tweetId" : "1576857272084402177",
      "fullText" : "After you're done being an electrical engineer and ready to call the design done that's when you morph into artiste mode. You've got a blank canvas for silkscreen art at your fingertips! There's nothing wrong with starting out with dickbutt either. Make art! https://t.co/pLofMG3xsr",
      "expandedUrl" : "https://twitter.com/i/web/status/1576857272084402177"
    }
  },
  {
    "like" : {
      "tweetId" : "1576855925163315201",
      "fullText" : "@River___Wang Next time put your name &amp; board name in silkscreen on it. This is why I didn't recognize it in the OSHW list. ;)",
      "expandedUrl" : "https://twitter.com/i/web/status/1576855925163315201"
    }
  },
  {
    "like" : {
      "tweetId" : "1576628411430162433",
      "fullText" : "Fluidic circuits add analog options for controlling soft robots. https://t.co/GqLIJAY4Fp",
      "expandedUrl" : "https://twitter.com/i/web/status/1576628411430162433"
    }
  },
  {
    "like" : {
      "tweetId" : "1576626050234167296",
      "fullText" : "Seth Woinowsky's DuoDeck Type is a retro-themed cyberdeck with a hidden KVM docking system: https://t.co/6d59ziphrf https://t.co/QDgE0sSyuy",
      "expandedUrl" : "https://twitter.com/i/web/status/1576626050234167296"
    }
  },
  {
    "like" : {
      "tweetId" : "1576602151463575552",
      "fullText" : "rate my new setup? https://t.co/tTyRsHtk4f",
      "expandedUrl" : "https://twitter.com/i/web/status/1576602151463575552"
    }
  },
  {
    "like" : {
      "tweetId" : "1576721113987526656",
      "fullText" : "Stack 'em up https://t.co/8x25uxQLiM",
      "expandedUrl" : "https://twitter.com/i/web/status/1576721113987526656"
    }
  },
  {
    "like" : {
      "tweetId" : "1576304135384829954",
      "fullText" : "I see there is a new release of CircuitPython on https://t.co/gyFGfqI4Sl - check it out! https://t.co/ctFcx3JP1b",
      "expandedUrl" : "https://twitter.com/i/web/status/1576304135384829954"
    }
  },
  {
    "like" : {
      "tweetId" : "1576357623405813761",
      "fullText" : "@extremedignity @fedora We're working with Fedora developers on that :-)",
      "expandedUrl" : "https://twitter.com/i/web/status/1576357623405813761"
    }
  },
  {
    "like" : {
      "tweetId" : "1576079436365299713",
      "fullText" : "Calculator https://t.co/HKCASBLHT0",
      "expandedUrl" : "https://twitter.com/i/web/status/1576079436365299713"
    }
  }
]