window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1599602517494575105"
          ],
          "editableUntil" : "2022-12-05T03:42:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "0",
              "14"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/PmXDZ9fVne",
            "expanded_url" : "https://fosstodon.org/@Riverwang/109458872389319278",
            "display_url" : "fosstodon.org/@Riverwang/109…",
            "indices" : [
              "15",
              "38"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "2",
      "id_str" : "1599602517494575105",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1599602517494575105",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 05 03:12:14 +0000 2022",
      "favorited" : false,
      "full_text" : "#CircuitPython https://t.co/PmXDZ9fVne",
      "lang" : "qme"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1597267337811755009"
          ],
          "editableUntil" : "2022-11-28T17:03:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "circuitpython",
            "indices" : [
              "0",
              "14"
            ]
          },
          {
            "text" : "keyboard",
            "indices" : [
              "15",
              "24"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/mWSKK8tTwH",
            "expanded_url" : "https://fosstodon.org/@Riverwang/109422344404814577",
            "display_url" : "fosstodon.org/@Riverwang/109…",
            "indices" : [
              "25",
              "48"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "0",
      "id_str" : "1597267337811755009",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1597267337811755009",
      "possibly_sensitive" : false,
      "created_at" : "Mon Nov 28 16:33:03 +0000 2022",
      "favorited" : false,
      "full_text" : "#circuitpython #keyboard https://t.co/mWSKK8tTwH",
      "lang" : "qme"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1594492683913158656"
          ],
          "editableUntil" : "2022-11-21T01:17:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/rdriYQShFW",
            "expanded_url" : "https://fosstodon.org/@Riverwang/109379011230661594",
            "display_url" : "fosstodon.org/@Riverwang/109…",
            "indices" : [
              "45",
              "68"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "id_str" : "1594492683913158656",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1594492683913158656",
      "possibly_sensitive" : false,
      "created_at" : "Mon Nov 21 00:47:34 +0000 2022",
      "favorited" : false,
      "full_text" : "It is official. Hope we all stay connected.\n\nhttps://t.co/rdriYQShFW",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1590372812492918784"
          ],
          "editableUntil" : "2022-11-09T16:26:40.853Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "112",
              "126"
            ]
          },
          {
            "text" : "ICYMI",
            "indices" : [
              "127",
              "133"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CircuitPython",
            "screen_name" : "CircuitPython",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "811605410293645313",
            "id" : "811605410293645313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1590372812492918784",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1590372812492918784",
      "created_at" : "Wed Nov 09 15:56:40 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @CircuitPython: ICYMI Python on Microcontrollers Newsletter: New Hardware, Python 3.12 Alpha, and much more! #CircuitPython #ICYMI micro…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1589809702967603201"
          ],
          "editableUntil" : "2022-11-08T03:09:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "AppNasty",
            "screen_name" : "AppNasty",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1057609746",
            "id" : "1057609746"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "96"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1589321079679770626",
      "id_str" : "1589809702967603201",
      "in_reply_to_user_id" : "1057609746",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1589809702967603201",
      "in_reply_to_status_id" : "1589321079679770626",
      "created_at" : "Tue Nov 08 02:39:05 +0000 2022",
      "favorited" : false,
      "full_text" : "@AppNasty It's probably not a TV crt. Instead, it is disassembled from a Pac-Man arcade machine.",
      "lang" : "en",
      "in_reply_to_screen_name" : "AppNasty",
      "in_reply_to_user_id_str" : "1057609746"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1589807806156529664"
          ],
          "editableUntil" : "2022-11-08T03:01:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "82",
              "96"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/MbMYEkPBGE",
            "expanded_url" : "https://urfdvw.github.io/CircuitPython-online-IDE/",
            "display_url" : "urfdvw.github.io/CircuitPython-…",
            "indices" : [
              "201",
              "224"
            ]
          },
          {
            "url" : "https://t.co/hJ0iydRwtx",
            "expanded_url" : "https://github.com/urfdvw/CircuitPython-online-IDE",
            "display_url" : "github.com/urfdvw/Circuit…",
            "indices" : [
              "243",
              "266"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "266"
      ],
      "favorite_count" : "7",
      "id_str" : "1589807806156529664",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1589807806156529664",
      "possibly_sensitive" : false,
      "created_at" : "Tue Nov 08 02:31:32 +0000 2022",
      "favorited" : false,
      "full_text" : "After fixing all the issues I found during my alpha test, I want to announce that #CircuitPython Online IDE is now beta! The pull request is merged and the new help document is also there. Try it out: https://t.co/MbMYEkPBGE and see the repo: https://t.co/hJ0iydRwtx",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588950924567117824"
          ],
          "editableUntil" : "2022-11-05T18:16:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/O5k2Fy91tg",
            "expanded_url" : "https://www.digikey.com/en/products/detail/sullins-connector-solutions/PRPC040SACN-RC/2776066?utm_adgroup=Rectangular%20Connectors%20-%20Headers%2C%20Male%20Pins&utm_source=google&utm_medium=cpc&utm_campaign=Shopping_Product_Connectors%2C%20Interconnects_NEW&utm_term=&utm_content=Rectangular%20Connectors%20-%20Headers%2C%20Male%20Pins&gclid=Cj0KCQjwk5ibBhDqARIsACzmgLT_BecTMQOXsjBWujGoGePzcsLLlSbvZqpU-GjEZv7xqoAvx4UwJ9kaAm1_EALw_wcB",
            "display_url" : "digikey.com/en/products/de…",
            "indices" : [
              "13",
              "36"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1588933192903405568",
      "id_str" : "1588950924567117824",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588950924567117824",
      "in_reply_to_status_id" : "1588933192903405568",
      "possibly_sensitive" : false,
      "created_at" : "Sat Nov 05 17:46:36 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev https://t.co/O5k2Fy91tg\nis all you need",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588357913856602112"
          ],
          "editableUntil" : "2022-11-04T03:00:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Michael Rangen",
            "screen_name" : "RangenMichael",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1346140504073768966",
            "id" : "1346140504073768966"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1588224011666063361",
      "id_str" : "1588357913856602112",
      "in_reply_to_user_id" : "1346140504073768966",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588357913856602112",
      "in_reply_to_status_id" : "1588224011666063361",
      "created_at" : "Fri Nov 04 02:30:11 +0000 2022",
      "favorited" : false,
      "full_text" : "@RangenMichael Congratulations!",
      "lang" : "en",
      "in_reply_to_screen_name" : "RangenMichael",
      "in_reply_to_user_id_str" : "1346140504073768966"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588169261834543106"
          ],
          "editableUntil" : "2022-11-03T14:30:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          },
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "15",
              "27"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          },
          {
            "name" : "🌟𝘾𝙮𝙗𝙚𝙧 𝘾𝙞𝙩𝙮 𝘾𝙞𝙧𝙘𝙪𝙞𝙩𝙨🌟",
            "screen_name" : "MakeAugusta",
            "indices" : [
              "28",
              "40"
            ],
            "id_str" : "957972848714440704",
            "id" : "957972848714440704"
          },
          {
            "name" : "Digi-Key Electronics",
            "screen_name" : "digikey",
            "indices" : [
              "41",
              "49"
            ],
            "id_str" : "17346756",
            "id" : "17346756"
          },
          {
            "name" : "adafruit industries",
            "screen_name" : "adafruit",
            "indices" : [
              "50",
              "59"
            ],
            "id_str" : "20731304",
            "id" : "20731304"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "151"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1588166867071295488",
      "id_str" : "1588169261834543106",
      "in_reply_to_user_id" : "4918794850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588169261834543106",
      "in_reply_to_status_id" : "1588166867071295488",
      "created_at" : "Thu Nov 03 14:00:33 +0000 2022",
      "favorited" : false,
      "full_text" : "@anne_engineer @TreasureDev @MakeAugusta @digikey @adafruit How come I never watched these videos. Great tutorials. Hopefully I can master it sometime.",
      "lang" : "en",
      "in_reply_to_screen_name" : "anne_engineer",
      "in_reply_to_user_id_str" : "4918794850"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588156968446877696"
          ],
          "editableUntil" : "2022-11-03T13:41:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          },
          {
            "name" : "🌟𝘾𝙮𝙗𝙚𝙧 𝘾𝙞𝙩𝙮 𝘾𝙞𝙧𝙘𝙪𝙞𝙩𝙨🌟",
            "screen_name" : "MakeAugusta",
            "indices" : [
              "13",
              "25"
            ],
            "id_str" : "957972848714440704",
            "id" : "957972848714440704"
          },
          {
            "name" : "Digi-Key Electronics",
            "screen_name" : "digikey",
            "indices" : [
              "26",
              "34"
            ],
            "id_str" : "17346756",
            "id" : "17346756"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "282"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1588013007115780103",
      "id_str" : "1588156968446877696",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588156968446877696",
      "in_reply_to_status_id" : "1588013007115780103",
      "created_at" : "Thu Nov 03 13:11:42 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev @MakeAugusta @digikey For years I have been using it through Google Shopping and select vendor digikey. That is probably the only feasible way of searching for an item there. I sort of know it has many other functions but don't bother exploring because of the messy UX.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1588003205618798594"
          ],
          "editableUntil" : "2022-11-03T03:30:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "235"
      ],
      "favorite_count" : "7",
      "id_str" : "1588003205618798594",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1588003205618798594",
      "created_at" : "Thu Nov 03 03:00:42 +0000 2022",
      "favorited" : false,
      "full_text" : "So happy that I just fixed a bug that has been there in the CircuitPython online IDE since day one. It took me more than a year to locate the real problem. Now it won't freeze any more when receives 2000+ lines of data from the serial.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1587644339328413697"
          ],
          "editableUntil" : "2022-11-02T03:44:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/j2b4hsQMlI",
            "expanded_url" : "https://docs.circuitpython.org/en/latest/shared-bindings/supervisor/index.html#supervisor.StatusBar",
            "display_url" : "docs.circuitpython.org/en/latest/shar…",
            "indices" : [
              "70",
              "93"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "93"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1587641979407564803",
      "id_str" : "1587644339328413697",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1587644339328413697",
      "in_reply_to_status_id" : "1587641979407564803",
      "possibly_sensitive" : false,
      "created_at" : "Wed Nov 02 03:14:42 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev Actually, you can turn it off if you find that annoying. https://t.co/j2b4hsQMlI",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1587626530917728256"
          ],
          "editableUntil" : "2022-11-02T02:33:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/MbMYEkP3R6",
            "expanded_url" : "https://urfdvw.github.io/CircuitPython-online-IDE/",
            "display_url" : "urfdvw.github.io/CircuitPython-…",
            "indices" : [
              "102",
              "125"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1587626530917728256/photo/1",
            "indices" : [
              "126",
              "149"
            ],
            "url" : "https://t.co/KqvrqaMAud",
            "media_url" : "http://pbs.twimg.com/media/Fghh0YgWQAEKriA.jpg",
            "id_str" : "1587626421207318529",
            "id" : "1587626421207318529",
            "media_url_https" : "https://pbs.twimg.com/media/Fghh0YgWQAEKriA.jpg",
            "sizes" : {
              "small" : {
                "w" : "473",
                "h" : "266",
                "resize" : "fit"
              },
              "large" : {
                "w" : "473",
                "h" : "266",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "473",
                "h" : "266",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/KqvrqaMAud"
          }
        ],
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "63",
              "77"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "149"
      ],
      "favorite_count" : "13",
      "id_str" : "1587626530917728256",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1587626530917728256",
      "possibly_sensitive" : false,
      "created_at" : "Wed Nov 02 02:03:56 +0000 2022",
      "favorited" : false,
      "full_text" : "CircuitPython Online IDE now supports Status Bar introduced in #CircuitPython 8.0.0. Try it out here: https://t.co/MbMYEkP3R6 https://t.co/KqvrqaMAud",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1587626530917728256/photo/1",
            "indices" : [
              "126",
              "149"
            ],
            "url" : "https://t.co/KqvrqaMAud",
            "media_url" : "http://pbs.twimg.com/media/Fghh0YgWQAEKriA.jpg",
            "id_str" : "1587626421207318529",
            "id" : "1587626421207318529",
            "media_url_https" : "https://pbs.twimg.com/media/Fghh0YgWQAEKriA.jpg",
            "sizes" : {
              "small" : {
                "w" : "473",
                "h" : "266",
                "resize" : "fit"
              },
              "large" : {
                "w" : "473",
                "h" : "266",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "473",
                "h" : "266",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/KqvrqaMAud"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1586898351596896256"
          ],
          "editableUntil" : "2022-10-31T02:20:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Retro Tech Dreams",
            "screen_name" : "RetroTechDreams",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1541080396837933056",
            "id" : "1541080396837933056"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "22",
      "in_reply_to_status_id_str" : "1586887185449746433",
      "id_str" : "1586898351596896256",
      "in_reply_to_user_id" : "1541080396837933056",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1586898351596896256",
      "in_reply_to_status_id" : "1586887185449746433",
      "created_at" : "Mon Oct 31 01:50:24 +0000 2022",
      "favorited" : false,
      "full_text" : "@RetroTechDreams I still love single function devices.",
      "lang" : "en",
      "in_reply_to_screen_name" : "RetroTechDreams",
      "in_reply_to_user_id_str" : "1541080396837933056"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1585846706901581830"
          ],
          "editableUntil" : "2022-10-28T04:41:33.189Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "🌟𝘾𝙮𝙗𝙚𝙧 𝘾𝙞𝙩𝙮 𝘾𝙞𝙧𝙘𝙪𝙞𝙩𝙨🌟",
            "screen_name" : "MakeAugusta",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "957972848714440704",
            "id" : "957972848714440704"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1585846706901581830",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1585846706901581830",
      "created_at" : "Fri Oct 28 04:11:33 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @MakeAugusta: Under-rated ICs and why? I’ll go first, MCP23017. I think people have been sleeping on this thing. An I2C device that give…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1585355370738089984"
          ],
          "editableUntil" : "2022-10-26T20:09:09.519Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CircuitPython",
            "screen_name" : "CircuitPython",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "811605410293645313",
            "id" : "811605410293645313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "0",
      "id_str" : "1585355370738089984",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1585355370738089984",
      "created_at" : "Wed Oct 26 19:39:09 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @CircuitPython: ICYMI Python on Microcontrollers Newsletter: Halloween Projects, CircuitPython 8 beta 3 &amp; CPython 3.11 out, and more! #C…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1585232295229034496"
          ],
          "editableUntil" : "2022-10-26T12:00:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Kevin Bates",
            "screen_name" : "bateskecom",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "729169855",
            "id" : "729169855"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "107"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1585119278537113600",
      "id_str" : "1585232295229034496",
      "in_reply_to_user_id" : "729169855",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1585232295229034496",
      "in_reply_to_status_id" : "1585119278537113600",
      "created_at" : "Wed Oct 26 11:30:06 +0000 2022",
      "favorited" : false,
      "full_text" : "@bateskecom Wait, I did. For a digispark knockoff. 1.6 is too thin for a bare PCB to be used as a USB port.",
      "lang" : "en",
      "in_reply_to_screen_name" : "bateskecom",
      "in_reply_to_user_id_str" : "729169855"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1585017872710914048"
          ],
          "editableUntil" : "2022-10-25T21:48:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Hackster.io",
            "screen_name" : "Hacksterio",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1473686120",
            "id" : "1473686120"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1584993279598563328",
      "id_str" : "1585017872710914048",
      "in_reply_to_user_id" : "1473686120",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1585017872710914048",
      "in_reply_to_status_id" : "1584993279598563328",
      "created_at" : "Tue Oct 25 21:18:03 +0000 2022",
      "favorited" : false,
      "full_text" : "@Hacksterio And pi zeros are still very expensive.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Hacksterio",
      "in_reply_to_user_id_str" : "1473686120"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1584743107362684929"
          ],
          "editableUntil" : "2022-10-25T03:36:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Phil Shapiro",
            "screen_name" : "philshapiro",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "40720843",
            "id" : "40720843"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1584742599201464320",
      "id_str" : "1584743107362684929",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1584743107362684929",
      "in_reply_to_status_id" : "1584742599201464320",
      "created_at" : "Tue Oct 25 03:06:14 +0000 2022",
      "favorited" : false,
      "full_text" : "@philshapiro Just Googled, 186C to be specific.",
      "lang" : "en",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1584742599201464320"
          ],
          "editableUntil" : "2022-10-25T03:34:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Phil Shapiro",
            "screen_name" : "philshapiro",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "40720843",
            "id" : "40720843"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "106"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1584737601080082435",
      "id_str" : "1584742599201464320",
      "in_reply_to_user_id" : "40720843",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1584742599201464320",
      "in_reply_to_status_id" : "1584737601080082435",
      "created_at" : "Tue Oct 25 03:04:13 +0000 2022",
      "favorited" : false,
      "full_text" : "@philshapiro Fun fact: melted sugar can be hotter than 100c. Just tried today, my cat was scared to death.",
      "lang" : "en",
      "in_reply_to_screen_name" : "philshapiro",
      "in_reply_to_user_id_str" : "40720843"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1584343730059759616"
          ],
          "editableUntil" : "2022-10-24T01:09:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CedarGrove (@cedargrove@mastodon.cloud)",
            "screen_name" : "CedarGroveMakr",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1014021799359627265",
            "id" : "1014021799359627265"
          },
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "16",
              "30"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1584327426863435777",
      "id_str" : "1584343730059759616",
      "in_reply_to_user_id" : "1014021799359627265",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1584343730059759616",
      "in_reply_to_status_id" : "1584327426863435777",
      "created_at" : "Mon Oct 24 00:39:15 +0000 2022",
      "favorited" : false,
      "full_text" : "@CedarGroveMakr @anne_engineer Will try!",
      "lang" : "en",
      "in_reply_to_screen_name" : "CedarGroveMakr",
      "in_reply_to_user_id_str" : "1014021799359627265"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1584011925259591680"
          ],
          "editableUntil" : "2022-10-23T03:10:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1584007607810871298",
      "id_str" : "1584011925259591680",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1584011925259591680",
      "in_reply_to_status_id" : "1584007607810871298",
      "created_at" : "Sun Oct 23 02:40:47 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev Good catch. Will fix.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1583949972122181632"
          ],
          "editableUntil" : "2022-10-22T23:04:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "29",
              "43"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/scQ1Q0zh46",
            "expanded_url" : "https://learn.adafruit.com/creating-and-sharing-a-circuitpython-library/creating-a-library",
            "display_url" : "learn.adafruit.com/creating-and-s…",
            "indices" : [
              "53",
              "76"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "76"
      ],
      "favorite_count" : "5",
      "in_reply_to_status_id_str" : "1583949377072033792",
      "id_str" : "1583949972122181632",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1583949972122181632",
      "in_reply_to_status_id" : "1583949377072033792",
      "possibly_sensitive" : false,
      "created_at" : "Sat Oct 22 22:34:36 +0000 2022",
      "favorited" : false,
      "full_text" : "TODO: learn how to publish a #CircuitPython library.\nhttps://t.co/scQ1Q0zh46",
      "lang" : "en",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1583949377072033792"
          ],
          "editableUntil" : "2022-10-22T23:02:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "66",
              "80"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/LqKgj6DLJ7",
            "expanded_url" : "https://github.com/urfdvw/CircuitPython_keypadi2c",
            "display_url" : "github.com/urfdvw/Circuit…",
            "indices" : [
              "213",
              "236"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "236"
      ],
      "favorite_count" : "6",
      "id_str" : "1583949377072033792",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1583949377072033792",
      "possibly_sensitive" : false,
      "created_at" : "Sat Oct 22 22:32:14 +0000 2022",
      "favorited" : false,
      "full_text" : "As a side product of my CircuitPython Keyboard project. I wrote a #CircuitPython library that \"extends\" the native keypad library to support MCP I2C IO expanders, where each IO pin is connected to a key switch.  \nhttps://t.co/LqKgj6DLJ7",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1583873114391203840"
          ],
          "editableUntil" : "2022-10-22T17:59:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Programmer Humor",
            "screen_name" : "PR0GRAMMERHUM0R",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "965774983527043072",
            "id" : "965774983527043072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "75"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1583654404431183872",
      "id_str" : "1583873114391203840",
      "in_reply_to_user_id" : "965774983527043072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1583873114391203840",
      "in_reply_to_status_id" : "1583654404431183872",
      "created_at" : "Sat Oct 22 17:29:12 +0000 2022",
      "favorited" : false,
      "full_text" : "@PR0GRAMMERHUM0R You Python players can just take them as C-style shebangs.",
      "lang" : "en",
      "in_reply_to_screen_name" : "PR0GRAMMERHUM0R",
      "in_reply_to_user_id_str" : "965774983527043072"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1507406740807168007"
          ],
          "editableUntil" : "2022-03-25T17:49:07.928Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1507406740807168007/photo/1",
            "indices" : [
              "15",
              "38"
            ],
            "url" : "https://t.co/pf1RswkBy1",
            "media_url" : "http://pbs.twimg.com/media/FOtibcEX0AEODPk.png",
            "id_str" : "1507406723816083457",
            "id" : "1507406723816083457",
            "media_url_https" : "https://pbs.twimg.com/media/FOtibcEX0AEODPk.png",
            "sizes" : {
              "medium" : {
                "w" : "628",
                "h" : "422",
                "resize" : "fit"
              },
              "large" : {
                "w" : "628",
                "h" : "422",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "628",
                "h" : "422",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/pf1RswkBy1"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1507404140108034051",
      "id_str" : "1507406740807168007",
      "in_reply_to_user_id" : "4918794850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1507406740807168007",
      "in_reply_to_status_id" : "1507404140108034051",
      "possibly_sensitive" : false,
      "created_at" : "Fri Mar 25 17:19:07 +0000 2022",
      "favorited" : false,
      "full_text" : "@anne_engineer https://t.co/pf1RswkBy1",
      "lang" : "qme",
      "in_reply_to_screen_name" : "anne_engineer",
      "in_reply_to_user_id_str" : "4918794850",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1507406740807168007/photo/1",
            "indices" : [
              "15",
              "38"
            ],
            "url" : "https://t.co/pf1RswkBy1",
            "media_url" : "http://pbs.twimg.com/media/FOtibcEX0AEODPk.png",
            "id_str" : "1507406723816083457",
            "id" : "1507406723816083457",
            "media_url_https" : "https://pbs.twimg.com/media/FOtibcEX0AEODPk.png",
            "sizes" : {
              "medium" : {
                "w" : "628",
                "h" : "422",
                "resize" : "fit"
              },
              "large" : {
                "w" : "628",
                "h" : "422",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "628",
                "h" : "422",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/pf1RswkBy1"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1507406494026932224"
          ],
          "editableUntil" : "2022-03-25T17:48:09.091Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "200"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1507404140108034051",
      "id_str" : "1507406494026932224",
      "in_reply_to_user_id" : "4918794850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1507406494026932224",
      "in_reply_to_status_id" : "1507404140108034051",
      "created_at" : "Fri Mar 25 17:18:09 +0000 2022",
      "favorited" : false,
      "full_text" : "@anne_engineer Seti@Home, wow, is it still active? I heard about that project when I was a kid. The only app that could max out my 10 cores M1 Pro is Cinebench, the most useless app ever in real life.",
      "lang" : "en",
      "in_reply_to_screen_name" : "anne_engineer",
      "in_reply_to_user_id_str" : "4918794850"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1507403325536415744"
          ],
          "editableUntil" : "2022-03-25T17:35:33.664Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "291"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1507367100599447556",
      "id_str" : "1507403325536415744",
      "in_reply_to_user_id" : "4918794850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1507403325536415744",
      "in_reply_to_status_id" : "1507367100599447556",
      "created_at" : "Fri Mar 25 17:05:33 +0000 2022",
      "favorited" : false,
      "full_text" : "@anne_engineer I always ask questions like, \"when will the software be optimized for the new hardware?\" I got an apple silicon laptop last year, and CPU usage never exceeds 30% when doing scientific calculations with Numpy. The BLAS package never used the full capabilities of apple silicon.",
      "lang" : "en",
      "in_reply_to_screen_name" : "anne_engineer",
      "in_reply_to_user_id_str" : "4918794850"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1505709659314966529"
          ],
          "editableUntil" : "2022-03-21T01:25:32.170Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Dana Sibera",
            "screen_name" : "NanoRaptor",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "2312854706",
            "id" : "2312854706"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/NanoRaptor/status/1505693898244440064/photo/1",
            "source_status_id" : "1505693898244440064",
            "indices" : [
              "37",
              "60"
            ],
            "url" : "https://t.co/GWg9FgASRh",
            "media_url" : "http://pbs.twimg.com/media/FOVMke0VIAQkRfN.jpg",
            "id_str" : "1505693840056852484",
            "source_user_id" : "2312854706",
            "id" : "1505693840056852484",
            "media_url_https" : "https://pbs.twimg.com/media/FOVMke0VIAQkRfN.jpg",
            "source_user_id_str" : "2312854706",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "384",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1536",
                "h" : "868",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "678",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1505693898244440064",
            "display_url" : "pic.twitter.com/GWg9FgASRh"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "0",
      "id_str" : "1505709659314966529",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1505709659314966529",
      "possibly_sensitive" : false,
      "created_at" : "Mon Mar 21 00:55:32 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @NanoRaptor: IBM ThinkPod Classic https://t.co/GWg9FgASRh",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/NanoRaptor/status/1505693898244440064/photo/1",
            "source_status_id" : "1505693898244440064",
            "indices" : [
              "37",
              "60"
            ],
            "url" : "https://t.co/GWg9FgASRh",
            "media_url" : "http://pbs.twimg.com/media/FOVMke0VIAQkRfN.jpg",
            "id_str" : "1505693840056852484",
            "source_user_id" : "2312854706",
            "id" : "1505693840056852484",
            "media_url_https" : "https://pbs.twimg.com/media/FOVMke0VIAQkRfN.jpg",
            "source_user_id_str" : "2312854706",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "384",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1536",
                "h" : "868",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "678",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1505693898244440064",
            "display_url" : "pic.twitter.com/GWg9FgASRh"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1502385180534788098"
          ],
          "editableUntil" : "2022-03-11T21:15:14.663Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Bret Berger 🇺🇦",
            "screen_name" : "BretBerger",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "18893657",
            "id" : "18893657"
          },
          {
            "name" : "Arduino",
            "screen_name" : "arduino",
            "indices" : [
              "12",
              "20"
            ],
            "id_str" : "266400754",
            "id" : "266400754"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "84"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1502364137862705155",
      "id_str" : "1502385180534788098",
      "in_reply_to_user_id" : "18893657",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1502385180534788098",
      "in_reply_to_status_id" : "1502364137862705155",
      "created_at" : "Fri Mar 11 20:45:14 +0000 2022",
      "favorited" : false,
      "full_text" : "@BretBerger @arduino Add face recognition then. If it is a cat, give the whole roll.",
      "lang" : "en",
      "in_reply_to_screen_name" : "BretBerger",
      "in_reply_to_user_id_str" : "18893657"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1502342807494799360"
          ],
          "editableUntil" : "2022-03-11T18:26:52.143Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "scottbez1",
            "screen_name" : "scottbez1",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "17183516",
            "id" : "17183516"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1502335672153034753",
      "id_str" : "1502342807494799360",
      "in_reply_to_user_id" : "17183516",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1502342807494799360",
      "in_reply_to_status_id" : "1502335672153034753",
      "created_at" : "Fri Mar 11 17:56:52 +0000 2022",
      "favorited" : false,
      "full_text" : "@scottbez1 Many of my dreams in one elegant piece. Wish I can make my own soon.",
      "lang" : "en",
      "in_reply_to_screen_name" : "scottbez1",
      "in_reply_to_user_id_str" : "17183516"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1502342220145385477"
          ],
          "editableUntil" : "2022-03-11T18:24:32.108Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "scottbez1",
            "screen_name" : "scottbez1",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "17183516",
            "id" : "17183516"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1502342220145385477",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1502342220145385477",
      "created_at" : "Fri Mar 11 17:54:32 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @scottbez1: BLDC gimbal motor + magnetic encoder + round LCD = SmartKnob View: An open-source haptic input knob\n\nQuick teaser below, and…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1500874996712976385"
          ],
          "editableUntil" : "2022-03-07T17:14:18.782Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "arturo182 🐀",
            "screen_name" : "arturo182",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "15699469",
            "id" : "15699469"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1500840941502046213",
      "id_str" : "1500874996712976385",
      "in_reply_to_user_id" : "15699469",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1500874996712976385",
      "in_reply_to_status_id" : "1500840941502046213",
      "created_at" : "Mon Mar 07 16:44:18 +0000 2022",
      "favorited" : false,
      "full_text" : "@arturo182 Reminds me of the lever rule",
      "lang" : "en",
      "in_reply_to_screen_name" : "arturo182",
      "in_reply_to_user_id_str" : "15699469"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1500476008037769216"
          ],
          "editableUntil" : "2022-03-06T14:48:52.469Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Maartje Eyskens (@maartje@blahaj.social)",
            "screen_name" : "MaartjeME",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1483447088",
            "id" : "1483447088"
          },
          {
            "name" : "ln",
            "screen_name" : "tachiniererin",
            "indices" : [
              "11",
              "25"
            ],
            "id_str" : "835402855427293184",
            "id" : "835402855427293184"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1500445526617116684",
      "id_str" : "1500476008037769216",
      "in_reply_to_user_id" : "1483447088",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1500476008037769216",
      "in_reply_to_status_id" : "1500445526617116684",
      "created_at" : "Sun Mar 06 14:18:52 +0000 2022",
      "favorited" : false,
      "full_text" : "@MaartjeME @tachiniererin Just about to say the same.",
      "lang" : "en",
      "in_reply_to_screen_name" : "MaartjeME",
      "in_reply_to_user_id_str" : "1483447088"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1499823519575822338"
          ],
          "editableUntil" : "2022-03-04T19:36:07.097Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Blitz City DIY",
            "screen_name" : "BlitzCityDIY",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "718826820938948608",
            "id" : "718826820938948608"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1499823519575822338/photo/1",
            "indices" : [
              "58",
              "81"
            ],
            "url" : "https://t.co/oepazJ3P1l",
            "media_url" : "http://pbs.twimg.com/media/FNBxiumWUAQ5K0j.jpg",
            "id_str" : "1499823517352742916",
            "id" : "1499823517352742916",
            "media_url_https" : "https://pbs.twimg.com/media/FNBxiumWUAQ5K0j.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/oepazJ3P1l"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "81"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1499537645415940100",
      "id_str" : "1499823519575822338",
      "in_reply_to_user_id" : "718826820938948608",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1499823519575822338",
      "in_reply_to_status_id" : "1499537645415940100",
      "possibly_sensitive" : false,
      "created_at" : "Fri Mar 04 19:06:07 +0000 2022",
      "favorited" : false,
      "full_text" : "@BlitzCityDIY It is fast. Gonna do something interesting. https://t.co/oepazJ3P1l",
      "lang" : "en",
      "in_reply_to_screen_name" : "BlitzCityDIY",
      "in_reply_to_user_id_str" : "718826820938948608",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1499823519575822338/photo/1",
            "indices" : [
              "58",
              "81"
            ],
            "url" : "https://t.co/oepazJ3P1l",
            "media_url" : "http://pbs.twimg.com/media/FNBxiumWUAQ5K0j.jpg",
            "id_str" : "1499823517352742916",
            "id" : "1499823517352742916",
            "media_url_https" : "https://pbs.twimg.com/media/FNBxiumWUAQ5K0j.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/oepazJ3P1l"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1499810649119014912"
          ],
          "editableUntil" : "2022-03-04T18:44:58.541Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Blitz City DIY",
            "screen_name" : "BlitzCityDIY",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "718826820938948608",
            "id" : "718826820938948608"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "209"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1499537645415940100",
      "id_str" : "1499810649119014912",
      "in_reply_to_user_id" : "718826820938948608",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1499810649119014912",
      "in_reply_to_status_id" : "1499537645415940100",
      "created_at" : "Fri Mar 04 18:14:58 +0000 2022",
      "favorited" : false,
      "full_text" : "@BlitzCityDIY I just brought 2 of these from Adafruit. Looks so attractive to me. Probably, I will make an iPod-like device with it. Sorry, I am not so creative. Just feeling nostalgia for my high school days.",
      "lang" : "en",
      "in_reply_to_screen_name" : "BlitzCityDIY",
      "in_reply_to_user_id_str" : "718826820938948608"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1499017092003155974"
          ],
          "editableUntil" : "2022-03-02T14:11:39.781Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Holisale Shop",
            "screen_name" : "holisaleshop",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1485477389157412865",
            "id" : "1485477389157412865"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1493063177952628738",
      "id_str" : "1499017092003155974",
      "in_reply_to_user_id" : "1485477389157412865",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1499017092003155974",
      "in_reply_to_status_id" : "1493063177952628738",
      "created_at" : "Wed Mar 02 13:41:39 +0000 2022",
      "favorited" : false,
      "full_text" : "@holisaleshop Exactly the worst way of learning.",
      "lang" : "en",
      "in_reply_to_screen_name" : "holisaleshop",
      "in_reply_to_user_id_str" : "1485477389157412865"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1496848458476503045"
          ],
          "editableUntil" : "2022-02-24T14:34:17.257Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "hackaday",
            "screen_name" : "hackaday",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "14607140",
            "id" : "14607140"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "81"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1496716009549434882",
      "id_str" : "1496848458476503045",
      "in_reply_to_user_id" : "14607140",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1496848458476503045",
      "in_reply_to_status_id" : "1496716009549434882",
      "created_at" : "Thu Feb 24 14:04:17 +0000 2022",
      "favorited" : false,
      "full_text" : "@hackaday I am too young to understand this. Is this some kind of game time card?",
      "lang" : "en",
      "in_reply_to_screen_name" : "hackaday",
      "in_reply_to_user_id_str" : "14607140"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1496134692340383747"
          ],
          "editableUntil" : "2022-02-22T15:18:02.149Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "aiu🥚",
            "screen_name" : "aiu404l",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "1366451690707120131",
            "id" : "1366451690707120131"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1495791287664279552",
      "id_str" : "1496134692340383747",
      "in_reply_to_user_id" : "1366451690707120131",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1496134692340383747",
      "in_reply_to_status_id" : "1495791287664279552",
      "created_at" : "Tue Feb 22 14:48:02 +0000 2022",
      "favorited" : false,
      "full_text" : "@aiu404l I want this on my switch. This exact one.",
      "lang" : "en",
      "in_reply_to_screen_name" : "aiu404l",
      "in_reply_to_user_id_str" : "1366451690707120131"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1496121771602415624"
          ],
          "editableUntil" : "2022-02-22T14:26:41.605Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FriendlyWire",
            "screen_name" : "FriendlyWire",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1102124503398703104",
            "id" : "1102124503398703104"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "212"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1496120824926986244",
      "id_str" : "1496121771602415624",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1496121771602415624",
      "in_reply_to_status_id" : "1496120824926986244",
      "created_at" : "Tue Feb 22 13:56:41 +0000 2022",
      "favorited" : false,
      "full_text" : "@FriendlyWire And I think that is why TI launchpads are not as popular as Arduino in K12. For K12 pure beginner-level projects, Ardunio document sites are enough, but for launchpads, one needs to read datasheets.",
      "lang" : "en",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1496120824926986244"
          ],
          "editableUntil" : "2022-02-22T14:22:55.900Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FriendlyWire",
            "screen_name" : "FriendlyWire",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1102124503398703104",
            "id" : "1102124503398703104"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "272"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1495942112906469384",
      "id_str" : "1496120824926986244",
      "in_reply_to_user_id" : "1102124503398703104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1496120824926986244",
      "in_reply_to_status_id" : "1495942112906469384",
      "created_at" : "Tue Feb 22 13:52:55 +0000 2022",
      "favorited" : false,
      "full_text" : "@FriendlyWire That will be the way I learn if I need to understand a new MCU. However, beginners are not all the same. Are you talking about adult beginners or colleges students or K-12? In my case, my 7th-G students will not have the brain capacity to swallow that chuck.",
      "lang" : "en",
      "in_reply_to_screen_name" : "FriendlyWire",
      "in_reply_to_user_id_str" : "1102124503398703104"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1495804292040699906"
          ],
          "editableUntil" : "2022-02-21T17:25:08.579Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "🆂🆄🅻🅵🆄🆁🅾🅸🅳",
            "screen_name" : "sulfuroid",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "754617844227305472",
            "id" : "754617844227305472"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "71"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1495791434540199936",
      "id_str" : "1495804292040699906",
      "in_reply_to_user_id" : "754617844227305472",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1495804292040699906",
      "in_reply_to_status_id" : "1495791434540199936",
      "created_at" : "Mon Feb 21 16:55:08 +0000 2022",
      "favorited" : false,
      "full_text" : "@sulfuroid This is neat! Are you using the headphone as the SW antenna?",
      "lang" : "en",
      "in_reply_to_screen_name" : "sulfuroid",
      "in_reply_to_user_id_str" : "754617844227305472"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1495236266765471748"
          ],
          "editableUntil" : "2022-02-20T03:48:00.800Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Guy Dupont",
            "screen_name" : "gvy_dvpont",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "258906098",
            "id" : "258906098"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1495093373534982150",
      "id_str" : "1495236266765471748",
      "in_reply_to_user_id" : "258906098",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1495236266765471748",
      "in_reply_to_status_id" : "1495093373534982150",
      "created_at" : "Sun Feb 20 03:18:00 +0000 2022",
      "favorited" : false,
      "full_text" : "@gvy_dvpont Maybe inside 3D printed lego and build your lego amibo?",
      "lang" : "en",
      "in_reply_to_screen_name" : "gvy_dvpont",
      "in_reply_to_user_id_str" : "258906098"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1491438497882054658"
          ],
          "editableUntil" : "2022-02-09T16:17:02.139Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dana Sibera",
            "screen_name" : "NanoRaptor",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "2312854706",
            "id" : "2312854706"
          },
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "12",
              "26"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1491394851300319234",
      "id_str" : "1491438497882054658",
      "in_reply_to_user_id" : "2312854706",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1491438497882054658",
      "in_reply_to_status_id" : "1491394851300319234",
      "created_at" : "Wed Feb 09 15:47:02 +0000 2022",
      "favorited" : false,
      "full_text" : "@NanoRaptor @anne_engineer This cannot be real.😳",
      "lang" : "en",
      "in_reply_to_screen_name" : "NanoRaptor",
      "in_reply_to_user_id_str" : "2312854706"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1491033718521479171"
          ],
          "editableUntil" : "2022-02-08T13:28:35.219Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "arturo182 🐀",
            "screen_name" : "arturo182",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "15699469",
            "id" : "15699469"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1490731386092797952",
      "id_str" : "1491033718521479171",
      "in_reply_to_user_id" : "15699469",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1491033718521479171",
      "in_reply_to_status_id" : "1490731386092797952",
      "created_at" : "Tue Feb 08 12:58:35 +0000 2022",
      "favorited" : false,
      "full_text" : "@arturo182 Jail versions?",
      "lang" : "en",
      "in_reply_to_screen_name" : "arturo182",
      "in_reply_to_user_id_str" : "15699469"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1490413233349578755"
          ],
          "editableUntil" : "2022-02-06T20:23:00.026Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ミエAC129/アタック工房",
            "screen_name" : "MieAC129",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1095878224456822785",
            "id" : "1095878224456822785"
          },
          {
            "name" : "adafruit industries",
            "screen_name" : "adafruit",
            "indices" : [
              "10",
              "19"
            ],
            "id_str" : "20731304",
            "id" : "20731304"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1490210759238123521",
      "id_str" : "1490413233349578755",
      "in_reply_to_user_id" : "1095878224456822785",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1490413233349578755",
      "in_reply_to_status_id" : "1490210759238123521",
      "created_at" : "Sun Feb 06 19:53:00 +0000 2022",
      "favorited" : false,
      "full_text" : "@MieAC129 @adafruit This is super scary you know.",
      "lang" : "en",
      "in_reply_to_screen_name" : "MieAC129",
      "in_reply_to_user_id_str" : "1095878224456822785"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1490355309201833993"
          ],
          "editableUntil" : "2022-02-06T16:32:49.833Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "sleepy duck pond appreciator 🦆✨🏳️‍🌈",
            "screen_name" : "0x47DF",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "758555881",
            "id" : "758555881"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "19"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1490061360042057732",
      "id_str" : "1490355309201833993",
      "in_reply_to_user_id" : "758555881",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1490355309201833993",
      "in_reply_to_status_id" : "1490061360042057732",
      "created_at" : "Sun Feb 06 16:02:49 +0000 2022",
      "favorited" : false,
      "full_text" : "@0x47DF I have a 10",
      "lang" : "en",
      "in_reply_to_screen_name" : "0x47DF",
      "in_reply_to_user_id_str" : "758555881"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1487863699926884359"
          ],
          "editableUntil" : "2022-01-30T19:32:03.890Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "日下氏（ゆっきー）",
            "screen_name" : "yukkieeeeeen",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "790440869379780608",
            "id" : "790440869379780608"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1487863699926884359/photo/1",
            "indices" : [
              "14",
              "37"
            ],
            "url" : "https://t.co/1vZSfoGGGU",
            "media_url" : "http://pbs.twimg.com/media/FKXz9TmXMAMrdUD.jpg",
            "id_str" : "1487863486474563587",
            "id" : "1487863486474563587",
            "media_url_https" : "https://pbs.twimg.com/media/FKXz9TmXMAMrdUD.jpg",
            "sizes" : {
              "small" : {
                "w" : "399",
                "h" : "414",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "399",
                "h" : "414",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "399",
                "h" : "414",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/1vZSfoGGGU"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "14",
      "in_reply_to_status_id_str" : "1487574884762800128",
      "id_str" : "1487863699926884359",
      "in_reply_to_user_id" : "790440869379780608",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1487863699926884359",
      "in_reply_to_status_id" : "1487574884762800128",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jan 30 19:02:03 +0000 2022",
      "favorited" : false,
      "full_text" : "@yukkieeeeeen https://t.co/1vZSfoGGGU",
      "lang" : "qme",
      "in_reply_to_screen_name" : "yukkieeeeeen",
      "in_reply_to_user_id_str" : "790440869379780608",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1487863699926884359/photo/1",
            "indices" : [
              "14",
              "37"
            ],
            "url" : "https://t.co/1vZSfoGGGU",
            "media_url" : "http://pbs.twimg.com/media/FKXz9TmXMAMrdUD.jpg",
            "id_str" : "1487863486474563587",
            "id" : "1487863486474563587",
            "media_url_https" : "https://pbs.twimg.com/media/FKXz9TmXMAMrdUD.jpg",
            "sizes" : {
              "small" : {
                "w" : "399",
                "h" : "414",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "399",
                "h" : "414",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "399",
                "h" : "414",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/1vZSfoGGGU"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1486761933307060225"
          ],
          "editableUntil" : "2022-01-27T18:34:02.258Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "arturo182 🐀",
            "screen_name" : "arturo182",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "15699469",
            "id" : "15699469"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1486761933307060225/photo/1",
            "indices" : [
              "29",
              "52"
            ],
            "url" : "https://t.co/UVqgevZaBF",
            "media_url" : "http://pbs.twimg.com/media/FKIKFmKXsAgnbW9.jpg",
            "id_str" : "1486761918245351432",
            "id" : "1486761918245351432",
            "media_url_https" : "https://pbs.twimg.com/media/FKIKFmKXsAgnbW9.jpg",
            "sizes" : {
              "large" : {
                "w" : "962",
                "h" : "356",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "252",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "962",
                "h" : "356",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/UVqgevZaBF"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "20",
      "in_reply_to_status_id_str" : "1486749634714390534",
      "id_str" : "1486761933307060225",
      "in_reply_to_user_id" : "15699469",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1486761933307060225",
      "in_reply_to_status_id" : "1486749634714390534",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jan 27 18:04:02 +0000 2022",
      "favorited" : false,
      "full_text" : "@arturo182 I strongly agree. https://t.co/UVqgevZaBF",
      "lang" : "en",
      "in_reply_to_screen_name" : "arturo182",
      "in_reply_to_user_id_str" : "15699469",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1486761933307060225/photo/1",
            "indices" : [
              "29",
              "52"
            ],
            "url" : "https://t.co/UVqgevZaBF",
            "media_url" : "http://pbs.twimg.com/media/FKIKFmKXsAgnbW9.jpg",
            "id_str" : "1486761918245351432",
            "id" : "1486761918245351432",
            "media_url_https" : "https://pbs.twimg.com/media/FKIKFmKXsAgnbW9.jpg",
            "sizes" : {
              "large" : {
                "w" : "962",
                "h" : "356",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "252",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "962",
                "h" : "356",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/UVqgevZaBF"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1486761470213902339"
          ],
          "editableUntil" : "2022-01-27T18:32:11.848Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "@sad_electronics",
            "screen_name" : "sad_electronics",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1062392065240285185",
            "id" : "1062392065240285185"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "83"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1486744103828303874",
      "id_str" : "1486761470213902339",
      "in_reply_to_user_id" : "1062392065240285185",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1486761470213902339",
      "in_reply_to_status_id" : "1486744103828303874",
      "created_at" : "Thu Jan 27 18:02:11 +0000 2022",
      "favorited" : false,
      "full_text" : "@sad_electronics That's so interesting. Just wondering what \"加油北京\" is referring to?",
      "lang" : "en",
      "in_reply_to_screen_name" : "sad_electronics",
      "in_reply_to_user_id_str" : "1062392065240285185"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1486743033475387401"
          ],
          "editableUntil" : "2022-01-27T17:18:56.187Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "@sad_electronics",
            "screen_name" : "sad_electronics",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1062392065240285185",
            "id" : "1062392065240285185"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "105"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1486466436390432768",
      "id_str" : "1486743033475387401",
      "in_reply_to_user_id" : "1062392065240285185",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1486743033475387401",
      "in_reply_to_status_id" : "1486466436390432768",
      "created_at" : "Thu Jan 27 16:48:56 +0000 2022",
      "favorited" : false,
      "full_text" : "@sad_electronics Could you please see the date the document was created in Adobe Reader? I am so curious.",
      "lang" : "en",
      "in_reply_to_screen_name" : "sad_electronics",
      "in_reply_to_user_id_str" : "1062392065240285185"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1486718889601814532"
          ],
          "editableUntil" : "2022-01-27T15:42:59.839Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "radicallabs",
            "screen_name" : "thakaraparambu",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1469537793311338501",
            "id" : "1469537793311338501"
          },
          {
            "name" : "Solder Party",
            "screen_name" : "solderparty",
            "indices" : [
              "16",
              "28"
            ],
            "id_str" : "1258655143815532544",
            "id" : "1258655143815532544"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "87"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1486588123219841027",
      "id_str" : "1486718889601814532",
      "in_reply_to_user_id" : "1469537793311338501",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1486718889601814532",
      "in_reply_to_status_id" : "1486588123219841027",
      "created_at" : "Thu Jan 27 15:12:59 +0000 2022",
      "favorited" : false,
      "full_text" : "@thakaraparambu @solderparty This is so nice. Love it, wish I can also make one myself.",
      "lang" : "en",
      "in_reply_to_screen_name" : "thakaraparambu",
      "in_reply_to_user_id_str" : "1469537793311338501"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1486490599586992129"
          ],
          "editableUntil" : "2022-01-27T00:35:51.258Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Selphie",
            "screen_name" : "selphieusagi",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "40879822",
            "id" : "40879822"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1485983806834176000",
      "id_str" : "1486490599586992129",
      "in_reply_to_user_id" : "40879822",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1486490599586992129",
      "in_reply_to_status_id" : "1485983806834176000",
      "created_at" : "Thu Jan 27 00:05:51 +0000 2022",
      "favorited" : false,
      "full_text" : "@selphieusagi Sorry I cannot see it clearly.",
      "lang" : "en",
      "in_reply_to_screen_name" : "selphieusagi",
      "in_reply_to_user_id_str" : "40879822"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1486180613287727105"
          ],
          "editableUntil" : "2022-01-26T04:04:04.765Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Jeff Eberl",
            "screen_name" : "jeffeb3",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "135322994",
            "id" : "135322994"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1486180613287727105/photo/1",
            "indices" : [
              "38",
              "61"
            ],
            "url" : "https://t.co/DAudmTKRvn",
            "media_url" : "http://pbs.twimg.com/media/FJ_5ZElWUAQQH_E.jpg",
            "id_str" : "1486180611177992196",
            "id" : "1486180611177992196",
            "media_url_https" : "https://pbs.twimg.com/media/FJ_5ZElWUAQQH_E.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/DAudmTKRvn"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1484164310339395593",
      "id_str" : "1486180613287727105",
      "in_reply_to_user_id" : "135322994",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1486180613287727105",
      "in_reply_to_status_id" : "1484164310339395593",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jan 26 03:34:04 +0000 2022",
      "favorited" : false,
      "full_text" : "@jeffeb3 I did what you said. Worked. https://t.co/DAudmTKRvn",
      "lang" : "en",
      "in_reply_to_screen_name" : "jeffeb3",
      "in_reply_to_user_id_str" : "135322994",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1486180613287727105/photo/1",
            "indices" : [
              "38",
              "61"
            ],
            "url" : "https://t.co/DAudmTKRvn",
            "media_url" : "http://pbs.twimg.com/media/FJ_5ZElWUAQQH_E.jpg",
            "id_str" : "1486180611177992196",
            "id" : "1486180611177992196",
            "media_url_https" : "https://pbs.twimg.com/media/FJ_5ZElWUAQQH_E.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/DAudmTKRvn"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1485718905649774595"
          ],
          "editableUntil" : "2022-01-24T21:29:25.086Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "adafruit industries",
            "screen_name" : "adafruit",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "20731304",
            "id" : "20731304"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1485658918864961544",
      "id_str" : "1485718905649774595",
      "in_reply_to_user_id" : "20731304",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1485718905649774595",
      "in_reply_to_status_id" : "1485658918864961544",
      "created_at" : "Mon Jan 24 20:59:25 +0000 2022",
      "favorited" : false,
      "full_text" : "@adafruit I can make that sound with my 3d printers",
      "lang" : "en",
      "in_reply_to_screen_name" : "adafruit",
      "in_reply_to_user_id_str" : "20731304"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1485668595019440128"
          ],
          "editableUntil" : "2022-01-24T18:09:30.097Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Guy Dupont",
            "screen_name" : "gvy_dvpont",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "258906098",
            "id" : "258906098"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1485287482979762176",
      "id_str" : "1485668595019440128",
      "in_reply_to_user_id" : "258906098",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1485668595019440128",
      "in_reply_to_status_id" : "1485287482979762176",
      "created_at" : "Mon Jan 24 17:39:30 +0000 2022",
      "favorited" : false,
      "full_text" : "@gvy_dvpont This happened when I was installing the latest Cpy and libs on 80 Trinket M0s for my students. Oh yes, plus that BOOT drive.",
      "lang" : "en",
      "in_reply_to_screen_name" : "gvy_dvpont",
      "in_reply_to_user_id_str" : "258906098"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1485635640180060162"
          ],
          "editableUntil" : "2022-01-24T15:58:33.051Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dana Sibera",
            "screen_name" : "NanoRaptor",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "2312854706",
            "id" : "2312854706"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1485476094023446528",
      "id_str" : "1485635640180060162",
      "in_reply_to_user_id" : "2312854706",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1485635640180060162",
      "in_reply_to_status_id" : "1485476094023446528",
      "created_at" : "Mon Jan 24 15:28:33 +0000 2022",
      "favorited" : false,
      "full_text" : "@NanoRaptor Is there an ESC key on GB?",
      "lang" : "en",
      "in_reply_to_screen_name" : "NanoRaptor",
      "in_reply_to_user_id_str" : "2312854706"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1485301800794300416"
          ],
          "editableUntil" : "2022-01-23T17:51:59.539Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "teachypiano 🏳️‍🌈",
            "screen_name" : "teachypiano",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "3177460930",
            "id" : "3177460930"
          },
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "13",
              "27"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          },
          {
            "name" : "Ann Coates 🦕🦖",
            "screen_name" : "setoacnna",
            "indices" : [
              "28",
              "38"
            ],
            "id_str" : "841724330962747392",
            "id" : "841724330962747392"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "89"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1485176566309134336",
      "id_str" : "1485301800794300416",
      "in_reply_to_user_id" : "3177460930",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1485301800794300416",
      "in_reply_to_status_id" : "1485176566309134336",
      "created_at" : "Sun Jan 23 17:21:59 +0000 2022",
      "favorited" : false,
      "full_text" : "@teachypiano @anne_engineer @setoacnna Because it is bent, the bird stays there. Why not.",
      "lang" : "en",
      "in_reply_to_screen_name" : "teachypiano",
      "in_reply_to_user_id_str" : "3177460930"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1484541542266195976"
          ],
          "editableUntil" : "2022-01-21T15:30:59.781Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "とよしま",
            "screen_name" : "toyoshim",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "15170204",
            "id" : "15170204"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "id_str" : "1484541542266195976",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1484541542266195976",
      "created_at" : "Fri Jan 21 15:00:59 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @toyoshim: これで正しい実装が複数あるんだから凄いよなぁ（他人事",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1484275128036962305"
          ],
          "editableUntil" : "2022-01-20T21:52:21.679Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jeff Eberl",
            "screen_name" : "jeffeb3",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "135322994",
            "id" : "135322994"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1484164310339395593",
      "id_str" : "1484275128036962305",
      "in_reply_to_user_id" : "135322994",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1484275128036962305",
      "in_reply_to_status_id" : "1484164310339395593",
      "created_at" : "Thu Jan 20 21:22:21 +0000 2022",
      "favorited" : false,
      "full_text" : "@jeffeb3 Will try this first",
      "lang" : "en",
      "in_reply_to_screen_name" : "jeffeb3",
      "in_reply_to_user_id_str" : "135322994"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1484210607784177677"
          ],
          "editableUntil" : "2022-01-20T17:35:58.852Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Lewis Workshop",
            "screen_name" : "LewisWorkshop",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1272490261625667584",
            "id" : "1272490261625667584"
          },
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "15",
              "29"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "184"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1484157074007334914",
      "id_str" : "1484210607784177677",
      "in_reply_to_user_id" : "1272490261625667584",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1484210607784177677",
      "in_reply_to_status_id" : "1484157074007334914",
      "created_at" : "Thu Jan 20 17:05:58 +0000 2022",
      "favorited" : false,
      "full_text" : "@LewisWorkshop @anne_engineer Thanks, but will that cause some trouble to the plastic case of the extruder and the rubber cable? The whole thermal block is fully covered under PLA now.",
      "lang" : "en",
      "in_reply_to_screen_name" : "LewisWorkshop",
      "in_reply_to_user_id_str" : "1272490261625667584"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1484157324436586501"
          ],
          "editableUntil" : "2022-01-20T14:04:15.112Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Timon🛠🐀",
            "screen_name" : "timonsku",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "946429829947252736",
            "id" : "946429829947252736"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1484152388286136326",
      "id_str" : "1484157324436586501",
      "in_reply_to_user_id" : "946429829947252736",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1484157324436586501",
      "in_reply_to_status_id" : "1484152388286136326",
      "created_at" : "Thu Jan 20 13:34:15 +0000 2022",
      "favorited" : false,
      "full_text" : "@timonsku I guess I am going to buy one. Thank you!",
      "lang" : "en",
      "in_reply_to_screen_name" : "timonsku",
      "in_reply_to_user_id_str" : "946429829947252736"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1484027283820187650"
          ],
          "editableUntil" : "2022-01-20T05:27:31.013Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1484027283820187650/photo/1",
            "indices" : [
              "68",
              "91"
            ],
            "url" : "https://t.co/PZtMru69Sz",
            "media_url" : "http://pbs.twimg.com/media/FJhS80UXwAIW_3M.jpg",
            "id_str" : "1484027282008293378",
            "id" : "1484027282008293378",
            "media_url_https" : "https://pbs.twimg.com/media/FJhS80UXwAIW_3M.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/PZtMru69Sz"
          }
        ],
        "hashtags" : [
          {
            "text" : "3Dprinter",
            "indices" : [
              "57",
              "67"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "91"
      ],
      "favorite_count" : "5",
      "id_str" : "1484027283820187650",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1484027283820187650",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jan 20 04:57:31 +0000 2022",
      "favorited" : false,
      "full_text" : "Anyone know if there is any way to rescue this extruder? #3Dprinter https://t.co/PZtMru69Sz",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1484027283820187650/photo/1",
            "indices" : [
              "68",
              "91"
            ],
            "url" : "https://t.co/PZtMru69Sz",
            "media_url" : "http://pbs.twimg.com/media/FJhS80UXwAIW_3M.jpg",
            "id_str" : "1484027282008293378",
            "id" : "1484027282008293378",
            "media_url_https" : "https://pbs.twimg.com/media/FJhS80UXwAIW_3M.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/PZtMru69Sz"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1483858876143394829"
          ],
          "editableUntil" : "2022-01-19T18:18:19.494Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "おぷら技研",
            "screen_name" : "OPLA_TECH",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1187317261662478337",
            "id" : "1187317261662478337"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1483774582729605122",
      "id_str" : "1483858876143394829",
      "in_reply_to_user_id" : "1187317261662478337",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1483858876143394829",
      "in_reply_to_status_id" : "1483774582729605122",
      "created_at" : "Wed Jan 19 17:48:19 +0000 2022",
      "favorited" : false,
      "full_text" : "@OPLA_TECH The BGM......",
      "lang" : "in",
      "in_reply_to_screen_name" : "OPLA_TECH",
      "in_reply_to_user_id_str" : "1187317261662478337"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1483794900424577028"
          ],
          "editableUntil" : "2022-01-19T14:04:06.494Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "𝐟𝐚𝐫𝐡𝐚𝐝 𝐤𝐚𝐢𝐬𝐞𝐫",
            "screen_name" : "farhadkaiser2",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1023204465011113984",
            "id" : "1023204465011113984"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/farhadkaiser2/status/1483496458364268546/video/1",
            "source_status_id" : "1483496458364268546",
            "indices" : [
              "107",
              "130"
            ],
            "url" : "https://t.co/6EYt5Ocfy5",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1483496431252287488/pu/img/fPdrW9iBoAo10i_P.jpg",
            "id_str" : "1483496431252287488",
            "source_user_id" : "1023204465011113984",
            "id" : "1483496431252287488",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1483496431252287488/pu/img/fPdrW9iBoAo10i_P.jpg",
            "source_user_id_str" : "1023204465011113984",
            "sizes" : {
              "small" : {
                "w" : "544",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "576",
                "h" : "720",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "576",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1483496458364268546",
            "display_url" : "pic.twitter.com/6EYt5Ocfy5"
          }
        ],
        "hashtags" : [
          {
            "text" : "Remote",
            "indices" : [
              "19",
              "26"
            ]
          },
          {
            "text" : "𝐒𝐜𝐢𝐞𝐧𝐜𝐞𝐀𝐧𝐝𝐓𝐞𝐜𝐡𝐧𝐨𝐥𝐨𝐠𝐲",
            "indices" : [
              "62",
              "83"
            ]
          },
          {
            "text" : "𝐈𝐧𝐧𝐨𝐯𝐚𝐭𝐢𝐨𝐧𝐅𝐨𝐫𝐄𝐯𝐞𝐫𝐲𝐨𝐧𝐞",
            "indices" : [
              "84",
              "106"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "130"
      ],
      "favorite_count" : "0",
      "id_str" : "1483794900424577028",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1483794900424577028",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jan 19 13:34:06 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @farhadkaiser2: #Remote Control Stair Climbing Wheelchair.\n#𝐒𝐜𝐢𝐞𝐧𝐜𝐞𝐀𝐧𝐝𝐓𝐞𝐜𝐡𝐧𝐨𝐥𝐨𝐠𝐲 #𝐈𝐧𝐧𝐨𝐯𝐚𝐭𝐢𝐨𝐧𝐅𝐨𝐫𝐄𝐯𝐞𝐫𝐲𝐨𝐧𝐞 https://t.co/6EYt5Ocfy5",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/farhadkaiser2/status/1483496458364268546/video/1",
            "source_status_id" : "1483496458364268546",
            "indices" : [
              "107",
              "130"
            ],
            "url" : "https://t.co/6EYt5Ocfy5",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1483496431252287488/pu/img/fPdrW9iBoAo10i_P.jpg",
            "id_str" : "1483496431252287488",
            "video_info" : {
              "aspect_ratio" : [
                "4",
                "5"
              ],
              "duration_millis" : "16137",
              "variants" : [
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1483496431252287488/pu/vid/576x720/G4JPh3mJ5KbH_Hfv.mp4?tag=12"
                },
                {
                  "bitrate" : "632000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1483496431252287488/pu/vid/320x400/o2OMs8nCfTFayZEA.mp4?tag=12"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1483496431252287488/pu/pl/G51SXVVIz6Y-KQM7.m3u8?tag=12&container=fmp4"
                },
                {
                  "bitrate" : "950000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1483496431252287488/pu/vid/480x600/4l-WHv57D7VTF_hl.mp4?tag=12"
                }
              ]
            },
            "source_user_id" : "1023204465011113984",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1483496431252287488",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1483496431252287488/pu/img/fPdrW9iBoAo10i_P.jpg",
            "source_user_id_str" : "1023204465011113984",
            "sizes" : {
              "small" : {
                "w" : "544",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "576",
                "h" : "720",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "576",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1483496458364268546",
            "display_url" : "pic.twitter.com/6EYt5Ocfy5"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1483546256479854603"
          ],
          "editableUntil" : "2022-01-18T21:36:05.158Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dean Woodyatt",
            "screen_name" : "Dean_Woodyatt",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "206610801",
            "id" : "206610801"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1483442344313692163",
      "id_str" : "1483546256479854603",
      "in_reply_to_user_id" : "206610801",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1483546256479854603",
      "in_reply_to_status_id" : "1483442344313692163",
      "created_at" : "Tue Jan 18 21:06:05 +0000 2022",
      "favorited" : false,
      "full_text" : "@Dean_Woodyatt Did you tried harshkey to repurpose the key?",
      "lang" : "en",
      "in_reply_to_screen_name" : "Dean_Woodyatt",
      "in_reply_to_user_id_str" : "206610801"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1483304257436721159"
          ],
          "editableUntil" : "2022-01-18T05:34:28.090Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Snoo's Keyboards",
            "screen_name" : "redditmechbot",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "3270355074",
            "id" : "3270355074"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "104"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1482950031464349696",
      "id_str" : "1483304257436721159",
      "in_reply_to_user_id" : "3270355074",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1483304257436721159",
      "in_reply_to_status_id" : "1482950031464349696",
      "created_at" : "Tue Jan 18 05:04:28 +0000 2022",
      "favorited" : false,
      "full_text" : "@redditmechbot Keep away from 95% if you use arrow keys a lot. That is the only layout hides arrow keys.",
      "lang" : "en",
      "in_reply_to_screen_name" : "redditmechbot",
      "in_reply_to_user_id_str" : "3270355074"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1483274834977169409"
          ],
          "editableUntil" : "2022-01-18T03:37:33.229Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Sarah Dvojack",
            "screen_name" : "sarahdvojack",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "372482716",
            "id" : "372482716"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1482833474876850177",
      "id_str" : "1483274834977169409",
      "in_reply_to_user_id" : "372482716",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1483274834977169409",
      "in_reply_to_status_id" : "1482833474876850177",
      "created_at" : "Tue Jan 18 03:07:33 +0000 2022",
      "favorited" : false,
      "full_text" : "@sarahdvojack Let's make one then.",
      "lang" : "en",
      "in_reply_to_screen_name" : "sarahdvojack",
      "in_reply_to_user_id_str" : "372482716"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1483067695314743299"
          ],
          "editableUntil" : "2022-01-17T13:54:27.285Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Adriana Porter Felt",
            "screen_name" : "__apf__",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "533539874",
            "id" : "533539874"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1482785181895303178",
      "id_str" : "1483067695314743299",
      "in_reply_to_user_id" : "533539874",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1483067695314743299",
      "in_reply_to_status_id" : "1482785181895303178",
      "created_at" : "Mon Jan 17 13:24:27 +0000 2022",
      "favorited" : false,
      "full_text" : "@__apf__ I have been teaching from my bedroom for half a year.",
      "lang" : "en",
      "in_reply_to_screen_name" : "__apf__",
      "in_reply_to_user_id_str" : "533539874"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1482452017092169741"
          ],
          "editableUntil" : "2022-01-15T21:07:58.158Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "@sad_electronics",
            "screen_name" : "sad_electronics",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1062392065240285185",
            "id" : "1062392065240285185"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1482413557358772233",
      "id_str" : "1482452017092169741",
      "in_reply_to_user_id" : "1062392065240285185",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1482452017092169741",
      "in_reply_to_status_id" : "1482413557358772233",
      "created_at" : "Sat Jan 15 20:37:58 +0000 2022",
      "favorited" : false,
      "full_text" : "@sad_electronics Oh my this is spreading",
      "lang" : "en",
      "in_reply_to_screen_name" : "sad_electronics",
      "in_reply_to_user_id_str" : "1062392065240285185"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1482369134889476100"
          ],
          "editableUntil" : "2022-01-15T15:38:37.501Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "70",
              "84"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/e6G3MlxAW6",
            "expanded_url" : "https://youtu.be/Pg17iSOyjxU",
            "display_url" : "youtu.be/Pg17iSOyjxU",
            "indices" : [
              "85",
              "108"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "108"
      ],
      "favorite_count" : "3",
      "id_str" : "1482369134889476100",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1482369134889476100",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jan 15 15:08:37 +0000 2022",
      "favorited" : false,
      "full_text" : "【CircuitPython IDE】A new Cpy library that does line-by-line debugging #CircuitPython\nhttps://t.co/e6G3MlxAW6",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1481996037132849158"
          ],
          "editableUntil" : "2022-01-14T14:56:04.064Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dana Sibera",
            "screen_name" : "NanoRaptor",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "2312854706",
            "id" : "2312854706"
          },
          {
            "name" : "adafruit industries",
            "screen_name" : "adafruit",
            "indices" : [
              "12",
              "21"
            ],
            "id_str" : "20731304",
            "id" : "20731304"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1375628710141825025",
      "id_str" : "1481996037132849158",
      "in_reply_to_user_id" : "2312854706",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1481996037132849158",
      "in_reply_to_status_id" : "1375628710141825025",
      "created_at" : "Fri Jan 14 14:26:04 +0000 2022",
      "favorited" : false,
      "full_text" : "@NanoRaptor @adafruit 我读书少，不要骗我。",
      "lang" : "zh",
      "in_reply_to_screen_name" : "NanoRaptor",
      "in_reply_to_user_id_str" : "2312854706"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1481310049201008646"
          ],
          "editableUntil" : "2022-01-12T17:30:11.796Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "タマゴさん",
            "screen_name" : "86723nasogamat",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "2928362778",
            "id" : "2928362778"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1481169014873538561",
      "id_str" : "1481310049201008646",
      "in_reply_to_user_id" : "2928362778",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1481310049201008646",
      "in_reply_to_status_id" : "1481169014873538561",
      "created_at" : "Wed Jan 12 17:00:11 +0000 2022",
      "favorited" : false,
      "full_text" : "@86723nasogamat 精湛刀法，砍得恰到好处。",
      "lang" : "zh",
      "in_reply_to_screen_name" : "86723nasogamat",
      "in_reply_to_user_id_str" : "2928362778"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1480330110091866119"
          ],
          "editableUntil" : "2022-01-10T00:36:16.106Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "arturo182 🐀",
            "screen_name" : "arturo182",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "15699469",
            "id" : "15699469"
          },
          {
            "name" : "KiCad PCB",
            "screen_name" : "kicad_pcb",
            "indices" : [
              "11",
              "21"
            ],
            "id_str" : "571812285",
            "id" : "571812285"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1480266156871233536",
      "id_str" : "1480330110091866119",
      "in_reply_to_user_id" : "15699469",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1480330110091866119",
      "in_reply_to_status_id" : "1480266156871233536",
      "created_at" : "Mon Jan 10 00:06:16 +0000 2022",
      "favorited" : false,
      "full_text" : "@arturo182 @kicad_pcb What if the other device also has TX RX on the right side?",
      "lang" : "en",
      "in_reply_to_screen_name" : "arturo182",
      "in_reply_to_user_id_str" : "15699469"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1479118267092402185"
          ],
          "editableUntil" : "2022-01-06T16:20:50.220Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "hackaday",
            "screen_name" : "hackaday",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "14607140",
            "id" : "14607140"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "71"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1478811354043666442",
      "id_str" : "1479118267092402185",
      "in_reply_to_user_id" : "14607140",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1479118267092402185",
      "in_reply_to_status_id" : "1478811354043666442",
      "created_at" : "Thu Jan 06 15:50:50 +0000 2022",
      "favorited" : false,
      "full_text" : "@hackaday I don't mind short-circuiting some of my old 500 mA chargers.",
      "lang" : "en",
      "in_reply_to_screen_name" : "hackaday",
      "in_reply_to_user_id_str" : "14607140"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1478724556282019842"
          ],
          "editableUntil" : "2022-01-05T14:16:22.248Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "高坂",
            "screen_name" : "t_takasaka",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1014720986",
            "id" : "1014720986"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1478724556282019842",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1478724556282019842",
      "created_at" : "Wed Jan 05 13:46:22 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @t_takasaka: スケッチからイラストをリアルタイムで自動生成する実験をしています。\nこれまで全く絵を描いたことがない人でも、それなりのクオリティのイラストを短時間で描けるようになればいいなと考えています。\n次はパラメータスライダーを追加して、描いた後に画風や形状…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1478723349299838981"
          ],
          "editableUntil" : "2022-01-05T14:11:34.481Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "hackaday",
            "screen_name" : "hackaday",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "14607140",
            "id" : "14607140"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1478543521611137027",
      "id_str" : "1478723349299838981",
      "in_reply_to_user_id" : "14607140",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1478723349299838981",
      "in_reply_to_status_id" : "1478543521611137027",
      "created_at" : "Wed Jan 05 13:41:34 +0000 2022",
      "favorited" : false,
      "full_text" : "@hackaday One for nose one for neck",
      "lang" : "en",
      "in_reply_to_screen_name" : "hackaday",
      "in_reply_to_user_id_str" : "14607140"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1478170250336161792"
          ],
          "editableUntil" : "2022-01-04T01:33:45.412Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "koya-ura",
            "screen_name" : "chisa7ha8wa",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1026112756733304833",
            "id" : "1026112756733304833"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1478021984307249153",
      "id_str" : "1478170250336161792",
      "in_reply_to_user_id" : "1026112756733304833",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1478170250336161792",
      "in_reply_to_status_id" : "1478021984307249153",
      "created_at" : "Tue Jan 04 01:03:45 +0000 2022",
      "favorited" : false,
      "full_text" : "@chisa7ha8wa Glad to hear that. I will keep working on this project and improving it.",
      "lang" : "en",
      "in_reply_to_screen_name" : "chisa7ha8wa",
      "in_reply_to_user_id_str" : "1026112756733304833"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1478025056357912579"
          ],
          "editableUntil" : "2022-01-03T15:56:48.470Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AR",
            "indices" : [
              "48",
              "51"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Franco Ronconi 🇮🇹",
            "screen_name" : "FrRonconi",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "1409726425",
            "id" : "1409726425"
          },
          {
            "name" : "Raspberry Pi",
            "screen_name" : "Raspberry_Pi",
            "indices" : [
              "114",
              "127"
            ],
            "id_str" : "302666251",
            "id" : "302666251"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1478025056357912579",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1478025056357912579",
      "created_at" : "Mon Jan 03 15:26:48 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @FrRonconi: A very cool and practical use of #AR:\nvisual explanations of real world objects, demonstrated with @Raspberry_Pi\n\n#Augmented…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1478002065196597249"
          ],
          "editableUntil" : "2022-01-03T14:25:26.950Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "koya-ura",
            "screen_name" : "chisa7ha8wa",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1026112756733304833",
            "id" : "1026112756733304833"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/MbMYEkP3R6",
            "expanded_url" : "https://urfdvw.github.io/CircuitPython-online-IDE/",
            "display_url" : "urfdvw.github.io/CircuitPython-…",
            "indices" : [
              "205",
              "228"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "228"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1477651182525227011",
      "id_str" : "1478002065196597249",
      "in_reply_to_user_id" : "1026112756733304833",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1478002065196597249",
      "in_reply_to_status_id" : "1477651182525227011",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jan 03 13:55:26 +0000 2022",
      "favorited" : false,
      "full_text" : "@chisa7ha8wa I recently published an online IDE for CircuitPython. Because it is purely browser-based it might be handy in some situations. Would you like to give it a try? Any feedbacks are very welcome. https://t.co/MbMYEkP3R6",
      "lang" : "en",
      "in_reply_to_screen_name" : "chisa7ha8wa",
      "in_reply_to_user_id_str" : "1026112756733304833"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1477492636487454720"
          ],
          "editableUntil" : "2022-01-02T04:41:09.681Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "60",
              "74"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/1ItIPwHRNX",
            "expanded_url" : "https://youtu.be/QL8hLER7wAg",
            "display_url" : "youtu.be/QL8hLER7wAg",
            "indices" : [
              "75",
              "98"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "98"
      ],
      "favorite_count" : "6",
      "id_str" : "1477492636487454720",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1477492636487454720",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jan 02 04:11:09 +0000 2022",
      "favorited" : false,
      "full_text" : "【CircuitPython IDE】Introduction to CircuitPython Online IDE #CircuitPython https://t.co/1ItIPwHRNX",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1477141204546510850"
          ],
          "editableUntil" : "2022-01-01T05:24:41.777Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "163",
              "177"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/MbMYEkP3R6",
            "expanded_url" : "https://urfdvw.github.io/CircuitPython-online-IDE/",
            "display_url" : "urfdvw.github.io/CircuitPython-…",
            "indices" : [
              "178",
              "201"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "201"
      ],
      "favorite_count" : "1",
      "id_str" : "1477141204546510850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1477141204546510850",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jan 01 04:54:41 +0000 2022",
      "favorited" : false,
      "full_text" : "Happy New Year!🥳🥳\nI am glad to announce that CircuitPython Online IDE is now based on the Ace editor. You will find it much nicer and easier to use. Enjoy Coding! #CircuitPython https://t.co/MbMYEkP3R6",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1476991442040020992"
          ],
          "editableUntil" : "2021-12-31T19:29:35.613Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "hackaday",
            "screen_name" : "hackaday",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "14607140",
            "id" : "14607140"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1476568957251428354",
      "id_str" : "1476991442040020992",
      "in_reply_to_user_id" : "14607140",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1476991442040020992",
      "in_reply_to_status_id" : "1476568957251428354",
      "created_at" : "Fri Dec 31 18:59:35 +0000 2021",
      "favorited" : false,
      "full_text" : "@hackaday DIY cars will be a thing. Definitely will.",
      "lang" : "en",
      "in_reply_to_screen_name" : "hackaday",
      "in_reply_to_user_id_str" : "14607140"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1476390099625680899"
          ],
          "editableUntil" : "2021-12-30T03:40:04.409Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Scott Shawcroft (@tannewt@mastodon.online)",
            "screen_name" : "tannewt",
            "indices" : [
              "143",
              "151"
            ],
            "id_str" : "49555459",
            "id" : "49555459"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1476390099625680899/photo/1",
            "indices" : [
              "188",
              "211"
            ],
            "url" : "https://t.co/OuTeMQUmvJ",
            "media_url" : "http://pbs.twimg.com/media/FH0u7z6X0AA9lCI.png",
            "id_str" : "1476387857929588736",
            "id" : "1476387857929588736",
            "media_url_https" : "https://pbs.twimg.com/media/FH0u7z6X0AA9lCI.png",
            "sizes" : {
              "large" : {
                "w" : "858",
                "h" : "480",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "380",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "858",
                "h" : "480",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/OuTeMQUmvJ"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "211"
      ],
      "favorite_count" : "7",
      "id_str" : "1476390099625680899",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1476390099625680899",
      "possibly_sensitive" : false,
      "created_at" : "Thu Dec 30 03:10:04 +0000 2021",
      "favorited" : false,
      "full_text" : "I started rewriting CircuitPython Online IDE based on Ace editor, which will be much nicer than the current version. I should have listened to @tannewt and abandoned CodeMirrow 5 earlier. https://t.co/OuTeMQUmvJ",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1476390099625680899/photo/1",
            "indices" : [
              "188",
              "211"
            ],
            "url" : "https://t.co/OuTeMQUmvJ",
            "media_url" : "http://pbs.twimg.com/media/FH0u7z6X0AA9lCI.png",
            "id_str" : "1476387857929588736",
            "id" : "1476387857929588736",
            "media_url_https" : "https://pbs.twimg.com/media/FH0u7z6X0AA9lCI.png",
            "sizes" : {
              "large" : {
                "w" : "858",
                "h" : "480",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "380",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "858",
                "h" : "480",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/OuTeMQUmvJ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1476255030713929730"
          ],
          "editableUntil" : "2021-12-29T18:43:21.471Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "hackaday",
            "screen_name" : "hackaday",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "14607140",
            "id" : "14607140"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1476165487453097987",
      "id_str" : "1476255030713929730",
      "in_reply_to_user_id" : "14607140",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1476255030713929730",
      "in_reply_to_status_id" : "1476165487453097987",
      "created_at" : "Wed Dec 29 18:13:21 +0000 2021",
      "favorited" : false,
      "full_text" : "@hackaday This 3D printed melted candle is so realistic, I should try it myself.",
      "lang" : "en",
      "in_reply_to_screen_name" : "hackaday",
      "in_reply_to_user_id_str" : "14607140"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1476253465265459206"
          ],
          "editableUntil" : "2021-12-29T18:37:08.239Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Vala Afshar",
            "screen_name" : "ValaAfshar",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "259725229",
            "id" : "259725229"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1475192959251488770",
      "id_str" : "1476253465265459206",
      "in_reply_to_user_id" : "259725229",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1476253465265459206",
      "in_reply_to_status_id" : "1475192959251488770",
      "created_at" : "Wed Dec 29 18:07:08 +0000 2021",
      "favorited" : false,
      "full_text" : "@ValaAfshar THAT 'FUTURE'",
      "lang" : "en",
      "in_reply_to_screen_name" : "ValaAfshar",
      "in_reply_to_user_id_str" : "259725229"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1475897217496104966"
          ],
          "editableUntil" : "2021-12-28T19:01:32.152Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "161",
              "175"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/WvtdLoOeXr",
            "expanded_url" : "https://youtu.be/20tLdkSwSWs",
            "display_url" : "youtu.be/20tLdkSwSWs",
            "indices" : [
              "176",
              "199"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "199"
      ],
      "favorite_count" : "4",
      "id_str" : "1475897217496104966",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1475897217496104966",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 28 18:31:32 +0000 2021",
      "favorited" : false,
      "full_text" : "【CircuitPython DIY】Bounce Ball: Can't resist writing a tiny game in the mid of a DIY project. The full project vlog is coming. No, it's not a handheld console.\n #CircuitPython https://t.co/WvtdLoOeXr",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1475607154140717060"
          ],
          "editableUntil" : "2021-12-27T23:48:55.659Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "hackaday",
            "screen_name" : "hackaday",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "14607140",
            "id" : "14607140"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1475572275592278025",
      "id_str" : "1475607154140717060",
      "in_reply_to_user_id" : "14607140",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1475607154140717060",
      "in_reply_to_status_id" : "1475572275592278025",
      "created_at" : "Mon Dec 27 23:18:55 +0000 2021",
      "favorited" : false,
      "full_text" : "@hackaday This is insane.....",
      "lang" : "en",
      "in_reply_to_screen_name" : "hackaday",
      "in_reply_to_user_id_str" : "14607140"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1474401021749338133"
          ],
          "editableUntil" : "2021-12-24T15:56:11.288Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "96",
              "110"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/Ie3x4jaWPA",
            "expanded_url" : "https://youtu.be/6GPNeYaMt9k",
            "display_url" : "youtu.be/6GPNeYaMt9k",
            "indices" : [
              "111",
              "134"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "134"
      ],
      "favorite_count" : "1",
      "id_str" : "1474401021749338133",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1474401021749338133",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 24 15:26:11 +0000 2021",
      "favorited" : false,
      "full_text" : "【CircuitPython 入门】02 点灯：用Python的“交互式编程”开发单片机程序，一边探索一边开发。Blink: REPL assisted Script development #CircuitPython https://t.co/Ie3x4jaWPA",
      "lang" : "zh"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1473802443360243713"
          ],
          "editableUntil" : "2021-12-23T00:17:39.079Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Friedt (@cfriedt@society.oftrolls.com)",
            "screen_name" : "cfriedt",
            "indices" : [
              "0",
              "8"
            ],
            "id_str" : "76065846",
            "id" : "76065846"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1473687716818792451",
      "id_str" : "1473802443360243713",
      "in_reply_to_user_id" : "76065846",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1473802443360243713",
      "in_reply_to_status_id" : "1473687716818792451",
      "created_at" : "Wed Dec 22 23:47:39 +0000 2021",
      "favorited" : false,
      "full_text" : "@cfriedt Raw Flash or EEPROM contents printed. I am almost sure because of the zeros.",
      "lang" : "en",
      "in_reply_to_screen_name" : "cfriedt",
      "in_reply_to_user_id_str" : "76065846"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1473346687901085700"
          ],
          "editableUntil" : "2021-12-21T18:06:38.510Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "arturo182 🐀",
            "screen_name" : "arturo182",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "15699469",
            "id" : "15699469"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1473339763784663051",
      "id_str" : "1473346687901085700",
      "in_reply_to_user_id" : "15699469",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1473346687901085700",
      "in_reply_to_status_id" : "1473339763784663051",
      "created_at" : "Tue Dec 21 17:36:38 +0000 2021",
      "favorited" : false,
      "full_text" : "@arturo182 I can watch this forever",
      "lang" : "en",
      "in_reply_to_screen_name" : "arturo182",
      "in_reply_to_user_id_str" : "15699469"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1473006926141272074"
          ],
          "editableUntil" : "2021-12-20T19:36:32.994Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "95",
              "109"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/uRfRjGZMWq",
            "expanded_url" : "https://youtu.be/7SdlKTyx1tk",
            "display_url" : "youtu.be/7SdlKTyx1tk",
            "indices" : [
              "110",
              "133"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "133"
      ],
      "favorite_count" : "2",
      "id_str" : "1473006926141272074",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1473006926141272074",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 20 19:06:32 +0000 2021",
      "favorited" : false,
      "full_text" : "【CircuitPython IDE】New Editor shortcuts in REPL mode help you explore while writing the script #CircuitPython https://t.co/uRfRjGZMWq",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1471849321209421827"
          ],
          "editableUntil" : "2021-12-17T14:56:38.471Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Tom's Hardware",
            "screen_name" : "tomshardware",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "17064514",
            "id" : "17064514"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "98"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1471547007214960640",
      "id_str" : "1471849321209421827",
      "in_reply_to_user_id" : "17064514",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1471849321209421827",
      "in_reply_to_status_id" : "1471547007214960640",
      "created_at" : "Fri Dec 17 14:26:38 +0000 2021",
      "favorited" : false,
      "full_text" : "@tomshardware When you really need that cooler, you are going to use up all lifespan within weeks.",
      "lang" : "en",
      "in_reply_to_screen_name" : "tomshardware",
      "in_reply_to_user_id_str" : "17064514"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1469706975302848513"
          ],
          "editableUntil" : "2021-12-11T17:03:43.404Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "135",
              "149"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/zhtjdOnvcS",
            "expanded_url" : "https://youtu.be/2cIQM3Ok-aI",
            "display_url" : "youtu.be/2cIQM3Ok-aI",
            "indices" : [
              "151",
              "174"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "174"
      ],
      "favorite_count" : "1",
      "id_str" : "1469706975302848513",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1469706975302848513",
      "possibly_sensitive" : false,
      "created_at" : "Sat Dec 11 16:33:43 +0000 2021",
      "favorited" : false,
      "full_text" : "【CircuitPython 入门】01.1 在 ESP32 S2 单片机上安装 CircuitPython，与单片机上交互式编程。 Installing CircuitPython on ESP32S2, and demo of simple REPL on it. #CircuitPython  https://t.co/zhtjdOnvcS",
      "lang" : "zh"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1466811803002880003"
          ],
          "editableUntil" : "2021-12-03T17:19:20.538Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "circuitpython",
            "indices" : [
              "122",
              "136"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/2M1wc3eR14",
            "expanded_url" : "https://youtu.be/kVDFoyLCqXU",
            "display_url" : "youtu.be/kVDFoyLCqXU",
            "indices" : [
              "137",
              "160"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "160"
      ],
      "favorite_count" : "2",
      "id_str" : "1466811803002880003",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1466811803002880003",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 03 16:49:20 +0000 2021",
      "favorited" : false,
      "full_text" : "【CircuitPython 入门】01. 从零开始，在单片机上运行你的第一个 CircuitPython 程序！Entry level Cpy tutorial in Chinese 01: From zero to Hello World #circuitpython https://t.co/2M1wc3eR14",
      "lang" : "zh"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1464340658102194176"
          ],
          "editableUntil" : "2021-11-26T21:39:53.682Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "circuitpython",
            "indices" : [
              "118",
              "132"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/yVCn6wmzRH",
            "expanded_url" : "https://youtu.be/t36nQOdAHVM",
            "display_url" : "youtu.be/t36nQOdAHVM",
            "indices" : [
              "133",
              "156"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "156"
      ],
      "favorite_count" : "1",
      "id_str" : "1464340658102194176",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1464340658102194176",
      "possibly_sensitive" : false,
      "created_at" : "Fri Nov 26 21:09:53 +0000 2021",
      "favorited" : false,
      "full_text" : "【CircuitPython IDE】The new update allows you to run a Code Cell (starts with `#%%`) in REPL by shortcut [Ctrl-Enter]. #circuitpython https://t.co/yVCn6wmzRH",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1463362986664415232"
          ],
          "editableUntil" : "2021-11-24T04:54:58.647Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "74",
              "88"
            ]
          },
          {
            "text" : "Bluetooth",
            "indices" : [
              "89",
              "99"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "adafruit industries",
            "screen_name" : "adafruit",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "20731304",
            "id" : "20731304"
          },
          {
            "name" : "@Riverwang@fosstodon.org",
            "screen_name" : "River___Wang",
            "indices" : [
              "100",
              "113"
            ],
            "id_str" : "1450661638009405445",
            "id" : "1450661638009405445"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/gP5v9qg7A7",
            "expanded_url" : "https://adafru.it/X3E",
            "display_url" : "adafru.it/X3E",
            "indices" : [
              "114",
              "137"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "0",
      "id_str" : "1463362986664415232",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1463362986664415232",
      "possibly_sensitive" : false,
      "created_at" : "Wed Nov 24 04:24:58 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @adafruit: Develop your CircuitPython code in a browser with two tools #CircuitPython #Bluetooth @River___Wang https://t.co/gP5v9qg7A7",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1462945531764875266"
          ],
          "editableUntil" : "2021-11-23T01:16:09.643Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "circuitpython",
            "indices" : [
              "85",
              "99"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/RWynOBnZYV",
            "expanded_url" : "https://youtu.be/CK9J1-xrzaE",
            "display_url" : "youtu.be/CK9J1-xrzaE",
            "indices" : [
              "101",
              "124"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "124"
      ],
      "favorite_count" : "2",
      "id_str" : "1462945531764875266",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1462945531764875266",
      "possibly_sensitive" : false,
      "created_at" : "Tue Nov 23 00:46:09 +0000 2021",
      "favorited" : false,
      "full_text" : "【CircuitPython 简介】用 Python 开发单片机？简单易学的单片机开发语言！CircuitPython introduction in Chinese. #circuitpython  https://t.co/RWynOBnZYV",
      "lang" : "zh"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1462838493370015749"
          ],
          "editableUntil" : "2021-11-22T18:10:49.701Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "157"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1462834543178702851",
      "id_str" : "1462838493370015749",
      "in_reply_to_user_id" : "4918794850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1462838493370015749",
      "in_reply_to_status_id" : "1462834543178702851",
      "created_at" : "Mon Nov 22 17:40:49 +0000 2021",
      "favorited" : false,
      "full_text" : "@anne_engineer Yes of course! Thanks for exposing my work. As you can see it was originally in English and the video is about making it available in Chinese.",
      "lang" : "en",
      "in_reply_to_screen_name" : "anne_engineer",
      "in_reply_to_user_id_str" : "4918794850"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1462491976771772416"
          ],
          "editableUntil" : "2021-11-21T19:13:53.706Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "cirtuitpython",
            "indices" : [
              "30",
              "44"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/PeP48lNIZq",
            "expanded_url" : "https://youtu.be/CQmM1jGZ23M",
            "display_url" : "youtu.be/CQmM1jGZ23M",
            "indices" : [
              "45",
              "68"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "3",
      "id_str" : "1462491976771772416",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1462491976771772416",
      "possibly_sensitive" : false,
      "created_at" : "Sun Nov 21 18:43:53 +0000 2021",
      "favorited" : false,
      "full_text" : "【CircuitPython IDE】中文开发环境上线了！ #cirtuitpython https://t.co/PeP48lNIZq",
      "lang" : "zh"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1460620832200433678"
          ],
          "editableUntil" : "2021-11-16T15:18:38.076Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "circuitpython",
            "indices" : [
              "217",
              "231"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "231"
      ],
      "favorite_count" : "1",
      "id_str" : "1460620832200433678",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1460620832200433678",
      "created_at" : "Tue Nov 16 14:48:38 +0000 2021",
      "favorited" : false,
      "full_text" : "I am sorry that my plan for posting the CircuitPython Chinese Video Series is slower than expected. I had some issues with my bilibili account. I will switch focus to other sites in the future. 抱歉遇到了一些困难,教程我还是会发,请期待. #circuitpython",
      "lang" : "zh"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1455609463696678912"
          ],
          "editableUntil" : "2021-11-02T19:25:14.718Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "65",
              "79"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/RA8UXaefy8",
            "expanded_url" : "https://youtu.be/r1pBs0Cx6oQ",
            "display_url" : "youtu.be/r1pBs0Cx6oQ",
            "indices" : [
              "80",
              "103"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "1",
      "id_str" : "1455609463696678912",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1455609463696678912",
      "possibly_sensitive" : false,
      "created_at" : "Tue Nov 02 18:55:14 +0000 2021",
      "favorited" : false,
      "full_text" : "【Cpy IDE】Plot and Help: New Features of CircuitPython Online IDE #CircuitPython https://t.co/RA8UXaefy8",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1452803261275295744"
          ],
          "editableUntil" : "2021-10-26T01:34:23.924Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "circuitpython",
            "indices" : [
              "47",
              "61"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/skTErSfv8k",
            "expanded_url" : "https://youtu.be/ztqier1PnYg",
            "display_url" : "youtu.be/ztqier1PnYg",
            "indices" : [
              "62",
              "85"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "1",
      "id_str" : "1452803261275295744",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1452803261275295744",
      "possibly_sensitive" : false,
      "created_at" : "Tue Oct 26 01:04:23 +0000 2021",
      "favorited" : false,
      "full_text" : "\"Hello, World!\" with CircuitPython online IDE.\n#circuitpython\nhttps://t.co/skTErSfv8k",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1583516777547718658"
          ],
          "editableUntil" : "2022-10-21T18:23:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "科興💉💉💉💉 ⭆LoRaBandit⭅",
            "screen_name" : "Kongduino",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "2918350304",
            "id" : "2918350304"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1583371110753525761",
      "id_str" : "1583516777547718658",
      "in_reply_to_user_id" : "2918350304",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1583516777547718658",
      "in_reply_to_status_id" : "1583371110753525761",
      "created_at" : "Fri Oct 21 17:53:14 +0000 2022",
      "favorited" : false,
      "full_text" : "@Kongduino How come I used such a thing before.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Kongduino",
      "in_reply_to_user_id_str" : "2918350304"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1582789663198445568"
          ],
          "editableUntil" : "2022-10-19T18:13:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Greening",
            "screen_name" : "MrBananas",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "19769449",
            "id" : "19769449"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1582717227328892928",
      "id_str" : "1582789663198445568",
      "in_reply_to_user_id" : "19769449",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1582789663198445568",
      "in_reply_to_status_id" : "1582717227328892928",
      "created_at" : "Wed Oct 19 17:43:57 +0000 2022",
      "favorited" : false,
      "full_text" : "@MrBananas Printed step motor?",
      "lang" : "en",
      "in_reply_to_screen_name" : "MrBananas",
      "in_reply_to_user_id_str" : "19769449"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1582762184312250368"
          ],
          "editableUntil" : "2022-10-19T16:24:45.696Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CircuitPython",
            "screen_name" : "CircuitPython",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "811605410293645313",
            "id" : "811605410293645313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1582762184312250368",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1582762184312250368",
      "created_at" : "Wed Oct 19 15:54:45 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @CircuitPython: ICYMI Python on Microcontrollers Newsletter: Ladyada at Espressif DevCon this week, CircuitPython 8 beta 2 and more! #Ci…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1582530567806930945"
          ],
          "editableUntil" : "2022-10-19T01:04:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Apple",
            "screen_name" : "Apple",
            "indices" : [
              "0",
              "6"
            ],
            "id_str" : "380749300",
            "id" : "380749300"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1582404174695628801",
      "id_str" : "1582530567806930945",
      "in_reply_to_user_id" : "380749300",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1582530567806930945",
      "in_reply_to_status_id" : "1582404174695628801",
      "created_at" : "Wed Oct 19 00:34:24 +0000 2022",
      "favorited" : false,
      "full_text" : "@Apple This ad caused me motion sickness. Need to be removed.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Apple",
      "in_reply_to_user_id_str" : "380749300"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1582450030497046529"
          ],
          "editableUntil" : "2022-10-18T19:44:22.427Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Coney Island Maker Faire #CIMF2023",
            "screen_name" : "MakerFaireConey",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "1573094455426654211",
            "id" : "1573094455426654211"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/MakerFaireConey/status/1581135411555880960/photo/1",
            "source_status_id" : "1581135411555880960",
            "indices" : [
              "110",
              "133"
            ],
            "url" : "https://t.co/wkEIZKXlPy",
            "media_url" : "http://pbs.twimg.com/media/FfFSBOvWIAIKBHD.jpg",
            "id_str" : "1581135125273780226",
            "source_user_id" : "1573094455426654211",
            "id" : "1581135125273780226",
            "media_url_https" : "https://pbs.twimg.com/media/FfFSBOvWIAIKBHD.jpg",
            "source_user_id_str" : "1573094455426654211",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1581135411555880960",
            "display_url" : "pic.twitter.com/wkEIZKXlPy"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "133"
      ],
      "favorite_count" : "0",
      "id_str" : "1582450030497046529",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1582450030497046529",
      "possibly_sensitive" : false,
      "created_at" : "Tue Oct 18 19:14:22 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @MakerFaireConey: SAVE THE DATE!\n\nOctober 6-8 2023\n\nThe Greatest Show and Tell On Earth comes back to NYC! https://t.co/wkEIZKXlPy",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/MakerFaireConey/status/1581135411555880960/photo/1",
            "source_status_id" : "1581135411555880960",
            "indices" : [
              "110",
              "133"
            ],
            "url" : "https://t.co/wkEIZKXlPy",
            "media_url" : "http://pbs.twimg.com/media/FfFSBOvWIAIKBHD.jpg",
            "id_str" : "1581135125273780226",
            "source_user_id" : "1573094455426654211",
            "id" : "1581135125273780226",
            "media_url_https" : "https://pbs.twimg.com/media/FfFSBOvWIAIKBHD.jpg",
            "source_user_id_str" : "1573094455426654211",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1581135411555880960",
            "display_url" : "pic.twitter.com/wkEIZKXlPy"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1581641546062888961"
          ],
          "editableUntil" : "2022-10-16T14:11:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "291"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1580219325226835968",
      "id_str" : "1581641546062888961",
      "in_reply_to_user_id" : "4918794850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1581641546062888961",
      "in_reply_to_status_id" : "1580219325226835968",
      "created_at" : "Sun Oct 16 13:41:44 +0000 2022",
      "favorited" : false,
      "full_text" : "@anne_engineer Icymi, my CPy online IDE got a big version update this week. I posted a 1 min intro video and demoed it live at Philly Maker Faire. The biggest upgrades of this version are file management, editor tabs and IDE settings saved on-chip. Documents and more videos are coming soon.",
      "lang" : "en",
      "in_reply_to_screen_name" : "anne_engineer",
      "in_reply_to_user_id_str" : "4918794850"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1581311596940636160"
          ],
          "editableUntil" : "2022-10-15T16:20:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "phl make",
            "screen_name" : "phlmake",
            "indices" : [
              "47",
              "55"
            ],
            "id_str" : "366117716",
            "id" : "366117716"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1581311596940636160/photo/1",
            "indices" : [
              "76",
              "99"
            ],
            "url" : "https://t.co/kGD9VdfHBO",
            "media_url" : "http://pbs.twimg.com/media/FfHyg0nWYAILAC2.jpg",
            "id_str" : "1581311589877178370",
            "id" : "1581311589877178370",
            "media_url_https" : "https://pbs.twimg.com/media/FfHyg0nWYAILAC2.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "904",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1542",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "512",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/kGD9VdfHBO"
          }
        ],
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "13",
              "27"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "99"
      ],
      "favorite_count" : "12",
      "id_str" : "1581311596940636160",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1581311596940636160",
      "possibly_sensitive" : false,
      "created_at" : "Sat Oct 15 15:50:38 +0000 2022",
      "favorited" : false,
      "full_text" : "Come and see #CircuitPython online IDE live at @phlmake Philly Maker Faire! https://t.co/kGD9VdfHBO",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1581311596940636160/photo/1",
            "indices" : [
              "76",
              "99"
            ],
            "url" : "https://t.co/kGD9VdfHBO",
            "media_url" : "http://pbs.twimg.com/media/FfHyg0nWYAILAC2.jpg",
            "id_str" : "1581311589877178370",
            "id" : "1581311589877178370",
            "media_url_https" : "https://pbs.twimg.com/media/FfHyg0nWYAILAC2.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "904",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1542",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "512",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/kGD9VdfHBO"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1581124770309214208"
          ],
          "editableUntil" : "2022-10-15T03:58:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/MbMYEkPBGE",
            "expanded_url" : "https://urfdvw.github.io/CircuitPython-online-IDE/",
            "display_url" : "urfdvw.github.io/CircuitPython-…",
            "indices" : [
              "63",
              "86"
            ]
          },
          {
            "url" : "https://t.co/PeDBULdBRW",
            "expanded_url" : "https://github.com/urfdvw/CircuitPython-online-IDE/tree/big-version-1",
            "display_url" : "github.com/urfdvw/Circuit…",
            "indices" : [
              "100",
              "123"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1581124770309214208/video/1",
            "indices" : [
              "124",
              "147"
            ],
            "url" : "https://t.co/x89sYkIxRi",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1581122874764574722/pu/img/EJKFNSZXJvaPulON.jpg",
            "id_str" : "1581122874764574722",
            "id" : "1581122874764574722",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1581122874764574722/pu/img/EJKFNSZXJvaPulON.jpg",
            "sizes" : {
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/x89sYkIxRi"
          }
        ],
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "22",
              "36"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "147"
      ],
      "favorite_count" : "12",
      "id_str" : "1581124770309214208",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1581124770309214208",
      "possibly_sensitive" : false,
      "created_at" : "Sat Oct 15 03:28:15 +0000 2022",
      "favorited" : false,
      "full_text" : "Behold, the brand new #CircuitPython Online IDE is here. \nIDE: https://t.co/MbMYEkPBGE\nGithub Repo: https://t.co/PeDBULdBRW https://t.co/x89sYkIxRi",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1581124770309214208/video/1",
            "indices" : [
              "124",
              "147"
            ],
            "url" : "https://t.co/x89sYkIxRi",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1581122874764574722/pu/img/EJKFNSZXJvaPulON.jpg",
            "id_str" : "1581122874764574722",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "67221",
              "variants" : [
                {
                  "bitrate" : "256000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1581122874764574722/pu/vid/480x270/3RkcZf91-eJqKs0p.mp4?tag=12"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1581122874764574722/pu/pl/M9QboooCJKwgQcfz.m3u8?tag=12&container=fmp4"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1581122874764574722/pu/vid/640x360/I_6Bzw_BNOMTx7s0.mp4?tag=12"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1581122874764574722/pu/vid/1280x720/mWa16xGNL94dnknB.mp4?tag=12"
                }
              ]
            },
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1581122874764574722",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1581122874764574722/pu/img/EJKFNSZXJvaPulON.jpg",
            "sizes" : {
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "display_url" : "pic.twitter.com/x89sYkIxRi"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580928170588483585"
          ],
          "editableUntil" : "2022-10-14T14:57:02.750Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "phl make",
            "screen_name" : "phlmake",
            "indices" : [
              "3",
              "11"
            ],
            "id_str" : "366117716",
            "id" : "366117716"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/0mUTVQTRQT",
            "expanded_url" : "https://ift.tt/xyKsJ3E",
            "display_url" : "ift.tt/xyKsJ3E",
            "indices" : [
              "62",
              "85"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/phlmake/status/1580864758487470080/photo/1",
            "source_status_id" : "1580864758487470080",
            "indices" : [
              "86",
              "109"
            ],
            "url" : "https://t.co/eMP1CJOptl",
            "media_url" : "http://pbs.twimg.com/media/FfBcHtyWAAA8khF.jpg",
            "id_str" : "1580864756826636288",
            "source_user_id" : "366117716",
            "id" : "1580864756826636288",
            "media_url_https" : "https://pbs.twimg.com/media/FfBcHtyWAAA8khF.jpg",
            "source_user_id_str" : "366117716",
            "sizes" : {
              "large" : {
                "w" : "750",
                "h" : "563",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "750",
                "h" : "563",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1580864758487470080",
            "display_url" : "pic.twitter.com/eMP1CJOptl"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "109"
      ],
      "favorite_count" : "0",
      "id_str" : "1580928170588483585",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580928170588483585",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 14 14:27:02 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @phlmake: News from MakeZine: Live: Maker Faire Lille 2022 https://t.co/0mUTVQTRQT https://t.co/eMP1CJOptl",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/phlmake/status/1580864758487470080/photo/1",
            "source_status_id" : "1580864758487470080",
            "indices" : [
              "86",
              "109"
            ],
            "url" : "https://t.co/eMP1CJOptl",
            "media_url" : "http://pbs.twimg.com/media/FfBcHtyWAAA8khF.jpg",
            "id_str" : "1580864756826636288",
            "source_user_id" : "366117716",
            "id" : "1580864756826636288",
            "media_url_https" : "https://pbs.twimg.com/media/FfBcHtyWAAA8khF.jpg",
            "source_user_id_str" : "366117716",
            "sizes" : {
              "large" : {
                "w" : "750",
                "h" : "563",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "750",
                "h" : "563",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1580864758487470080",
            "display_url" : "pic.twitter.com/eMP1CJOptl"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580927243236229120"
          ],
          "editableUntil" : "2022-10-14T14:53:21.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dana Sibera",
            "screen_name" : "NanoRaptor",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "2312854706",
            "id" : "2312854706"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1580923602676854785",
      "id_str" : "1580927243236229120",
      "in_reply_to_user_id" : "2312854706",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580927243236229120",
      "in_reply_to_status_id" : "1580923602676854785",
      "created_at" : "Fri Oct 14 14:23:21 +0000 2022",
      "favorited" : false,
      "full_text" : "@NanoRaptor Belts on. Taking off.",
      "lang" : "en",
      "in_reply_to_screen_name" : "NanoRaptor",
      "in_reply_to_user_id_str" : "2312854706"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580584761709379585"
          ],
          "editableUntil" : "2022-10-13T16:12:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "82"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1580559810277216257",
      "id_str" : "1580584761709379585",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580584761709379585",
      "in_reply_to_status_id" : "1580559810277216257",
      "created_at" : "Thu Oct 13 15:42:27 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev Testing it intensively. Will figure out how reasonable the layout is.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580584546679934982"
          ],
          "editableUntil" : "2022-10-13T16:11:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "271"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1580559810277216257",
      "id_str" : "1580584546679934982",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580584546679934982",
      "in_reply_to_status_id" : "1580559810277216257",
      "created_at" : "Thu Oct 13 15:41:36 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev Also it is easy to buy the standard sized key caps like 6.5u space bar and stablizer. Still I made a mistake that the Cap kit I bought does not have 1.75u shift key so I have to use a Ctrl key instead on the right. You can tell how much I need the Ctrl keys.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580584053237231617"
          ],
          "editableUntil" : "2022-10-13T16:09:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "295"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1580559810277216257",
      "id_str" : "1580584053237231617",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580584053237231617",
      "in_reply_to_status_id" : "1580559810277216257",
      "created_at" : "Thu Oct 13 15:39:38 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev Do you mean the layout? I designed such a layout very much based on my habit and parts availability. Like I want the left Ctrl to be as close to C and V as possible (to use stack overflow 🤦‍♂️), and on the right the only key I actually use is Ctrl. I like the Fn on the left better.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580526435948957696"
          ],
          "editableUntil" : "2022-10-13T12:20:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "195"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1580440061853605888",
      "id_str" : "1580526435948957696",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1580526435948957696",
      "in_reply_to_status_id" : "1580440061853605888",
      "created_at" : "Thu Oct 13 11:50:41 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev I like arranging the arrow keys in this strange looking way so that they incline towards the center. Feels better. The 3d print quality is not very high. Looking for other solutions.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1580406111513251841"
          ],
          "editableUntil" : "2022-10-13T04:22:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1580406111513251841/photo/1",
            "indices" : [
              "180",
              "203"
            ],
            "url" : "https://t.co/Nv2sHR0wiC",
            "media_url" : "http://pbs.twimg.com/media/Fe66-nmXoAE3PVf.jpg",
            "id_str" : "1580406104198193153",
            "id" : "1580406104198193153",
            "media_url_https" : "https://pbs.twimg.com/media/Fe66-nmXoAE3PVf.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Nv2sHR0wiC"
          }
        ],
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "123",
              "137"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "203"
      ],
      "favorite_count" : "9",
      "id_str" : "1580406111513251841",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1580406111513251841",
      "possibly_sensitive" : false,
      "created_at" : "Thu Oct 13 03:52:34 +0000 2022",
      "favorited" : false,
      "full_text" : "Despite a 1 mm mismatched dimension I got my first Keyboard made, with magnetic palm rest. Firmware is still developing in #CircuitPython, of course with the brand new Online IDE. https://t.co/Nv2sHR0wiC",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1580406111513251841/photo/1",
            "indices" : [
              "180",
              "203"
            ],
            "url" : "https://t.co/Nv2sHR0wiC",
            "media_url" : "http://pbs.twimg.com/media/Fe66-nmXoAE3PVf.jpg",
            "id_str" : "1580406104198193153",
            "id" : "1580406104198193153",
            "media_url_https" : "https://pbs.twimg.com/media/Fe66-nmXoAE3PVf.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Nv2sHR0wiC"
          },
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1580406111513251841/photo/1",
            "indices" : [
              "180",
              "203"
            ],
            "url" : "https://t.co/Nv2sHR0wiC",
            "media_url" : "http://pbs.twimg.com/media/Fe66-6MWQAE5LiL.jpg",
            "id_str" : "1580406109189324801",
            "id" : "1580406109189324801",
            "media_url_https" : "https://pbs.twimg.com/media/Fe66-6MWQAE5LiL.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Nv2sHR0wiC"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1579924338857627648"
          ],
          "editableUntil" : "2022-10-11T20:28:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Programmer Humor",
            "screen_name" : "PR0GRAMMERHUM0R",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "965774983527043072",
            "id" : "965774983527043072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "99"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1579728533466718208",
      "id_str" : "1579924338857627648",
      "in_reply_to_user_id" : "965774983527043072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1579924338857627648",
      "in_reply_to_status_id" : "1579728533466718208",
      "created_at" : "Tue Oct 11 19:58:10 +0000 2022",
      "favorited" : false,
      "full_text" : "@PR0GRAMMERHUM0R CPP is all about habits. Allowed does not always mean good. BTW, use the last one.",
      "lang" : "en",
      "in_reply_to_screen_name" : "PR0GRAMMERHUM0R",
      "in_reply_to_user_id_str" : "965774983527043072"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1579586120102268929"
          ],
          "editableUntil" : "2022-10-10T22:04:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "nixCraft 🐧",
            "screen_name" : "nixcraft",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "17484680",
            "id" : "17484680"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "83"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1579539063023243266",
      "id_str" : "1579586120102268929",
      "in_reply_to_user_id" : "17484680",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1579586120102268929",
      "in_reply_to_status_id" : "1579539063023243266",
      "created_at" : "Mon Oct 10 21:34:12 +0000 2022",
      "favorited" : false,
      "full_text" : "@nixcraft Pop!_OS is usually doing a good job. At least usually better than Ubuntu.",
      "lang" : "en",
      "in_reply_to_screen_name" : "nixcraft",
      "in_reply_to_user_id_str" : "17484680"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1579552619613519873"
          ],
          "editableUntil" : "2022-10-10T19:51:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/tuaSp2Yf2S",
            "expanded_url" : "https://urfdvw.github.io/cpy-ol-ide-tests/#",
            "display_url" : "urfdvw.github.io/cpy-ol-ide-tes…",
            "indices" : [
              "112",
              "135"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1579552619613519873/photo/1",
            "indices" : [
              "278",
              "301"
            ],
            "url" : "https://t.co/0rZiWHOIS1",
            "media_url" : "http://pbs.twimg.com/media/FeuxTKWXEAk1Lek.jpg",
            "id_str" : "1579551037077262345",
            "id" : "1579551037077262345",
            "media_url_https" : "https://pbs.twimg.com/media/FeuxTKWXEAk1Lek.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "307",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1504",
                "h" : "678",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "541",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/0rZiWHOIS1"
          }
        ],
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "25",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "301"
      ],
      "favorite_count" : "10",
      "id_str" : "1579552619613519873",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1579552619613519873",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 10 19:21:05 +0000 2022",
      "favorited" : false,
      "full_text" : "Alpha version of the new #CircuitPython online IDE is out! 🎉🎉🎉 If you want to help me test it out, please visit https://t.co/tuaSp2Yf2S Sorry the Github repo is a bit messy right now. It is going public soon. For now, please use \"Help-&gt;Feedback\" to send me some suggestions. https://t.co/0rZiWHOIS1",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1579552619613519873/photo/1",
            "indices" : [
              "278",
              "301"
            ],
            "url" : "https://t.co/0rZiWHOIS1",
            "media_url" : "http://pbs.twimg.com/media/FeuxTKWXEAk1Lek.jpg",
            "id_str" : "1579551037077262345",
            "id" : "1579551037077262345",
            "media_url_https" : "https://pbs.twimg.com/media/FeuxTKWXEAk1Lek.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "307",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1504",
                "h" : "678",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "541",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/0rZiWHOIS1"
          },
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1579552619613519873/photo/1",
            "indices" : [
              "278",
              "301"
            ],
            "url" : "https://t.co/0rZiWHOIS1",
            "media_url" : "http://pbs.twimg.com/media/FeuxUhuX0AEFlzI.png",
            "id_str" : "1579551060531859457",
            "id" : "1579551060531859457",
            "media_url_https" : "https://pbs.twimg.com/media/FeuxUhuX0AEFlzI.png",
            "sizes" : {
              "large" : {
                "w" : "664",
                "h" : "680",
                "resize" : "fit"
              },
              "small" : {
                "w" : "664",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "664",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/0rZiWHOIS1"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1579471452042317825"
          ],
          "editableUntil" : "2022-10-10T14:28:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dana Sibera",
            "screen_name" : "NanoRaptor",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "2312854706",
            "id" : "2312854706"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1579464590479749122",
      "id_str" : "1579471452042317825",
      "in_reply_to_user_id" : "2312854706",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1579471452042317825",
      "in_reply_to_status_id" : "1579464590479749122",
      "created_at" : "Mon Oct 10 13:58:33 +0000 2022",
      "favorited" : false,
      "full_text" : "@NanoRaptor Vibrating touch that conveys a striking feeling.",
      "lang" : "en",
      "in_reply_to_screen_name" : "NanoRaptor",
      "in_reply_to_user_id_str" : "2312854706"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1579438693886353409"
          ],
          "editableUntil" : "2022-10-10T12:18:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Programmer Humor",
            "screen_name" : "PR0GRAMMERHUM0R",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "965774983527043072",
            "id" : "965774983527043072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1579245349197471744",
      "id_str" : "1579438693886353409",
      "in_reply_to_user_id" : "965774983527043072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1579438693886353409",
      "in_reply_to_status_id" : "1579245349197471744",
      "created_at" : "Mon Oct 10 11:48:23 +0000 2022",
      "favorited" : false,
      "full_text" : "@PR0GRAMMERHUM0R Mac programmer",
      "lang" : "de",
      "in_reply_to_screen_name" : "PR0GRAMMERHUM0R",
      "in_reply_to_user_id_str" : "965774983527043072"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1578240773270933504"
          ],
          "editableUntil" : "2022-10-07T04:58:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "おぷら技研",
            "screen_name" : "OPLA_TECH",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1187317261662478337",
            "id" : "1187317261662478337"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "76"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1535231815526805504",
      "id_str" : "1578240773270933504",
      "in_reply_to_user_id" : "1187317261662478337",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1578240773270933504",
      "in_reply_to_status_id" : "1535231815526805504",
      "created_at" : "Fri Oct 07 04:28:17 +0000 2022",
      "favorited" : false,
      "full_text" : "@OPLA_TECH New knowledge: ordinary household in Japan have milling machines.",
      "lang" : "en",
      "in_reply_to_screen_name" : "OPLA_TECH",
      "in_reply_to_user_id_str" : "1187317261662478337"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1577491239766663168"
          ],
          "editableUntil" : "2022-10-05T03:19:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1577491239766663168/photo/1",
            "indices" : [
              "62",
              "85"
            ],
            "url" : "https://t.co/LZf7wyjIqo",
            "media_url" : "http://pbs.twimg.com/media/FeRfjrDWYAIEFXn.jpg",
            "id_str" : "1577490835943350274",
            "id" : "1577490835943350274",
            "media_url_https" : "https://pbs.twimg.com/media/FeRfjrDWYAIEFXn.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "266",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1594",
                "h" : "624",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "470",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/LZf7wyjIqo"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1577131516911824896",
      "id_str" : "1577491239766663168",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1577491239766663168",
      "in_reply_to_status_id" : "1577131516911824896",
      "possibly_sensitive" : false,
      "created_at" : "Wed Oct 05 02:49:54 +0000 2022",
      "favorited" : false,
      "full_text" : "The basic UI is done. Now it is time for some business logic. https://t.co/LZf7wyjIqo",
      "lang" : "en",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1577491239766663168/photo/1",
            "indices" : [
              "62",
              "85"
            ],
            "url" : "https://t.co/LZf7wyjIqo",
            "media_url" : "http://pbs.twimg.com/media/FeRfjrDWYAIEFXn.jpg",
            "id_str" : "1577490835943350274",
            "id" : "1577490835943350274",
            "media_url_https" : "https://pbs.twimg.com/media/FeRfjrDWYAIEFXn.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "266",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1594",
                "h" : "624",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "470",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/LZf7wyjIqo"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1577131516911824896"
          ],
          "editableUntil" : "2022-10-04T03:30:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1577131516911824896/photo/1",
            "indices" : [
              "203",
              "226"
            ],
            "url" : "https://t.co/IBPYYWGmT9",
            "media_url" : "http://pbs.twimg.com/media/FeMWwXZWYAER21x.jpg",
            "id_str" : "1577129314679676929",
            "id" : "1577129314679676929",
            "media_url_https" : "https://pbs.twimg.com/media/FeMWwXZWYAER21x.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "642",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1754",
                "h" : "938",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "364",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/IBPYYWGmT9"
          }
        ],
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "188",
              "202"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "226"
      ],
      "favorite_count" : "6",
      "id_str" : "1577131516911824896",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1577131516911824896",
      "possibly_sensitive" : false,
      "created_at" : "Tue Oct 04 03:00:29 +0000 2022",
      "favorited" : false,
      "full_text" : "Finally, I have found all the tech pieces needed for the coming CircuitPython Online IDE. It is such a pleasure putting things together. Construction progress is like 20% now. Stay tuned. #CircuitPython https://t.co/IBPYYWGmT9",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1577131516911824896/photo/1",
            "indices" : [
              "203",
              "226"
            ],
            "url" : "https://t.co/IBPYYWGmT9",
            "media_url" : "http://pbs.twimg.com/media/FeMWwXZWYAER21x.jpg",
            "id_str" : "1577129314679676929",
            "id" : "1577129314679676929",
            "media_url_https" : "https://pbs.twimg.com/media/FeMWwXZWYAER21x.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "642",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1754",
                "h" : "938",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "364",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/IBPYYWGmT9"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1576208864201932800"
          ],
          "editableUntil" : "2022-10-01T14:24:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1576056947140624385",
      "id_str" : "1576208864201932800",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1576208864201932800",
      "in_reply_to_status_id" : "1576056947140624385",
      "created_at" : "Sat Oct 01 13:54:12 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev Liquid PCB is coming.😸",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1575972587666305024"
          ],
          "editableUntil" : "2022-09-30T22:45:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1575972587666305024/photo/1",
            "indices" : [
              "101",
              "124"
            ],
            "url" : "https://t.co/SJX5kFwEZz",
            "media_url" : "http://pbs.twimg.com/media/Fd76t3fXEA8X1JK.jpg",
            "id_str" : "1575972585522794511",
            "id" : "1575972585522794511",
            "media_url_https" : "https://pbs.twimg.com/media/Fd76t3fXEA8X1JK.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "448",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1126",
                "h" : "742",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1126",
                "h" : "742",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/SJX5kFwEZz"
          }
        ],
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "16",
              "30"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "124"
      ],
      "favorite_count" : "4",
      "id_str" : "1575972587666305024",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1575972587666305024",
      "possibly_sensitive" : false,
      "created_at" : "Fri Sep 30 22:15:19 +0000 2022",
      "favorited" : false,
      "full_text" : "The case of the #CircuitPython keyboard is sent to the factory. Pray that the dimensions will match. https://t.co/SJX5kFwEZz",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1575972587666305024/photo/1",
            "indices" : [
              "101",
              "124"
            ],
            "url" : "https://t.co/SJX5kFwEZz",
            "media_url" : "http://pbs.twimg.com/media/Fd76t3fXEA8X1JK.jpg",
            "id_str" : "1575972585522794511",
            "id" : "1575972585522794511",
            "media_url_https" : "https://pbs.twimg.com/media/Fd76t3fXEA8X1JK.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "448",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1126",
                "h" : "742",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1126",
                "h" : "742",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/SJX5kFwEZz"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1575840978086526977"
          ],
          "editableUntil" : "2022-09-30T14:02:21.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          },
          {
            "name" : "adafruit industries",
            "screen_name" : "adafruit",
            "indices" : [
              "13",
              "22"
            ],
            "id_str" : "20731304",
            "id" : "20731304"
          },
          {
            "name" : "OSHWA (Open Source Hardware Association)",
            "screen_name" : "oshwassociation",
            "indices" : [
              "23",
              "39"
            ],
            "id_str" : "733454251",
            "id" : "733454251"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "160"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1575771718420938753",
      "id_str" : "1575840978086526977",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1575840978086526977",
      "in_reply_to_status_id" : "1575771718420938753",
      "created_at" : "Fri Sep 30 13:32:21 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev @adafruit @oshwassociation Thank you for mentioning me, but I feel like this is way above my capabilities. Let's see my growth in the coming years.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1575602138075365378"
          ],
          "editableUntil" : "2022-09-29T22:13:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "166"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1575529012893458432",
      "id_str" : "1575602138075365378",
      "in_reply_to_user_id" : "4918794850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1575602138075365378",
      "in_reply_to_status_id" : "1575529012893458432",
      "created_at" : "Thu Sep 29 21:43:17 +0000 2022",
      "favorited" : false,
      "full_text" : "@anne_engineer I had 2 pebbles before: v1 and v2 se. Loved them. The problem is that they refuse to connect to phones anymore, no matter by any software. That is sad.",
      "lang" : "en",
      "in_reply_to_screen_name" : "anne_engineer",
      "in_reply_to_user_id_str" : "4918794850"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1575330630132535299"
          ],
          "editableUntil" : "2022-09-29T04:14:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "171"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1575255653878210560",
      "id_str" : "1575330630132535299",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1575330630132535299",
      "in_reply_to_status_id" : "1575255653878210560",
      "created_at" : "Thu Sep 29 03:44:25 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev Wow. That's beyond my expectations.\n\nI am currently trying to get the first big version 1.0 deployed before the 10/15 Maker fair, so that I can show off then.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1574737113072906240"
          ],
          "editableUntil" : "2022-09-27T12:55:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "PocketGriffon",
            "screen_name" : "GriffonPocket",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1162160085725958146",
            "id" : "1162160085725958146"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "158"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1574736071207829504",
      "id_str" : "1574737113072906240",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1574737113072906240",
      "in_reply_to_status_id" : "1574736071207829504",
      "created_at" : "Tue Sep 27 12:25:59 +0000 2022",
      "favorited" : false,
      "full_text" : "@GriffonPocket I am not an expert. But it seems that Pop! OS has better hardware drivers supports than Ubuntu, so I always try it first on unordinary devices.",
      "lang" : "en",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1574736071207829504"
          ],
          "editableUntil" : "2022-09-27T12:51:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "PocketGriffon",
            "screen_name" : "GriffonPocket",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1162160085725958146",
            "id" : "1162160085725958146"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "246"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1574571022199975937",
      "id_str" : "1574736071207829504",
      "in_reply_to_user_id" : "1162160085725958146",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1574736071207829504",
      "in_reply_to_status_id" : "1574571022199975937",
      "created_at" : "Tue Sep 27 12:21:51 +0000 2022",
      "favorited" : false,
      "full_text" : "@GriffonPocket I have the same model. Pop! OS is working pretty well on it. Worth trying. When running Linux, this puppy generates much less heat than Win10. The heat sink on this device is not properly designed, and Win10 is barely usable there.",
      "lang" : "en",
      "in_reply_to_screen_name" : "GriffonPocket",
      "in_reply_to_user_id_str" : "1162160085725958146"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1573764603103813632"
          ],
          "editableUntil" : "2022-09-24T20:31:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1573764603103813632/photo/1",
            "indices" : [
              "126",
              "149"
            ],
            "url" : "https://t.co/Z3J1eaVp8u",
            "media_url" : "http://pbs.twimg.com/media/FdcijwgX0AEQfzC.jpg",
            "id_str" : "1573764592500723713",
            "id" : "1573764592500723713",
            "media_url_https" : "https://pbs.twimg.com/media/FdcijwgX0AEQfzC.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Z3J1eaVp8u"
          }
        ],
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "91",
              "105"
            ]
          },
          {
            "text" : "MechanicalKeyboard",
            "indices" : [
              "106",
              "125"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "149"
      ],
      "favorite_count" : "3",
      "id_str" : "1573764603103813632",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1573764603103813632",
      "possibly_sensitive" : false,
      "created_at" : "Sat Sep 24 20:01:35 +0000 2022",
      "favorited" : false,
      "full_text" : "All keys are working now. The plate is sent to the factory. Now, it's time to make a case. #CircuitPython #MechanicalKeyboard https://t.co/Z3J1eaVp8u",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1573764603103813632/photo/1",
            "indices" : [
              "126",
              "149"
            ],
            "url" : "https://t.co/Z3J1eaVp8u",
            "media_url" : "http://pbs.twimg.com/media/FdcijwgX0AEQfzC.jpg",
            "id_str" : "1573764592500723713",
            "id" : "1573764592500723713",
            "media_url_https" : "https://pbs.twimg.com/media/FdcijwgX0AEQfzC.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Z3J1eaVp8u"
          },
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1573764603103813632/photo/1",
            "indices" : [
              "126",
              "149"
            ],
            "url" : "https://t.co/Z3J1eaVp8u",
            "media_url" : "http://pbs.twimg.com/media/FdcikFTXwAIE30V.jpg",
            "id_str" : "1573764598083338242",
            "id" : "1573764598083338242",
            "media_url_https" : "https://pbs.twimg.com/media/FdcikFTXwAIE30V.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Z3J1eaVp8u"
          },
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1573764603103813632/photo/1",
            "indices" : [
              "126",
              "149"
            ],
            "url" : "https://t.co/Z3J1eaVp8u",
            "media_url" : "http://pbs.twimg.com/media/FdcikRUWAAE92fB.jpg",
            "id_str" : "1573764601308643329",
            "id" : "1573764601308643329",
            "media_url_https" : "https://pbs.twimg.com/media/FdcikRUWAAE92fB.jpg",
            "sizes" : {
              "large" : {
                "w" : "1566",
                "h" : "562",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "244",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "431",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Z3J1eaVp8u"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1572613762758184960"
          ],
          "editableUntil" : "2022-09-21T16:18:33.449Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "RaspberryPi",
            "indices" : [
              "84",
              "96"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "adafruit industries",
            "screen_name" : "adafruit",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "20731304",
            "id" : "20731304"
          },
          {
            "name" : "Pete Warden",
            "screen_name" : "petewarden",
            "indices" : [
              "97",
              "108"
            ],
            "id_str" : "14642896",
            "id" : "14642896"
          },
          {
            "name" : "Raspberry Pi",
            "screen_name" : "Raspberry_Pi",
            "indices" : [
              "109",
              "122"
            ],
            "id_str" : "302666251",
            "id" : "302666251"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1572613762758184960",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1572613762758184960",
      "created_at" : "Wed Sep 21 15:48:33 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @adafruit: How to build Raspberry Pi Pico programs with no software installation #RaspberryPi @petewarden @Raspberry_Pi https://t.co/Tgl…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1572430693392596995"
          ],
          "editableUntil" : "2022-09-21T04:11:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "82",
              "96"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "phl make",
            "screen_name" : "phlmake",
            "indices" : [
              "73",
              "81"
            ],
            "id_str" : "366117716",
            "id" : "366117716"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "96"
      ],
      "favorite_count" : "6",
      "id_str" : "1572430693392596995",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1572430693392596995",
      "created_at" : "Wed Sep 21 03:41:06 +0000 2022",
      "favorited" : false,
      "full_text" : "🎉🎉🎉 CircuitPython Online IDE is going to be shown on Philly Maker Faire! @phlmake #CircuitPython",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1572262423318482944"
          ],
          "editableUntil" : "2022-09-20T17:02:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "156"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1572016859402338304",
      "id_str" : "1572262423318482944",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1572262423318482944",
      "in_reply_to_status_id" : "1572016859402338304",
      "created_at" : "Tue Sep 20 16:32:27 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev In CircuitPython, with i2c = busio.I2C(SCL, SDA, frequency=int(1e6)), I can get a 400 Hz scan rate of 4 mcp23017s and one trackball. Scan only.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1572214298201698304"
          ],
          "editableUntil" : "2022-09-20T13:51:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matix",
            "screen_name" : "MatzElectronics",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "3479427252",
            "id" : "3479427252"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "81"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1572091670438772738",
      "id_str" : "1572214298201698304",
      "in_reply_to_user_id" : "3479427252",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1572214298201698304",
      "in_reply_to_status_id" : "1572091670438772738",
      "created_at" : "Tue Sep 20 13:21:13 +0000 2022",
      "favorited" : false,
      "full_text" : "@MatzElectronics That looks similar to what I currently have. Thanks for sharing.",
      "lang" : "en",
      "in_reply_to_screen_name" : "MatzElectronics",
      "in_reply_to_user_id_str" : "3479427252"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1571995476995739648"
          ],
          "editableUntil" : "2022-09-19T23:21:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1571994968339746819",
      "id_str" : "1571995476995739648",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1571995476995739648",
      "in_reply_to_status_id" : "1571994968339746819",
      "created_at" : "Mon Sep 19 22:51:42 +0000 2022",
      "favorited" : false,
      "full_text" : "The mode indicator seems to be rather unnecessary, but is actually one part of the test redesigning the whole serial console. Stay tuned.",
      "lang" : "en",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1571994968339746819"
          ],
          "editableUntil" : "2022-09-19T23:19:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1571994968339746819/photo/1",
            "indices" : [
              "259",
              "282"
            ],
            "url" : "https://t.co/219zf971ZS",
            "media_url" : "http://pbs.twimg.com/media/FdDY9B1WQAAaz7f.png",
            "id_str" : "1571994812928114688",
            "id" : "1571994812928114688",
            "media_url_https" : "https://pbs.twimg.com/media/FdDY9B1WQAAaz7f.png",
            "sizes" : {
              "large" : {
                "w" : "332",
                "h" : "194",
                "resize" : "fit"
              },
              "small" : {
                "w" : "332",
                "h" : "194",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "332",
                "h" : "194",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/219zf971ZS"
          }
        ],
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "244",
              "258"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "282"
      ],
      "favorite_count" : "8",
      "id_str" : "1571994968339746819",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1571994968339746819",
      "possibly_sensitive" : false,
      "created_at" : "Mon Sep 19 22:49:41 +0000 2022",
      "favorited" : false,
      "full_text" : "Two features that I have being promised for so long are finally added to CircuitPython Online IDE. One is the file modification indicator. The other is the serial mode indicator showing whether the microcontroller is in REPL or running script. #CircuitPython https://t.co/219zf971ZS",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1571994968339746819/photo/1",
            "indices" : [
              "259",
              "282"
            ],
            "url" : "https://t.co/219zf971ZS",
            "media_url" : "http://pbs.twimg.com/media/FdDY9B1WQAAaz7f.png",
            "id_str" : "1571994812928114688",
            "id" : "1571994812928114688",
            "media_url_https" : "https://pbs.twimg.com/media/FdDY9B1WQAAaz7f.png",
            "sizes" : {
              "large" : {
                "w" : "332",
                "h" : "194",
                "resize" : "fit"
              },
              "small" : {
                "w" : "332",
                "h" : "194",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "332",
                "h" : "194",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/219zf971ZS"
          },
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1571994968339746819/photo/1",
            "indices" : [
              "259",
              "282"
            ],
            "url" : "https://t.co/219zf971ZS",
            "media_url" : "http://pbs.twimg.com/media/FdDY91oXgAA1dYO.png",
            "id_str" : "1571994826832314368",
            "id" : "1571994826832314368",
            "media_url_https" : "https://pbs.twimg.com/media/FdDY91oXgAA1dYO.png",
            "sizes" : {
              "large" : {
                "w" : "402",
                "h" : "212",
                "resize" : "fit"
              },
              "small" : {
                "w" : "402",
                "h" : "212",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "402",
                "h" : "212",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/219zf971ZS"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1571863322886307842"
          ],
          "editableUntil" : "2022-09-19T14:36:34.641Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Hackster.io",
            "screen_name" : "Hacksterio",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1473686120",
            "id" : "1473686120"
          },
          {
            "name" : "Seeed Studio",
            "screen_name" : "seeedstudio",
            "indices" : [
              "67",
              "79"
            ],
            "id_str" : "28542415",
            "id" : "28542415"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/5cuW1TGKeD",
            "expanded_url" : "https://bit.ly/3xwsI1W",
            "display_url" : "bit.ly/3xwsI1W",
            "indices" : [
              "95",
              "118"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1571863322886307842",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1571863322886307842",
      "possibly_sensitive" : false,
      "created_at" : "Mon Sep 19 14:06:34 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @Hacksterio: Purple Owl is a 60% mechanical keyboard powered by @SeeedStudio's XIAO RP2040: https://t.co/5cuW1TGKeD https://t.co/9liWJTq…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1571696596957667334"
          ],
          "editableUntil" : "2022-09-19T03:34:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "181"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1571603390286766081",
      "id_str" : "1571696596957667334",
      "in_reply_to_user_id" : "4918794850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1571696596957667334",
      "in_reply_to_status_id" : "1571603390286766081",
      "created_at" : "Mon Sep 19 03:04:04 +0000 2022",
      "favorited" : false,
      "full_text" : "@anne_engineer At the time of making, I didn't find an easy way to mimic Switch Pro controller, so a fighter board is used. Ideally, everything can be done with a 2040, like GP2040.",
      "lang" : "en",
      "in_reply_to_screen_name" : "anne_engineer",
      "in_reply_to_user_id_str" : "4918794850"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1571696424110243840"
          ],
          "editableUntil" : "2022-09-19T03:33:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "201"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1571603390286766081",
      "id_str" : "1571696424110243840",
      "in_reply_to_user_id" : "4918794850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1571696424110243840",
      "in_reply_to_status_id" : "1571603390286766081",
      "created_at" : "Mon Sep 19 03:03:22 +0000 2022",
      "favorited" : false,
      "full_text" : "@anne_engineer A fighter board is used for the blue switches and yellow buttons. A SAMD21 is used to covert encoder signal to button push signal and send to the fighter board. Code is in CircuitPython.",
      "lang" : "en",
      "in_reply_to_screen_name" : "anne_engineer",
      "in_reply_to_user_id_str" : "4918794850"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1571197084191137795"
          ],
          "editableUntil" : "2022-09-17T18:29:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "J.Argente",
            "screen_name" : "JArgente5",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1518308037592850432",
            "id" : "1518308037592850432"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "275"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1571167349696258054",
      "id_str" : "1571197084191137795",
      "in_reply_to_user_id" : "1518308037592850432",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1571197084191137795",
      "in_reply_to_status_id" : "1571167349696258054",
      "created_at" : "Sat Sep 17 17:59:10 +0000 2022",
      "favorited" : false,
      "full_text" : "@JArgente5 It's not like any rules there. It's just about tight space and limited air flow. I used a fume extractor before. It's very good at reducing the amount of fume but the smell is still there. I am also looking for some local makerspace. I hope I can find some nearby.",
      "lang" : "en",
      "in_reply_to_screen_name" : "JArgente5",
      "in_reply_to_user_id_str" : "1518308037592850432"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1571190379285716993"
          ],
          "editableUntil" : "2022-09-17T18:02:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jacek Fedoryński",
            "screen_name" : "jfedorynski",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1222262234631606274",
            "id" : "1222262234631606274"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "101"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1571123809520066561",
      "id_str" : "1571190379285716993",
      "in_reply_to_user_id" : "1222262234631606274",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1571190379285716993",
      "in_reply_to_status_id" : "1571123809520066561",
      "created_at" : "Sat Sep 17 17:32:32 +0000 2022",
      "favorited" : false,
      "full_text" : "@jfedorynski Hey! Just realized that you are the author of the HID remapper! Thank you for your work!",
      "lang" : "en",
      "in_reply_to_screen_name" : "jfedorynski",
      "in_reply_to_user_id_str" : "1222262234631606274"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1571188799706726401"
          ],
          "editableUntil" : "2022-09-17T17:56:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1571188799706726401/video/1",
            "indices" : [
              "20",
              "43"
            ],
            "url" : "https://t.co/w8FrEYoLlN",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1571188432579297283/pu/img/B6hIzd4YjUGydZp8.jpg",
            "id_str" : "1571188432579297283",
            "id" : "1571188432579297283",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1571188432579297283/pu/img/B6hIzd4YjUGydZp8.jpg",
            "sizes" : {
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/w8FrEYoLlN"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "4",
      "id_str" : "1571188799706726401",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1571188799706726401",
      "possibly_sensitive" : false,
      "created_at" : "Sat Sep 17 17:26:15 +0000 2022",
      "favorited" : false,
      "full_text" : "A strange game pad. https://t.co/w8FrEYoLlN",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1571188799706726401/video/1",
            "indices" : [
              "20",
              "43"
            ],
            "url" : "https://t.co/w8FrEYoLlN",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1571188432579297283/pu/img/B6hIzd4YjUGydZp8.jpg",
            "id_str" : "1571188432579297283",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "70464",
              "variants" : [
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1571188432579297283/pu/vid/640x360/Xyn_G7f-m7MruuDL.mp4?tag=12"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1571188432579297283/pu/vid/1280x720/NSSKR6zzIVYrilZ0.mp4?tag=12"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1571188432579297283/pu/pl/RjpJfQIaBzbsTsrA.m3u8?tag=12&container=fmp4"
                },
                {
                  "bitrate" : "256000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1571188432579297283/pu/vid/480x270/E7Ezyg8XFvyVXfDs.mp4?tag=12"
                }
              ]
            },
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1571188432579297283",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1571188432579297283/pu/img/B6hIzd4YjUGydZp8.jpg",
            "sizes" : {
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "display_url" : "pic.twitter.com/w8FrEYoLlN"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1571139638097776640"
          ],
          "editableUntil" : "2022-09-17T14:40:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jacek Fedoryński",
            "screen_name" : "jfedorynski",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1222262234631606274",
            "id" : "1222262234631606274"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/E4pwMD2sRr",
            "expanded_url" : "https://oshwlab.com/urfdvw/keyboard-modifier",
            "display_url" : "oshwlab.com/urfdvw/keyboar…",
            "indices" : [
              "13",
              "36"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "171"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1571123809520066561",
      "id_str" : "1571139638097776640",
      "in_reply_to_user_id" : "1222262234631606274",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1571139638097776640",
      "in_reply_to_status_id" : "1571123809520066561",
      "possibly_sensitive" : false,
      "created_at" : "Sat Sep 17 14:10:54 +0000 2022",
      "favorited" : false,
      "full_text" : "@jfedorynski https://t.co/E4pwMD2sRr\nTotally unnecessary making a board just for a USB port. But as I use it all the time, just want it to look a little nicer on the desk.",
      "lang" : "en",
      "in_reply_to_screen_name" : "jfedorynski",
      "in_reply_to_user_id_str" : "1222262234631606274"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1571136711325020161"
          ],
          "editableUntil" : "2022-09-17T14:29:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "J.Argente",
            "screen_name" : "JArgente5",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1518308037592850432",
            "id" : "1518308037592850432"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "207"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1571129286094102537",
      "id_str" : "1571136711325020161",
      "in_reply_to_user_id" : "1518308037592850432",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1571136711325020161",
      "in_reply_to_status_id" : "1571129286094102537",
      "created_at" : "Sat Sep 17 13:59:16 +0000 2022",
      "favorited" : false,
      "full_text" : "@JArgente5 I actually thought about it before. But the situation is that the apartment that I am living in does not allow me to solder indoors. So I brought a gas powered hot air gun which is handy outdoors.",
      "lang" : "en",
      "in_reply_to_screen_name" : "JArgente5",
      "in_reply_to_user_id_str" : "1518308037592850432"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1571135029883080705"
          ],
          "editableUntil" : "2022-09-17T14:22:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "David Glaude🦠💉💉💉💉",
            "screen_name" : "DavidGlaude",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "534421496",
            "id" : "534421496"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "147"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1571124062088495104",
      "id_str" : "1571135029883080705",
      "in_reply_to_user_id" : "534421496",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1571135029883080705",
      "in_reply_to_status_id" : "1571124062088495104",
      "created_at" : "Sat Sep 17 13:52:36 +0000 2022",
      "favorited" : false,
      "full_text" : "@DavidGlaude Teensy 4.1 does have USB host in CPy, but is surely overkill for a remapper and usually out of stock. Hope it could be port to RP2040.",
      "lang" : "en",
      "in_reply_to_screen_name" : "DavidGlaude",
      "in_reply_to_user_id_str" : "534421496"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570900638208512001"
          ],
          "editableUntil" : "2022-09-16T22:51:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/hv9YoSZk6d",
            "expanded_url" : "https://github.com/jfedor2/hid-remapper",
            "display_url" : "github.com/jfedor2/hid-re…",
            "indices" : [
              "16",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "7",
      "in_reply_to_status_id_str" : "1570899638018002944",
      "id_str" : "1570900638208512001",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1570900638208512001",
      "in_reply_to_status_id" : "1570899638018002944",
      "possibly_sensitive" : false,
      "created_at" : "Fri Sep 16 22:21:12 +0000 2022",
      "favorited" : false,
      "full_text" : "Currently using https://t.co/hv9YoSZk6d.",
      "lang" : "en",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570899638018002944"
          ],
          "editableUntil" : "2022-09-16T22:47:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1570899638018002944/photo/1",
            "indices" : [
              "222",
              "245"
            ],
            "url" : "https://t.co/B7oIG42rnQ",
            "media_url" : "http://pbs.twimg.com/media/Fcz05TFXkAk_KCj.jpg",
            "id_str" : "1570899635257970697",
            "id" : "1570899635257970697",
            "media_url_https" : "https://pbs.twimg.com/media/Fcz05TFXkAk_KCj.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1580",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "525",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "926",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/B7oIG42rnQ"
          }
        ],
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "179",
              "193"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "245"
      ],
      "favorite_count" : "79",
      "id_str" : "1570899638018002944",
      "truncated" : false,
      "retweet_count" : "8",
      "id" : "1570899638018002944",
      "possibly_sensitive" : false,
      "created_at" : "Fri Sep 16 22:17:14 +0000 2022",
      "favorited" : false,
      "full_text" : "Bought my first hot air gun in life. Now I can recycle microcontrollers from failed prototypes. Just made a keyboard remapper from a recycled Xiao2040. The question is, when will #CircuitPython support USB host on RP2040? https://t.co/B7oIG42rnQ",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1570899638018002944/photo/1",
            "indices" : [
              "222",
              "245"
            ],
            "url" : "https://t.co/B7oIG42rnQ",
            "media_url" : "http://pbs.twimg.com/media/Fcz05TFXkAk_KCj.jpg",
            "id_str" : "1570899635257970697",
            "id" : "1570899635257970697",
            "media_url_https" : "https://pbs.twimg.com/media/Fcz05TFXkAk_KCj.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1580",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "525",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "926",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/B7oIG42rnQ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570801562699845633"
          ],
          "editableUntil" : "2022-09-16T16:17:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Emillé Levassor",
            "screen_name" : "RzR0tsch1ld",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1434745092019920896",
            "id" : "1434745092019920896"
          },
          {
            "name" : "hackaday",
            "screen_name" : "hackaday",
            "indices" : [
              "13",
              "22"
            ],
            "id_str" : "14607140",
            "id" : "14607140"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1570666350070341632",
      "id_str" : "1570801562699845633",
      "in_reply_to_user_id" : "1434745092019920896",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1570801562699845633",
      "in_reply_to_status_id" : "1570666350070341632",
      "created_at" : "Fri Sep 16 15:47:31 +0000 2022",
      "favorited" : false,
      "full_text" : "@RzR0tsch1ld @hackaday Or D - Go to the dark side of Assembly.",
      "lang" : "en",
      "in_reply_to_screen_name" : "RzR0tsch1ld",
      "in_reply_to_user_id_str" : "1434745092019920896"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570801161795694594"
          ],
          "editableUntil" : "2022-09-16T16:15:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "hackaday",
            "screen_name" : "hackaday",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "14607140",
            "id" : "14607140"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "122"
      ],
      "favorite_count" : "10",
      "in_reply_to_status_id_str" : "1570652701125660672",
      "id_str" : "1570801161795694594",
      "in_reply_to_user_id" : "14607140",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1570801161795694594",
      "in_reply_to_status_id" : "1570652701125660672",
      "created_at" : "Fri Sep 16 15:45:55 +0000 2022",
      "favorited" : false,
      "full_text" : "@hackaday I pushed all the limit of an attiny85 by A for like half a year. Tired of it, and doing B with SAMD21 right now.",
      "lang" : "en",
      "in_reply_to_screen_name" : "hackaday",
      "in_reply_to_user_id_str" : "14607140"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570523528331669504"
          ],
          "editableUntil" : "2022-09-15T21:52:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          },
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "15",
              "27"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          },
          {
            "name" : "CircuitPython",
            "screen_name" : "CircuitPython",
            "indices" : [
              "28",
              "42"
            ],
            "id_str" : "811605410293645313",
            "id" : "811605410293645313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "270"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1570488524297895942",
      "id_str" : "1570523528331669504",
      "in_reply_to_user_id" : "4918794850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1570523528331669504",
      "in_reply_to_status_id" : "1570488524297895942",
      "created_at" : "Thu Sep 15 21:22:42 +0000 2022",
      "favorited" : false,
      "full_text" : "@anne_engineer @TreasureDev @CircuitPython Underestimated the level of protection there. The only 2 things I can read from serial info are USB Vender ID and USB Product ID. Didn't find good ways to decode them with JS. I think probability need to wait for the next step.",
      "lang" : "en",
      "in_reply_to_screen_name" : "anne_engineer",
      "in_reply_to_user_id_str" : "4918794850"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570511815381225472"
          ],
          "editableUntil" : "2022-09-15T21:06:10.142Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "kenneth cassel",
            "screen_name" : "KennethCassel",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1319269656264409088",
            "id" : "1319269656264409088"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1570511815381225472",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1570511815381225472",
      "created_at" : "Thu Sep 15 20:36:10 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @KennethCassel: Build, program, and run hardware projects in the browser\n\nyou can play w/ a very limited demo now\nhttps://t.co/gHDTfJnXU…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570501557342580737"
          ],
          "editableUntil" : "2022-09-15T20:25:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          },
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "15",
              "27"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          },
          {
            "name" : "CircuitPython",
            "screen_name" : "CircuitPython",
            "indices" : [
              "28",
              "42"
            ],
            "id_str" : "811605410293645313",
            "id" : "811605410293645313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "271"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1570488524297895942",
      "id_str" : "1570501557342580737",
      "in_reply_to_user_id" : "4918794850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1570501557342580737",
      "in_reply_to_status_id" : "1570488524297895942",
      "created_at" : "Thu Sep 15 19:55:24 +0000 2022",
      "favorited" : false,
      "full_text" : "@anne_engineer @TreasureDev @CircuitPython Might do that through Serial Port description first. This can be added to the current release without much code modification.\nReading boot_out.txt requires opening the folder instead of a file, which is planned in the next step.",
      "lang" : "en",
      "in_reply_to_screen_name" : "anne_engineer",
      "in_reply_to_user_id_str" : "4918794850"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570499024498855936"
          ],
          "editableUntil" : "2022-09-15T20:15:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          },
          {
            "name" : "CircuitPython",
            "screen_name" : "CircuitPython",
            "indices" : [
              "13",
              "27"
            ],
            "id_str" : "811605410293645313",
            "id" : "811605410293645313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "70"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1570485538729381888",
      "id_str" : "1570499024498855936",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1570499024498855936",
      "in_reply_to_status_id" : "1570485538729381888",
      "created_at" : "Thu Sep 15 19:45:20 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev @CircuitPython That is a good point I should keep in mind",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570447435394322432"
          ],
          "editableUntil" : "2022-09-15T16:50:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          },
          {
            "name" : "Maker Melissa @makermelissa@mastodon.social",
            "screen_name" : "makermelissa",
            "indices" : [
              "15",
              "28"
            ],
            "id_str" : "41765435",
            "id" : "41765435"
          },
          {
            "name" : "CircuitPython",
            "screen_name" : "CircuitPython",
            "indices" : [
              "29",
              "43"
            ],
            "id_str" : "811605410293645313",
            "id" : "811605410293645313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1570447066593398785",
      "id_str" : "1570447435394322432",
      "in_reply_to_user_id" : "4918794850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1570447435394322432",
      "in_reply_to_status_id" : "1570447066593398785",
      "created_at" : "Thu Sep 15 16:20:20 +0000 2022",
      "favorited" : false,
      "full_text" : "@anne_engineer @makermelissa @CircuitPython Would love to.",
      "lang" : "en",
      "in_reply_to_screen_name" : "anne_engineer",
      "in_reply_to_user_id_str" : "4918794850"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570446407747657728"
          ],
          "editableUntil" : "2022-09-15T16:46:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Maker Melissa @makermelissa@mastodon.social",
            "screen_name" : "makermelissa",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "41765435",
            "id" : "41765435"
          },
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "14",
              "28"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          },
          {
            "name" : "CircuitPython",
            "screen_name" : "CircuitPython",
            "indices" : [
              "29",
              "43"
            ],
            "id_str" : "811605410293645313",
            "id" : "811605410293645313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "149"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1570441549405880323",
      "id_str" : "1570446407747657728",
      "in_reply_to_user_id" : "41765435",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1570446407747657728",
      "in_reply_to_status_id" : "1570441549405880323",
      "created_at" : "Thu Sep 15 16:16:15 +0000 2022",
      "favorited" : false,
      "full_text" : "@makermelissa @anne_engineer @CircuitPython My code are still vanilla JS right now. Still learning things 🤦. Too much delays ever since changing job.",
      "lang" : "en",
      "in_reply_to_screen_name" : "makermelissa",
      "in_reply_to_user_id_str" : "41765435"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570427738799968256"
          ],
          "editableUntil" : "2022-09-15T15:32:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          },
          {
            "name" : "CircuitPython",
            "screen_name" : "CircuitPython",
            "indices" : [
              "13",
              "27"
            ],
            "id_str" : "811605410293645313",
            "id" : "811605410293645313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "97"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1570426109271089154",
      "id_str" : "1570427738799968256",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1570427738799968256",
      "in_reply_to_status_id" : "1570426109271089154",
      "created_at" : "Thu Sep 15 15:02:04 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev @CircuitPython See if I have enough time to learn the skill to make it rearrangable.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570426479246295042"
          ],
          "editableUntil" : "2022-09-15T15:27:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1570423577685659650",
      "id_str" : "1570426479246295042",
      "in_reply_to_user_id" : "4918794850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1570426479246295042",
      "in_reply_to_status_id" : "1570423577685659650",
      "created_at" : "Thu Sep 15 14:57:04 +0000 2022",
      "favorited" : false,
      "full_text" : "@anne_engineer Will do!",
      "lang" : "en",
      "in_reply_to_screen_name" : "anne_engineer",
      "in_reply_to_user_id_str" : "4918794850"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570426344613322753"
          ],
          "editableUntil" : "2022-09-15T15:26:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "TreasureDev@Hackaday.social",
            "screen_name" : "TreasureDev",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "4557157036",
            "id" : "4557157036"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "200"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1570424247293460484",
      "id_str" : "1570426344613322753",
      "in_reply_to_user_id" : "4557157036",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1570426344613322753",
      "in_reply_to_status_id" : "1570424247293460484",
      "created_at" : "Thu Sep 15 14:56:32 +0000 2022",
      "favorited" : false,
      "full_text" : "@TreasureDev Instead of diodes I want to try out the I2C IO expander for reading keys. Actually all peripherals (including a track ball and an oled) are I2C devices so actually only two pins are used.",
      "lang" : "en",
      "in_reply_to_screen_name" : "TreasureDev",
      "in_reply_to_user_id_str" : "4557157036"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1570391147800924161"
          ],
          "editableUntil" : "2022-09-15T13:06:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1570391147800924161/photo/1",
            "indices" : [
              "38",
              "61"
            ],
            "url" : "https://t.co/X1JeKtXobv",
            "media_url" : "http://pbs.twimg.com/media/Fcsma4IWQAAoHLF.jpg",
            "id_str" : "1570391138254602240",
            "id" : "1570391138254602240",
            "media_url_https" : "https://pbs.twimg.com/media/Fcsma4IWQAAoHLF.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/X1JeKtXobv"
          }
        ],
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "13",
              "27"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "7",
      "id_str" : "1570391147800924161",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1570391147800924161",
      "possibly_sensitive" : false,
      "created_at" : "Thu Sep 15 12:36:40 +0000 2022",
      "favorited" : false,
      "full_text" : "Let's make a #CircuitPython keyboard! https://t.co/X1JeKtXobv",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1570391147800924161/photo/1",
            "indices" : [
              "38",
              "61"
            ],
            "url" : "https://t.co/X1JeKtXobv",
            "media_url" : "http://pbs.twimg.com/media/Fcsma4IWQAAoHLF.jpg",
            "id_str" : "1570391138254602240",
            "id" : "1570391138254602240",
            "media_url_https" : "https://pbs.twimg.com/media/Fcsma4IWQAAoHLF.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/X1JeKtXobv"
          },
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1570391147800924161/photo/1",
            "indices" : [
              "38",
              "61"
            ],
            "url" : "https://t.co/X1JeKtXobv",
            "media_url" : "http://pbs.twimg.com/media/FcsmbLEWYAYNY3Z.jpg",
            "id_str" : "1570391143338106886",
            "id" : "1570391143338106886",
            "media_url_https" : "https://pbs.twimg.com/media/FcsmbLEWYAYNY3Z.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/X1JeKtXobv"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1569828480208216064"
          ],
          "editableUntil" : "2022-09-13T23:50:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mike Diehl",
            "screen_name" : "w8lid",
            "indices" : [
              "0",
              "6"
            ],
            "id_str" : "2989375544",
            "id" : "2989375544"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1569786728344338434",
      "id_str" : "1569828480208216064",
      "in_reply_to_user_id" : "2989375544",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1569828480208216064",
      "in_reply_to_status_id" : "1569786728344338434",
      "created_at" : "Tue Sep 13 23:20:50 +0000 2022",
      "favorited" : false,
      "full_text" : "@w8lid A nut this size is insanity.",
      "lang" : "en",
      "in_reply_to_screen_name" : "w8lid",
      "in_reply_to_user_id_str" : "2989375544"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1569688433953591296"
          ],
          "editableUntil" : "2022-09-13T14:34:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dana Sibera",
            "screen_name" : "NanoRaptor",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "2312854706",
            "id" : "2312854706"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "70"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1569657936611508224",
      "id_str" : "1569688433953591296",
      "in_reply_to_user_id" : "2312854706",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1569688433953591296",
      "in_reply_to_status_id" : "1569657936611508224",
      "created_at" : "Tue Sep 13 14:04:20 +0000 2022",
      "favorited" : false,
      "full_text" : "@NanoRaptor The new 78Hz ~ 155Hz refresh rate is called Promotion Plus",
      "lang" : "en",
      "in_reply_to_screen_name" : "NanoRaptor",
      "in_reply_to_user_id_str" : "2312854706"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1569637956016635904"
          ],
          "editableUntil" : "2022-09-13T11:13:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Programmer Humor",
            "screen_name" : "PR0GRAMMERHUM0R",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "965774983527043072",
            "id" : "965774983527043072"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "19"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1569491084996231168",
      "id_str" : "1569637956016635904",
      "in_reply_to_user_id" : "965774983527043072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1569637956016635904",
      "in_reply_to_status_id" : "1569491084996231168",
      "created_at" : "Tue Sep 13 10:43:45 +0000 2022",
      "favorited" : false,
      "full_text" : "@PR0GRAMMERHUM0R Me",
      "lang" : "und",
      "in_reply_to_screen_name" : "PR0GRAMMERHUM0R",
      "in_reply_to_user_id_str" : "965774983527043072"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1569507317854654465"
          ],
          "editableUntil" : "2022-09-13T02:34:39.269Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "hackaday",
            "screen_name" : "hackaday",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "14607140",
            "id" : "14607140"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/H5oJUiYWlg",
            "expanded_url" : "https://hackaday.com/2022/09/12/the-philly-maker-faire-is-back-and-wants-your-hacks/",
            "display_url" : "hackaday.com/2022/09/12/the…",
            "indices" : [
              "105",
              "128"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "128"
      ],
      "favorite_count" : "0",
      "id_str" : "1569507317854654465",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1569507317854654465",
      "possibly_sensitive" : false,
      "created_at" : "Tue Sep 13 02:04:39 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @hackaday: The Philly Maker Faire returns, and is looking for hackers and makers to show their stuff. https://t.co/H5oJUiYWlg",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1568000185204371457"
          ],
          "editableUntil" : "2022-09-08T22:45:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1568000185204371457/video/1",
            "indices" : [
              "164",
              "187"
            ],
            "url" : "https://t.co/a3qIROoZxu",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1568000134553767936/pu/img/xfBggf-GqPH66Q6H.jpg",
            "id_str" : "1568000134553767936",
            "id" : "1568000134553767936",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1568000134553767936/pu/img/xfBggf-GqPH66Q6H.jpg",
            "sizes" : {
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "720",
                "h" : "1280",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "383",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/a3qIROoZxu"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "187"
      ],
      "favorite_count" : "4",
      "id_str" : "1568000185204371457",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1568000185204371457",
      "possibly_sensitive" : false,
      "created_at" : "Thu Sep 08 22:15:50 +0000 2022",
      "favorited" : false,
      "full_text" : "This is probably the 100th time I got trapped in the maze called NY Penn station. Finally find an exit. Wait, something strange here. Should I take this adventure? https://t.co/a3qIROoZxu",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1568000185204371457/video/1",
            "indices" : [
              "164",
              "187"
            ],
            "url" : "https://t.co/a3qIROoZxu",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1568000134553767936/pu/img/xfBggf-GqPH66Q6H.jpg",
            "id_str" : "1568000134553767936",
            "video_info" : {
              "aspect_ratio" : [
                "9",
                "16"
              ],
              "duration_millis" : "3459",
              "variants" : [
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1568000134553767936/pu/vid/720x1280/8ZQyl9vsqqGIIfaD.mp4?tag=12"
                },
                {
                  "bitrate" : "950000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1568000134553767936/pu/vid/480x852/19mDP5CdN9AaNHB0.mp4?tag=12"
                },
                {
                  "bitrate" : "632000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1568000134553767936/pu/vid/320x568/5pmbY-ioZEQMb046.mp4?tag=12"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1568000134553767936/pu/pl/3Av2Hd5TfJUeK5K-.m3u8?tag=12&container=fmp4"
                }
              ]
            },
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1568000134553767936",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1568000134553767936/pu/img/xfBggf-GqPH66Q6H.jpg",
            "sizes" : {
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "720",
                "h" : "1280",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "383",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "display_url" : "pic.twitter.com/a3qIROoZxu"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1561175736114896896"
          ],
          "editableUntil" : "2022-08-21T02:47:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Amelia Warner",
            "screen_name" : "facetimeJS",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "820249925384630273",
            "id" : "820249925384630273"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1560993555937624064",
      "id_str" : "1561175736114896896",
      "in_reply_to_user_id" : "820249925384630273",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1561175736114896896",
      "in_reply_to_status_id" : "1560993555937624064",
      "created_at" : "Sun Aug 21 02:17:55 +0000 2022",
      "favorited" : false,
      "full_text" : "@facetimeJS Wsl",
      "lang" : "und",
      "in_reply_to_screen_name" : "facetimeJS",
      "in_reply_to_user_id_str" : "820249925384630273"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1560760811269885952"
          ],
          "editableUntil" : "2022-08-19T23:19:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Linux Handbook",
            "screen_name" : "LinuxHandbook",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1023073045781590019",
            "id" : "1023073045781590019"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "170"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1560500770553810944",
      "id_str" : "1560760811269885952",
      "in_reply_to_user_id" : "1023073045781590019",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1560760811269885952",
      "in_reply_to_status_id" : "1560500770553810944",
      "created_at" : "Fri Aug 19 22:49:09 +0000 2022",
      "favorited" : false,
      "full_text" : "@LinuxHandbook Avoid preaching Linux as your life's only choice. Instead, try to get people into WSL and alike. You don't have to abandon what you already have for Linux.",
      "lang" : "en",
      "in_reply_to_screen_name" : "LinuxHandbook",
      "in_reply_to_user_id_str" : "1023073045781590019"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1557885438735667200"
          ],
          "editableUntil" : "2022-08-12T00:53:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Martin Nobel",
            "screen_name" : "MartinNobel_",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1501834629623742464",
            "id" : "1501834629623742464"
          },
          {
            "name" : "Dana Sibera",
            "screen_name" : "NanoRaptor",
            "indices" : [
              "14",
              "25"
            ],
            "id_str" : "2312854706",
            "id" : "2312854706"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1557685036211912704",
      "id_str" : "1557885438735667200",
      "in_reply_to_user_id" : "1501834629623742464",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1557885438735667200",
      "in_reply_to_status_id" : "1557685036211912704",
      "created_at" : "Fri Aug 12 00:23:27 +0000 2022",
      "favorited" : false,
      "full_text" : "@MartinNobel_ @NanoRaptor Like the last one before flattening.",
      "lang" : "en",
      "in_reply_to_screen_name" : "MartinNobel_",
      "in_reply_to_user_id_str" : "1501834629623742464"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1556748336358739968"
          ],
          "editableUntil" : "2022-08-08T21:35:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CircuitPython",
            "screen_name" : "CircuitPython",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "811605410293645313",
            "id" : "811605410293645313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1556410494839398400",
      "id_str" : "1556748336358739968",
      "in_reply_to_user_id" : "811605410293645313",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1556748336358739968",
      "in_reply_to_status_id" : "1556410494839398400",
      "created_at" : "Mon Aug 08 21:05:01 +0000 2022",
      "favorited" : false,
      "full_text" : "@CircuitPython This raised so many possibilities.",
      "lang" : "en",
      "in_reply_to_screen_name" : "CircuitPython",
      "in_reply_to_user_id_str" : "811605410293645313"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1553086773529567235"
          ],
          "editableUntil" : "2022-07-29T19:05:16.423Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "The CircuitPython Show",
            "screen_name" : "circuitpyshow",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1479807513356816384",
            "id" : "1479807513356816384"
          },
          {
            "name" : "CircuitPython",
            "screen_name" : "CircuitPython",
            "indices" : [
              "45",
              "59"
            ],
            "id_str" : "811605410293645313",
            "id" : "811605410293645313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1553086773529567235",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1553086773529567235",
      "created_at" : "Fri Jul 29 18:35:16 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @circuitpyshow: Three weeks from today is @CircuitPython Day! I'll be hosting a LIVE panel with Kattni, Jeff, Dan, and Tim from Adafruit…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1552698629894426625"
          ],
          "editableUntil" : "2022-07-28T17:22:55.769Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Paul Cutler 🇺🇦",
            "screen_name" : "prcutler",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "944651",
            "id" : "944651"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/prcutler/status/1552685289965064193/photo/1",
            "source_status_id" : "1552685289965064193",
            "indices" : [
              "98",
              "121"
            ],
            "url" : "https://t.co/BrtZ5yPXBb",
            "media_url" : "http://pbs.twimg.com/media/FYw_CfiXgAAKPqJ.jpg",
            "id_str" : "1552685283593912320",
            "source_user_id" : "944651",
            "id" : "1552685283593912320",
            "media_url_https" : "https://pbs.twimg.com/media/FYw_CfiXgAAKPqJ.jpg",
            "source_user_id_str" : "944651",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "417",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1257",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "737",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1552685289965064193",
            "display_url" : "pic.twitter.com/BrtZ5yPXBb"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "121"
      ],
      "favorite_count" : "0",
      "id_str" : "1552698629894426625",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1552698629894426625",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jul 28 16:52:55 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @prcutler: Shh, don’t tell anyone.  (I’m working on some documentation for the Mu code editor) https://t.co/BrtZ5yPXBb",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/prcutler/status/1552685289965064193/photo/1",
            "source_status_id" : "1552685289965064193",
            "indices" : [
              "98",
              "121"
            ],
            "url" : "https://t.co/BrtZ5yPXBb",
            "media_url" : "http://pbs.twimg.com/media/FYw_CfiXgAAKPqJ.jpg",
            "id_str" : "1552685283593912320",
            "source_user_id" : "944651",
            "id" : "1552685283593912320",
            "media_url_https" : "https://pbs.twimg.com/media/FYw_CfiXgAAKPqJ.jpg",
            "source_user_id_str" : "944651",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "417",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1257",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "737",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1552685289965064193",
            "display_url" : "pic.twitter.com/BrtZ5yPXBb"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1552631493326999552"
          ],
          "editableUntil" : "2022-07-28T12:56:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "てるミ",
            "screen_name" : "Tellme_oekaki_",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1365658687847550982",
            "id" : "1365658687847550982"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1552631493326999552/photo/1",
            "indices" : [
              "16",
              "39"
            ],
            "url" : "https://t.co/JMTk6xvrft",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/FYwN9JCXwAEJ2b_.jpg",
            "id_str" : "1552631315585024001",
            "id" : "1552631315585024001",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/FYwN9JCXwAEJ2b_.jpg",
            "sizes" : {
              "medium" : {
                "w" : "342",
                "h" : "284",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "342",
                "h" : "284",
                "resize" : "fit"
              },
              "large" : {
                "w" : "342",
                "h" : "284",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/JMTk6xvrft"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1552345080052457472",
      "id_str" : "1552631493326999552",
      "in_reply_to_user_id" : "1365658687847550982",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1552631493326999552",
      "in_reply_to_status_id" : "1552345080052457472",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jul 28 12:26:09 +0000 2022",
      "favorited" : false,
      "full_text" : "@Tellme_oekaki_ https://t.co/JMTk6xvrft",
      "lang" : "qme",
      "in_reply_to_screen_name" : "Tellme_oekaki_",
      "in_reply_to_user_id_str" : "1365658687847550982",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1552631493326999552/photo/1",
            "indices" : [
              "16",
              "39"
            ],
            "url" : "https://t.co/JMTk6xvrft",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/FYwN9JCXwAEJ2b_.jpg",
            "id_str" : "1552631315585024001",
            "video_info" : {
              "aspect_ratio" : [
                "171",
                "142"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/FYwN9JCXwAEJ2b_.mp4"
                }
              ]
            },
            "id" : "1552631315585024001",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/FYwN9JCXwAEJ2b_.jpg",
            "sizes" : {
              "medium" : {
                "w" : "342",
                "h" : "284",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "342",
                "h" : "284",
                "resize" : "fit"
              },
              "large" : {
                "w" : "342",
                "h" : "284",
                "resize" : "fit"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.twitter.com/JMTk6xvrft"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1548143383297662976"
          ],
          "editableUntil" : "2022-07-16T03:42:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1548143383297662976/photo/1",
            "indices" : [
              "40",
              "63"
            ],
            "url" : "https://t.co/HVUQhTQXrY",
            "media_url" : "http://pbs.twimg.com/media/FXwb8UXUsAIvE61.jpg",
            "id_str" : "1548143094981242882",
            "id" : "1548143094981242882",
            "media_url_https" : "https://pbs.twimg.com/media/FXwb8UXUsAIvE61.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2007",
                "h" : "2048",
                "resize" : "fit"
              },
              "small" : {
                "w" : "666",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1176",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/HVUQhTQXrY"
          }
        ],
        "hashtags" : [
          {
            "text" : "惑星のさみだれ",
            "indices" : [
              "31",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "63"
      ],
      "favorite_count" : "2",
      "id_str" : "1548143383297662976",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1548143383297662976",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jul 16 03:12:00 +0000 2022",
      "favorited" : false,
      "full_text" : "I know I am late to the party. #惑星のさみだれ https://t.co/HVUQhTQXrY",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1548143383297662976/photo/1",
            "indices" : [
              "40",
              "63"
            ],
            "url" : "https://t.co/HVUQhTQXrY",
            "media_url" : "http://pbs.twimg.com/media/FXwb8UXUsAIvE61.jpg",
            "id_str" : "1548143094981242882",
            "id" : "1548143094981242882",
            "media_url_https" : "https://pbs.twimg.com/media/FXwb8UXUsAIvE61.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2007",
                "h" : "2048",
                "resize" : "fit"
              },
              "small" : {
                "w" : "666",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1176",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/HVUQhTQXrY"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1546132130392064000"
          ],
          "editableUntil" : "2022-07-10T14:30:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jasper Sikken find me on Mastodon",
            "screen_name" : "jrsikken",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "413117673",
            "id" : "413117673"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1546131728795897859",
      "id_str" : "1546132130392064000",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1546132130392064000",
      "in_reply_to_status_id" : "1546131728795897859",
      "created_at" : "Sun Jul 10 14:00:00 +0000 2022",
      "favorited" : false,
      "full_text" : "@jrsikken I am too serious and don't have a sense of humor.🙃",
      "lang" : "en",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1546131728795897859"
          ],
          "editableUntil" : "2022-07-10T14:28:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Jasper Sikken find me on Mastodon",
            "screen_name" : "jrsikken",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "413117673",
            "id" : "413117673"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "205"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1545825544067055617",
      "id_str" : "1546131728795897859",
      "in_reply_to_user_id" : "413117673",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1546131728795897859",
      "in_reply_to_status_id" : "1545825544067055617",
      "created_at" : "Sun Jul 10 13:58:24 +0000 2022",
      "favorited" : false,
      "full_text" : "@jrsikken For your questions: there are some lipo battery use exact same package as aa battery, so you can use a lipo and a dummy battery in place of two aa batteries, with a little higher voltage 3.7 vs 3",
      "lang" : "en",
      "in_reply_to_screen_name" : "jrsikken",
      "in_reply_to_user_id_str" : "413117673"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1546130211695198209"
          ],
          "editableUntil" : "2022-07-10T14:22:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dana Sibera",
            "screen_name" : "NanoRaptor",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "2312854706",
            "id" : "2312854706"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1546015883507933185",
      "id_str" : "1546130211695198209",
      "in_reply_to_user_id" : "2312854706",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1546130211695198209",
      "in_reply_to_status_id" : "1546015883507933185",
      "created_at" : "Sun Jul 10 13:52:22 +0000 2022",
      "favorited" : false,
      "full_text" : "@NanoRaptor Waiting for the bug zipper version",
      "lang" : "en",
      "in_reply_to_screen_name" : "NanoRaptor",
      "in_reply_to_user_id_str" : "2312854706"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1546081770759757825"
          ],
          "editableUntil" : "2022-07-10T11:09:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Amelia Warner",
            "screen_name" : "facetimeJS",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "820249925384630273",
            "id" : "820249925384630273"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1545773265888710656",
      "id_str" : "1546081770759757825",
      "in_reply_to_user_id" : "820249925384630273",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1546081770759757825",
      "in_reply_to_status_id" : "1545773265888710656",
      "created_at" : "Sun Jul 10 10:39:53 +0000 2022",
      "favorited" : false,
      "full_text" : "@facetimeJS Wsl",
      "lang" : "und",
      "in_reply_to_screen_name" : "facetimeJS",
      "in_reply_to_user_id_str" : "820249925384630273"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1545504247944462339"
          ],
          "editableUntil" : "2022-07-08T20:55:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "BornHack Badge",
            "screen_name" : "BornhackBadge",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1005540115362533376",
            "id" : "1005540115362533376"
          },
          {
            "name" : "BornHack",
            "screen_name" : "BornHax",
            "indices" : [
              "15",
              "23"
            ],
            "id_str" : "3537051394",
            "id" : "3537051394"
          },
          {
            "name" : "Raspberry Pi",
            "screen_name" : "Raspberry_Pi",
            "indices" : [
              "24",
              "37"
            ],
            "id_str" : "302666251",
            "id" : "302666251"
          },
          {
            "name" : "CircuitPython",
            "screen_name" : "CircuitPython",
            "indices" : [
              "38",
              "52"
            ],
            "id_str" : "811605410293645313",
            "id" : "811605410293645313"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1544399463061626882",
      "id_str" : "1545504247944462339",
      "in_reply_to_user_id" : "1005540115362533376",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1545504247944462339",
      "in_reply_to_status_id" : "1544399463061626882",
      "created_at" : "Fri Jul 08 20:25:01 +0000 2022",
      "favorited" : false,
      "full_text" : "@BornhackBadge @BornHax @Raspberry_Pi @CircuitPython That's cool.\nWhat is that shiny thing on the left?",
      "lang" : "en",
      "in_reply_to_screen_name" : "BornhackBadge",
      "in_reply_to_user_id_str" : "1005540115362533376"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1544203832636235776"
          ],
          "editableUntil" : "2022-07-05T06:47:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dana Sibera",
            "screen_name" : "NanoRaptor",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "2312854706",
            "id" : "2312854706"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "5",
      "in_reply_to_status_id_str" : "1544191008723705857",
      "id_str" : "1544203832636235776",
      "in_reply_to_user_id" : "2312854706",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1544203832636235776",
      "in_reply_to_status_id" : "1544191008723705857",
      "created_at" : "Tue Jul 05 06:17:38 +0000 2022",
      "favorited" : false,
      "full_text" : "@NanoRaptor How do the arrow keys work?",
      "lang" : "en",
      "in_reply_to_screen_name" : "NanoRaptor",
      "in_reply_to_user_id_str" : "2312854706"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1543766195941167104"
          ],
          "editableUntil" : "2022-07-04T01:48:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1543766195941167104/photo/1",
            "indices" : [
              "65",
              "88"
            ],
            "url" : "https://t.co/jWj9CJl858",
            "media_url" : "http://pbs.twimg.com/media/FWyPHgUUsAUcSag.jpg",
            "id_str" : "1543766131378270213",
            "id" : "1543766131378270213",
            "media_url_https" : "https://pbs.twimg.com/media/FWyPHgUUsAUcSag.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/jWj9CJl858"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "88"
      ],
      "favorite_count" : "1",
      "id_str" : "1543766195941167104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1543766195941167104",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 04 01:18:37 +0000 2022",
      "favorited" : false,
      "full_text" : "Just visited Computer History Museum in San Francisco. Love it 💞 https://t.co/jWj9CJl858",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1543766195941167104/photo/1",
            "indices" : [
              "65",
              "88"
            ],
            "url" : "https://t.co/jWj9CJl858",
            "media_url" : "http://pbs.twimg.com/media/FWyPHgUUsAUcSag.jpg",
            "id_str" : "1543766131378270213",
            "id" : "1543766131378270213",
            "media_url_https" : "https://pbs.twimg.com/media/FWyPHgUUsAUcSag.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/jWj9CJl858"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1539630175427694593"
          ],
          "editableUntil" : "2022-06-22T15:53:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Massimo",
            "screen_name" : "Rainmaker1973",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "177101260",
            "id" : "177101260"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "78"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1539305846370406400",
      "id_str" : "1539630175427694593",
      "in_reply_to_user_id" : "177101260",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1539630175427694593",
      "in_reply_to_status_id" : "1539305846370406400",
      "created_at" : "Wed Jun 22 15:23:33 +0000 2022",
      "favorited" : false,
      "full_text" : "@Rainmaker1973 I can watch this all day long\nTo wait for them tie up together.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Rainmaker1973",
      "in_reply_to_user_id_str" : "177101260"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1538899589549400064"
          ],
          "editableUntil" : "2022-06-20T15:30:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "The CircuitPython Show",
            "screen_name" : "circuitpyshow",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1479807513356816384",
            "id" : "1479807513356816384"
          },
          {
            "name" : "Guy Dupont",
            "screen_name" : "gvy_dvpont",
            "indices" : [
              "15",
              "26"
            ],
            "id_str" : "258906098",
            "id" : "258906098"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1538897918882627586",
      "id_str" : "1538899589549400064",
      "in_reply_to_user_id" : "1479807513356816384",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1538899589549400064",
      "in_reply_to_status_id" : "1538897918882627586",
      "created_at" : "Mon Jun 20 15:00:28 +0000 2022",
      "favorited" : false,
      "full_text" : "@circuitpyshow @gvy_dvpont Ho ho, have been waiting for this episode!",
      "lang" : "en",
      "in_reply_to_screen_name" : "circuitpyshow",
      "in_reply_to_user_id_str" : "1479807513356816384"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1538158367612575744"
          ],
          "editableUntil" : "2022-06-18T14:25:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "James Lewis",
            "screen_name" : "baldengineer",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "9600442",
            "id" : "9600442"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1537963586391142407",
      "id_str" : "1538158367612575744",
      "in_reply_to_user_id" : "9600442",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1538158367612575744",
      "in_reply_to_status_id" : "1537963586391142407",
      "created_at" : "Sat Jun 18 13:55:07 +0000 2022",
      "favorited" : false,
      "full_text" : "@baldengineer Could become my commute working station",
      "lang" : "en",
      "in_reply_to_screen_name" : "baldengineer",
      "in_reply_to_user_id_str" : "9600442"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1536011761807138817"
          ],
          "editableUntil" : "2022-06-12T16:15:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "CircuitPython",
            "screen_name" : "CircuitPython",
            "indices" : [
              "89",
              "103"
            ],
            "id_str" : "811605410293645313",
            "id" : "811605410293645313"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1536011761807138817/photo/1",
            "indices" : [
              "104",
              "127"
            ],
            "url" : "https://t.co/3S11ENTNpw",
            "media_url" : "http://pbs.twimg.com/media/FVEBnkuXoAEdWbb.jpg",
            "id_str" : "1536010727294738433",
            "id" : "1536010727294738433",
            "media_url_https" : "https://pbs.twimg.com/media/FVEBnkuXoAEdWbb.jpg",
            "sizes" : {
              "large" : {
                "w" : "1489",
                "h" : "1183",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "540",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "953",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/3S11ENTNpw"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "127"
      ],
      "favorite_count" : "15",
      "id_str" : "1536011761807138817",
      "truncated" : false,
      "retweet_count" : "5",
      "id" : "1536011761807138817",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jun 12 15:45:16 +0000 2022",
      "favorited" : false,
      "full_text" : "Planing the first big version of CPy OL IDE. Just started to learn Vue. Any suggestions? @CircuitPython https://t.co/3S11ENTNpw",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1536011761807138817/photo/1",
            "indices" : [
              "104",
              "127"
            ],
            "url" : "https://t.co/3S11ENTNpw",
            "media_url" : "http://pbs.twimg.com/media/FVEBnkuXoAEdWbb.jpg",
            "id_str" : "1536010727294738433",
            "id" : "1536010727294738433",
            "media_url_https" : "https://pbs.twimg.com/media/FVEBnkuXoAEdWbb.jpg",
            "sizes" : {
              "large" : {
                "w" : "1489",
                "h" : "1183",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "540",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "953",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/3S11ENTNpw"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1535609862905815044"
          ],
          "editableUntil" : "2022-06-11T13:38:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Massimo",
            "screen_name" : "Rainmaker1973",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "177101260",
            "id" : "177101260"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "72"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1535585412361723904",
      "id_str" : "1535609862905815044",
      "in_reply_to_user_id" : "177101260",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1535609862905815044",
      "in_reply_to_status_id" : "1535585412361723904",
      "created_at" : "Sat Jun 11 13:08:16 +0000 2022",
      "favorited" : false,
      "full_text" : "@Rainmaker1973 Reminds me of my students in the last-day review session.",
      "lang" : "en",
      "in_reply_to_screen_name" : "Rainmaker1973",
      "in_reply_to_user_id_str" : "177101260"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1533497580260364294"
          ],
          "editableUntil" : "2022-06-05T17:44:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Linux Format",
            "screen_name" : "linuxformat",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "255410383",
            "id" : "255410383"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/MbMYEkP3R6",
            "expanded_url" : "https://urfdvw.github.io/CircuitPython-online-IDE/",
            "display_url" : "urfdvw.github.io/CircuitPython-…",
            "indices" : [
              "204",
              "227"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "227"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1533295834951032832",
      "id_str" : "1533497580260364294",
      "in_reply_to_user_id" : "255410383",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1533497580260364294",
      "in_reply_to_status_id" : "1533295834951032832",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jun 05 17:14:48 +0000 2022",
      "favorited" : false,
      "full_text" : "@linuxformat On Chromebooks, I highly recommend CircuitPython Online IDE. No need for installation of anything, everything is in one place. Very handy. It is not perfect at all but it is written by me 😁. https://t.co/MbMYEkP3R6",
      "lang" : "en",
      "in_reply_to_screen_name" : "linuxformat",
      "in_reply_to_user_id_str" : "255410383"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1533456130722123777"
          ],
          "editableUntil" : "2022-06-05T15:00:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Asahi Linux (@AsahiLinux@treehouse.systems)",
            "screen_name" : "AsahiLinux",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1339487819903856640",
            "id" : "1339487819903856640"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "131"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1532035506539995136",
      "id_str" : "1533456130722123777",
      "in_reply_to_user_id" : "1339487819903856640",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1533456130722123777",
      "in_reply_to_status_id" : "1532035506539995136",
      "created_at" : "Sun Jun 05 14:30:06 +0000 2022",
      "favorited" : false,
      "full_text" : "@AsahiLinux I can see it coming soon: Apple silicones' gaming potential is fully released because of Linux, not MacOS, Not Windows.",
      "lang" : "en",
      "in_reply_to_screen_name" : "AsahiLinux",
      "in_reply_to_user_id_str" : "1339487819903856640"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1532470872556158976"
          ],
          "editableUntil" : "2022-06-02T21:45:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "@gallaugher@mastodon.world",
            "screen_name" : "gallaugher",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "16288392",
            "id" : "16288392"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1532444617131663360",
      "id_str" : "1532470872556158976",
      "in_reply_to_user_id" : "16288392",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1532470872556158976",
      "in_reply_to_status_id" : "1532444617131663360",
      "created_at" : "Thu Jun 02 21:15:02 +0000 2022",
      "favorited" : false,
      "full_text" : "@gallaugher Basically, I want the clickwheel back.",
      "lang" : "en",
      "in_reply_to_screen_name" : "gallaugher",
      "in_reply_to_user_id_str" : "16288392"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1532430226248060931"
          ],
          "editableUntil" : "2022-06-02T19:03:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Shawn Hymel - @shawnhymel@masto.ai",
            "screen_name" : "ShawnHymel",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "840322392",
            "id" : "840322392"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1532381333267402752",
      "id_str" : "1532430226248060931",
      "in_reply_to_user_id" : "840322392",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1532430226248060931",
      "in_reply_to_status_id" : "1532381333267402752",
      "created_at" : "Thu Jun 02 18:33:31 +0000 2022",
      "favorited" : false,
      "full_text" : "@ShawnHymel Vote up Pico.",
      "lang" : "en",
      "in_reply_to_screen_name" : "ShawnHymel",
      "in_reply_to_user_id_str" : "840322392"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1532180670809837568"
          ],
          "editableUntil" : "2022-06-02T02:31:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "日下氏（ゆっきー）",
            "screen_name" : "yukkieeeeeen",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "790440869379780608",
            "id" : "790440869379780608"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1531996242456485888",
      "id_str" : "1532180670809837568",
      "in_reply_to_user_id" : "790440869379780608",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1532180670809837568",
      "in_reply_to_status_id" : "1531996242456485888",
      "created_at" : "Thu Jun 02 02:01:53 +0000 2022",
      "favorited" : false,
      "full_text" : "@yukkieeeeeen 最爱",
      "lang" : "zh",
      "in_reply_to_screen_name" : "yukkieeeeeen",
      "in_reply_to_user_id_str" : "790440869379780608"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1529483424829956102"
          ],
          "editableUntil" : "2022-05-25T15:53:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Den of Wonder",
            "screen_name" : "den_of_wonder",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1445496352880795654",
            "id" : "1445496352880795654"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "295"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1529061576950546433",
      "id_str" : "1529483424829956102",
      "in_reply_to_user_id" : "1445496352880795654",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1529483424829956102",
      "in_reply_to_status_id" : "1529061576950546433",
      "created_at" : "Wed May 25 15:23:59 +0000 2022",
      "favorited" : false,
      "full_text" : "@den_of_wonder I had a theory that the I/O bandwidth defines the usage of electronics. Computers with huge monitors and comfortable keyboards have the largest bandwidth so they are used in serious workflows. Phones in the middle. Watches with tiny screens can barely do more than health tracking",
      "lang" : "en",
      "in_reply_to_screen_name" : "den_of_wonder",
      "in_reply_to_user_id_str" : "1445496352880795654"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1527373711262658562"
          ],
          "editableUntil" : "2022-05-19T20:10:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "maintenance dept",
            "screen_name" : "pleasantgoose",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1359640482",
            "id" : "1359640482"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1527293728867639296",
      "id_str" : "1527373711262658562",
      "in_reply_to_user_id" : "1359640482",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1527373711262658562",
      "in_reply_to_status_id" : "1527293728867639296",
      "created_at" : "Thu May 19 19:40:44 +0000 2022",
      "favorited" : false,
      "full_text" : "@pleasantgoose Damocles sword",
      "lang" : "en",
      "in_reply_to_screen_name" : "pleasantgoose",
      "in_reply_to_user_id_str" : "1359640482"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1526580642099642368"
          ],
          "editableUntil" : "2022-05-17T15:39:22.230Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "XD",
            "screen_name" : "BaconPuppets",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "864321731988668416",
            "id" : "864321731988668416"
          },
          {
            "name" : "hackaday",
            "screen_name" : "hackaday",
            "indices" : [
              "18",
              "27"
            ],
            "id_str" : "14607140",
            "id" : "14607140"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/BaconPuppets/status/1525726341538062336/photo/1",
            "source_status_id" : "1525726341538062336",
            "indices" : [
              "68",
              "91"
            ],
            "url" : "https://t.co/gGn5uzxaGa",
            "media_url" : "http://pbs.twimg.com/media/FSx4BX1VIAEtGjq.jpg",
            "id_str" : "1525726338744655873",
            "source_user_id" : "864321731988668416",
            "id" : "1525726338744655873",
            "media_url_https" : "https://pbs.twimg.com/media/FSx4BX1VIAEtGjq.jpg",
            "source_user_id_str" : "864321731988668416",
            "sizes" : {
              "small" : {
                "w" : "383",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1152",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1525726341538062336",
            "display_url" : "pic.twitter.com/gGn5uzxaGa"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "91"
      ],
      "favorite_count" : "0",
      "id_str" : "1526580642099642368",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1526580642099642368",
      "possibly_sensitive" : false,
      "created_at" : "Tue May 17 15:09:22 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @BaconPuppets: @hackaday Almost lost it! Safe on the fridge now! https://t.co/gGn5uzxaGa",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/BaconPuppets/status/1525726341538062336/photo/1",
            "source_status_id" : "1525726341538062336",
            "indices" : [
              "68",
              "91"
            ],
            "url" : "https://t.co/gGn5uzxaGa",
            "media_url" : "http://pbs.twimg.com/media/FSx4BX1VIAEtGjq.jpg",
            "id_str" : "1525726338744655873",
            "source_user_id" : "864321731988668416",
            "id" : "1525726338744655873",
            "media_url_https" : "https://pbs.twimg.com/media/FSx4BX1VIAEtGjq.jpg",
            "source_user_id_str" : "864321731988668416",
            "sizes" : {
              "small" : {
                "w" : "383",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1152",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1525726341538062336",
            "display_url" : "pic.twitter.com/gGn5uzxaGa"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1524578820438822913"
          ],
          "editableUntil" : "2022-05-12T03:04:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1524578820438822913/photo/1",
            "indices" : [
              "199",
              "222"
            ],
            "url" : "https://t.co/holfn8asM7",
            "media_url" : "http://pbs.twimg.com/media/FShkRq6WYAAXEly.jpg",
            "id_str" : "1524578728604491776",
            "id" : "1524578728604491776",
            "media_url_https" : "https://pbs.twimg.com/media/FShkRq6WYAAXEly.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/holfn8asM7"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "222"
      ],
      "favorite_count" : "3",
      "id_str" : "1524578820438822913",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1524578820438822913",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 12 02:34:50 +0000 2022",
      "favorited" : false,
      "full_text" : "3D printed cases for my password keepers came in today. Nicely fit. Left one side open and slided the PCB in. Here are the 52840 feather Bluetooth version. Xiao 2040 version and the Pi Pico version. https://t.co/holfn8asM7",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1524578820438822913/photo/1",
            "indices" : [
              "199",
              "222"
            ],
            "url" : "https://t.co/holfn8asM7",
            "media_url" : "http://pbs.twimg.com/media/FShkRq6WYAAXEly.jpg",
            "id_str" : "1524578728604491776",
            "id" : "1524578728604491776",
            "media_url_https" : "https://pbs.twimg.com/media/FShkRq6WYAAXEly.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/holfn8asM7"
          },
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1524578820438822913/photo/1",
            "indices" : [
              "199",
              "222"
            ],
            "url" : "https://t.co/holfn8asM7",
            "media_url" : "http://pbs.twimg.com/media/FShkRq5XwAEIEdD.jpg",
            "id_str" : "1524578728600387585",
            "id" : "1524578728600387585",
            "media_url_https" : "https://pbs.twimg.com/media/FShkRq5XwAEIEdD.jpg",
            "sizes" : {
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/holfn8asM7"
          },
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1524578820438822913/photo/1",
            "indices" : [
              "199",
              "222"
            ],
            "url" : "https://t.co/holfn8asM7",
            "media_url" : "http://pbs.twimg.com/media/FShkRrVXIAEWvPJ.jpg",
            "id_str" : "1524578728717787137",
            "id" : "1524578728717787137",
            "media_url_https" : "https://pbs.twimg.com/media/FShkRrVXIAEWvPJ.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/holfn8asM7"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1524578242547625984"
          ],
          "editableUntil" : "2022-05-12T03:02:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/EJUygoM5eG",
            "expanded_url" : "https://github.com/urfdvw/Password-Keeper",
            "display_url" : "github.com/urfdvw/Passwor…",
            "indices" : [
              "0",
              "23"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1524576946339860482",
      "id_str" : "1524578242547625984",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1524578242547625984",
      "in_reply_to_status_id" : "1524576946339860482",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 12 02:32:32 +0000 2022",
      "favorited" : false,
      "full_text" : "https://t.co/EJUygoM5eG",
      "lang" : "zxx",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1524576946339860482"
          ],
          "editableUntil" : "2022-05-12T02:57:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1524576946339860482/video/1",
            "indices" : [
              "58",
              "81"
            ],
            "url" : "https://t.co/kelYVq9OTB",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1524576335515074561/pu/img/ucAYFaTJt3j8CwhJ.jpg",
            "id_str" : "1524576335515074561",
            "id" : "1524576335515074561",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1524576335515074561/pu/img/ucAYFaTJt3j8CwhJ.jpg",
            "sizes" : {
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1920",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "383",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/kelYVq9OTB"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "81"
      ],
      "favorite_count" : "2",
      "id_str" : "1524576946339860482",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1524576946339860482",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 12 02:27:23 +0000 2022",
      "favorited" : false,
      "full_text" : "Fully working Bluetooth password keeper! Data enciphered. https://t.co/kelYVq9OTB",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1524576946339860482/video/1",
            "indices" : [
              "58",
              "81"
            ],
            "url" : "https://t.co/kelYVq9OTB",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1524576335515074561/pu/img/ucAYFaTJt3j8CwhJ.jpg",
            "id_str" : "1524576335515074561",
            "video_info" : {
              "aspect_ratio" : [
                "9",
                "16"
              ],
              "duration_millis" : "27809",
              "variants" : [
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1524576335515074561/pu/pl/gIReAkMfrZj0B3OE.m3u8?tag=12&container=fmp4"
                },
                {
                  "bitrate" : "950000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1524576335515074561/pu/vid/480x852/M5oLh_Ehbh4GkQVd.mp4?tag=12"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1524576335515074561/pu/vid/720x1280/fANWVHFeAbSzOv34.mp4?tag=12"
                },
                {
                  "bitrate" : "632000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1524576335515074561/pu/vid/320x568/ISYcn_poeMoxCFJ1.mp4?tag=12"
                }
              ]
            },
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1524576335515074561",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1524576335515074561/pu/img/ucAYFaTJt3j8CwhJ.jpg",
            "sizes" : {
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1920",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "383",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "display_url" : "pic.twitter.com/kelYVq9OTB"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1523341437227655170"
          ],
          "editableUntil" : "2022-05-08T17:07:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "The CircuitPython Show",
            "screen_name" : "circuitpyshow",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1479807513356816384",
            "id" : "1479807513356816384"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1523341157417246721",
      "id_str" : "1523341437227655170",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1523341437227655170",
      "in_reply_to_status_id" : "1523341157417246721",
      "created_at" : "Sun May 08 16:37:55 +0000 2022",
      "favorited" : false,
      "full_text" : "@circuitpyshow 3d printed case is still on the way though.",
      "lang" : "en",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1523341157417246721"
          ],
          "editableUntil" : "2022-05-08T17:06:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "The CircuitPython Show",
            "screen_name" : "circuitpyshow",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1479807513356816384",
            "id" : "1479807513356816384"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1523341157417246721/photo/1",
            "indices" : [
              "72",
              "95"
            ],
            "url" : "https://t.co/cNSr7opLFt",
            "media_url" : "http://pbs.twimg.com/media/FSP-k5dXEAMgBAZ.jpg",
            "id_str" : "1523341008834072579",
            "id" : "1523341008834072579",
            "media_url_https" : "https://pbs.twimg.com/media/FSP-k5dXEAMgBAZ.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/cNSr7opLFt"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "95"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1522992658385276934",
      "id_str" : "1523341157417246721",
      "in_reply_to_user_id" : "1479807513356816384",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1523341157417246721",
      "in_reply_to_status_id" : "1522992658385276934",
      "possibly_sensitive" : false,
      "created_at" : "Sun May 08 16:36:48 +0000 2022",
      "favorited" : false,
      "full_text" : "@circuitpyshow Finally got some time to work on my BLE password keeper. https://t.co/cNSr7opLFt",
      "lang" : "en",
      "in_reply_to_screen_name" : "circuitpyshow",
      "in_reply_to_user_id_str" : "1479807513356816384",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1523341157417246721/photo/1",
            "indices" : [
              "72",
              "95"
            ],
            "url" : "https://t.co/cNSr7opLFt",
            "media_url" : "http://pbs.twimg.com/media/FSP-k5dXEAMgBAZ.jpg",
            "id_str" : "1523341008834072579",
            "id" : "1523341008834072579",
            "media_url_https" : "https://pbs.twimg.com/media/FSP-k5dXEAMgBAZ.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/cNSr7opLFt"
          },
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1523341157417246721/photo/1",
            "indices" : [
              "72",
              "95"
            ],
            "url" : "https://t.co/cNSr7opLFt",
            "media_url" : "http://pbs.twimg.com/media/FSP-k5dX0AAZNyl.jpg",
            "id_str" : "1523341008834121728",
            "id" : "1523341008834121728",
            "media_url_https" : "https://pbs.twimg.com/media/FSP-k5dX0AAZNyl.jpg",
            "sizes" : {
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/cNSr7opLFt"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1521829642876948481"
          ],
          "editableUntil" : "2022-05-04T13:00:35.746Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Peter Wang",
            "screen_name" : "pwang",
            "indices" : [
              "3",
              "9"
            ],
            "id_str" : "8472272",
            "id" : "8472272"
          },
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "11",
              "25"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          },
          {
            "name" : "@Riverwang@fosstodon.org",
            "screen_name" : "River___Wang",
            "indices" : [
              "26",
              "39"
            ],
            "id_str" : "1450661638009405445",
            "id" : "1450661638009405445"
          },
          {
            "name" : "Mariatta 🤦",
            "screen_name" : "mariatta",
            "indices" : [
              "40",
              "49"
            ],
            "id_str" : "17009144",
            "id" : "17009144"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1521829642876948481",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1521829642876948481",
      "created_at" : "Wed May 04 12:30:35 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @pwang: @anne_engineer @River___Wang @mariatta Brython is a re-implementation of the Python language, that transpiles to Javascript. It…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1521123498005082114"
          ],
          "editableUntil" : "2022-05-02T14:14:37.689Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mariatta 🤦",
            "screen_name" : "mariatta",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "17009144",
            "id" : "17009144"
          },
          {
            "name" : "Anne Barela @anneb@octodon.social",
            "screen_name" : "anne_engineer",
            "indices" : [
              "10",
              "24"
            ],
            "id_str" : "4918794850",
            "id" : "4918794850"
          },
          {
            "name" : "Peter Wang",
            "screen_name" : "pwang",
            "indices" : [
              "25",
              "31"
            ],
            "id_str" : "8472272",
            "id" : "8472272"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "80"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1520432987359399936",
      "id_str" : "1521123498005082114",
      "in_reply_to_user_id" : "17009144",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1521123498005082114",
      "in_reply_to_status_id" : "1520432987359399936",
      "created_at" : "Mon May 02 13:44:37 +0000 2022",
      "favorited" : false,
      "full_text" : "@mariatta @anne_engineer @pwang What is the difference between this and Brython?",
      "lang" : "en",
      "in_reply_to_screen_name" : "mariatta",
      "in_reply_to_user_id_str" : "17009144"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1520241826359222272"
          ],
          "editableUntil" : "2022-04-30T03:51:10.788Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1520241826359222272/photo/1",
            "indices" : [
              "36",
              "59"
            ],
            "url" : "https://t.co/4KKlpr8g82",
            "media_url" : "http://pbs.twimg.com/media/FRj7mB0XEAUL4bA.jpg",
            "id_str" : "1520241504979193861",
            "id" : "1520241504979193861",
            "media_url_https" : "https://pbs.twimg.com/media/FRj7mB0XEAUL4bA.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/4KKlpr8g82"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1520017055365304320",
      "id_str" : "1520241826359222272",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1520241826359222272",
      "in_reply_to_status_id" : "1520017055365304320",
      "possibly_sensitive" : false,
      "created_at" : "Sat Apr 30 03:21:10 +0000 2022",
      "favorited" : false,
      "full_text" : "Took my door name plate home today. https://t.co/4KKlpr8g82",
      "lang" : "en",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1520241826359222272/photo/1",
            "indices" : [
              "36",
              "59"
            ],
            "url" : "https://t.co/4KKlpr8g82",
            "media_url" : "http://pbs.twimg.com/media/FRj7mB0XEAUL4bA.jpg",
            "id_str" : "1520241504979193861",
            "id" : "1520241504979193861",
            "media_url_https" : "https://pbs.twimg.com/media/FRj7mB0XEAUL4bA.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/4KKlpr8g82"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1520017055365304320"
          ],
          "editableUntil" : "2022-04-29T12:58:01.207Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "251"
      ],
      "favorite_count" : "5",
      "id_str" : "1520017055365304320",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1520017055365304320",
      "created_at" : "Fri Apr 29 12:28:01 +0000 2022",
      "favorited" : false,
      "full_text" : "Today is my last day formally as a teacher. I am joining industry as a software engineer. The company is know for good wlb, so I will have more time working on my personal projects which I never had a chance to teach on the stage. You will see me more",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1519841357736595456"
          ],
          "editableUntil" : "2022-04-29T01:19:51.628Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/ZtWnWutFCO",
            "expanded_url" : "https://github.com/urfdvw/XiaoExp",
            "display_url" : "github.com/urfdvw/XiaoExp",
            "indices" : [
              "0",
              "23"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1519837706381107202",
      "id_str" : "1519841357736595456",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1519841357736595456",
      "in_reply_to_status_id" : "1519837706381107202",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 29 00:49:51 +0000 2022",
      "favorited" : false,
      "full_text" : "https://t.co/ZtWnWutFCO",
      "lang" : "zxx",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1519837706381107202"
          ],
          "editableUntil" : "2022-04-29T01:05:21.077Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/ZtWnWutFCO",
            "expanded_url" : "https://github.com/urfdvw/XiaoExp",
            "display_url" : "github.com/urfdvw/XiaoExp",
            "indices" : [
              "200",
              "223"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1519837706381107202/photo/1",
            "indices" : [
              "239",
              "262"
            ],
            "url" : "https://t.co/srRqXqNaBI",
            "media_url" : "http://pbs.twimg.com/media/FReLjkNXoAA4Ytu.jpg",
            "id_str" : "1519836842392264704",
            "id" : "1519836842392264704",
            "media_url_https" : "https://pbs.twimg.com/media/FReLjkNXoAA4Ytu.jpg",
            "sizes" : {
              "medium" : {
                "w" : "926",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1581",
                "h" : "2048",
                "resize" : "fit"
              },
              "small" : {
                "w" : "525",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/srRqXqNaBI"
          }
        ],
        "hashtags" : [
          {
            "text" : "CircuitPython",
            "indices" : [
              "224",
              "238"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "262"
      ],
      "favorite_count" : "9",
      "id_str" : "1519837706381107202",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1519837706381107202",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 29 00:35:21 +0000 2022",
      "favorited" : false,
      "full_text" : "My latest project on CircuitPython education is a cheap expansion board for Seeed Xiao to be used in classes and camps. I also slimed down the CPy display library so that it can run on Xiao (SAMD21). https://t.co/ZtWnWutFCO #CircuitPython https://t.co/srRqXqNaBI",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1519837706381107202/photo/1",
            "indices" : [
              "239",
              "262"
            ],
            "url" : "https://t.co/srRqXqNaBI",
            "media_url" : "http://pbs.twimg.com/media/FReLjkNXoAA4Ytu.jpg",
            "id_str" : "1519836842392264704",
            "id" : "1519836842392264704",
            "media_url_https" : "https://pbs.twimg.com/media/FReLjkNXoAA4Ytu.jpg",
            "sizes" : {
              "medium" : {
                "w" : "926",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1581",
                "h" : "2048",
                "resize" : "fit"
              },
              "small" : {
                "w" : "525",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/srRqXqNaBI"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1519643108899790848"
          ],
          "editableUntil" : "2022-04-28T12:12:05.422Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "@sad_electronics",
            "screen_name" : "sad_electronics",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1062392065240285185",
            "id" : "1062392065240285185"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1519575866396889089",
      "id_str" : "1519643108899790848",
      "in_reply_to_user_id" : "1062392065240285185",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1519643108899790848",
      "in_reply_to_status_id" : "1519575866396889089",
      "created_at" : "Thu Apr 28 11:42:05 +0000 2022",
      "favorited" : false,
      "full_text" : "@sad_electronics Never thought about it. That's inspiring.",
      "lang" : "en",
      "in_reply_to_screen_name" : "sad_electronics",
      "in_reply_to_user_id_str" : "1062392065240285185"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1517904527596437505"
          ],
          "editableUntil" : "2022-04-23T17:03:35.338Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Microchip Makes",
            "screen_name" : "MicrochipMakes",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "138475538",
            "id" : "138475538"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1517614317088169986",
      "id_str" : "1517904527596437505",
      "in_reply_to_user_id" : "138475538",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1517904527596437505",
      "in_reply_to_status_id" : "1517614317088169986",
      "created_at" : "Sat Apr 23 16:33:35 +0000 2022",
      "favorited" : false,
      "full_text" : "@MicrochipMakes Feynman will cry if he sees how you treat his physics textbook.",
      "lang" : "en",
      "in_reply_to_screen_name" : "MicrochipMakes",
      "in_reply_to_user_id_str" : "138475538"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1516520274845437959"
          ],
          "editableUntil" : "2022-04-19T21:23:03.764Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/xAEhLRtdFK",
            "expanded_url" : "https://github.com/urfdvw/CircuitPython-online-IDE-for-classes",
            "display_url" : "github.com/urfdvw/Circuit…",
            "indices" : [
              "114",
              "137"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "137"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1516518964142161922",
      "id_str" : "1516520274845437959",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1516520274845437959",
      "in_reply_to_status_id" : "1516518964142161922",
      "possibly_sensitive" : false,
      "created_at" : "Tue Apr 19 20:53:03 +0000 2022",
      "favorited" : false,
      "full_text" : "The last figure is a tool monitoring students' code online in real time. Please see this github page for details: https://t.co/xAEhLRtdFK",
      "lang" : "en",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1516518964142161922"
          ],
          "editableUntil" : "2022-04-19T21:17:51.268Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1516518964142161922/photo/1",
            "indices" : [
              "272",
              "295"
            ],
            "url" : "https://t.co/F66igapM1x",
            "media_url" : "http://pbs.twimg.com/media/FQvAPGaXsAUXET4.png",
            "id_str" : "1516517065192091653",
            "id" : "1516517065192091653",
            "media_url_https" : "https://pbs.twimg.com/media/FQvAPGaXsAUXET4.png",
            "sizes" : {
              "medium" : {
                "w" : "1140",
                "h" : "446",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "266",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1140",
                "h" : "446",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/F66igapM1x"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "295"
      ],
      "favorite_count" : "33",
      "id_str" : "1516518964142161922",
      "truncated" : false,
      "retweet_count" : "10",
      "id" : "1516518964142161922",
      "possibly_sensitive" : false,
      "created_at" : "Tue Apr 19 20:47:51 +0000 2022",
      "favorited" : false,
      "full_text" : "🎉 🎉 🎉 My educational paper is finally accepted to ASEE (American Society for Engineering Education) 2022 conference. ✌️It talked about how we use CircuitPython and CircuitPython Online IDE to teach microcontroller programming in remote classes. Is anyone coming as well?😊 https://t.co/F66igapM1x",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1516518964142161922/photo/1",
            "indices" : [
              "272",
              "295"
            ],
            "url" : "https://t.co/F66igapM1x",
            "media_url" : "http://pbs.twimg.com/media/FQvAPGaXsAUXET4.png",
            "id_str" : "1516517065192091653",
            "id" : "1516517065192091653",
            "media_url_https" : "https://pbs.twimg.com/media/FQvAPGaXsAUXET4.png",
            "sizes" : {
              "medium" : {
                "w" : "1140",
                "h" : "446",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "266",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1140",
                "h" : "446",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/F66igapM1x"
          },
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1516518964142161922/photo/1",
            "indices" : [
              "272",
              "295"
            ],
            "url" : "https://t.co/F66igapM1x",
            "media_url" : "http://pbs.twimg.com/media/FQvAVI5XIAUVcya.jpg",
            "id_str" : "1516517168938164229",
            "id" : "1516517168938164229",
            "media_url_https" : "https://pbs.twimg.com/media/FQvAVI5XIAUVcya.jpg",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/F66igapM1x"
          },
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1516518964142161922/photo/1",
            "indices" : [
              "272",
              "295"
            ],
            "url" : "https://t.co/F66igapM1x",
            "media_url" : "http://pbs.twimg.com/media/FQvAxdpXsAoIfp5.jpg",
            "id_str" : "1516517655544573962",
            "id" : "1516517655544573962",
            "media_url_https" : "https://pbs.twimg.com/media/FQvAxdpXsAoIfp5.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1149",
                "h" : "429",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1149",
                "h" : "429",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "254",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/F66igapM1x"
          },
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1516518964142161922/photo/1",
            "indices" : [
              "272",
              "295"
            ],
            "url" : "https://t.co/F66igapM1x",
            "media_url" : "http://pbs.twimg.com/media/FQvAycjXoAAryx6.jpg",
            "id_str" : "1516517672430837760",
            "id" : "1516517672430837760",
            "media_url_https" : "https://pbs.twimg.com/media/FQvAycjXoAAryx6.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "203",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1189",
                "h" : "355",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1189",
                "h" : "355",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/F66igapM1x"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1516151823006158848"
          ],
          "editableUntil" : "2022-04-18T20:58:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mark Hodgkinson (Hodgy) @iamhodgy@mastodon.social",
            "screen_name" : "iamhodgy",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "494838775",
            "id" : "494838775"
          },
          {
            "name" : "rappet",
            "screen_name" : "rappet_",
            "indices" : [
              "10",
              "18"
            ],
            "id_str" : "2668037331",
            "id" : "2668037331"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1515704288097574916",
      "id_str" : "1516151823006158848",
      "in_reply_to_user_id" : "494838775",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1516151823006158848",
      "in_reply_to_status_id" : "1515704288097574916",
      "created_at" : "Mon Apr 18 20:28:58 +0000 2022",
      "favorited" : false,
      "full_text" : "@iamhodgy @rappet_ Exactly what I am thinking about.",
      "lang" : "en",
      "in_reply_to_screen_name" : "iamhodgy",
      "in_reply_to_user_id_str" : "494838775"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1513893778389671943"
          ],
          "editableUntil" : "2022-04-12T15:26:18.211Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "🆂🆄🅻🅵🆄🆁🅾🅸🅳",
            "screen_name" : "sulfuroid",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "754617844227305472",
            "id" : "754617844227305472"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1513858393420800009",
      "id_str" : "1513893778389671943",
      "in_reply_to_user_id" : "754617844227305472",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1513893778389671943",
      "in_reply_to_status_id" : "1513858393420800009",
      "created_at" : "Tue Apr 12 14:56:18 +0000 2022",
      "favorited" : false,
      "full_text" : "@sulfuroid Great! What project do you have in mind?",
      "lang" : "en",
      "in_reply_to_screen_name" : "sulfuroid",
      "in_reply_to_user_id_str" : "754617844227305472"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1513368182077206530"
          ],
          "editableUntil" : "2022-04-11T04:37:46.285Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Tod Kurt @todbot@mastodon.social",
            "screen_name" : "todbot",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "38213",
            "id" : "38213"
          },
          {
            "name" : "The CircuitPython Show",
            "screen_name" : "circuitpyshow",
            "indices" : [
              "8",
              "22"
            ],
            "id_str" : "1479807513356816384",
            "id" : "1479807513356816384"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1513352382788235269",
      "id_str" : "1513368182077206530",
      "in_reply_to_user_id" : "38213",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1513368182077206530",
      "in_reply_to_status_id" : "1513352382788235269",
      "created_at" : "Mon Apr 11 04:07:46 +0000 2022",
      "favorited" : false,
      "full_text" : "@todbot @circuitpyshow 🤔",
      "lang" : "und",
      "in_reply_to_screen_name" : "todbot",
      "in_reply_to_user_id_str" : "38213"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1513347892127354882"
          ],
          "editableUntil" : "2022-04-11T03:17:08.784Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Tod Kurt @todbot@mastodon.social",
            "screen_name" : "todbot",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "38213",
            "id" : "38213"
          },
          {
            "name" : "The CircuitPython Show",
            "screen_name" : "circuitpyshow",
            "indices" : [
              "8",
              "22"
            ],
            "id_str" : "1479807513356816384",
            "id" : "1479807513356816384"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "130"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1513279070296969218",
      "id_str" : "1513347892127354882",
      "in_reply_to_user_id" : "38213",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1513347892127354882",
      "in_reply_to_status_id" : "1513279070296969218",
      "created_at" : "Mon Apr 11 02:47:08 +0000 2022",
      "favorited" : false,
      "full_text" : "@todbot @circuitpyshow Is the communication frequency of i2c or spi too low? I remembered the default frequency was not very high.",
      "lang" : "en",
      "in_reply_to_screen_name" : "todbot",
      "in_reply_to_user_id_str" : "38213"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1511373770308698114"
          ],
          "editableUntil" : "2022-04-05T16:32:41.465Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "FriendlyWire",
            "screen_name" : "FriendlyWire",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1102124503398703104",
            "id" : "1102124503398703104"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "83"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1511170753978376197",
      "id_str" : "1511373770308698114",
      "in_reply_to_user_id" : "1102124503398703104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1511373770308698114",
      "in_reply_to_status_id" : "1511170753978376197",
      "created_at" : "Tue Apr 05 16:02:41 +0000 2022",
      "favorited" : false,
      "full_text" : "@FriendlyWire I saw people use that to display video like and subscription numbers.",
      "lang" : "en",
      "in_reply_to_screen_name" : "FriendlyWire",
      "in_reply_to_user_id_str" : "1102124503398703104"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1509995482986201088"
          ],
          "editableUntil" : "2022-04-01T21:15:52.160Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Paul Cutler 🇺🇦",
            "screen_name" : "prcutler",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "944651",
            "id" : "944651"
          },
          {
            "name" : "Tod Kurt @todbot@mastodon.social",
            "screen_name" : "todbot",
            "indices" : [
              "10",
              "17"
            ],
            "id_str" : "38213",
            "id" : "38213"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "287"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1509974869911515146",
      "id_str" : "1509995482986201088",
      "in_reply_to_user_id" : "944651",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1509995482986201088",
      "in_reply_to_status_id" : "1509974869911515146",
      "created_at" : "Fri Apr 01 20:45:52 +0000 2022",
      "favorited" : false,
      "full_text" : "@prcutler @todbot You are 100% correct. Software mp3 decode is too heavy and hardware decoder VS1053 is not supported. I Played WAV files to test out the I2S module and it was working pretty well. But my goal is a minimalist connected player, WAV resources are not that available online.",
      "lang" : "en",
      "in_reply_to_screen_name" : "prcutler",
      "in_reply_to_user_id_str" : "944651"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1509965314418778122"
          ],
          "editableUntil" : "2022-04-01T19:15:59.413Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "249"
      ],
      "favorite_count" : "1",
      "id_str" : "1509965314418778122",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1509965314418778122",
      "created_at" : "Fri Apr 01 18:45:59 +0000 2022",
      "favorited" : false,
      "full_text" : "Don't know if it is a bad idea to stream online mp3 podcasts on an ESP32S2 with CircuitPython. Wifi is fine. I2S DAC is fine. However, did not have any luck decompressing mp3 files. Might either switch to C/C++ or Raspberry Pi. Wish I don't have to.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1509710671168122888"
          ],
          "editableUntil" : "2022-04-01T02:24:07.731Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/lUFKh8qknf",
            "expanded_url" : "https://oshwlab.com/urfdvw/saola-2nd-usb_copy",
            "display_url" : "oshwlab.com/urfdvw/saola-2…",
            "indices" : [
              "0",
              "23"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1509707339087101957",
      "id_str" : "1509710671168122888",
      "in_reply_to_user_id" : "1450661638009405445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1509710671168122888",
      "in_reply_to_status_id" : "1509707339087101957",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 01 01:54:07 +0000 2022",
      "favorited" : false,
      "full_text" : "https://t.co/lUFKh8qknf",
      "lang" : "zxx",
      "in_reply_to_screen_name" : "River___Wang",
      "in_reply_to_user_id_str" : "1450661638009405445"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1509707339087101957"
          ],
          "editableUntil" : "2022-04-01T02:10:53.301Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1509707339087101957/photo/1",
            "indices" : [
              "70",
              "93"
            ],
            "url" : "https://t.co/fy51hWuJFm",
            "media_url" : "http://pbs.twimg.com/media/FPOO0tqWYAEjMVF.jpg",
            "id_str" : "1509707336360812545",
            "id" : "1509707336360812545",
            "media_url_https" : "https://pbs.twimg.com/media/FPOO0tqWYAEjMVF.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/fy51hWuJFm"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "93"
      ],
      "favorite_count" : "3",
      "id_str" : "1509707339087101957",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1509707339087101957",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 01 01:40:53 +0000 2022",
      "favorited" : false,
      "full_text" : "An elegant way to connect the native USB on the esp32 s2 Saola board. https://t.co/fy51hWuJFm",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/River___Wang/status/1509707339087101957/photo/1",
            "indices" : [
              "70",
              "93"
            ],
            "url" : "https://t.co/fy51hWuJFm",
            "media_url" : "http://pbs.twimg.com/media/FPOO0tqWYAEjMVF.jpg",
            "id_str" : "1509707336360812545",
            "id" : "1509707336360812545",
            "media_url_https" : "https://pbs.twimg.com/media/FPOO0tqWYAEjMVF.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/fy51hWuJFm"
          }
        ]
      }
    }
  }
]