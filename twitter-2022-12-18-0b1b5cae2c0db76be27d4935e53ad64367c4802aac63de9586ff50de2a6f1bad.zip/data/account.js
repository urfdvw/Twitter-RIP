window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "urfdvw@gmail.com",
      "createdVia" : "oauth:3033300",
      "username" : "River___Wang",
      "accountId" : "1450661638009405445",
      "createdAt" : "2021-10-20T03:14:48.578Z",
      "accountDisplayName" : "@Riverwang@fosstodon.org"
    }
  }
]