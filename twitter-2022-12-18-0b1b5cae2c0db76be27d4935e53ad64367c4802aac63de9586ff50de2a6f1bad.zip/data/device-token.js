window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "QYjBDbXd8i3R0xJQ98w2rExbJQEvxB2DsoSxlp8M",
      "createdAt" : "2021-10-20T03:14:48.667Z",
      "lastSeenAt" : "2021-10-20T03:14:48.669Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "UTEmQ3jo7iUpHLIePZ22ssBtrW1G8dmNPYyl16G5",
      "createdAt" : "2021-10-26T02:52:15.556Z",
      "lastSeenAt" : "2021-10-26T02:52:15.557Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "bjYllMFNJg3eC85ExENVr9ywo8ei0Px6ICkO7v4r",
      "createdAt" : "2021-10-27T12:56:23.239Z",
      "lastSeenAt" : "2021-10-27T12:56:23.245Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "yh5DOTOaboelzI5AZKeOXnMjq03wITob2w2patbu",
      "createdAt" : "2021-11-16T14:36:54.110Z",
      "lastSeenAt" : "2021-11-16T14:36:54.111Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "258901",
      "token" : "rJqr225u71rbFjPbnwUXvLw5TAgVrFPOueGQ1zpW",
      "createdAt" : "2021-11-04T22:26:16.585Z",
      "lastSeenAt" : "2022-03-13T13:53:12.682Z",
      "clientApplicationName" : "Twitter for Android (Twitter, Inc.)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "j9GP9wmt8aZlh39S2tvTTowO3Li7mGZXemGXljHf",
      "createdAt" : "2022-03-22T19:18:36.720Z",
      "lastSeenAt" : "2022-03-22T19:18:36.722Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "t36TG7mG7gdLk8oR0apzvbYyXwNHps4Tw3XFEXdV",
      "createdAt" : "2022-05-29T01:49:46.374Z",
      "lastSeenAt" : "2022-05-29T01:49:46.375Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "fJS1cSuLiFqEAKKECQ1cjZnUl2YyTBGHMTt1Kx9s",
      "createdAt" : "2022-06-06T00:16:50.449Z",
      "lastSeenAt" : "2022-06-06T00:16:50.451Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "9EupfRJ1dQ4wVqAAbrPO27c42w77Vrzj85sbpEf1",
      "createdAt" : "2022-06-13T13:42:09.409Z",
      "lastSeenAt" : "2022-06-13T13:42:09.411Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "Rb9AhFCTLZdmYP8JBD7eErGbMMNKM9WjKPjBtkxz",
      "createdAt" : "2022-06-27T13:36:26.765Z",
      "lastSeenAt" : "2022-06-27T13:36:26.767Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "jgzs55b6VSO4otZfd7OYQemP6ZPI5hGL2eLGUqmJ",
      "createdAt" : "2022-03-24T10:58:32.743Z",
      "lastSeenAt" : "2022-07-01T02:42:47.190Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "258901",
      "token" : "lWJuffIYhE8jm8bbeIZK98gFLR9iQGqnAwnopuh4",
      "createdAt" : "2022-07-16T03:20:21.162Z",
      "lastSeenAt" : "2022-07-16T03:20:21.164Z",
      "clientApplicationName" : "Twitter for Android (Twitter, Inc.)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "6nGhdbx2yde24y6STqwH3QgHBtidKvjRFT4Qp7bH",
      "createdAt" : "2022-10-10T21:30:59.120Z",
      "lastSeenAt" : "2022-10-10T21:30:59.122Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "258901",
      "token" : "geZ1XNQVvMvmbawHEOi5q7Ec1YNtRfsPYoCgX5E8",
      "createdAt" : "2022-10-11T03:06:04.933Z",
      "lastSeenAt" : "2022-10-11T03:06:04.935Z",
      "clientApplicationName" : "Twitter for Android (Twitter, Inc.)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "258901",
      "token" : "cf1sfq3dgYjzD53FxCJ0zSSoQZb0Bzseql4UTdVC",
      "createdAt" : "2022-10-14T04:03:10.809Z",
      "lastSeenAt" : "2022-10-14T04:03:10.811Z",
      "clientApplicationName" : "Twitter for Android (Twitter, Inc.)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "OQzG0E9lWnYXPecPSyIPT4bj8XQYUSb8L60zF587",
      "createdAt" : "2022-10-30T01:04:52.701Z",
      "lastSeenAt" : "2022-12-05T17:10:45.428Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "PkWmelcvgoAZwWjKQUI4DiuUrtL3NwXH2p7mcfOo",
      "createdAt" : "2022-11-05T16:23:05.784Z",
      "lastSeenAt" : "2022-12-16T22:21:19.802Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]