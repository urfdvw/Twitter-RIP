window.YTD.lists_member.part0 = [
  {
    "userListInfo" : {
      "url" : "https://twitter.com/andypiper/lists/1442802293594857472"
    }
  }
]