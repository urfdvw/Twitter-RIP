window.YTD.twitter_circle.part0 = [
  {
    "twitterCircle" : {
      "id" : "1522035131992752128",
      "ownerUserId" : "1450661638009405445",
      "createdAt" : "2022-05-05T02:07:08.167Z"
    }
  }
]