window.YTD.ad_mobile_conversions_attributed.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "attributedMobileAppConversions" : {
          "conversions" : [
            {
              "attributedConversionType" : "ReEngage",
              "mobilePlatform" : "Android",
              "conversionEvent" : "re_engage",
              "applicationName" : "LinkedIn: Jobs & Business News",
              "conversionValue" : "0",
              "conversionTime" : "2022-10-20 01:26:06"
            },
            {
              "attributedConversionType" : "Login",
              "mobilePlatform" : "Android",
              "conversionEvent" : "login",
              "applicationName" : "LinkedIn: Jobs & Business News",
              "conversionValue" : "0",
              "conversionTime" : "2022-10-20 00:59:06"
            },
            {
              "attributedConversionType" : "Install",
              "mobilePlatform" : "Android",
              "conversionEvent" : "install",
              "applicationName" : "LinkedIn: Jobs & Business News",
              "conversionValue" : "0",
              "conversionTime" : "2022-10-20 00:59:04"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "attributedMobileAppConversions" : {
          "conversions" : [
            {
              "attributedConversionType" : "ReEngage",
              "mobilePlatform" : "Android",
              "conversionEvent" : "re_engage",
              "applicationName" : "LinkedIn: Jobs & Business News",
              "conversionValue" : "0",
              "conversionTime" : "2022-10-20 12:34:01"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "attributedMobileAppConversions" : {
          "conversions" : [
            {
              "attributedConversionType" : "ReEngage",
              "mobilePlatform" : "Android",
              "conversionEvent" : "re_engage",
              "applicationName" : "LinkedIn: Jobs & Business News",
              "conversionValue" : "0",
              "conversionTime" : "2022-10-21 12:31:46"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "attributedMobileAppConversions" : {
          "conversions" : [
            {
              "attributedConversionType" : "ReEngage",
              "mobilePlatform" : "Android",
              "conversionEvent" : "re_engage",
              "applicationName" : "LinkedIn: Jobs & Business News",
              "conversionValue" : "0",
              "conversionTime" : "2022-11-16 19:14:19"
            },
            {
              "attributedConversionType" : "ReEngage",
              "mobilePlatform" : "Android",
              "conversionEvent" : "re_engage",
              "applicationName" : "LinkedIn: Jobs & Business News",
              "conversionValue" : "0",
              "conversionTime" : "2022-11-16 17:50:41"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "attributedMobileAppConversions" : {
          "conversions" : [
            {
              "attributedConversionType" : "ReEngage",
              "mobilePlatform" : "Android",
              "conversionEvent" : "re_engage",
              "applicationName" : "LinkedIn: Jobs & Business News",
              "conversionValue" : "0",
              "conversionTime" : "2022-11-16 22:50:04"
            }
          ]
        }
      }
    }
  }
]