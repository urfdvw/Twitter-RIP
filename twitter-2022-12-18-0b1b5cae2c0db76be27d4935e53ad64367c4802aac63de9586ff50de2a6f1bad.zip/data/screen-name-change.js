window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "1450661638009405445",
      "screenNameChange" : {
        "changedAt" : "2021-10-20T03:16:11.000Z",
        "changedFrom" : "RiverWang14",
        "changedTo" : "River___Wang"
      }
    }
  }
]