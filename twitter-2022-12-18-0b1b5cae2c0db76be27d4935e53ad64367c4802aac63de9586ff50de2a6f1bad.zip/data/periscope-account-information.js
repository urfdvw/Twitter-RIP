window.YTD.periscope_account_information.part0 = [
  {
    "periscopeAccountInformation" : {
      "displayName" : "River Wang",
      "digitsId" : "",
      "username" : "River___Wang",
      "twitterId" : "1450661638009405445",
      "id" : "1XJQkObLpBnQL",
      "twitterScreenName" : "River___Wang",
      "isTwitterUser" : true,
      "createdAt" : "2021-11-26T02:38:07.984711314Z"
    }
  }
]