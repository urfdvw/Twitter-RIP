window.YTD.sso.part0 = [
  {
    "singleSignOnMetaValues" : {
      "ssoId" : "102318396145308104128",
      "ssoEmail" : "urfdvw@gmail.com",
      "associationMethodType" : "Signup",
      "createdAt" : "2021-10-20T03:14:48.705Z"
    }
  }
]