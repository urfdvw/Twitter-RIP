window.YTD.lists_subscribed.part0 = [
  {
    "userListInfo" : {
      "url" : "https://twitter.com/dougpark/lists/microcontrollers-11657"
    }
  }
]