window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "To get the latest updates of CircuitPython Online IDE, follow me on Mastodon @Riverwang@fosstodon.org",
        "website" : "https://t.co/SO9ek6oKzi",
        "location" : "NY, USA"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1452803444767612933/z0onu-aP.png"
    }
  }
]