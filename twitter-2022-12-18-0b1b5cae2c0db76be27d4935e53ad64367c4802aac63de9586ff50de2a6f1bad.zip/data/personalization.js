window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          },
          {
            "language" : "German",
            "isDisabled" : false
          },
          {
            "language" : "No linguistic content",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "male"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "#HappyFriday",
            "isDisabled" : false
          },
          {
            "name" : "#HappyMonday",
            "isDisabled" : false
          },
          {
            "name" : "2D animation",
            "isDisabled" : false
          },
          {
            "name" : "3M",
            "isDisabled" : false
          },
          {
            "name" : "A Silent Voice",
            "isDisabled" : false
          },
          {
            "name" : "Ado",
            "isDisabled" : false
          },
          {
            "name" : "AliExpress",
            "isDisabled" : false
          },
          {
            "name" : "Alibaba Group",
            "isDisabled" : false
          },
          {
            "name" : "Amazon",
            "isDisabled" : false
          },
          {
            "name" : "Android",
            "isDisabled" : false
          },
          {
            "name" : "Animated films",
            "isDisabled" : false
          },
          {
            "name" : "Animation directors, producers, & writers",
            "isDisabled" : false
          },
          {
            "name" : "Anime & game music",
            "isDisabled" : false
          },
          {
            "name" : "Anker",
            "isDisabled" : false
          },
          {
            "name" : "Aposto!",
            "isDisabled" : false
          },
          {
            "name" : "Apple - Watch",
            "isDisabled" : false
          },
          {
            "name" : "Apple Mac",
            "isDisabled" : false
          },
          {
            "name" : "Apple TV+",
            "isDisabled" : false
          },
          {
            "name" : "Arduino",
            "isDisabled" : false
          },
          {
            "name" : "Arknights",
            "isDisabled" : false
          },
          {
            "name" : "Assault Lily",
            "isDisabled" : false
          },
          {
            "name" : "Azumi Waki",
            "isDisabled" : false
          },
          {
            "name" : "Azur Lane",
            "isDisabled" : false
          },
          {
            "name" : "Banjo-Kazooie",
            "isDisabled" : false
          },
          {
            "name" : "Best Buy",
            "isDisabled" : false
          },
          {
            "name" : "Best Buy",
            "isDisabled" : false
          },
          {
            "name" : "Bette Midler",
            "isDisabled" : false
          },
          {
            "name" : "Bitcoin cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Blender",
            "isDisabled" : false
          },
          {
            "name" : "Blogging",
            "isDisabled" : false
          },
          {
            "name" : "Blue Archive",
            "isDisabled" : false
          },
          {
            "name" : "Blue Oath",
            "isDisabled" : false
          },
          {
            "name" : "Brisbane Lions",
            "isDisabled" : false
          },
          {
            "name" : "Business & finance news",
            "isDisabled" : false
          },
          {
            "name" : "Business news",
            "isDisabled" : false
          },
          {
            "name" : "COVID-19",
            "isDisabled" : false
          },
          {
            "name" : "CaptainFlowers",
            "isDisabled" : false
          },
          {
            "name" : "Casey Newton",
            "isDisabled" : false
          },
          {
            "name" : "Caturday",
            "isDisabled" : false
          },
          {
            "name" : "Character design",
            "isDisabled" : false
          },
          {
            "name" : "Chrono Cross",
            "isDisabled" : false
          },
          {
            "name" : "Climate change",
            "isDisabled" : false
          },
          {
            "name" : "Collectibles",
            "isDisabled" : false
          },
          {
            "name" : "Comedy",
            "isDisabled" : false
          },
          {
            "name" : "Comedy TV",
            "isDisabled" : false
          },
          {
            "name" : "Comiket",
            "isDisabled" : false
          },
          {
            "name" : "Comitia",
            "isDisabled" : false
          },
          {
            "name" : "Competitive games",
            "isDisabled" : false
          },
          {
            "name" : "Computer gaming",
            "isDisabled" : false
          },
          {
            "name" : "Computer programming",
            "isDisabled" : false
          },
          {
            "name" : "Computer reviews",
            "isDisabled" : false
          },
          {
            "name" : "Computer software",
            "isDisabled" : false
          },
          {
            "name" : "Cooperative games",
            "isDisabled" : false
          },
          {
            "name" : "Crash Bandicoot",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocoins",
            "isDisabled" : false
          },
          {
            "name" : "Cryptocurrencies",
            "isDisabled" : false
          },
          {
            "name" : "Cultural events",
            "isDisabled" : false
          },
          {
            "name" : "Cyberpunk 2077",
            "isDisabled" : false
          },
          {
            "name" : "DECO*27",
            "isDisabled" : false
          },
          {
            "name" : "DIY",
            "isDisabled" : false
          },
          {
            "name" : "DMM Games",
            "isDisabled" : false
          },
          {
            "name" : "Dance & electronic",
            "isDisabled" : false
          },
          {
            "name" : "Dell",
            "isDisabled" : false
          },
          {
            "name" : "Dell",
            "isDisabled" : false
          },
          {
            "name" : "DevOps",
            "isDisabled" : false
          },
          {
            "name" : "Digital asset industry",
            "isDisabled" : false
          },
          {
            "name" : "Digital assets & cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Digital goods & currency",
            "isDisabled" : false
          },
          {
            "name" : "Discord",
            "isDisabled" : false
          },
          {
            "name" : "Doctor Who",
            "isDisabled" : false
          },
          {
            "name" : "Doctor Who",
            "isDisabled" : false
          },
          {
            "name" : "Dogs",
            "isDisabled" : false
          },
          {
            "name" : "Donkey Kong",
            "isDisabled" : false
          },
          {
            "name" : "Drama films",
            "isDisabled" : false
          },
          {
            "name" : "Drawing reference",
            "isDisabled" : false
          },
          {
            "name" : "Drinks",
            "isDisabled" : false
          },
          {
            "name" : "E3",
            "isDisabled" : false
          },
          {
            "name" : "EVO",
            "isDisabled" : false
          },
          {
            "name" : "EarthBound (Mother)",
            "isDisabled" : false
          },
          {
            "name" : "Eiko Kano",
            "isDisabled" : false
          },
          {
            "name" : "Electronic music",
            "isDisabled" : false
          },
          {
            "name" : "Enon Kawatani",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment industry",
            "isDisabled" : false
          },
          {
            "name" : "Envoy",
            "isDisabled" : false
          },
          {
            "name" : "Escape rooms",
            "isDisabled" : false
          },
          {
            "name" : "Ethereum cryptocurrency",
            "isDisabled" : false
          },
          {
            "name" : "Events",
            "isDisabled" : false
          },
          {
            "name" : "F-Zero",
            "isDisabled" : false
          },
          {
            "name" : "FOD",
            "isDisabled" : false
          },
          {
            "name" : "Family & nostalgic",
            "isDisabled" : false
          },
          {
            "name" : "Family & relationships",
            "isDisabled" : false
          },
          {
            "name" : "Fantasy games",
            "isDisabled" : false
          },
          {
            "name" : "Fashion accessories",
            "isDisabled" : false
          },
          {
            "name" : "Fate/Grand Order",
            "isDisabled" : false
          },
          {
            "name" : "Fate/kaleid liner Prisma Illya",
            "isDisabled" : false
          },
          {
            "name" : "Fighting games",
            "isDisabled" : false
          },
          {
            "name" : "Firefox",
            "isDisabled" : false
          },
          {
            "name" : "Fonts",
            "isDisabled" : false
          },
          {
            "name" : "Food Blogs",
            "isDisabled" : false
          },
          {
            "name" : "France national news",
            "isDisabled" : false
          },
          {
            "name" : "Free-to-play games",
            "isDisabled" : false
          },
          {
            "name" : "FromSoftware",
            "isDisabled" : false
          },
          {
            "name" : "GL",
            "isDisabled" : false
          },
          {
            "name" : "GLAY",
            "isDisabled" : false
          },
          {
            "name" : "Gacha games",
            "isDisabled" : false
          },
          {
            "name" : "Game Boy",
            "isDisabled" : false
          },
          {
            "name" : "Game emulation",
            "isDisabled" : false
          },
          {
            "name" : "Gaming content creators",
            "isDisabled" : false
          },
          {
            "name" : "Gaming hardware & accessories",
            "isDisabled" : false
          },
          {
            "name" : "Gaming influencers",
            "isDisabled" : false
          },
          {
            "name" : "Gaming news and general info",
            "isDisabled" : false
          },
          {
            "name" : "Gaming retail",
            "isDisabled" : false
          },
          {
            "name" : "Gesu no Kiwami Otome",
            "isDisabled" : false
          },
          {
            "name" : "Girls' Frontline",
            "isDisabled" : false
          },
          {
            "name" : "Google Doodles",
            "isDisabled" : false
          },
          {
            "name" : "Google Innovation",
            "isDisabled" : false
          },
          {
            "name" : "Google brand conversation",
            "isDisabled" : false
          },
          {
            "name" : "Government institutions",
            "isDisabled" : false
          },
          {
            "name" : "HBO Max",
            "isDisabled" : false
          },
          {
            "name" : "Hank Green",
            "isDisabled" : false
          },
          {
            "name" : "Home automation",
            "isDisabled" : false
          },
          {
            "name" : "Home improvement",
            "isDisabled" : false
          },
          {
            "name" : "Hoshimachi Suisei",
            "isDisabled" : false
          },
          {
            "name" : "House of the Dragon",
            "isDisabled" : false
          },
          {
            "name" : "IBM",
            "isDisabled" : false
          },
          {
            "name" : "Idol games",
            "isDisabled" : false
          },
          {
            "name" : "Idoly Pride",
            "isDisabled" : false
          },
          {
            "name" : "Industries",
            "isDisabled" : false
          },
          {
            "name" : "Inflation",
            "isDisabled" : false
          },
          {
            "name" : "Is the Order a Rabbit?",
            "isDisabled" : false
          },
          {
            "name" : "Isaac CB",
            "isDisabled" : false
          },
          {
            "name" : "JKap",
            "isDisabled" : false
          },
          {
            "name" : "Journalists",
            "isDisabled" : false
          },
          {
            "name" : "Jumputi Heroes",
            "isDisabled" : false
          },
          {
            "name" : "Kaf",
            "isDisabled" : false
          },
          {
            "name" : "Kantai Collection",
            "isDisabled" : false
          },
          {
            "name" : "Kaori Maeda",
            "isDisabled" : false
          },
          {
            "name" : "Kemono Friends",
            "isDisabled" : false
          },
          {
            "name" : "Kirby",
            "isDisabled" : false
          },
          {
            "name" : "Konomi Kohara",
            "isDisabled" : false
          },
          {
            "name" : "Kyoto Animation",
            "isDisabled" : false
          },
          {
            "name" : "LEGO",
            "isDisabled" : false
          },
          {
            "name" : "Land of the Lustrous",
            "isDisabled" : false
          },
          {
            "name" : "Larry Beyince",
            "isDisabled" : false
          },
          {
            "name" : "Linus Tech",
            "isDisabled" : false
          },
          {
            "name" : "Linux",
            "isDisabled" : false
          },
          {
            "name" : "Linux",
            "isDisabled" : false
          },
          {
            "name" : "Loans",
            "isDisabled" : false
          },
          {
            "name" : "Lunch",
            "isDisabled" : false
          },
          {
            "name" : "Made in Abyss",
            "isDisabled" : false
          },
          {
            "name" : "Masahiro Sakurai",
            "isDisabled" : false
          },
          {
            "name" : "Mascots",
            "isDisabled" : false
          },
          {
            "name" : "Matthew Berry",
            "isDisabled" : false
          },
          {
            "name" : "Mega Man",
            "isDisabled" : false
          },
          {
            "name" : "Microchip Technology",
            "isDisabled" : false
          },
          {
            "name" : "Microcontrollers",
            "isDisabled" : false
          },
          {
            "name" : "Mirai Akari",
            "isDisabled" : false
          },
          {
            "name" : "Miss Kobayashi's Dragon Maid",
            "isDisabled" : false
          },
          {
            "name" : "MkLeo",
            "isDisabled" : false
          },
          {
            "name" : "MultiVersus",
            "isDisabled" : false
          },
          {
            "name" : "Multiplayer games",
            "isDisabled" : false
          },
          {
            "name" : "MythBusters",
            "isDisabled" : false
          },
          {
            "name" : "Netflix",
            "isDisabled" : false
          },
          {
            "name" : "News",
            "isDisabled" : false
          },
          {
            "name" : "News outlets",
            "isDisabled" : false
          },
          {
            "name" : "Nickelodeon All-Star Brawl",
            "isDisabled" : false
          },
          {
            "name" : "Niel",
            "isDisabled" : false
          },
          {
            "name" : "Online gaming",
            "isDisabled" : false
          },
          {
            "name" : "Osamake",
            "isDisabled" : false
          },
          {
            "name" : "Pac-Man",
            "isDisabled" : false
          },
          {
            "name" : "Patreon",
            "isDisabled" : false
          },
          {
            "name" : "Physics",
            "isDisabled" : false
          },
          {
            "name" : "Platformers",
            "isDisabled" : false
          },
          {
            "name" : "PlayStation",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts",
            "isDisabled" : false
          },
          {
            "name" : "Police in a Pod",
            "isDisabled" : false
          },
          {
            "name" : "Political events",
            "isDisabled" : false
          },
          {
            "name" : "Political figures",
            "isDisabled" : false
          },
          {
            "name" : "Political issues",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Princess Connect",
            "isDisabled" : false
          },
          {
            "name" : "Ranking of Kings",
            "isDisabled" : false
          },
          {
            "name" : "Raspberry Pi",
            "isDisabled" : false
          },
          {
            "name" : "Reddit",
            "isDisabled" : false
          },
          {
            "name" : "Remake our Life",
            "isDisabled" : false
          },
          {
            "name" : "Reol",
            "isDisabled" : false
          },
          {
            "name" : "Retail industry",
            "isDisabled" : false
          },
          {
            "name" : "Rhythm games",
            "isDisabled" : false
          },
          {
            "name" : "Robotics",
            "isDisabled" : false
          },
          {
            "name" : "Roger Craig Smith",
            "isDisabled" : false
          },
          {
            "name" : "Roleplaying games",
            "isDisabled" : false
          },
          {
            "name" : "Root",
            "isDisabled" : false
          },
          {
            "name" : "Ryan Reynolds",
            "isDisabled" : false
          },
          {
            "name" : "S&P 500",
            "isDisabled" : false
          },
          {
            "name" : "SHOW BY ROCK!",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi & fantasy",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi and fantasy",
            "isDisabled" : false
          },
          {
            "name" : "Science news",
            "isDisabled" : false
          },
          {
            "name" : "Scorpio",
            "isDisabled" : false
          },
          {
            "name" : "Selection Project",
            "isDisabled" : false
          },
          {
            "name" : "Sesame Street",
            "isDisabled" : false
          },
          {
            "name" : "Shinya Arino",
            "isDisabled" : false
          },
          {
            "name" : "Shoes",
            "isDisabled" : false
          },
          {
            "name" : "Shooting games",
            "isDisabled" : false
          },
          {
            "name" : "Show by Rock!!",
            "isDisabled" : false
          },
          {
            "name" : "Siro",
            "isDisabled" : false
          },
          {
            "name" : "Sky: Children of the Light",
            "isDisabled" : false
          },
          {
            "name" : "Smart technology",
            "isDisabled" : false
          },
          {
            "name" : "Sneakers",
            "isDisabled" : false
          },
          {
            "name" : "Sonic Mania",
            "isDisabled" : false
          },
          {
            "name" : "Space and astronomy",
            "isDisabled" : false
          },
          {
            "name" : "Sports events",
            "isDisabled" : false
          },
          {
            "name" : "Spotify",
            "isDisabled" : false
          },
          {
            "name" : "Square Enix",
            "isDisabled" : false
          },
          {
            "name" : "Starlink",
            "isDisabled" : false
          },
          {
            "name" : "Steam",
            "isDisabled" : false
          },
          {
            "name" : "Steam Deck",
            "isDisabled" : false
          },
          {
            "name" : "Stop motion animation",
            "isDisabled" : false
          },
          {
            "name" : "Summit1G",
            "isDisabled" : false
          },
          {
            "name" : "Super Smash Bros.",
            "isDisabled" : false
          },
          {
            "name" : "Superstores",
            "isDisabled" : false
          },
          {
            "name" : "Survival games",
            "isDisabled" : false
          },
          {
            "name" : "T-Mobile",
            "isDisabled" : false
          },
          {
            "name" : "THE IDOLM@STER",
            "isDisabled" : false
          },
          {
            "name" : "TOMORROW X TOGETHER",
            "isDisabled" : false
          },
          {
            "name" : "Tech news",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Television networks",
            "isDisabled" : false
          },
          {
            "name" : "Tetris",
            "isDisabled" : false
          },
          {
            "name" : "The Journey of Elaina",
            "isDisabled" : false
          },
          {
            "name" : "To Love Ru",
            "isDisabled" : false
          },
          {
            "name" : "Tokyo Game Show",
            "isDisabled" : false
          },
          {
            "name" : "Touhou Project",
            "isDisabled" : false
          },
          {
            "name" : "Twitter",
            "isDisabled" : false
          },
          {
            "name" : "US national news",
            "isDisabled" : false
          },
          {
            "name" : "Uma Musume",
            "isDisabled" : false
          },
          {
            "name" : "United States political events",
            "isDisabled" : false
          },
          {
            "name" : "United States political figures",
            "isDisabled" : false
          },
          {
            "name" : "United States politics",
            "isDisabled" : false
          },
          {
            "name" : "Utaite",
            "isDisabled" : false
          },
          {
            "name" : "Voice of Cards",
            "isDisabled" : false
          },
          {
            "name" : "WarioWare",
            "isDisabled" : false
          },
          {
            "name" : "Watches",
            "isDisabled" : false
          },
          {
            "name" : "Weather",
            "isDisabled" : false
          },
          {
            "name" : "Will Ferrell",
            "isDisabled" : false
          },
          {
            "name" : "Work from home",
            "isDisabled" : false
          },
          {
            "name" : "Writing",
            "isDisabled" : false
          },
          {
            "name" : "Yassuo",
            "isDisabled" : false
          },
          {
            "name" : "eBay",
            "isDisabled" : false
          },
          {
            "name" : "eCommerce industry",
            "isDisabled" : false
          },
          {
            "name" : "hololive",
            "isDisabled" : false
          },
          {
            "name" : "pixiv (ピクシブ)",
            "isDisabled" : false
          },
          {
            "name" : "高専ロボコン",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [
            "@GRDSMN_GLOBAL",
            "@LinkedIn",
            "@McDoCanada",
            "@McDonaldsCanada",
            "@RobinhoodApp",
            "@StarbucksCanada",
            "@Tinder_Japan",
            "@Uber",
            "@duolingo",
            "@eToro",
            "@foodpandaPH",
            "@gopayindonesia",
            "@rakutenapp",
            "@summonerswarapp",
            "@tinderbrasil",
            "@AMAEdHub",
            "@Azure",
            "@BCG",
            "@BSSportsbook",
            "@BestBuy",
            "@Betterment",
            "@BoonsMedia",
            "@BusinessInsider",
            "@CMEActiveTrader",
            "@CMEGroup",
            "@Chase",
            "@CityNational",
            "@DAMch_Official",
            "@DollarGeneral",
            "@Drive_pedia",
            "@Dropbox",
            "@EducativeInc",
            "@Energizer",
            "@FamilyFeudABC",
            "@ForeignPolicy",
            "@FortuneMagazine",
            "@FrontierCorp",
            "@FrontiersIn",
            "@HBO",
            "@Hellmanns",
            "@HomeDepot",
            "@IBM",
            "@IllinoisLottery",
            "@JCB_CARD",
            "@KinguinNet",
            "@Lenovo_in",
            "@Lexus",
            "@LibraryLantern",
            "@LogRocket",
            "@Lowes",
            "@LumixUK",
            "@MSFTGameDev",
            "@NintendoAmerica",
            "@NintendoCanada",
            "@NordVPN",
            "@OneOfNFT",
            "@OnyxCollective",
            "@PanasonicUK",
            "@ParentsDome",
            "@PartsUnknownCNN",
            "@PayPal",
            "@PayPalUK",
            "@Prusa3D",
            "@RapCaviar",
            "@ReasonableHulu",
            "@SAPANZ",
            "@SHOP_KAGOME",
            "@SamsungCanada",
            "@SlackHQ",
            "@Snapchat",
            "@SouthwestAir",
            "@Spotify",
            "@SpotifyARG",
            "@SpotifyAU",
            "@SpotifyAfrica",
            "@SpotifyArabia",
            "@SpotifyBrasil",
            "@SpotifyCanada",
            "@SpotifyChile",
            "@SpotifyColombia",
            "@SpotifyDE",
            "@SpotifyHK",
            "@SpotifyID",
            "@SpotifyItaly",
            "@SpotifyJP",
            "@SpotifyKR",
            "@SpotifyKSA",
            "@SpotifyKpop",
            "@SpotifyMY",
            "@SpotifyMexico",
            "@SpotifyPoland",
            "@SpotifySG",
            "@SpotifySpain",
            "@SpotifyTurkiye",
            "@SpotifyUK",
            "@SpotifyVietnam",
            "@Spotify_PH",
            "@Spotify_TH",
            "@T2Interactive",
            "@T2InteractiveEU",
            "@T2InteractiveUS",
            "@ThisFoolHulu",
            "@TwitterBlue",
            "@TwitterSafety",
            "@USPS",
            "@UberEats",
            "@Ubisoft",
            "@UniFirst_Corp",
            "@VICE",
            "@VelaEdFund",
            "@VerizonBusiness",
            "@Viveport",
            "@WSJ",
            "@WaltDisneyWorld",
            "@WellfoundHQ",
            "@WorldBank",
            "@Zoom",
            "@astepro_us",
            "@beincrypto",
            "@business",
            "@digikey",
            "@eaglennsworld",
            "@fiverr",
            "@formlabs",
            "@guardian",
            "@hbomax",
            "@hulu",
            "@intel",
            "@kardashianshulu",
            "@kroger",
            "@lendistry",
            "@nixplaycloud",
            "@on_running",
            "@pr_canadel",
            "@redbubble",
            "@rockstarenergy",
            "@sega_pso2",
            "@shonenjump",
            "@skio_official",
            "@spotifyfrance",
            "@spotifyindia",
            "@spotifypodcasts",
            "@spotifytaiwan",
            "@startefacts_",
            "@technics",
            "@theiwise1",
            "@tmg_social",
            "@toptal",
            "@turingcom",
            "@unitygames",
            "@verge",
            "@vivino",
            "@voxsup",
            "@washingtonpost"
          ],
          "advertisers" : [
            "@Azure",
            "@BestBuy",
            "@CMEActiveTrader",
            "@CMEGroup",
            "@DAMch_Official",
            "@Dropbox",
            "@FamilyFeudABC",
            "@FrontierCorp",
            "@Lenovo_in",
            "@LumixUK",
            "@MSFTGameDev",
            "@NintendoAmerica",
            "@NintendoCanada",
            "@OnyxCollective",
            "@PanasonicUK",
            "@PayPal",
            "@RapCaviar",
            "@ReasonableHulu",
            "@SHOP_KAGOME",
            "@Snapchat",
            "@Spotify",
            "@SpotifyARG",
            "@SpotifyAU",
            "@SpotifyAfrica",
            "@SpotifyArabia",
            "@SpotifyBrasil",
            "@SpotifyCanada",
            "@SpotifyChile",
            "@SpotifyColombia",
            "@SpotifyDE",
            "@SpotifyHK",
            "@SpotifyID",
            "@SpotifyItaly",
            "@SpotifyJP",
            "@SpotifyKR",
            "@SpotifyKSA",
            "@SpotifyKpop",
            "@SpotifyMY",
            "@SpotifyMexico",
            "@SpotifyPoland",
            "@SpotifySG",
            "@SpotifySpain",
            "@SpotifyTurkiye",
            "@SpotifyUK",
            "@SpotifyVietnam",
            "@Spotify_PH",
            "@Spotify_TH",
            "@ThisFoolHulu",
            "@TwitterBlue",
            "@TwitterSafety",
            "@hulu",
            "@kardashianshulu",
            "@nixplaycloud",
            "@pr_canadel",
            "@sega_pso2",
            "@skio_official",
            "@spotifyfrance",
            "@spotifyindia",
            "@spotifypodcasts",
            "@spotifytaiwan",
            "@technics",
            "@turingcom",
            "@vivino"
          ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "239"
        },
        "shows" : [
          "A League of Their Own",
          "Akira",
          "Back to the Future",
          "Battle Bots",
          "BattleBots",
          "Black Panther",
          "Black Panther 2 ",
          "Blade Runner",
          "CFL Football",
          "Catfish: The TV Show",
          "College Football",
          "Conan",
          "Devs",
          "Doctor Who",
          "Don",
          "Everything Everywhere All At Once",
          "Face the Nation",
          "Fate/Apocrypha",
          "Flash",
          "For All Mankind",
          "Formula One Racing",
          "Foundation",
          "Futebol NFL",
          "Fórmula 1",
          "Fútbol Americano de la NFL",
          "Fútbol Mexicano (La Liga MX)",
          "Halt and Catch Fire",
          "Hannibal",
          "Indiana Jones",
          "Industry",
          "Lendas do Amanhã",
          "Live: NBA Basketball",
          "Live: The Masters PGA Tour Golf",
          "Lust",
          "MLB Baseball",
          "MLS Soccer",
          "Modern Family",
          "Ms. Marvel",
          "MythBusters",
          "NBA Basketball",
          "NFL Football",
          "NHL Hockey",
          "Obi-Wan Kenobi",
          "Os Simpsons",
          "PUI PUI モルカー",
          "Planet Earth",
          "Premier League",
          "Project Runway",
          "Pulp Fiction",
          "SHOW BY ROCK!",
          "Sesame Street",
          "Seven Worlds, One Planet",
          "She-Hulk: Attorney at Law",
          "Sing 2",
          "South Park",
          "Squid Game",
          "Squid Game: The Challenge",
          "Star Trek: Discovery",
          "Star Trek: Lower Decks",
          "Star Trek: Strange New Worlds",
          "Stranger Things",
          "Stranger Things (Netflix)",
          "The Batman",
          "The Book of Boba Fett",
          "The Lord of the Rings: The Rings of Power",
          "The Mandalorian",
          "The Peripheral",
          "The Simpsons",
          "The Wizard of Oz",
          "The X-Files",
          "Top of the Pops",
          "Twin Peaks",
          "Twin Peaks: The Return",
          "この素晴らしい世界に祝福を!",
          "アイドルマスター",
          "ザ・タイムショック",
          "ヘボット!",
          "モブサイコ100（アニメ）",
          "惑星のさみだれ"
        ]
      },
      "locationHistory" : [
        "Brooklyn, NY, USA",
        "Irvington, NJ, USA"
      ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]