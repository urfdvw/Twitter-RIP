window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "SupplyFrame, Inc",
        "url" : "http://www.supplyframe.com/",
        "privacyPolicyUrl" : "https://hackaday.io/privacy-policy",
        "termsAndConditionsUrl" : "https://hackaday.io/tos"
      },
      "name" : "Hackaday.io",
      "description" : "Hackaday.io is a platform for people who like to hack things for the better.",
      "permissions" : [
        "read",
        "write",
        "emailaddress"
      ],
      "approvedAt" : "2022-06-28T21:29:20.000Z",
      "id" : "12348085"
    }
  }
]