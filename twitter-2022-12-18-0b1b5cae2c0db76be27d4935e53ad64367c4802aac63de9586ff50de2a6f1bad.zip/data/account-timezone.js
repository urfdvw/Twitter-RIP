window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1450661638009405445"
    }
  }
]