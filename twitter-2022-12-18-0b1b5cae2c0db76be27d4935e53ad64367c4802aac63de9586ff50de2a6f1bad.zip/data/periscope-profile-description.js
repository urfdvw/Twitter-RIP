window.YTD.periscope_profile_description.part0 = [
  {
    "periscopeProfileDescription" : {
      "bio" : "I am the author of the CircuitPython Online IDE. I will post updates about the IDE and Cpy related stuff here (in English). 中文 Cpy 视频教程也会发在这里"
    }
  }
]