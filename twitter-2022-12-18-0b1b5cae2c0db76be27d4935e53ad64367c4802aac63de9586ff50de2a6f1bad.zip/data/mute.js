window.YTD.mute.part0 = [
  {
    "muting" : {
      "accountId" : "1372887446669647875",
      "userLink" : "https://twitter.com/intent/user?user_id=1372887446669647875"
    }
  },
  {
    "muting" : {
      "accountId" : "17484680",
      "userLink" : "https://twitter.com/intent/user?user_id=17484680"
    }
  },
  {
    "muting" : {
      "accountId" : "1541751331018653696",
      "userLink" : "https://twitter.com/intent/user?user_id=1541751331018653696"
    }
  },
  {
    "muting" : {
      "accountId" : "593425336",
      "userLink" : "https://twitter.com/intent/user?user_id=593425336"
    }
  },
  {
    "muting" : {
      "accountId" : "847527486552276992",
      "userLink" : "https://twitter.com/intent/user?user_id=847527486552276992"
    }
  },
  {
    "muting" : {
      "accountId" : "3146752729",
      "userLink" : "https://twitter.com/intent/user?user_id=3146752729"
    }
  },
  {
    "muting" : {
      "accountId" : "232680302",
      "userLink" : "https://twitter.com/intent/user?user_id=232680302"
    }
  },
  {
    "muting" : {
      "accountId" : "15699469",
      "userLink" : "https://twitter.com/intent/user?user_id=15699469"
    }
  },
  {
    "muting" : {
      "accountId" : "1047329053492039680",
      "userLink" : "https://twitter.com/intent/user?user_id=1047329053492039680"
    }
  },
  {
    "muting" : {
      "accountId" : "1361663216619835398",
      "userLink" : "https://twitter.com/intent/user?user_id=1361663216619835398"
    }
  },
  {
    "muting" : {
      "accountId" : "1663172653",
      "userLink" : "https://twitter.com/intent/user?user_id=1663172653"
    }
  },
  {
    "muting" : {
      "accountId" : "939091",
      "userLink" : "https://twitter.com/intent/user?user_id=939091"
    }
  },
  {
    "muting" : {
      "accountId" : "4898627980",
      "userLink" : "https://twitter.com/intent/user?user_id=4898627980"
    }
  },
  {
    "muting" : {
      "accountId" : "46822887",
      "userLink" : "https://twitter.com/intent/user?user_id=46822887"
    }
  },
  {
    "muting" : {
      "accountId" : "3562121415",
      "userLink" : "https://twitter.com/intent/user?user_id=3562121415"
    }
  },
  {
    "muting" : {
      "accountId" : "22529181",
      "userLink" : "https://twitter.com/intent/user?user_id=22529181"
    }
  },
  {
    "muting" : {
      "accountId" : "759459947344175104",
      "userLink" : "https://twitter.com/intent/user?user_id=759459947344175104"
    }
  },
  {
    "muting" : {
      "accountId" : "1016059981907386368",
      "userLink" : "https://twitter.com/intent/user?user_id=1016059981907386368"
    }
  },
  {
    "muting" : {
      "accountId" : "1546497037117579264",
      "userLink" : "https://twitter.com/intent/user?user_id=1546497037117579264"
    }
  },
  {
    "muting" : {
      "accountId" : "1349149096909668363",
      "userLink" : "https://twitter.com/intent/user?user_id=1349149096909668363"
    }
  },
  {
    "muting" : {
      "accountId" : "965774983527043072",
      "userLink" : "https://twitter.com/intent/user?user_id=965774983527043072"
    }
  },
  {
    "muting" : {
      "accountId" : "1496380248442691588",
      "userLink" : "https://twitter.com/intent/user?user_id=1496380248442691588"
    }
  },
  {
    "muting" : {
      "accountId" : "29508496",
      "userLink" : "https://twitter.com/intent/user?user_id=29508496"
    }
  },
  {
    "muting" : {
      "accountId" : "1499601936697335810",
      "userLink" : "https://twitter.com/intent/user?user_id=1499601936697335810"
    }
  },
  {
    "muting" : {
      "accountId" : "1510547267727597571",
      "userLink" : "https://twitter.com/intent/user?user_id=1510547267727597571"
    }
  },
  {
    "muting" : {
      "accountId" : "33773592",
      "userLink" : "https://twitter.com/intent/user?user_id=33773592"
    }
  },
  {
    "muting" : {
      "accountId" : "44196397",
      "userLink" : "https://twitter.com/intent/user?user_id=44196397"
    }
  },
  {
    "muting" : {
      "accountId" : "2446221907",
      "userLink" : "https://twitter.com/intent/user?user_id=2446221907"
    }
  },
  {
    "muting" : {
      "accountId" : "2201528492",
      "userLink" : "https://twitter.com/intent/user?user_id=2201528492"
    }
  },
  {
    "muting" : {
      "accountId" : "1262827536284651520",
      "userLink" : "https://twitter.com/intent/user?user_id=1262827536284651520"
    }
  },
  {
    "muting" : {
      "accountId" : "14444413",
      "userLink" : "https://twitter.com/intent/user?user_id=14444413"
    }
  },
  {
    "muting" : {
      "accountId" : "1064296043855167493",
      "userLink" : "https://twitter.com/intent/user?user_id=1064296043855167493"
    }
  },
  {
    "muting" : {
      "accountId" : "1128730872163852288",
      "userLink" : "https://twitter.com/intent/user?user_id=1128730872163852288"
    }
  },
  {
    "muting" : {
      "accountId" : "15778803",
      "userLink" : "https://twitter.com/intent/user?user_id=15778803"
    }
  },
  {
    "muting" : {
      "accountId" : "1527252073879945216",
      "userLink" : "https://twitter.com/intent/user?user_id=1527252073879945216"
    }
  },
  {
    "muting" : {
      "accountId" : "1004140468647575553",
      "userLink" : "https://twitter.com/intent/user?user_id=1004140468647575553"
    }
  },
  {
    "muting" : {
      "accountId" : "1175793589118308352",
      "userLink" : "https://twitter.com/intent/user?user_id=1175793589118308352"
    }
  },
  {
    "muting" : {
      "accountId" : "494287469",
      "userLink" : "https://twitter.com/intent/user?user_id=494287469"
    }
  },
  {
    "muting" : {
      "accountId" : "707136806",
      "userLink" : "https://twitter.com/intent/user?user_id=707136806"
    }
  },
  {
    "muting" : {
      "accountId" : "1263555193951657984",
      "userLink" : "https://twitter.com/intent/user?user_id=1263555193951657984"
    }
  },
  {
    "muting" : {
      "accountId" : "3252001501",
      "userLink" : "https://twitter.com/intent/user?user_id=3252001501"
    }
  },
  {
    "muting" : {
      "accountId" : "26988628",
      "userLink" : "https://twitter.com/intent/user?user_id=26988628"
    }
  },
  {
    "muting" : {
      "accountId" : "164833319",
      "userLink" : "https://twitter.com/intent/user?user_id=164833319"
    }
  }
]