window.YTD.following.part0 = [
  {
    "following" : {
      "accountId" : "2574260239",
      "userLink" : "https://twitter.com/intent/user?user_id=2574260239"
    }
  },
  {
    "following" : {
      "accountId" : "28542415",
      "userLink" : "https://twitter.com/intent/user?user_id=28542415"
    }
  },
  {
    "following" : {
      "accountId" : "363657912",
      "userLink" : "https://twitter.com/intent/user?user_id=363657912"
    }
  },
  {
    "following" : {
      "accountId" : "17346756",
      "userLink" : "https://twitter.com/intent/user?user_id=17346756"
    }
  },
  {
    "following" : {
      "accountId" : "1577413597831237636",
      "userLink" : "https://twitter.com/intent/user?user_id=1577413597831237636"
    }
  },
  {
    "following" : {
      "accountId" : "2445281202",
      "userLink" : "https://twitter.com/intent/user?user_id=2445281202"
    }
  },
  {
    "following" : {
      "accountId" : "17296531",
      "userLink" : "https://twitter.com/intent/user?user_id=17296531"
    }
  },
  {
    "following" : {
      "accountId" : "3479427252",
      "userLink" : "https://twitter.com/intent/user?user_id=3479427252"
    }
  },
  {
    "following" : {
      "accountId" : "534421496",
      "userLink" : "https://twitter.com/intent/user?user_id=534421496"
    }
  },
  {
    "following" : {
      "accountId" : "909696417375096832",
      "userLink" : "https://twitter.com/intent/user?user_id=909696417375096832"
    }
  },
  {
    "following" : {
      "accountId" : "1245561210424213505",
      "userLink" : "https://twitter.com/intent/user?user_id=1245561210424213505"
    }
  },
  {
    "following" : {
      "accountId" : "19429480",
      "userLink" : "https://twitter.com/intent/user?user_id=19429480"
    }
  },
  {
    "following" : {
      "accountId" : "109322200",
      "userLink" : "https://twitter.com/intent/user?user_id=109322200"
    }
  },
  {
    "following" : {
      "accountId" : "131508488",
      "userLink" : "https://twitter.com/intent/user?user_id=131508488"
    }
  },
  {
    "following" : {
      "accountId" : "16842712",
      "userLink" : "https://twitter.com/intent/user?user_id=16842712"
    }
  },
  {
    "following" : {
      "accountId" : "770326714333405184",
      "userLink" : "https://twitter.com/intent/user?user_id=770326714333405184"
    }
  },
  {
    "following" : {
      "accountId" : "1346316379939606528",
      "userLink" : "https://twitter.com/intent/user?user_id=1346316379939606528"
    }
  },
  {
    "following" : {
      "accountId" : "1476575174593892355",
      "userLink" : "https://twitter.com/intent/user?user_id=1476575174593892355"
    }
  },
  {
    "following" : {
      "accountId" : "1573094455426654211",
      "userLink" : "https://twitter.com/intent/user?user_id=1573094455426654211"
    }
  },
  {
    "following" : {
      "accountId" : "1102246346722021378",
      "userLink" : "https://twitter.com/intent/user?user_id=1102246346722021378"
    }
  },
  {
    "following" : {
      "accountId" : "745232190733189120",
      "userLink" : "https://twitter.com/intent/user?user_id=745232190733189120"
    }
  },
  {
    "following" : {
      "accountId" : "3193354282",
      "userLink" : "https://twitter.com/intent/user?user_id=3193354282"
    }
  },
  {
    "following" : {
      "accountId" : "3233484298",
      "userLink" : "https://twitter.com/intent/user?user_id=3233484298"
    }
  },
  {
    "following" : {
      "accountId" : "40720843",
      "userLink" : "https://twitter.com/intent/user?user_id=40720843"
    }
  },
  {
    "following" : {
      "accountId" : "684143",
      "userLink" : "https://twitter.com/intent/user?user_id=684143"
    }
  },
  {
    "following" : {
      "accountId" : "1339490167451574272",
      "userLink" : "https://twitter.com/intent/user?user_id=1339490167451574272"
    }
  },
  {
    "following" : {
      "accountId" : "1559759744759656448",
      "userLink" : "https://twitter.com/intent/user?user_id=1559759744759656448"
    }
  },
  {
    "following" : {
      "accountId" : "1518308037592850432",
      "userLink" : "https://twitter.com/intent/user?user_id=1518308037592850432"
    }
  },
  {
    "following" : {
      "accountId" : "1222262234631606274",
      "userLink" : "https://twitter.com/intent/user?user_id=1222262234631606274"
    }
  },
  {
    "following" : {
      "accountId" : "280074645",
      "userLink" : "https://twitter.com/intent/user?user_id=280074645"
    }
  },
  {
    "following" : {
      "accountId" : "41765435",
      "userLink" : "https://twitter.com/intent/user?user_id=41765435"
    }
  },
  {
    "following" : {
      "accountId" : "4557157036",
      "userLink" : "https://twitter.com/intent/user?user_id=4557157036"
    }
  },
  {
    "following" : {
      "accountId" : "366117716",
      "userLink" : "https://twitter.com/intent/user?user_id=366117716"
    }
  },
  {
    "following" : {
      "accountId" : "15699469",
      "userLink" : "https://twitter.com/intent/user?user_id=15699469"
    }
  },
  {
    "following" : {
      "accountId" : "1473686120",
      "userLink" : "https://twitter.com/intent/user?user_id=1473686120"
    }
  },
  {
    "following" : {
      "accountId" : "957972848714440704",
      "userLink" : "https://twitter.com/intent/user?user_id=957972848714440704"
    }
  },
  {
    "following" : {
      "accountId" : "1525854088277430272",
      "userLink" : "https://twitter.com/intent/user?user_id=1525854088277430272"
    }
  },
  {
    "following" : {
      "accountId" : "817417121743380480",
      "userLink" : "https://twitter.com/intent/user?user_id=817417121743380480"
    }
  },
  {
    "following" : {
      "accountId" : "638363",
      "userLink" : "https://twitter.com/intent/user?user_id=638363"
    }
  },
  {
    "following" : {
      "accountId" : "729169855",
      "userLink" : "https://twitter.com/intent/user?user_id=729169855"
    }
  },
  {
    "following" : {
      "accountId" : "913919833174982657",
      "userLink" : "https://twitter.com/intent/user?user_id=913919833174982657"
    }
  },
  {
    "following" : {
      "accountId" : "1339487819903856640",
      "userLink" : "https://twitter.com/intent/user?user_id=1339487819903856640"
    }
  },
  {
    "following" : {
      "accountId" : "241252878",
      "userLink" : "https://twitter.com/intent/user?user_id=241252878"
    }
  },
  {
    "following" : {
      "accountId" : "16288392",
      "userLink" : "https://twitter.com/intent/user?user_id=16288392"
    }
  },
  {
    "following" : {
      "accountId" : "1346140504073768966",
      "userLink" : "https://twitter.com/intent/user?user_id=1346140504073768966"
    }
  },
  {
    "following" : {
      "accountId" : "1306632375342755840",
      "userLink" : "https://twitter.com/intent/user?user_id=1306632375342755840"
    }
  },
  {
    "following" : {
      "accountId" : "15481850",
      "userLink" : "https://twitter.com/intent/user?user_id=15481850"
    }
  },
  {
    "following" : {
      "accountId" : "1340820002786725890",
      "userLink" : "https://twitter.com/intent/user?user_id=1340820002786725890"
    }
  },
  {
    "following" : {
      "accountId" : "258906098",
      "userLink" : "https://twitter.com/intent/user?user_id=258906098"
    }
  },
  {
    "following" : {
      "accountId" : "96962811",
      "userLink" : "https://twitter.com/intent/user?user_id=96962811"
    }
  },
  {
    "following" : {
      "accountId" : "38213",
      "userLink" : "https://twitter.com/intent/user?user_id=38213"
    }
  },
  {
    "following" : {
      "accountId" : "138475538",
      "userLink" : "https://twitter.com/intent/user?user_id=138475538"
    }
  },
  {
    "following" : {
      "accountId" : "1479807513356816384",
      "userLink" : "https://twitter.com/intent/user?user_id=1479807513356816384"
    }
  },
  {
    "following" : {
      "accountId" : "718826820938948608",
      "userLink" : "https://twitter.com/intent/user?user_id=718826820938948608"
    }
  },
  {
    "following" : {
      "accountId" : "892775671910486016",
      "userLink" : "https://twitter.com/intent/user?user_id=892775671910486016"
    }
  },
  {
    "following" : {
      "accountId" : "754617844227305472",
      "userLink" : "https://twitter.com/intent/user?user_id=754617844227305472"
    }
  },
  {
    "following" : {
      "accountId" : "1365658687847550982",
      "userLink" : "https://twitter.com/intent/user?user_id=1365658687847550982"
    }
  },
  {
    "following" : {
      "accountId" : "790440869379780608",
      "userLink" : "https://twitter.com/intent/user?user_id=790440869379780608"
    }
  },
  {
    "following" : {
      "accountId" : "1062392065240285185",
      "userLink" : "https://twitter.com/intent/user?user_id=1062392065240285185"
    }
  },
  {
    "following" : {
      "accountId" : "944651",
      "userLink" : "https://twitter.com/intent/user?user_id=944651"
    }
  },
  {
    "following" : {
      "accountId" : "1026112756733304833",
      "userLink" : "https://twitter.com/intent/user?user_id=1026112756733304833"
    }
  },
  {
    "following" : {
      "accountId" : "39478528",
      "userLink" : "https://twitter.com/intent/user?user_id=39478528"
    }
  },
  {
    "following" : {
      "accountId" : "1072885009818763264",
      "userLink" : "https://twitter.com/intent/user?user_id=1072885009818763264"
    }
  },
  {
    "following" : {
      "accountId" : "945137016642998272",
      "userLink" : "https://twitter.com/intent/user?user_id=945137016642998272"
    }
  },
  {
    "following" : {
      "accountId" : "2043381",
      "userLink" : "https://twitter.com/intent/user?user_id=2043381"
    }
  },
  {
    "following" : {
      "accountId" : "1183539479518146560",
      "userLink" : "https://twitter.com/intent/user?user_id=1183539479518146560"
    }
  },
  {
    "following" : {
      "accountId" : "4918794850",
      "userLink" : "https://twitter.com/intent/user?user_id=4918794850"
    }
  },
  {
    "following" : {
      "accountId" : "49555459",
      "userLink" : "https://twitter.com/intent/user?user_id=49555459"
    }
  },
  {
    "following" : {
      "accountId" : "2201055433",
      "userLink" : "https://twitter.com/intent/user?user_id=2201055433"
    }
  },
  {
    "following" : {
      "accountId" : "266400754",
      "userLink" : "https://twitter.com/intent/user?user_id=266400754"
    }
  },
  {
    "following" : {
      "accountId" : "17877351",
      "userLink" : "https://twitter.com/intent/user?user_id=17877351"
    }
  },
  {
    "following" : {
      "accountId" : "14607140",
      "userLink" : "https://twitter.com/intent/user?user_id=14607140"
    }
  },
  {
    "following" : {
      "accountId" : "2670064278",
      "userLink" : "https://twitter.com/intent/user?user_id=2670064278"
    }
  },
  {
    "following" : {
      "accountId" : "20731304",
      "userLink" : "https://twitter.com/intent/user?user_id=20731304"
    }
  },
  {
    "following" : {
      "accountId" : "3241668860",
      "userLink" : "https://twitter.com/intent/user?user_id=3241668860"
    }
  },
  {
    "following" : {
      "accountId" : "811605410293645313",
      "userLink" : "https://twitter.com/intent/user?user_id=811605410293645313"
    }
  }
]