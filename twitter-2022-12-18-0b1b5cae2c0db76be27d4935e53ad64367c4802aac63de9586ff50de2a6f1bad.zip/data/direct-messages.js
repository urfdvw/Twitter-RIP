window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "41765435-1450661638009405445",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "41765435",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Let me see if I can understand what is already there, and then maybe I can contribute small pieces.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1572274495452516363",
            "createdAt" : "2022-09-20T17:20:25.850Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "41765435",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Thank you for this explanation.\nI will probably need to catch up for a bit because I was using a different set of tools such as Ace.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1572274057328095236",
            "createdAt" : "2022-09-20T17:18:41.405Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1450661638009405445",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/WzRBopDqab",
                "expanded" : "https://learn.adafruit.com/getting-started-with-web-workflow-using-the-code-editor",
                "display" : "learn.adafruit.com/getting-starte…"
              },
              {
                "url" : "https://t.co/DCdmXJfjxj",
                "expanded" : "https://docs.circuitpython.org/en/latest/docs/workflows.html",
                "display" : "docs.circuitpython.org/en/latest/docs…"
              }
            ],
            "text" : "Hi. Here's a guide I wrote on the setup and usage of the editor: https://t.co/WzRBopDqab and here's some documentation on the workflows: https://t.co/DCdmXJfjxj. \nCurrently USB has not been completely implemented, which is why the button is grayed out, but I'm working on that at the moment.\nBLE is kinda buggy at the moment, but I need to test on some different systems besides my development system.\nAs for tools, I pretty much wrote it all in Vanilla JS , but it also makes use of the xterm, codemirror, jszip, and adafruit-ble-file-transfer components.\nProgram workflow is to basically load up the editor and when connecting, you choose a workflow which is subclassed under assets/js/workflows. The idea is to be able to switch between connection types depending on your need, but still be able to edit while not connected.\nWeb Workflow is the most complicated (but most complete) because it needs to be loaded from the device and the script assets/js/device.js does the magic of making it appear to load from the device. Current work can be transferred between different devices via hashtag, which works out well too.",
            "mediaUrls" : [ ],
            "senderId" : "41765435",
            "id" : "1572268973949087748",
            "createdAt" : "2022-09-20T16:58:29.450Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "41765435",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "As I understand, the goal here is to ungray the USB button. Am I correct?",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1572220238535475206",
            "createdAt" : "2022-09-20T13:44:50.005Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "41765435",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "If you have time could you please direct me to some document indicating the tools you used and a little bit of the workflow.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1572219862369374214",
            "createdAt" : "2022-09-20T13:43:20.308Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "41765435",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "As I read the code of code.circuitpython in github, it looks like there are some build process.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1572219671666884612",
            "createdAt" : "2022-09-20T13:42:34.842Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "41765435",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Melissa!",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1572219507048960004",
            "createdAt" : "2022-09-20T13:41:55.596Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "4918794850-1450661638009405445",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1450661638009405445",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oh no, no worries, I was just trying to help out. Your debug library work is fantastic",
            "mediaUrls" : [ ],
            "senderId" : "4918794850",
            "id" : "1483129809043664901",
            "createdAt" : "2022-01-17T17:31:16.384Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "4918794850",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Thanks for the spelling fix. Sorry I should have been more careful.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1483129525500325898",
            "createdAt" : "2022-01-17T17:30:08.783Z"
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1014021799359627265-1450661638009405445",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1450661638009405445",
            "reactions" : [
              {
                "senderId" : "1450661638009405445",
                "reactionKey" : "like",
                "eventId" : "1587256144187346945",
                "createdAt" : "2022-11-01T01:32:09.240Z"
              }
            ],
            "urls" : [ ],
            "text" : "I’ll be around whenever you’re ready and if you need a hand. I’ve been working on a few more libraries lately and might be a bit smarter in a week or two.",
            "mediaUrls" : [ ],
            "senderId" : "1014021799359627265",
            "id" : "1587256053955428356",
            "createdAt" : "2022-11-01T01:31:47.748Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1014021799359627265",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Thanks. Will let you know if any progress",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1587255463145623558",
            "createdAt" : "2022-11-01T01:29:26.881Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1450661638009405445",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oh, sorry to hear that. Take care of yourself. Hope you feel better soon.",
            "mediaUrls" : [ ],
            "senderId" : "1014021799359627265",
            "id" : "1587255308518592518",
            "createdAt" : "2022-11-01T01:28:50.009Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1014021799359627265",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Will try later when I feel better.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1587254503052550148",
            "createdAt" : "2022-11-01T01:25:37.981Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1014021799359627265",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I got COVID last week.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1587254386979475460",
            "createdAt" : "2022-11-01T01:25:10.304Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1014021799359627265",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sadly.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1587254275054395398",
            "createdAt" : "2022-11-01T01:24:43.620Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1014021799359627265",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sorry there were too many meetings yesterday. I didn't get a chance to open the computer. Will try tonight.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1585593327931604998",
            "createdAt" : "2022-10-27T11:24:42.964Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1450661638009405445",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "How's your library submittal coming along? Let me know if there's anything else I can do to help.",
            "mediaUrls" : [ ],
            "senderId" : "1014021799359627265",
            "id" : "1585511424767434758",
            "createdAt" : "2022-10-27T05:59:15.724Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1450661638009405445",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sorry -- had to take a break for dinner. I'm over in Discord now.",
            "mediaUrls" : [ ],
            "senderId" : "1014021799359627265",
            "id" : "1585096891120893956",
            "createdAt" : "2022-10-26T02:32:03.211Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1014021799359627265",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sorry, I would need to catch an early train tomorrow so will need to go to 🛏️ now. Thank you again for offering help. Will let you know if any progress or blocker.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1585091373857906692",
            "createdAt" : "2022-10-26T02:10:07.803Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1014021799359627265",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "If things are still not right. Can I pin you in the channels?",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1585090690417147908",
            "createdAt" : "2022-10-26T02:07:24.858Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1014021799359627265",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I will try everything from fresh tomorrow and see if I get things right.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1585089833978023940",
            "createdAt" : "2022-10-26T02:04:00.668Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1014021799359627265",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sorry I was mostly mumbling.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1585089537226809348",
            "createdAt" : "2022-10-26T02:02:49.902Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1014021799359627265",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Thanks for offering help.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1585089122594693127",
            "createdAt" : "2022-10-26T02:01:11.055Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1450661638009405445",
            "reactions" : [
              {
                "senderId" : "1450661638009405445",
                "reactionKey" : "like",
                "eventId" : "1585089063048077314",
                "createdAt" : "2022-10-26T02:00:56.829Z"
              }
            ],
            "urls" : [ ],
            "text" : "I leaned from many tries to get cookiecutter to work. I still have to change my local branch to 'main' and rename the published branch when using GitHub desktop.",
            "mediaUrls" : [ ],
            "senderId" : "1014021799359627265",
            "id" : "1585088003394994180",
            "createdAt" : "2022-10-26T01:56:44.223Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1450661638009405445",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Can we link up in the Adafruit Discord so you can show me the cookiecutter settings you used? My handle there is @CGrover. Is yours @River?",
            "mediaUrls" : [ ],
            "senderId" : "1014021799359627265",
            "id" : "1585087700889178122",
            "createdAt" : "2022-10-26T01:55:32.088Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1014021799359627265",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Read the doc complaining about not finding index.rst. I don't think it should exist anyway. I am building readme.rst.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1585086824703315974",
            "createdAt" : "2022-10-26T01:52:03.198Z"
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1014021799359627265",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "😔 literally nothing worked except cookie cutter. And I don't know whether the things I fed the cookie cutter make any sense.",
            "mediaUrls" : [ ],
            "senderId" : "1450661638009405445",
            "id" : "1585085886307475460",
            "createdAt" : "2022-10-26T01:48:19.456Z"
          }
        }
      ]
    }
  }
]