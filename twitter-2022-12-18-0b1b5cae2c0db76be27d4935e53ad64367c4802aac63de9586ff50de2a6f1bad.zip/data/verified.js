window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "1450661638009405445",
      "verified" : false
    }
  }
]